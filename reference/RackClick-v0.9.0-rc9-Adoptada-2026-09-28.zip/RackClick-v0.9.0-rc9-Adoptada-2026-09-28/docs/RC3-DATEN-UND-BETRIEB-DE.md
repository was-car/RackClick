# v0.9.0-rc3 – Infrastruktur und Portseiten

Stand: 26.09.2026. Kandidat, nicht übernommen. Ergänzung für Techniker.

## Bedienung
Systemhaus links anklicken und benennen. Infrastruktur verwalten öffnen. Kunde ist Pflicht; Standort, Gebäude und Raum sind optional. Ort hinzufügen speichert zunächst nur im Dialogentwurf. Racks zuordnen und mit Speichern übernehmen. Abbrechen/Escape verwirft den Entwurf. Belegte Orte können nicht gelöscht werden. Umbenennen aktualisiert zugeordnete Racks. Strg+Z/Y gilt nach Schließen des Dialogs; währenddessen werden globale Projektbefehle unterdrückt.
Speichern exportiert das gesamte Projekt mit allen Kunden. Dies ist eine Organisationsstruktur, kein Berechtigungsmodell und keine Mandantentrennung. Techniker bleibt projektweit.

## Daten und Rückweg
JSON-Version bleibt 0.8; zusätzliche optionale Metadaten:
- Projekt: rackclickSystemhaus (String, max. 80), rackclickLocations (Array).
- Rack: rackclickLocation mit client/site/building/room (Strings, max. 100, client nicht leer).
- Port: rackclickFace = front oder rear. Fehlend bedeutet schematische Automatik.
Die bestehende rackclick_ui_systemhaus-Präferenz dient nur als Fallback. Keine neue localStorage-Schlüssel. Autosave, Backups und Snapshots enthalten die Metadaten mit dem Projekt. Import prüft Typen atomar; Boot prüft beschädigte Metadaten vor dem Rendern und nutzt Wiederherstellung/Quarantäne.
Die ursprünglichen v0.8.6-Validatoren und das Save-Muster wurden mit einem angereicherten Projekt geprüft: Topologie und Metadaten bleiben erhalten. v0.8.6 zeigt die Zusatzdaten nicht an. Kein Versprechen für jede historische Teilimport-/Merge-Funktion. Für Rückweg immer vollständiges JSON und externe Kopie verwenden.

## Vorder- und Rückseite
Die Geräte ändern beim Umschalten nicht ihre vertikale Reihenfolge. Automatik: Server/NAS/Storage/UPS auf Rückseite, power-Ports hinten, andere vorn. Dies ist keine Herstellerzertifizierung. Portseiten einstellen erlaubt explizite Zuordnung. Eine Seite pro logischem Port; keine neuen Port-IDs. Rückseitige Gehäusedetails sind Illustration.
Durchgehendes Kabel verbindet zwei sichtbare Endpunkte. Gestrichelter Auslauf kennzeichnet den nicht sichtbaren Gegenpunkt (andere Seite, Rack oder eingeklapptes Gerät). Gegenpunkt und Kabelnotiz stehen im Portinspektor. Verbindungskarte öffnet die bestehende Bearbeitung.
Patchpanel-IDC und interne Durchgänge sind nicht modelliert. Leere Rückseiten werden als nicht dokumentiert angezeigt, statt Anschlussmöglichkeiten zu erfinden. Das separate Demoformat wird nicht importiert.

## Betrieb und QA
HTML lokal öffnen, keine Laufzeitinstallation. Vor Versionswechsel JSON exportieren, alten Browserpfad und Profil behalten. Eine aktive Registerkarte. Rückfall v0.8.6 unverändert; dessen CDN-Abhängigkeit bleibt bestehen.
Neue UI in DE/EN/ES. Automatische Chromium-Prüfungen und unabhängige gezielte Prüfung belegt. Firefox, reale Windows-/Ubuntu-Bedienung, Touch und vollständige 278-Zeilen-Parität sind offen. Bestehende ältere Dokumente im Paket sind historische Planungsunterlagen; diese Ergänzung und README bestimmen den rc3-Stand.

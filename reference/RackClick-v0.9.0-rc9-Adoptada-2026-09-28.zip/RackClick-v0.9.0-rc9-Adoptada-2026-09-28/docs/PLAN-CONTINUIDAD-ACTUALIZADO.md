# ADOPTADA · v0.9.0-rc9 · 28.09.2026

Confirmación expresa de Wascar. Archivo y hash exactos preservados. Véase ACTA-ADOPCION.md. Los estados de candidata en las entradas anteriores son históricos.

# Actualización 28.09.2026

Wascar reportó resultados satisfactorios de RC8 y una objeción visual a etiquetas en lote. RC9 atiende esa objeción y el indicador PoE amarillo. Siguiente: comprobar estos dos cambios y confirmar adopción del artefacto exacto; después retomar servidor, base de datos y permisos por grupos. La revisión lingüística profunda no fue realizada por decisión expresa. Nada de servidor queda cerrado por estas pruebas offline.

---

# RackClick · Plan de continuidad actualizado

Fecha del registro: 27 de septiembre de 2026. Documento de planificación; no constituye adopción ni resultado de pruebas.

## Dónde estamos

Wascar entregó un relato completo de su recorrido por los 57 casos de RC7. El registro distingue 24 resultados positivos reportados, 20 casos con observaciones, 11 parciales y dos no ejecutados: táctil físico y rescate condicionado. El recorrido ya no debe figurar genéricamente como «57 casos pendientes», pero tampoco como «57 aprobados».

La nueva información autoriza corregir y verificar en una candidata RC8, conservando la dirección visual aprobada. Los cambios, las pruebas técnicas y la aceptación del usuario mantienen estados separados. RC7 no queda adoptada por este documento y RC8 tampoco.

El piloto R3 permanece separado de la aplicación offline. Según el registro de continuidad, sus 25 pruebas en Windows siguen pendientes de evidencia final. El éxito histórico de la migración y arranque en Windows no sustituye ese resultado. Este documento no registra una nueva ejecución del piloto ni lo convierte en servidor definitivo.

## Orden de trabajo y puertas de salida

| Paso | Entrega | Responsable principal | Condición para avanzar |
|---|---|---|---|
| 1 | RC8: correcciones de integridad, interacción, legibilidad, reportes y manual | Desarrollo, ingeniería de redes y documentación | Cada cambio vinculado a un hallazgo; defecto reproducido cuando sea posible; evidencia antes/después; ninguna pérdida silenciosa |
| 2 | Regresión técnica y revisión independiente de RC8 | QA y revisor separado de implementación | Pruebas pertinentes en verde; sin P0/P1 abiertos del alcance offline; limitaciones y pendientes visibles; build, hashes y rollback verificables |
| 3 | QA dirigida de Wascar | Wascar con guía preparada por QA | Repetir los recorridos afectados y completar los casos parciales relevantes; conservar «no ejecutado» cuando falte dispositivo o escenario |
| 4 | Adopción offline y paquete final | Wascar confirma; release manager prepara | Confirmación expresa de Wascar sobre la candidata identificada; actualización documental y registro de versión adoptada |
| 5 | Contrato del servidor Windows | Arquitectura, seguridad, ingeniería de redes y PO | Modelo, API, importación, permisos, concurrencia y recuperación acordados; estimación por bloques; escenarios de aceptación definidos |
| 6 | Servidor mínimo verificable | Backend, operación y QA | Autenticación, DB, importación atómica, backup y restore; aislamiento por cliente en lectura y escritura; instalación de prueba documentada |
| 7 | GUI actual conectada a datos persistentes | Frontend/backend | La GUI aprobada lee y guarda mediante API; errores honestos; persistencia tras reinicio; paridad de operaciones incluidas en esta entrega |
| 8 | Edición concurrente y recuperación de conflictos | Backend, frontend y QA | Revisiones, idempotencia y transacciones en ambos extremos; un usuario no sobrescribe silenciosamente a otro; undo por operación compatible con concurrencia |
| 9 | Panel administrativo completo | Seguridad, backend y UX | Usuarios, grupos de usuarios, grupos de clientes, roles, ámbitos y permisos efectivos; revocación, sesiones y auditoría comprobadas |
| 10 | Servicio Windows y piloto operativo | Operación, QA y técnicos | Arranque como servicio, actualización/rollback, restauración en VM limpia, configuración y claves recuperables, piloto multiusuario y aceptación |
| Posterior | Linux, AD/OIDC y servidor MCP | Arquitectura y equipos correspondientes | Nuevos alcances y contratos específicos, respetando autorización por cliente y trazabilidad de operaciones |

La autorización, auditoría mínima y protección frente a conflictos necesarias para una operación se incorporan desde su primera entrega. Los pasos 8 y 9 completan y validan la experiencia multiusuario; no significan que los pasos anteriores permitan escritura desprotegida.

El contrato del servidor puede prepararse en papel mientras Wascar realiza su QA. La entrega de servidor como siguiente línea funcional comienza después de la adopción offline y de la puerta del contrato. No se declara una fecha de finalización mientras existan defectos sin reproducir o un alcance sin estimar.

## Alcance del contrato servidor

- Identidad estable de Systemhaus, cliente, sede, edificio, sala, rack, dispositivo y puerto; nombres editables separados de IDs.
- Propiedad y pertenencia de recursos, enlaces locales/cross-rack, eliminación explícita y transacciones completas.
- Usuarios que pertenecen a grupos; grupos con roles sobre clientes o grupos de clientes. Los grupos de usuarios y las colecciones de clientes son entidades distintas.
- Matriz de capacidades: leer, editar, conectar, borrar, importar, exportar y administrar. Una etiqueta «Technician» no sustituye permisos explícitos.
- API que autoriza cada recurso y cada escritura, incluida la descarga de originales, búsqueda, reportes y tareas diferidas. El frontend no es una frontera de seguridad.
- Contraseñas y recuperación mediante componentes de identidad contrastados, sesiones y transporte protegidos. Preparación para AD/OIDC sin fingir que ya está integrado.
- Importación y exportación con versión, validación, original preservado y tratamiento definido de incompatibilidades. El flujo de campo offline requiere manifiesto y resolución de retorno, no sustitución ciega de datos del servidor.
- Revisiones de entidades afectadas, idempotencia, conflictos explícitos y deshacer condicionado. Mover un dispositivo o conectar racks debe proteger todos los extremos implicados.
- Backup manual/automático en destino definido, retención y restauración comprobada. Archivo generado, copia verificada y restauración ensayada son estados diferentes.
- Matriz Windows explícita y verificable; versiones de runtime/DB, instalación, identidad del servicio, rutas de datos, logs, actualización y rollback.

## Gantt relativo, sin fechas ficticias

Los bloques muestran dependencias y posible solapamiento. No representan días ni semanas y no son una estimación de esfuerzo.

| Línea de trabajo | A: corrección | B: regresión | C: QA dirigida | D: adopción | E: contrato | F: servidor base | G: GUI persistida | H: concurrencia/admin | I: operación/piloto |
|---|---|---|---|---|---|---|---|---|---|
| RC8 y manual | Activo | Ajustes | Correcciones si aparecen | Publicación del paquete aceptado | — | — | — | — | — |
| QA independiente | Pruebas de fallos | Activo | Apoyo | Evidencia final | Revisión | Activo | Activo | Activo | Activo |
| Wascar | Observaciones | — | Activo | Confirmación | Decisiones necesarias | Prueba dirigida | Prueba dirigida | Roles y trabajo simultáneo | Aceptación del piloto |
| Diseño servidor | Preparación documental | Preparación documental | Preparación documental | — | Puerta de diseño | — | — | Ajustes de contrato | — |
| Backend/API/DB | — | — | — | — | Estimación | Activo | Integración | Activo | Correcciones |
| Frontend servidor | — | — | — | — | Contrato de UI | Preparación | Activo | Activo | Correcciones |
| Operación Windows | — | — | — | — | Diseño instalación/restore | Entorno de prueba | Verificación | Servicio y recuperación | Activo |
| Linux/AD/OIDC/MCP | Backlog | Backlog | Backlog | Backlog | Preparar extensibilidad | Backlog | Backlog | Backlog | Planificar siguiente entrega |

Si una puerta falla, el bloque correspondiente vuelve a corrección y regresión. El progreso del proyecto no se calcula contando casillas verdes sin distinguir su evidencia.

## Responsabilidades y continuidad

**Project manager/PO:** mantiene el registro de requisitos, alcance, prioridades, decisiones, dependencias y actas; asigna cada observación a un responsable y vincula la evidencia. Evita que una mejora visual se pierda o se convierta sin decisión en rediseño del modelo.

**Desarrollo y redes:** implementan cambios acotados y pruebas que demuestran el comportamiento esperado. Documentan incompatibilidades y límites de realismo sin borrar datos para hacer pasar las pruebas.

**QA independiente:** revisa cambios, ejecuta escenarios y distingue defecto, limitación del arnés, resultado no reproducido y prueba no ejecutada. Quien implementa no otorga por sí solo la aceptación final.

**Documentación/release:** actualiza manuales, capturas, procedimiento de instalación, changelog, hashes y rollback de cada candidata/adopción.

**Wascar:** valida los recorridos reales, ergonomía y necesidades del negocio; confirma expresamente la adopción. No necesita asumir la comprobación técnica del backend que corresponde al equipo.

Los agentes trabajan durante las sesiones autorizadas. No existe un agente que vigile el proyecto permanentemente entre conversaciones. La continuidad se apoya en archivos versionados y en su lectura al comenzar cada sesión, con autor, fecha, versión/hash y enlaces de evidencia.

## Estados que no deben mezclarse

| Estado | Qué significa |
|---|---|
| Reportado | Wascar o un revisor describe un comportamiento |
| Reproducido | Se consiguió repetirlo en una versión y entorno identificados |
| No reproducido | El escenario concreto no falló; se conserva salida y no se borra el reporte |
| Implementado | Hay un cambio de código o documentación, aún sin implicar aceptación |
| Verificado técnicamente | Las pruebas definidas se ejecutaron con evidencia suficiente para ese alcance |
| Revisado independientemente | Otro revisor contrastó cambio y evidencia |
| QA usuario pendiente/parcial | Falta o no es completo el recorrido de aceptación de Wascar |
| Diferido | Se conserva alcance, motivo y condición de retorno; no equivale a resuelto |
| Adoptado | Wascar confirmó la versión candidata identificada y se registró la decisión |

## Documentos maestros que se deben mantener

1. **PLAN-MAESTRO/plan de continuidad:** fases, dependencias, puertas, estado y siguiente acción.
2. **Registro de decisiones:** decisión, motivo, alternativas descartadas, autor y alcance temporal.
3. **Registro QA de Wascar:** caso estable, relato original, interpretación, versión probada, observaciones y resultado; conservar historial.
4. **Backlog único de hallazgos:** IDs W, ARQ, RED, SEC, MQ y GOV relacionados, prioridad, responsable, estado, prueba y decisión de cierre.
5. **Matriz de paridad:** función, handler/operación, caso automático, paso manual y estado por línea offline/servidor.
6. **Contrato de datos/API/permisos:** esquemas, invariantes, capacidades, ámbitos, errores, concurrencia y compatibilidad.
7. **Manuales visuales y técnicos:** comportamiento real, limitaciones, capturas con procedencia y funciones planificadas diferenciadas.
8. **Operación Windows:** instalación limpia, servicio, configuración, backup, restore, actualización, rollback y diagnóstico.
9. **Evidencias de QA/revisión:** comandos, navegador/SO, fixtures sintéticos, resultados, trazas y limitaciones; nunca incluir JSON privado del usuario en paquetes públicos.
10. **CHANGELOG y manifiesto de release:** versión/hash exactos, cambios, defectos abiertos, verificación y estado de adopción.
11. **Acta de sesión:** qué cambió, qué quedó pendiente, quién debe actuar y cuál es el siguiente bloque. Resumen de traspaso apoyado en rutas reales.

En este bloque se crearon el registro QA y la normalización de observaciones; este plan es su continuidad. La existencia del plan no significa que todas esas correcciones o todos los documentos del servidor estén terminados.

# QA dirigida RC8 · 20–30 minutos orientativos

Estado: todas las casillas pendientes de Wascar. Los resultados automáticos no rellenan esta hoja. Exportar datos antes de empezar.

## Checklist dirigido propuesto para Wascar después de RC8

No repetir57 casos enteros por rutina: equipo ejecuta regresión general. Propuesta de recorrido manual afectado:

1. Infraestructura con muchas ubicaciones: guardar/cancelar visibles, nombre/logo/técnico y selector manual/lista del rack.
2. Oscuro/claro y ventana estrecha: presets, estrella, inputs25–48 y lupa legibles.
3. Favoritos/plantillas arriba; crear preset propio y conservar tras F5.
4. Hover equipo y puertos local/cross/eléctrico muestra datos reales y notas, también tras renombrar.
5. PoE off/on conserva posición; lote5–14 solo modifica rango y suma PoE correcta.
6. Seleccionar origen y batch-disable: salir y volver a conectar sin quedar bloqueado; reserved aceptar/cancelar.
7. Doble clic en conectado: reconectar, cancelar y undo; libre mantiene etiqueta rápida.
8. Bulk25–48: previsualizar24 puertos concretos y resultado exacto.
9. CSV cliente/global y etiquetas lote: alcance correcto, ningún cliente ajeno. ImportaciónCSV 36 sigue prueba propia.
10. Informe cliente con logo/técnico; PDF moderno y PNG, impresión etiquetas.
11. Firefox caso 14 exacto: clic guardar, pérdida de foco controlada, confirmaciones, F5 e IDs/atributos persistentes.
12. Manual: importar/exportar notas, recuperación frente a nota malformada y PDF capítulo completo.

Los casos36/37/42 requieren fixtures de prueba adecuados. Las situaciones destructivas/corrupción52 las reproduce el equipo en perfiles descartables. Táctil físico50 queda explícitamente no ejecutado hasta disponer de dispositivo. La decisión de adopción no implica pruebas inexistentes.

> Historischer Stand rc2. Aktuelle Ergänzung: RC3-DATEN-UND-BETRIEB-DE.md.

# RackClick v0.9.0-rc2 — Technischer Nachtrag

Stand: 26.09.2026. Zielgruppe: Netzwerktechniker. Status: Testkandidat, nicht freigegeben.
Dieser Nachtrag ersetzt die abgenommenen v0.8.6-Handbücher nicht. Die vollständige Dokumentationsfreigabe gehört zur späteren v0.9.0-Abnahme.

## Start und Datenübernahme

ZIP in einen neuen Ordner entpacken. `RackClick-v0.9.0-rc2-Offline.html` im Browser öffnen. Keine Installation, kein lokaler Webserver und keine Netzwerkverbindung erforderlich. Für den ersten Test „Demo“ wählen. Für eigene Daten zuerst in v0.8.6 JSON exportieren und eine externe Kopie aufbewahren; danach die Kopie über Load/Laden öffnen.

Browserprofil, Dateipfad und Browser beeinflussen den Zugriff auf localStorage. Ein Projekt-JSON enthält keine Favoriten, Vorlagen oder Snapshots aus einem anderen Browserprofil. Bestehendes Profil nicht löschen. Eine Browser-Downloadmeldung ist kein Nachweis für ein erfolgreiches externes Backup: heruntergeladene Datei prüfen und getrennt aufbewahren.

## Bedienung

Links: Systemhausname, Projekt und vorhandene Racks. Der Name des Systemhauses ist in Settings editierbar. Die Navigation erfindet keine Kunden-, Gebäude- oder Raumdaten, die im JSON v0.8 fehlen.

Mitte: schematische Gerätefronten mit den tatsächlichen Port-IDs des Projekts. Rechts: Port-/Rackinspektor, Gerät hinzufügen und Verbindungsliste. Zwei freie Ports mit je einem Klick verbinden. Die vorgewählte Kabelfarbe hat Vorrang vor der automatischen Gruppenfarbe. Wattwerte sind dokumentierte Daten, keine Telemetrie.

Doppelklick auf einen freien Port öffnet die Label-Eingabe. Rechtsklick bzw. Shift+F10 öffnet Portaktionen. Reserved verlangt eine Bestätigung, disabled/faulty blockieren neue Verbindungen. Bestehende Verbindungen bleiben einsehbar. Die Checkboxen erlauben Mehrfachauswahl. Strg+Z/Y macht Änderungen rückgängig bzw. stellt sie wieder her; Strg+S exportiert JSON. Escape schließt zusätzlich den Verbindungsdialog und Bulk-Connect.

Front/Rear entspricht weiterhin der Legacy-Semantik. JSON v0.8 enthält keine verlässliche Zuordnung zu physischen Gerätevorder-/rückseiten. Beide Ansichten erhalten sämtliche Interfaces; keine Ports werden aufgrund einer optischen Vermutung entfernt. Der QR ist dekorativ. Für mehrere Browser-Tabs gibt es keine Schreibsperre: nur eine aktive Bearbeitungssitzung verwenden.

## Datenintegrität und Migration

Die ursprüngliche v0.8.6-JSX-Datei liegt unverändert in `src/`. Der Build prüft ihren vollständigen SHA-256 vor der Transformation. Neue Darstellungen nutzen die vorhandenen State- und Undo-Handler. JSON-Schemaversion bleibt 0.8. Unbekannte Zusatzattribute werden bei Remapping erhalten.

Zusätzlicher Präsentationsschlüssel: `rackclick_ui_systemhaus`, String, voreingestellter Systemhausname. Keine Kundendatenbank, keine Anmeldeinformationen. Der v0.8.6-Rescue-Bundle behält seine 13 Datenschlüssel; der neue UI-Präferenzschlüssel ist kein Projektdatum und nicht Teil dieses alten Bundles.

Beim Anhängen/Fusionieren werden alle IDs konsistent neu zugeordnet, einschließlich crossConns. Dateien werden vor dem Commit auf Struktur und Endpoint-Zugehörigkeit geprüft. Mehrere JSON-Dateien bilden eine atomare Importoperation. Ändert sich das offene Projekt während des Dateilesens, wird der Import abgebrochen. CSV mit mehrfach vorkommender Portnummer benötigt den Porttyp. Ambiguität, belegte oder gesperrte Ports verhindern den gesamten CSV-Import; cross-rack bleibt ein JSON-Transfer.

Boot, Quarantäne, abgesicherter Modus und ErrorBoundary stammen aus v0.8.6; die nicht abgenommene v0.8.7 ist nicht eingebaut. Das bedeutet auch: neue A2-Slot-Metadaten und mehrere Quarantäneepisoden werden hier nicht zugesichert.

## Build reproduzieren

Zum bloßen Öffnen sind diese Schritte nicht nötig. Für Entwickler:

1. Node.js mit npm bereitstellen. Getestete Node-Version steht in `evidence/environment.json`.
2. Im entpackten Projektordner `npm ci` ausführen. Netzwerkzugriff ist nur für diese Entwicklungsinstallation nötig; Versionsbindung über package-lock.json.
3. `npm run build` ausführen.
4. Ausgabe in `dist/` mit `evidence/build.json` vergleichen. Bei unveränderten Eingaben muss der SHA-256 gleich sein.
5. `npm run test:build` prüft manipulierte Quelle, Rollback, Version, Bibliothek, Fontmanifest, i18n und externes CSS. Fehlerhafte Builds dürfen keine veraltete Kandidaten-HTML stehen lassen.

Der Build bindet React 18.2.0, ReactDOM 18.2.0, html2canvas 1.4.1 und WOFF2-Schriften ein. JSX wird mit esbuild 0.25.10 vorab kompiliert. Keine Babel-Laufzeit. Quellen, Bibliotheken und Schriften werden über Hashes geprüft. Die Sprachprüfung umfasst 197 Core- und 42 neue Schlüssel; das ist **kein** Nachweis, dass sämtliche hartcodierten Legacy-Texte bereits übersetzt sind.

## Automatische Tests

Python mit Playwright installieren: `python -m pip install -r tests/requirements.txt`, danach `python -m playwright install chromium`. Unter Ubuntu heißt der Python-Aufruf gegebenenfalls `python3` und sollte in einer virtuellen Umgebung erfolgen. Anschließend `python tests/run_qa.py`.

Die Tests verwenden getrennte persistente Browserprofile und blockieren HTTP/HTTPS. Sie verändern weder produktive Browserprofile noch das Original-JSON. Pro Suite entsteht ein Protokoll in evidence. Ein optionaler eigener Chromium-Pfad wird über RACKCLICK_CHROMIUM gesetzt. Für die noch nicht ausgeführte Firefox-Prüfung sind Playwright Firefox und RACKCLICK_BROWSER=firefox nötig; die Unterstützung des Testpfads ist keine bestandene Browserfreigabe.

`tests/visual_smoke.mjs` benötigt zusätzlich Playwright für Node. Die beiliegenden Bildnachweise sind mit der in environment.json genannten Testumgebung erstellt. Die JavaScript-Testskripte unterstützen RACKCLICK_PLAYWRIGHT als Modulpfad.

## Freigabegrenzen und Rückfall

Ein unabhängiger Agent prüfte gezielt Code und Bedienwege; Berichte mit den jeweils getesteten Hashes liegen unter evidence/review. Die 278-zeilige Paritätsmatrix ist noch nicht einzeln zertifiziert. Firefox, reale Touchbedienung, alle Dialoge in allen Sprachen und vollständige Kontrast-/Überlappungsprüfung bleiben offen. Daher keine Produktivfreigabe und keine Veröffentlichung als stabile Version.

Bei Problemen Kandidat schließen, unveränderte v0.8.6 aus rollback öffnen und externe JSON-Kopie laden. Alte Browserdaten nicht löschen. Finale Abnahme ausschließlich durch Wascar nach eigenem QA.

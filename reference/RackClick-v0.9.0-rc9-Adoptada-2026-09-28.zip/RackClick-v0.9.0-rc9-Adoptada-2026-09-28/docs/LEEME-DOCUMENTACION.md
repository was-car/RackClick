# Documentación de la candidata RC8

La entrega visual actualizada es `RackClick-Manual-Visual-RC8.zip`, separada del producto. Incluye44 capítulos y57casos, notas importables/exportables, impresión por capítulo y apéndice con capturas RC8. Las254capturas originales mantienen su identidadRC7; no son pruebas realizadas de nuevo.

En este paquete: NOVEDADES-RC8-DE.md, CHECKLIST-DIRIGIDO-RC8.md, REGISTRO-QA-WASCAR.json, PLAN-CONTINUIDAD-ACTUALIZADO.md y ACTA-RC8.md son los documentos vigentes. Los manuales HTML y controles RC4–RC7 se conservan como referencias históricas, identificadas por sus títulos; las instrucciones RC8 prevalecen para funciones cambiadas.

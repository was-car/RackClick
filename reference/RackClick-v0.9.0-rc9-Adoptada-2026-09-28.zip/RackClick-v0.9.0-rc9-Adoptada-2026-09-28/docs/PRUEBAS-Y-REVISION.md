# Evidencias rc3
Artefacto final SHA-256: 24fdbf340b5b0460736337fd60ca6aafbd266b61f62a7975b7dc44af9e2a8a09.
Diez suites previas PASS en ejecución conjunta; nueva suite infraestructura PASS por separado sobre el mismo hash: 21 comprobaciones. run_qa.py incorpora ya las once para siguientes ejecuciones. qa-summary.json reúne ambas ejecuciones sin presentarlas como una sola.
Cambios de arnés: conteo de puertos como unión disjunta de frontal/trasera; orden solo de filas físicas (el DOM clásico oculto conserva su comportamiento legacy); espera tras recarga en perfil persistente; selector del botón frontal/trasera usa su icono estable; i18n-added.json es fixture histórica sin modificar. No se omiten aserciones de integridad.
Prueba de compatibilidad: ejecución de los validadores originales v0.8.6 y su patrón de Save con campos opcionales; no es recorrido E2E íntegro del navegador v0.8.6.
Pruebas negativas: siete mutaciones rechazadas; dos builds limpios iguales entre sí y al HTML entregado.
Visual: 18 combinaciones (EN/DE/ES × oscuro/claro × 1440/1024/390), seis vistas por combinación (proyecto, rack frontal, edición equipo, rack trasero, caras, infraestructura): 108 capturas. summary.json tiene 36 medidas: 18 viewport + 18 diálogo infraestructura. Sin overflow global en esa muestra; no certifica todo recorte/solapamiento/contraste ni todos los modales legacy.
Revisión independiente: probe.mjs sobre bfb6b5c7…, settings.mjs sobre hash final. P2 de undo Settings corregido y probado específicamente. No aprobación de adopción.
Entorno: Chromium 153 headless, Linux. Firefox, Windows/Ubuntu reales y táctil quedan abiertos. Diez suites anteriores cubren boot/autosave/snapshot/qa/v085/f2a1/connection_policy/integrated/pointer_stability/performance.

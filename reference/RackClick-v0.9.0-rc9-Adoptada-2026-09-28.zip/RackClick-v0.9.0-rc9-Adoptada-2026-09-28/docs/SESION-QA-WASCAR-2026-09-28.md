# RC8 · Sesión QA de Wascar · 28.09.2026

Fuente: relato directo del chat. No se inventan resultados ni se sustituye el registro anterior. El hash del archivo usado en su PC no se verificó en esta sesión.

| Caso | Estado | Evidencia reportada |
|---|---|---|
| 58 | OK reportado | Clientes, Systemhaus e infraestructura funcionan según la sesión. |
| 59 | OK reportado | Crear/editar/clonar rack y sugerencias de ubicación revisados. |
| 60 | OK reportado | Nuevo equipo, favorito y plantilla propia aparecen en sus grupos. No se atribuye una recarga adicional no descrita. |
| 61 | OK reportado | Tooltips de equipo y puerto conectado confirmados. |
| 62 | OK reportado | PoE individual y por rango encontrado; probó 10–20, apagado y encendido. |
| 63 | OK reportado para el defecto | Puerto 33 seleccionado; lote 31–35 Disabled elimina el bloqueo anterior. No se infiere repetición de todas las ramas Reserved/Faulty. |
| 64 | OK reportado | Reconexión por doble clic y elección de destino funcionan. No se infiere una repetición de todas las ramas Cancelar/Undo. |
| 65 | OK reportado | Origen/destino de Bulk y cambio frontal/trasera funcionan; no se presume cotejo individual de 24 enlaces. |
| 66 | Con observación visual | CSV global y cliente, logo e informe satisfactorios. Etiquetas en lote deben tener el diseño de la individual. Retira la sugerencia de sustituir RackClick por nombre del cliente. |
| 67 | OK reportado | Guardar JSON y snapshots satisfactorios. |
| 68 | Parcial por decisión del usuario | Búsqueda satisfactoria. No realizará revisión profunda de idiomas; no registrar PASS lingüístico exhaustivo. |
| 69 | Alternativa elegida | Prefiere narrar observaciones para transcribirlas. No registrar exportación de notas como probada. |

## Decisiones

- Corregir etiquetas en lote tomando como referencia la etiqueta individual aprobada visualmente.
- Mantener RackClick y versión en el informe. La propuesta contraria fue retirada por Wascar.
- Aplicar la petición anterior de PoE activo amarillo.
- Aceptar observaciones dictadas: no es obligatorio completar notas del manual.
- RC9 es una candidata con estos dos cambios. La aceptación funcional relatada de RC8 se conserva; no equivale a adoptar automáticamente un binario nuevo.
- Idiomas: revisión profunda de Wascar no realizada por decisión expresa. Esto no elimina las comprobaciones automáticas ni permite ocultar futuros defectos.

# Estado rc7 — 2026-09-26 · CANDIDATA EN QA FINAL

Wascar aprobó la dirección visual de rc6 y autorizó corregir los 22 grupos de hallazgos de la auditoría exhaustiva, con prueba de reproducción y nueva verificación por corrección. Dos hallazgos son P1 de integridad (cuarentena previa sobrescrita y lectura de localStorage ilegible tratada como vacío). Ninguno se declara cerrado en este encabezado: consultar `CONTROL-CORRECCIONES-RC7.md` y evidencias definitivas. QA manual y adopción de Wascar pendientes.

Después de la candidata offline: propuesta de servicio Windows y base de datos con usuarios → grupos → acciones → ámbitos de clientes/recursos; permisos efectivos evaluados en cada lectura y escritura. El HTML offline no ofrece autenticación multiusuario. La especificación futura no es implementación en rc7.

## Historial previo

# Estado rc6 — 2026-09-26
Informes de rack/cliente unificados; plantillas con caras/roles/colores; clientes ficticios con nombres estables; manual técnico ilustrado y matriz HTML/CSV. Candidata no adoptada. Ver README-ENTREGA y evidencia por hash.

## Próxima plataforma
Windows primero: Windows 11 y Windows Server 2019/2022 y posteriores, sujetos a matriz de compatibilidad del runtime elegido. Linux aplazado por decisión de Wascar. Esta candidata sigue siendo un HTML offline, sin servidor ni BD central ni permisos multiusuario. La implementación cliente-servidor se entrega por separado; no sustituye el respaldo offline.

## Historial
# Estado rc5 — 2026-09-26
Vista trasera explícita, alimentación PDU/UPS y documentación ampliada entregadas como candidata. El informe tiene aprobación visual de Wascar, sin adopción funcional. QA automática y revisión independiente registradas en evidence. Usuarios Windows/Ubuntu, paridad total y adopción final permanecen abiertos. Base adoptada v0.8.6; v0.8.7 no incorporada. No se modifica el piloto servidor.

## Registro histórico
# Estado actual: rc4 candidata — 2026-09-26
Implementación del directorio de clientes, 10 escenarios, alcance de acciones/exportes, informe de cliente y manual offline terminada para revisión. Evidencias actuales en qa-summary.json, visual-clients/summary.json y review-rc4/. Ninguna puerta de adopción cerrada. La auditoría completa de paridad y plataformas continúa abierta. v0.8.6 es base adoptada y rollback; v0.8.7 no se incorpora. No se modifica el piloto servidor.

## Registro previo (histórico)
# Estado rc3 · 26-09-2026
Dirección visual aprobada por Wascar. Observaciones implementadas en candidata: edición Systemhaus directa, ubicaciones y clientes offline, caras editables y primera diferenciación trasera, notas de cables.
No equivale a adopción. Pendiente: QA usuario, Firefox, tactil, certificación 278 filas y refinamiento visual exhaustivo. Circuitos de panel/Dose y modelos físicos detallados siguen abiertos: rc3 no inventa endpoints. Backend/PostgreSQL y piloto R3 separados. Web/GitHub no modificados.
Las coberturas/matrices heredadas no certifican automáticamente la candidata. Evidencia actual: qa-summary.json, tests-infrastructure.txt, review-rc3, visual/summary.json.

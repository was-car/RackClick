# Acta técnica RC8 · candidata, no adoptada

## Identidad y alcance

HTML `20ba6bf676fa932967bf14862858ea34ef69c7074a1185fb83e8d6a1687c8cad`. Base fuente v0.8.6 intacta `ddac495636a22b5a9b1da9086456b684795ed93b885a0946737de3f5f304cb12`; rollback adoptado `12deafdd6e3d5f7f1169f5b5e8390f43e3b0a12ae4e0653524af5da19f025404`. RC7 referencia `557bd3d720258a5e3df2c3e3662dcfb576496c9c923ea2fe70a1959becd1dbe8`. No se integra v0.8.7. No se cambia el diseño general ni se implementa servidor.

## Resultados

| Verificación | Resultado | Evidencia |
|---|---|---|
| Regresión legacy/integración |14/14 suites tras reejecutar dos arneses adaptados |`evidence/qa-summary.json`, `tests-*.txt`|
| QA independiente de producto |29 comprobaciones PASS en hash final |`evidence/rc8/independent/INFORME-INDEPENDIENTE.md`|
| Reconexión, oráculo de atomicidad |11 PASS |`evidence/rc8/core/atomic-results.json`|
| Red y presentación |9unitarias +6browser PASS |`evidence/rc8/network/`|
| UX dirigida |14 PASS |`evidence/rc8/ux/results.json`|
| Matriz visual representativa |108 vistas,18capturas;0hallazgos en ámbito medido |`evidence/rc8/ux/matrix/scan.json`|
| Reportes/CSV de cartera |13+5PASS |`evidence/rc8/reports/`|
| Exportes y edición RC7 |7+9PASS, hashes de ejecución indicados |`evidence/rc8/regression-extra/`|
| Integridad almacenamiento |5regresiones históricas +rescate14claves/dos episodios PASS |`evidence/rc8/integrity/`|
| Build negativo/reproducibilidad |8negativos y2builds limpios idénticos PASS |`evidence/rc8/build-negative-and-reproducible.txt`|

Chromium 153.0.8010.0/Linux con perfiles persistentes y bloqueo de HTTP(S). Algunas comprobaciones auxiliares anteriores llevan hash previo RC8 y se conservan como evidencia de desarrollo; los29independientes, reportes, CSV, núcleo, red, matriz y14suites identifican el HTML final. Integridad ejecutada antes de añadir solo el botón CSV global; no se reescribe su hash para hacerla pasar por otra ejecución.

Los contadores se solapan; no deben sumarse como si fueran casos únicos. Ninguna tabla acredita57 casos manuales RC8 ni todas las combinaciones posibles.

## Fallos encontrados durante integración y resolución

- RC7: PoE off movía el puerto; resumen incluía watts de interfaces noPoE. Reproducidos y corregidos; antes/después independiente preservado.
- Primera RC8: clic simple abría el diálogo sobre el puerto antes de recibir dobleclic. Corregido aplazando280ms únicamente la apertura de puertos ocupados. Conexión de puertos libres sigue inmediata. Dobleclic real, cancelación, destino nuevo y undo/redo reprobados por otro agente.
- Arnés: glyphestrella reemplazado por SVG, puertos ahora agrupados físicamente de modo estable, texto localizado y catálogo33presets. Se usan IDs/aria y laboratorio96U; no se debilitan aserciones de integridad. Las dos salidas fallidas originales y motivos están en `evidence/rc8/harness/`. Reejecuciones exit0 sobre idéntico hash.

## Límites abiertos

Firefox 146.0.1 fue descargado pero no inicia aquí: EPERM al crear su sandbox de procesos. Se registra BLOCKED_ENVIRONMENT, ceroaserciones; no se desactivó para simular compatibilidad. Windows y táctil físico pendientes.

Contraste automatizado es el algoritmo heredado sobre textoHTML visible de seisvistas; excluye SVG,gradientes y opacidad. No certifica todos los modales/estados/colores configurables. Tooltips nativos verificados por contenidoDOM; capturas no muestran sus globos del sistema.

Los presets son genéricos editables, no reproducciones verificadas de fabricantes. Compatibilidad óptica/eléctrica completa, continuidad interna panel/Dose, inventario certificado y telemetría quedan al contrato de plataforma. AP1U es representación organizativa. Doble ocupación histórica se conserva con aviso.

CSV cartera es export identificable, no se acredita importaciónmulticliente de ese CSV; usar JSONcompleto para ida/vuelta. Rackindividual no transporta cross-rack externos. QR decorativo no se presenta escaneable. Front/rear representa ubicación, no circuito interno automático.

Una pestaña de edición de producto. El manual protege notas por sección con WebLocks, pero no convierte el producto en multiusuario. No hay autenticación offline ni permisosNTFS/AD reales.

## Manual y seguimiento

Manual visual se entrega separado:44 capítulos,57 casos,254 referenciasRC7 identificadas y4 capturasRC8 en apéndice. Notas validadas/importables, rescate, conflicto explícito, guardado releído, impresión completa y aviso de salida con borradores. Sus propias pruebas/independiente se incluyen en suZIP. No se afirma que todas las254imágenes se hayan vuelto a capturar.

Registro de Wascar:24positivos reportados,20con observaciones,11parciales,2no ejecutados. Se conserva su relato sin transformarlo en PASS técnico. Consultar `REGISTRO-QA-WASCAR.json`, `OBSERVACIONES-Y-ALCANCE.md` y checklistdirigido12 bloques.

## Puerta siguiente

Wascar verifica cambios y Firefox en su Windows, informa incidencias y decide adopción. Solo después comienza contrato de servidor con identidad estable, grupos/permisos por recurso, DB/API, concurrencia, recuperación y panel administrativo. El plan de continuidad define puertas; el pilotoR3 no se convierte por esta entrega en producción.

# RC9 · Ergänzung zum Benutzer- und Betriebshandbuch

Stand: 28.09.2026. Kandidat, noch nicht übernommen.

## Rack-Etiketten eines Kunden

Kundenkarte öffnen → **Alle Rack-Etiketten**. Jedes Etikett verwendet jetzt die Gestaltung des einzelnen Rack-Etiketts: abgerundeter schwarzer Rahmen, Rackname, Standort, Geräteanzahl, Höheneinheiten, lokale Verbindungen, eingerahmte Rack-ID sowie RackClick-Version, Kunde, Techniker und Datum. Die Anzahl der Verbindungen entspricht wie beim einzelnen Etikett den lokalen Rack-Verbindungen; sie ist keine Gesamtsumme inklusive Cross-Rack.

**Drucken / PDF** öffnet den Druckdialog. Vor dem Druck Papierformat und Skalierung prüfen. Etiketten werden nicht innerhalb einer Karte umgebrochen. Lange Namen werden umgebrochen. Kein scannbarer QR-Code. Nur Racks des ausgewählten Kunden erscheinen.

## PoE-Anzeige

Ein dokumentierter aktiver PoE-Port hat einen gelb gefüllten Blitz. Bei deaktiviertem PoE bleibt der Blitz ungefüllt. Die Anzeige ist Dokumentation, keine Live-Messung und keine Fernsteuerung des Switches. Einzel- und Bereichsaktionen bleiben unverändert.

## Betrieb und Rückkehr

Vor dem Versionswechsel vollständiges JSON exportieren. RC9 in separatem Profil mit einer Kopie testen. RC8 liegt unverändert im Ordner rollback. Benutzerbeobachtungen können auch mündlich übermittelt und im QA-Protokoll dokumentiert werden; die Notizfunktion des Manuals ist optional.

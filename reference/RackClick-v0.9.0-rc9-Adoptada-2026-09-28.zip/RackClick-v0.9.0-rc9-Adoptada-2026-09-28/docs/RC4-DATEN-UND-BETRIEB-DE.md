# RackClick v0.9.0-rc4 · Kundenstruktur
2026-09-26 · Kandidat, nicht übernommen

## Daten und Navigation
Ein Gesamtprojekt bleibt die Quelle für Autosave und Undo. Die Oberfläche projiziert einen aktiven Kunden. Abfragen, Rackauswahl, Verschieben und Teilimporte werden auf diesen Kunden begrenzt. Das ist keine Berechtigungsgrenze: jeder Besitzer der HTML/JSON-Datei kann den gesamten Inhalt lesen.

Optionale JSON-v0.8-Erweiterungen: rackclickClientMeta (client, technician, optional logo) und rackclickDemoLanguage (en/de/es). rackclickLocation/rackclickLocations und rackclickSystemhaus bleiben erhalten. Keine neuen localStorage-Schlüssel. Kein Server oder Benutzerkonto. Synthetische Übersetzungen erhalten IDs und individuell geänderte Texte.

## Sicherung
Kundenexport umfasst einen Kunden; Gesamtsicherung alle. Autosave und Snapshots sind global. Wiederherstellung eines Snapshots ersetzt den gesamten Bestand nach Bestätigung. Eine Registerkarte verwenden. Externe JSON-Sicherung vor Versionswechsel und Demoimport. Verbindungen über Kundengrenzen bleiben erhalten; Teilersatz/-export wird in diesem Fall gesperrt. Alte unzugeordnete Racks bleiben sichtbar.

## Berichte und Rückfall
Neuer Kundenbericht mit schematischen Rackgrafiken, weißem Druckhintergrund und Verbindungen. Klassischer Bericht explizit erreichbar. rollback/rackclick-v0.8.6.html unverändert. Vor Nutzung des Rollbacks vollständiges JSON exportieren; Kundenhierarchie ist dort keine native Ansicht. Der komplette neue Bestand ist im Gesamtexport, nicht im einzelnen Kundenexport.

## Prüfung
Siehe evidence/qa-summary.json, evidence/visual-clients/summary.json und unabhängige Prüfung evidence/review-rc4/. Der HTML-Leitfaden enthält neun Kapitel und eine manuelle Checkliste in DE/EN/ES. Vollständige Parität aller alten Funktionen bleibt offen, ebenso Nutzer-QA Windows/Ubuntu und automatisiertes Firefox-QA dieser Lieferung.

# Revisión manual de RackClick rc7 / Manuelle Prüfung RackClick rc7

**Duración objetivo / Zielzeit:** 20–25 minutos. **Estado:** sin ejecutar / nicht durchgeführt. Anotar fecha, Windows, navegador, HTML SHA-256, resultado y captura o archivo descargado. Usar perfil de navegador separado y copia del proyecto real. Exportar respaldo completo antes de cargar datos de prueba. No aprobar por apariencia visual solamente.

| Min | Español: acción y resultado observable | Deutsch: Aktion und beobachtbares Ergebnis | Resultado / Ergebnis |
|---:|---|---|---|
| 0–2 | Abrir offline con red desactivada; elegir DE y comprobar clientes y rack sin avisos de carga. | Offline ohne Netz öffnen; DE wählen, Kunden und Rack ohne Ladefehler. | ☐ |
| 2–4 | Exportar respaldo completo; verificar que el archivo existe y contiene los clientes y enlaces cross-rack. | Gesamtsicherung exportieren; Datei, Kunden und rackübergreifende Verbindungen prüfen. | ☐ |
| 4–6 | Renombrar cliente desde infraestructura; técnico, logo y proyecto se mantienen tras recarga. | Kunde aus Infrastruktur umbenennen; Techniker, Logo und Projekt nach Neuladen erhalten. | ☐ |
| 6–8 | Crear conexión libre Click-Click en dos clics; reserved pide confirmación; disabled/faulty bloqueados. | Freie Verbindung mit zwei Klicks; reserved fragt; disabled/faulty gesperrt. | ☐ |
| 8–10 | Editar watts: 0 persiste, negativos rechazados, Undo/Redo restaura; Delete dentro de búsqueda no borra equipo. | Watt: 0 bleibt, negative Eingabe abgewiesen, Rückgängig/Wiederholen; Entf im Suchfeld löscht kein Gerät. | ☐ |
| 10–12 | Editar nota de cable y reordenar con flechas; Undo/Redo. Mover equipo por táctil si hay dispositivo táctil. | Kabelnotiz ändern und Pfeile zur Reihenfolge; Undo/Redo. Berührungsgeste nur bei echtem Touchgerät. | ☐ |
| 12–14 | Abrir informe moderno de cliente y rack; CSV accesible; PNG transparente con fondo realmente transparente. | Modernen Kunden- und Rackbericht öffnen; CSV verfügbar; transparentes PNG tatsächlich mit Alpha. | ☐ |
| 14–16 | Exportar rack con enlace cross; comprobar aviso de alcance y conservar respaldo global. | Rack mit rackübergreifendem Link exportieren; Umfangshinweis lesen, Gesamtsicherung behalten. | ☐ |
| 16–18 | Abrir Settings: plantillas/favoritos; cambiar claro/oscuro y ES/DE; buscar y usar teclado sin recortes evidentes. | Einstellungen: Vorlagen/Favoriten; Hell/Dunkel und ES/DE; Suche/Tastatur ohne sichtbare Abschneidung. | ☐ |
| 18–20 | Descarga de rescate/quarantena sobre un perfil de prueba con datos sintéticos: comprobar archivos; no provocar fallos sobre el proyecto real. | Rettung/Quarantäne nur mit synthetischen Daten im Testprofil; Dateien prüfen. Keine Fehler im Originalprojekt auslösen. | ☐ |

| 20–25 | En Firefox y Windows: cambiar grupo de puertos 2→3 y pulsar **Guardar con ratón** varias veces; recargar, comprobar IDs, color y watts, luego Undo/Redo. Abrir informe y **Imprimir/Guardar PDF** con navegador real; anotar resultado. | In Firefox unter Windows: Portgruppe 2→3, mehrmals **mit Maus speichern**; neu laden, IDs/Farbe/Watt sowie Rückgängig/Wiederholen prüfen. Bericht im echten Browser **drucken/als PDF sichern**. | ☐ |

**Resultado global / Gesamtergebnis:** ☐ conforme / bestanden ☐ incidencia / Fehler ☐ no realizado / nicht durchgeführt. Registrar incidencias con acción, resultado esperado, resultado obtenido y captura. Esta lista no sustituye las suites de regresión ni la prueba de fallo de almacenamiento automatizada.

# RackClick v0.9.0-rc6 · Informes, plantillas y documentación
2026-09-26 · CANDIDATA OFFLINE. No adoptada ni publicada. Base adoptada/rollback: v0.8.6. v0.8.7 excluida.

## Abrir y probar (10 minutos)
1. Exporta un respaldo completo desde tu versión actual; extrae este ZIP en una carpeta nueva.
2. Abre RackClick-v0.9.0-rc6-Offline.html. No necesita instalar servidor ni conectarse a Internet.
3. Desde Todos los clientes, carga los 10 clientes de ejemplo si quieres ver los nombres nuevos. Esta acción reemplaza todo el conjunto, previa confirmación; no la uses sobre datos sin respaldo.
4. Abre Nordhafen Logistik → Distribuidor principal → Informe. Ahora usa el mismo diseño, ilustración y tabla del informe del cliente, limitado al rack seleccionado. Las conexiones cross-rack siguen en la tabla. Imprimir permite guardar PDF; el informe clásico queda como respaldo explícito.
5. Configura caras frontal/trasera en un equipo y guarda como plantilla desde el menú contextual del equipo. Crea otro equipo desde esa plantilla y comprueba sus caras, etiquetas y colores.
6. Abre ABRIR-DOCUMENTACION.html: manual de uso, manual técnico ampliado con diagramas, pack de pruebas y matriz HTML con búsqueda y descarga CSV.

## Cambios rc6
- Informe del rack y del cliente comparten el mismo componente aprobado, sin rediseñarlo. El informe moderno ya no espera una captura PNG para abrirse.
- Diez clientes ficticios con nombres estables en ES/DE/EN y 68 racks. El idioma traduce los términos de infraestructura, no los nombres propios. No se renombran los proyectos existentes.
- Plantillas: conservan orden, tipo, número, capacidad PoE, etiqueta, color manual, cara y rol eléctrico de cada puerto. Cada instancia genera IDs nuevos. No se copian cables, ocupación/estado ni watts operativos.
- Plantillas antiguas sin distribución física siguen utilizables; para conservar una distribución editada, guarda una nueva plantilla.
- Manual técnico ilustrado y matriz consultable offline. La matriz explica trazabilidad documental; no certifica por sí misma la paridad funcional.

## Diez ejemplos ficticios
| Cliente | Racks |
|---|---:|
| Lindenwerk Architektur | 1 |
| Nordhafen Logistik | 2 |
| Sonnenfeld Medizin | 3 |
| Bergstrom Fertigung | 4 |
| Elbwinkel Handel | 5 |
| Falkenhof Bildung | 6 |
| Westbogen Hotel | 8 |
| Kieselpark Medien | 10 |
| Morgenwald Verwaltung | 12 |
| Sternbruck Campus | 17 |
No son instalaciones reales ni referencias comerciales. Conservan las topologías sintéticas editables de la candidata anterior.

## Datos, límites y próxima plataforma
Guardar JSON del cliente guarda solo el cliente activo. Exportar respaldo completo guarda todos. Autosave y snapshots son globales. Mantén una copia externa y una sola pestaña activa.
La separación de clientes offline es organizativa, sin usuarios ni permisos de servidor. Los enlaces eléctricos son documentación, sin simulación de tensión, carga o autonomía. Dos PSU en la misma PDU no son redundancia A/B; PDU lateral 0U pendiente.
Windows es la prioridad de la siguiente etapa de servidor/BD: Windows 11 y Windows Server 2019/2022 y posteriores sujetos a verificación de compatibilidad. Linux queda aplazado. Este ZIP entrega la aplicación offline; no declara implantado ese servidor.

## Verificación y honestidad de estado
- evidence/qa-summary.json: suites automatizadas, hash exacto y salidas por suite.
- evidence/reports-templates.json: paridad visual del informe por rack respecto al cliente, cross-rack y reutilización de plantilla tras recarga.
- evidence/visual-clients/: 90 capturas en 3 idiomas, 2 temas y 3 anchos; comprueba desbordamiento global, errores JS y solicitudes HTTP(S). No cubre todo recorte interno/contraste de todos los modales.
- evidence/build-negative.txt: 7 fallos provocados y dos builds limpios idénticos al entregado.
- evidence/review-rc6/: revisión independiente focalizada; los informes rc5 y anteriores son históricos.
- Tu revisión rápida es valoración visual, no adopción. Paridad completa legacy, Firefox automatizado, táctil real y QA de Windows siguen abiertos.

## Desarrollo opcional
No necesario para abrir el HTML. Build: npm ci, después npm run build. Pruebas: instalar tests/requirements.txt y Chromium de Playwright, ejecutar python tests/run_qa.py o Windows/03-probar.ps1. Las pruebas usan perfiles temporales y datos sintéticos. Este entorno no ejecuta Windows; sus launchers requieren validación allí.

## Rollback
SHA256SUMS.txt cubre los archivos entregados. rollback/rackclick-v0.8.6.html conserva la versión adoptada intacta y sus CDN originales. Las candidatas rc4/rc5 en rollback son referencias, no versiones adoptadas. Exporta respaldo completo antes de cambiar de versión. Un HTML en otra ruta puede usar almacenamiento separado: carga una copia del JSON. Ningún JSON real de Wascar se incluye.

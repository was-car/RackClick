# Fuentes y límites de los escenarios sintéticos
Consulta: 2026-09-26. Los escenarios se diseñaron para probar RackClick; no son proyectos reales ni prescripciones de instalación.

- Cisco, Campus LAN and Wireless LAN Solution Design Guide: https://www.cisco.com/c/en/us/td/docs/solutions/CVD/Campus/cisco-campus-lan-wlan-design-guide.html — referencia para separar acceso y agregación y representar enlaces entre edificios.
- Ubiquiti, Getting Started with UniFi Protect: https://help.ui.com/hc/en-us/articles/27878858632599-Getting-Started-with-UniFi-Protect — contexto de terminales conectados mediante switches PoE. Esta entrega no añade cámaras físicas al catálogo.
- Ubiquiti, PoE Availability and Modes: https://help.ui.com/hc/en-us/articles/115000263008-PoE-Availability-and-Modes — referencia sobre presupuesto y compatibilidad PoE. Los 7/15 W de la demo son datos ficticios; no se atribuyen a ningún equipo real.

Los diez escenarios comparten un patrón genérico de acceso/agregación, con escala y nombres distintos: 1/2/3/4/5/6/8/10/12/17 racks, 68 en total. No representan diez diseños de ingeniería independientes ni reproducen modelos físicos de fabricantes. Patchpanel, switch, firewall, servidor, NAS y UPS son plantillas genéricas. No contienen datos del usuario. Los JSON EN/DE/ES de fixtures se generan desde irDemo y los endpoints son comprobados automáticamente.

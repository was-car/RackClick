# RackClick · Observaciones de Wascar y alcance de RC8

Fecha: 2026-09-27. Fuente completa: `Eingefügter Text(20260927-215124).txt`.

## Estado y criterio

Este registro concilia el relato completo de los57 casos. No modifica el producto, no constituye aprobación de RC7/RC8, no sustituye pruebas independientes y no borra registros históricos. El usuario autoriza corregir y comprobar; prevé confirmar adopción después. Los17 puntos anteriores no se declaran perdidos ni se reconstruyen de memoria: este documento añade la nueva revisión completa.

Resumen de resultados reportados: OK_REPORTADO: 24, CON_OBSERVACIONES: 20, PARCIAL: 11, NO_EJECUTADO: 1, NO_EJECUTADO_CONDICIONAL: 1.

`OK_REPORTADO` significa resultado positivo declarado, no ejecución acreditada de todas las ramas. `CON_OBSERVACIONES` conserva resultado funcional y cambios solicitados. `PARCIAL` limita exactamente lo probado; no se convierte en PASS. Los fallos nuevos del relato todavía requieren reproducción técnica.

## Conciliaciones importantes

- Caso25: reserved sí conecta según la aclaración final. Mantener confirmación; el bloqueo posterior a batch-disable es otro hallazgo (W15).
- Caso42: sí existe export de rack. No duplicar función. No consta comprobación específica de sus enlaces cross-rack.
- Caso36: abrir CSV en Excel no prueba importar CSV a RackClick.
- Caso46: idiomas no revisados por Wascar. Caso50: táctil no ejecutado. Caso52: rescate no apareció; modo seguro de Firefox es distinto del modo seguro de RackClick.
- Caso14: resultado verbal positivo, pero la secuencia concreta de guardado Firefox no se relata con suficiente precisión. Mantener GOV-02 y repetición dirigida.
- Caso31: finalmente hizo bulk y reportó éxito; la transcripción combina25–48 y30–48, por lo que no se certifica un conteo exacto.
- Caso40: se corrigió al abrir un archivo equivocado y finalmente vio todos los caracteres. No registrar pérdida XLS que él mismo descartó.

## Pedidos normalizados

| ID | Casos | Clase | Pedido y razón | Fase | Criterio verificable |
|---|---|---|---|---|---|
| W01 | 4,47,48 | UX | **Zoom y ancho del rack.** Conservar acceso al rack y panel derecho al zoom/ventana estrecha; priorizar navegación y no deformar representación física. | Actual | No ocultar controles y documentar scroll deliberado. |
| W02 | 5,38 | BUG | **Logo y técnico en informe cliente.** Mostrar logo/nombre técnico del cliente; usuario aclara que no son necesarios en informe individual de rack. | Actual | Informe cliente con logo real sin red y escapes; informe rack conserva diseño aprobado. |
| W03 | 5,6 | UX | **Guardar/Cancelar accesibles.** Barra de acciones visible sin bajar hasta final de infraestructura. | Actual | Crear ubicación en lista larga y guardar/cancelar desde viewport actual sin pérdida. |
| W04 | 7 | MEJORA | **Ubicación de rack: selector y manual.** Reutilizar ubicaciones existentes y permitir entrada manual. Sin exigir DB en offline. | Actual | Selección coherente con cliente; manual aún disponible; sin mezcla entre clientes. |
| W05 | 10,46 | BUG_UX | **Contraste de alta de equipos.** Revisar nombres, presets, símbolos y colores especialmente claro; oscuro ya resulta legible. | Actual | Medir contraste y revisar oscuro/claro; sin textos invisibles. |
| W06 | 10,28 | MEJORA | **Más presets genéricos.** Switch8/24/48, routers, servidores, almacenamiento y AP; frontal/trasera configurables. | Actual acotado; catálogo exacto futuro | No inventar modelo fabricante; presets editables y etiquetas de realismo genérico. |
| W07 | 10 | UX | **Nombre no es filtro.** Usuario confundió Device Name opcional con búsqueda y se corrigió; mejorar distinción, buscador de presets si se añade. | Actual | Campos separados y etiqueta inequívoca, sin registrar fallo de filtro inexistente. |
| W08 | 11 | MEJORA | **Tooltip de dispositivo.** Hover en nombre muestra modelo, IP, firmware, serie/notas disponibles sin abrir editor. | Actual | Datos actuales, texto seguro y acceso equivalente por teclado. |
| W09 | 13,21,23,29,30 | MEJORA | **Tooltip de conexión completo.** Origen/destino rack/equipo/puerto, etiqueta, watts documentados, notas y estado; datos conocidos sin inventar. | Actual | Local/cross/eléctrico correctos tras renombrar/mover; no depender de nombres antiguos copiados. |
| W10 | 17 | UX | **Favoritos y plantillas arriba.** Priorizar favoritos y luego plantillas bajo nombre; estrella visible y accesible. | Actual | Alta/eliminar/reload conservan favoritos y diseño ordenado. |
| W11 | 18 | DOCUMENTACION | **Aclarar selección múltiple.** Explicar diferencia equipos seleccionados y puertos/rangos; caso quedó parcial por confusión. | Actual | Ejemplo visual de dos equipos y resultado concreto por operación. |
| W12 | 21 | BUG | **PoE off no debe recolocar puerto.** Mantener posición y orden al activar/desactivar PoE, indicador eléctrico claro. | Actual | Mismo ID/gn/fila/columna y conexiones; on/off no cambia agrupación física. |
| W13 | 22 | BUG_UX | **Inputs de rango legibles.** Dígitos de dos cifras truncados en Port Batch de patchpanel/switch. | Actual | Mostrar1–48 y rangos25–48 a anchos objetivo; inputs conservan valor. |
| W14 | 22 | MEJORA | **PoE por lote.** Añadir PoE on/off a rango explícito de puertos aptos, mantener orden; watts por lote a definir. | Actual | Solo rango/tipos aptos modificados; no alterar IDs/cables ni PSU general. |
| W15 | 25,26 | BUG_POR_REPRODUCIR | **Origen seleccionado luego disabled por lote.** Usuario tuvo que reactivar/desactivar para seguir; limpiar o revalidar selección tras cambio de estado. | Actual | Iniciar click-click, batch-disable origen, cancelar/seguir sin bloqueo y sin conexión ilegal. |
| W16 | 30 | MEJORA | **Reconectar mediante doble clic en ocupado.** Destino nuevo sin destruir enlace original hasta confirmar; doble clic libre sigue etiqueta rápida y clic simple conserva panel. | Actual requiere interacción explícita | Cancelar/no válido deja enlace intacto; nuevo válido mantiene color/notas; undo restaura. |
| W17 | 31 | UX | **Bulk visible y rango físico claro.** Se encontró y ejecutó, pero visibilidad condicional y comienzo/fin confusos. | Actual | Explicar condición; previsualizar puertos concretos25–48 y count24; no confundir índice libres con gn. |
| W18 | 36 | MEJORA | **CSV cliente y cartera.** Export cliente con todos sus racks y export global; identificar cliente/rack para entregar paquete. | Actual | Alcance explícito y filas identificables; no fuga accidental de cartera al export cliente. |
| W19 | 40,43 | MEJORA | **Etiquetas por cliente.** Imprimir etiquetas de todos los racks de cliente de una sola vez. | Actual | N etiquetas N racks, saltos adecuados, caracteres especiales y sin cliente ajeno. |
| W20 | 41 | MEJORA | **PDF con identidad Bericht.** PDF debe reutilizar misma presentación de informe moderno, no exportador antiguo tipo tabla. | Actual | Mismo contenido/layout moderno, fondo blanco imprimible, no cortar imágenes. |
| W21 | 43 | FUTURO | **QR escaneable conectado al servidor.** Usuario difiere al final: escanear rack y consultar conexiones/búsqueda con acceso autorizado. | Servidor posterior | No convertir QR decorativo en falsa función offline; URL/identidad/autorización sin secretos QR. |
| W22 | 46 | UX | **Solo oscuro y claro.** Retirar opciones semidark/silver, migrar preferencia UI sin alterar datos. | Actual | semidark→oscuro, silver→claro; ambas paletas legibles. |
| W23 | 46 | QA | **Idiomas delegados al equipo.** Usuario no verificó idiomas; EN/DE/ES y términos técnicos estables. | Actual | Pruebas paridad y textos fijos, revisión vistas/modales/reportes; no afirmar QA usuario. |
| W24 | 50 | QA_DIFERIDA | **Táctil físico no disponible.** Usuario no pudo probar; validación automatizada no equivale dispositivo real. | Pendiente, no bloquear decisión sin explicar limitación | Marcar no ejecutado y conservar para futura prueba física. |
| W25 | 52 | ACLARACION | **Modo seguro Firefox ≠ RackClick.** No apareció rescate/cuarentena; no es fallo por no mostrarse con datos sanos. | Actual documentación + QA automatizada | Provocar corrupción en perfil descartable, no en cartera usuario. |
| W26 | 53 | DOCUMENTACION | **Actualizar manual después de correcciones.** Mantener formato visual; no requiere nuevo acceso por menú contextual ahora. | Actual | Capturas y57 casos vinculados a build final real; validar notas/impresión. |
| W27 | 55 | BUG_UX | **Lupa de búsqueda.** Sustituir símbolo incorrecto por icono SVG coherente. | Actual | Visible ambos temas, nombre accesible y no carácter roto. |
| W28 | cierre | GOBIERNO | **Corregir → verificar → adoptar → servidor.** Usuario autoriza agentes y correcciones; confirmación de adopción será posterior; contrato servidor paso5 después. | Actual y futuro | Evidencia antes/después, revisión independiente, checklist dirigido, sin adopción automática. |
| W29 | 42 | RECTIFICACION | **Export rack ya existe.** No agregar duplicado basado en comentario inicial; después encontró y exportó/reimportó rack. | Actual trazabilidad | Mantener función; probar limitación cross-rack de manera dirigida. |
| W30 | 25 | RECTIFICACION | **Reserved sí admite conexión.** Afirmación inicial negativa corregida explícitamente al conectar reservado. | Actual trazabilidad | No convertir reserved en bloqueado; reconfirmar aceptar/cancelar. |

## Relación de las38 observaciones previas

Los IDs originales siguen abiertos hasta aportar evidencia y revisión. «Actual» indica trabajo de corrección y documentación, no que todo esté corregido. Las recomendaciones estructurales servidor no se convierten en ampliación urgente del HTML.

| ID | Tema | Tratamiento y relación |
|---|---|---|
| ARQ-01 | Los nombres de cliente y ubicación actúan como identidad | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| ARQ-02 | El ensamblado por sustituciones necesita trazabilidad completa | Actual: trazabilidad de build y pruebas negativas; conservar GUI. |
| ARQ-03 | Separar operaciones de negocio de los manejadores React | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| ARQ-04 | Precisar la unidad de concurrencia y las operaciones entre racks | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| ARQ-05 | Undo global offline no equivale a deshacer multiusuario | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| ARQ-06 | Contrato explícito para las extensiones JSON y metadatos | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| ARQ-07 | Separar verdad actual de los nombres copiados en conexiones | Actual: coherencia tooltip W09 tras renombrado; diseño identidad servidor después. |
| ARQ-08 | Importación tolerante offline frente a integridad estricta servidor | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| ARQ-09 | Completar el contrato de propiedad e integridad referencial servidor | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| RED-01 | P2, defecto reproducido en función | Actual: corregir cálculo PoE junto W12/W14; separar watts eléctricos generales. |
| RED-02 | P2, limitación reproducida en función + análisis estático | Futuro contrato conector/medio; documentar límites offline; no inventar bloqueos nuevos. |
| RED-03 | P2, verificación estática | Actual: revalidar cambio de rol eléctrico; no borrar conexión silenciosamente. |
| RED-04 | P2, verificación estática | Actual: representar rol desconocido honestamente; W09. |
| RED-05 | P3, requisito de modelo futuro | Futuro continuidad panel/face; mantener comportamiento actual declarado. |
| RED-06 | P3, limitación comprobada en fuente | W06: presets genéricos ahora; procedencia/catálogo físico exacto después. |
| RED-07 | P2, verificación estática | Actual: diagnóstico completo doble ocupación; nunca borrar histórico al avisar. |
| RED-08 | P3, requisito de producto/manual | Manual actual: estado documentado ≠ telemetría; plataforma futura. |
| SEC-01 | Clasificar y custodiar los bundles offline como datos de toda la cartera | Actual manual: bundle global es dato sensible de toda cartera; W18/W26. |
| SEC-02 | Concretar recuperación de cuentas y alta inicial antes de implementar el panel | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| SEC-03 | Especificar contrato de sesión, transporte y CSRF | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| SEC-04 | Convertir la revocación «antes de commit» en garantía de concurrencia verificable | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| SEC-05 | Un backup recuperable debe incluir configuración y claves necesarias, no sólo inventario | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| SEC-06 | Hacer atómica la relación entre cambio de datos y auditoría | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| SEC-07 | Diseñar la instalación Windows con identidad de servicio y separación de datos | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| SEC-08 | Añadir límites cuantitativos a importaciones y adjuntos | Medir límites/importaciones ahora; política dura en contrato servidor después. |
| SEC-09 | Separar preferencia offline de persistencia sensible en el navegador multiusuario | Contrato/servidor posterior (pasos5–8); conservar como requisito verificable, no implementado por este registro. |
| MQ-01 | Reproducido: JSON válido con tipo incorrecto rompe las notas | Actual manual: corregir y verificar independientemente; W26. |
| MQ-02 | Reproducido: un array produce éxito fantasma y pierde la anotación | Actual manual: corregir y verificar independientemente; W26. |
| MQ-03 | Reproducido: dos pestañas sobrescriben notas posteriores | Actual manual: corregir y verificar independientemente; W26. |
| MQ-04 | Carencia comprobada por inspección: exportar notas no permite recuperarlas en el manual | Actual manual: corregir y verificar independientemente; W26. |
| MQ-05 | Reproducido: el PDF de un capítulo omite recorridos plegados | Actual manual: corregir y verificar independientemente; W26. |
| MQ-06 | Confirmado: semántica accesible incompleta en ampliación y navegación | Actual manual: corregir y verificar independientemente; W26. |
| MQ-07 | Reproducido: búsqueda de un modo filtra silenciosamente el otro | Actual manual: corregir y verificar independientemente; W26. |
| MQ-08 | Brecha de cobertura: el arnés usa estado interno en lugar del recorrido del usuario | Actual manual: corregir y verificar independientemente; W26. |
| GOV-01 | Separar evidencia documental, funcional y aceptación | Actual: este registro separa QA reportado/técnico/adopción; W28. |
| GOV-02 | Conservar el fallo inicial de Firefox y resolver la incertidumbre | Actual: repetir caso 14 Firefox dirigido; impresión39 es evidencia separada. |
| GOV-03 | Hacer portable la comprobación del manual | Actual: arnés/manual portable Windows con requisitos y rutas explícitas. |
| GOV-04 | Planificar por puertas verificables | Actual: puertas de entrega y futuro contrato servidor; W28. |

## Orden de ejecución recomendado

1. Congelar RC7 y conservar su hash/rollback. Crear candidata RC8 separada.
2. Reproducir W12/W15 y RED-01/03/04/07; pruebas antes/después. Corregir la integridad primero.
3. Implementar legibilidad, acciones accesibles, tooltips, favoritos, selector ubicación y presets genéricos editables.
4. Reconexión y lote con cancelación atómica; exportes cliente, etiquetas y PDF reutilizan identidad aprobada.
5. Corregir manual MQ-01–08 y actualizar capturas según RC8 efectiva; idiomas y recorrido responsive automatizados.
6. Revisión independiente y evidencia reproducible, más límites Firefox/táctil claros.
7. Wascar repite checklist dirigido, confirma o devuelve observaciones; solo su confirmación adopta.
8. Contrato servidor Windows, DB/API y panel administrativo; QR real vinculado a autorización queda posterior.

## Checklist dirigido propuesto para Wascar después de RC8

No repetir57 casos enteros por rutina: equipo ejecuta regresión general. Propuesta de recorrido manual afectado:

1. Infraestructura con muchas ubicaciones: guardar/cancelar visibles, nombre/logo/técnico y selector manual/lista del rack.
2. Oscuro/claro y ventana estrecha: presets, estrella, inputs25–48 y lupa legibles.
3. Favoritos/plantillas arriba; crear preset propio y conservar tras F5.
4. Hover equipo y puertos local/cross/eléctrico muestra datos reales y notas, también tras renombrar.
5. PoE off/on conserva posición; lote5–14 solo modifica rango y suma PoE correcta.
6. Seleccionar origen y batch-disable: salir y volver a conectar sin quedar bloqueado; reserved aceptar/cancelar.
7. Doble clic en conectado: reconectar, cancelar y undo; libre mantiene etiqueta rápida.
8. Bulk25–48: previsualizar24 puertos concretos y resultado exacto.
9. CSV cliente/global y etiquetas lote: alcance correcto, ningún cliente ajeno. ImportaciónCSV 36 sigue prueba propia.
10. Informe cliente con logo/técnico; PDF moderno y PNG, impresión etiquetas.
11. Firefox caso 14 exacto: clic guardar, pérdida de foco controlada, confirmaciones, F5 e IDs/atributos persistentes.
12. Manual: importar/exportar notas, recuperación frente a nota malformada y PDF capítulo completo.

Los casos36/37/42 requieren fixtures de prueba adecuados. Las situaciones destructivas/corrupción52 las reproduce el equipo en perfiles descartables. Táctil físico50 queda explícitamente no ejecutado hasta disponer de dispositivo. La decisión de adopción no implica pruebas inexistentes.

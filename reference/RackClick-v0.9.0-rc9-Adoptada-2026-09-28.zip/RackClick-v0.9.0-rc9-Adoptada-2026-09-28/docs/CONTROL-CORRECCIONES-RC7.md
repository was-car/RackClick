# Control de correcciones · v0.9.0-rc7

**Estado:** candidata para QA de Wascar, 26.09.2026. La aprobación visual de rc6 no equivale a adopción funcional de rc7. Esta tabla vincula cada hallazgo de la auditoría rc6 con una prueba exigida. Un cambio de código no cierra por sí solo una fila. Fuente: `RackClick-Auditoria-rc6-2026-09-26/HALLAZGOS.json`, SHA-256 de la aplicación rc6 `f342fa8ba331bdcbaa0ca7c3b908e5878616f4ce8a1fe4028849ed8db271b88e`.

| ID | Prioridad | Resultado exigido para rc7 | Estado y evidencia |
|---|---|---|---|
| AUD-001 | P1 | Dos episodios de cuarentena preservan sus bytes originales y son exportables antes de limpieza expresa. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE (`evidence/integrity/test_integrity.py`, `results.json`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-002 | P1 | Una excepción al leer almacenamiento no se interpreta como primer uso y no sobrescribe el proyecto; rescate/manual disponibles. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE (`evidence/integrity/test_integrity.py`, `results.json`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-003 | P2 | Cuota al crear o error al borrar cuarentena no muestran éxito y conservan la fila y los datos. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE (`evidence/integrity/test_integrity.py`, `results.json`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-004 | P2 | CSV del informe moderno disponible en contexto cliente y rack, con ámbitos declarados. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE Chromium/Firefox, ver acta `evidence/QA-FINAL-RC7.md` (`tests/test_export_patches.py`, `evidence/export-fixes/`) |
| AUD-005 | P2 | PNG transparente contiene píxeles alfa 0 y contenido visible; PNG opaco no cambia. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE Chromium/Firefox, ver acta `evidence/QA-FINAL-RC7.md` (`tests/test_export_patches.py`, `evidence/export-fixes/`) |
| AUD-006 | P2 | Exportar rack advierte que omite enlaces hacia otros racks y señala respaldo completo. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE Chromium/Firefox, ver acta `evidence/QA-FINAL-RC7.md` (`tests/test_export_patches.py`, `evidence/export-fixes/`) |
| AUD-007 | P2 | Entrada inválida que antes rompía al dibujar queda validada, recuperable y sin pérdida del original. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: RC6 ErrorBoundary → RC7 boot seguro/original exacto en cuarentena (`evidence/integrity/results.json`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-008 | P2 | El QR decorativo se anuncia como tal al descargarlo y en su artefacto. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE Chromium/Firefox, ver acta `evidence/QA-FINAL-RC7.md` (`tests/test_export_patches.py`, `evidence/export-fixes/`) |
| AUD-009 | P2 | Renombrado desde infraestructura conserva técnico, logo y metadatos tras recarga y exportación. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE (`tests/test_edit_fixes.py`, `evidence/edit-fixes/`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-010 | P2 | Borrar rack cierra editor y limpia selección sin cambiar otros racks. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: Cancel/Accept/Undo (`tests/ux_delete_rack_rc7.mjs`, `evidence/ux-rc7/delete-rack.json`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-011 | P2 | DE/ES/EN íntegros en títulos, temas, búsqueda y nombres accesibles. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE (`tests/test_ux_rc7.mjs`, `evidence/ux-rc7/`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-012 | P2 | Flechas de orden, watts y nota de cable generan historial transaccional; Undo/Redo/reload coherentes. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE (`tests/test_edit_fixes.py`, `evidence/edit-fixes/`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-013 | P2 | 0 W es valor válido y persistente; negativo/no finito se rechaza sin mutación. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: 0 W válido, vacío desconocido, negativo/no finito/>90 W rechazados (`tests/test_edit_fixes.py`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-014 | P2 | Altura entera positiva y no superior al rack, sin efectos parciales ante rechazo. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: edición/alta/movimiento verifican ocupación total U (`tests/test_edit_fixes.py`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-015 | P2 | Pulsación larga en cabecera abre menú y no inicia arrastre accidental. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: pulsación 550 ms y cancelación al mover >10 px (`tests/ux_interactions_rc7.mjs`), pendiente táctil real |
| AUD-016 | P2 | Equipo muestra presupuesto/consumo PoE agregado, separando desconocido de 0 W. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: resumen de consumo/presupuesto y puertos sin watts (`tests/ux_actions_rc7.mjs`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-017 | P2 | Delete en búsqueda/editor no abre confirmación de borrar equipos; Delete fuera sigue funcionando. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: inputs/textarea/select/contenteditable/textbox protegen tecla Delete (`tests/test_edit_fixes.py`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-018 | P2 | Contraste ≥4,5:1 texto y ≥3:1 bordes/estados medidos en temas y controles afectados. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: seis vistas inspeccionadas (`tests/contrast_rc7.mjs`), no todos los modales/estados |
| AUD-019 | P2 | Ajustes da acceso a plantillas y favoritos o documenta aplazamiento aprobado por Wascar. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: Settings abre gestión y borrado de plantillas/favoritos (`tests/ux_actions_rc7.mjs`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-020 | P2 | Bloqueo de red intercepta URL anidada HTTP(S); canario del arnés falla si deja salir tráfico. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: canario HTTP(S) anidado (`tests/test_network_guard.py`), ver acta `evidence/QA-FINAL-RC7.md` |
| AUD-021 | P2 | Cada suite exige resultado final estructurado/marcador, además de código de salida 0. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: `tests/run_qa.py` exige marcador + exit 0, pendiente prueba negativa independiente de truncación en build final |
| AUD-022 | P3 | Vista previa de lote cuenta interfaces afectadas, no solo números de puerto. | CORREGIDO EN ALCANCE PROBADO; QA INDEPENDIENTE: GN1 sobre cuatro interfaces muestra 4 (`tests/ux_actions_rc7.mjs`), ver acta `evidence/QA-FINAL-RC7.md` |

## Puertas de entrega

1. Reproducir cada defecto original en rc6 inmutable; ejecutar el mismo oráculo en rc7 y adjuntar salida.
2. Construir dos veces y comparar hashes; comprobar versión en título, HTML, reportes, etiqueta y rescate.
3. Regresión del proyecto completo, un E2E por acción crítica, navegador Chromium y Firefox, bloqueo de red comprobado.
4. Revisar diferencias de formato persistente. Nuevas claves de episodios: `rackclick_*` y contrato de recuperación descritos en manual técnico; ningún borrado automático de episodios previos.
5. Revisar visualmente idioma ES/DE/EN y temas oscuro/claro en 1440, 1024 y 390 px. Pruebas reales en Windows las hace Wascar y se registran aparte.
6. Revisión independiente y checklist de Wascar. La versión solo se marca ADOPTADA después de su confirmación.

## Fuera de esta candidatura

El servidor multiusuario, Active Directory, grupos, permisos por cliente, API y base de datos siguen propuestos. La aplicación offline organiza clientes, pero no aplica autorización entre usuarios. v0.8.7 no se incorpora por inferencia.

## Dictamen y adopción

La revisión independiente de AUD-001…AUD-022 está en `evidence/QA-FINAL-RC7.md`. Firefox conserva una observación P2 intermitente de Guardar con ratón; el caso pasó en 12/12 repeticiones y una suite F2-A1 completa posterior. Impresión PDF real y táctil físico pendientes de QA manual. Ninguna fila ni RC7 se considera adoptada antes de la confirmación expresa de Wascar.

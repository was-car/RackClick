# rc5: alimentación y vista trasera
2026-09-26. Candidata. Base adoptada v0.8.6; v0.8.7 no incluida.

## Cambio solicitado
Botones Frontal y Trasera con texto junto al rack. El informe de cliente aprobado se conserva: IRClientReport byte-idéntico a rc4, comprobado en tests/test_power.py. Los equipos adicionales de un proyecto se muestran naturalmente en sus informes.

PDU: regleta de distribución de alimentación. Para esta candidata se usa montaje horizontal de 1U, editable con los mismos controles de un dispositivo. No se finge un montaje vertical 0U: ese modelo requeriría ubicación lateral y revisión de cálculos de ocupación. Referencia oficial Eaton: https://www.eaton.com/us/en-us/products/backup-power-ups-surge-it-power-distribution/power-distribution-for-it-equipment/rack-pdu-buying-guide.html (consulta 2026-09-26).

## Modelo y límites
Se mantiene type=power en el JSON v0.8. Cada puerto puede incluir rackclickFace y rackclickPowerRole (inlet/outlet). Rol ausente significa sin especificar. Los valores inválidos se rechazan en validación de presentación y de importación. Configurar caras permite editar explícitamente ambos atributos, con undo/redo. La forma del conector es ilustrativa; no certifica IEC concreto, tensión o intensidad.

Las conexiones nuevas rechazan power↔datos y dos roles iguales explícitos. Rol sin especificar mantiene la compatibilidad legacy. Los datos importados existentes no se migran ni cablean automáticamente. Tampoco se eliminan conexiones antiguas contradictorias. No hay simulación de continuidad interna, carga, tensión, autonomía, conmutación, protección ni capacidad eléctrica.

Los presets nuevos de servidor/NAS/SAN tienen dos entradas de alimentación; switches/router/firewall/conversor tienen una. PDU: una entrada y ocho salidas; UPS: una entrada y cuatro salidas. Son valores genéricos editables, nunca especificaciones de fabricante. Los dispositivos ya existentes conservan puertos e IDs. Para añadir alimentación a uno existente: Editar dispositivo → agregar grupo Power → Guardar → Configurar caras → Trasera y rol explícito.

## Demos
Los diez clientes conservan 68 racks. Cada rack tiene UPS/PDU y conexiones sintéticas UPS→PDU→equipos. Las dos fuentes de un servidor están conectadas a la misma PDU: NO representan redundancia A/B. La entrada de la UPS queda sin upstream documentado. No se muestra ni se afirma alimentación de red pública. Los puertos nuevos tienen IDs únicos y número consecutivo dentro del tipo.

## Evidencias
- tests-power.txt: conexiones con dos clics, rechazo de pares inválidos, role edit/undo/redo, recarga persistente, exportación, informe sin cambios.
- qa-summary.json: regresión de núcleo y estructura.
- visual-clients/summary.json: combinaciones visuales realizadas, cobertura limitada explícita.
- review-rc5/: revisión independiente focalizada.
- QA manual del usuario pendiente. Aprobar visualmente el informe no implica adoptar rc5 ni acreditar todos los flujos.

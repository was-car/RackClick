# RackClick RC8 · Änderungen für Techniker

**Kandidat, nicht übernommen.** Das vertraute Rack-Layout bleibt erhalten. Keine Serverinstallation erforderlich.

## Infrastruktur und Geräte

Speichern/Abbrechen stehen oben im Infrastruktur-Dialog. Änderungen bleiben bis Speichern Entwurf. Im Rack-Editor kann Standort aus Vorschlägen des aktuellen Kunden gewählt oder frei eingegeben werden; Kundenzuordnung bleibt unter Infrastruktur.

Neue Geräte: Favoriten, eigene Vorlagen, danach Katalog. Name ist kein Suchfilter.33generische bearbeitbare Vorlagen, einschließlich8neuer Varianten. Ein Access Point wird organisatorisch als1U dargestellt, nicht als geprüftes19-Zoll-Modell. Portgruppen eigener Geräte können vorne/hinten/automatisch angeordnet werden. Keine Herstellerzertifizierung.

Nur Dunkel/Hell; alte Einstellungen semidark→dunkel und silver→hell. Geräte- und Portinformationen beim Überfahren zeigen vorhandene Metadaten, dokumentierte Watt und Kabelnotizen. Werte sind Dokumentation, keine Live-Telemetrie.

## PoE und Verkabelung

PoE aus/ein verschiebt keinen RJ45-Port. Die Summe berücksichtigt aktivierte PoE-RJ45-Ports;0W ist ein bekannter Wert, fehlender Wert wird getrennt gezählt. Netzanschluss-Watt gehören nicht in diese Summe. Im Gerätekontextmenü Portstatus-Bereich öffnen, Von/Bis eingeben und PoE ein/aus wählen. Nur geeignete RJ45-Ports im Bereich ändern sich. IDs, Wattangaben und Kabel bleiben erhalten; Strg+Z/Y ist verfügbar.

Einfacher Klick auf belegten Port öffnet nach kurzer Doppelklick-Erkennung den Kabeldialog. **Doppelklick auf eindeutig belegten Port startet Neu verbinden.** Alten Port als festen Endpunkt behalten, freien neuen Zielport anklicken. Das alte Kabel bleibt bis zur gültigen Änderung bestehen; Farbe/Notiz/ID werden übernommen. Escape oder Abbrechen lässt es unverändert. Reservierte Ports benötigen Bestätigung, disabled/faulty sind blockiert. Mehrdeutig doppelt belegte Ursprünge werden nicht automatisch umgesteckt. Doppelklick auf freien Port bleibt Schnellbeschriftung. Normales Click-Click zwischen freien Ports bleibt unmittelbar.

Bulk-Start ist die Position in der gefilterten Liste freier Ports, nicht notwendigerweise die aufgedruckte Nummer. Vorschau der konkreten Endpunkte prüfen;25–48 sind24Ports. Doppelte historische Belegung wird gemeldet und nicht still gelöscht. Das Offline-Modell prüft keine vollständige elektrische/optische Kompatibilitätsmatrix und simuliert keine interne Switch-/Panel-Schaltung.

## Export und Rückkehr

Kundenreport zeigt eingebettetes Rasterlogo und Techniker. Der PDF-Button im Rack öffnet denselben modernen druckbaren Bericht; im Druckdialog PDF speichern. Kunden-CSV und Etiketten aller Kundenracks sind auf der Projektseite erreichbar. CSV der gesamten Infrastruktur ist eindeutig als Gesamtbestand ausgewiesen; Kundenspalte verhindert Verwechslungen gleichnamiger Racks. Globales JSON/Rettungsbundle kann Daten aller Kunden enthalten, nicht ungeprüft weitergeben. Einzelrack-JSON war schon vorhanden; rackübergreifende Verbindungen benötigen vollständiges Kunden-/Gesamtbackup. QR bleibt dekorativ.

## Betrieb und Grenzen

Nur eine Browser-Registerkarte zur Bearbeitung verwenden. RC8 fügt keine Mehrbenutzer-Sperren zur Anwendung hinzu. Browser-Speicher ist kein externes Backup. Vor Wechsel JSON exportieren. Firefox-Fehlerbehebungsmodus ist nicht RackClicks abgesicherter Datenrettungsmodus. Notfallprüfungen nur mit synthetischen Daten in separatem Profil.

Manual-Notizen können exportiert/importiert werden. Ungültige Rohdaten werden nicht überschrieben. Bei Quotenfehlern oder Konflikten Entwurf herunterladen, bevor Seite geschlossen wird. Für vollständigen Kapiteldruck den Druckbutton im Manual verwenden.

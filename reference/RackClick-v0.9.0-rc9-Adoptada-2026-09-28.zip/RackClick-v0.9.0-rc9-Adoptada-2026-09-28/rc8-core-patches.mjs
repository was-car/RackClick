// RC8: atomic reconnect, transient selection validity, PoE range and role validation.
import{readFileSync}from'node:fs';
const once=(s,a,b)=>{const p=s.split(a);if(p.length!==2)throw Error('RC8 core anchor '+a.slice(0,90)+' ['+(p.length-1)+']');return p.join(b)};
export const RC8_CORE_WORDS={
 en:{reconnect:'Reconnect: choose a free destination port. The current cable remains until the new connection is saved.',reconnectBlocked:'This cable cannot be reconnected here. Check occupancy, state and client.',batchPoe:'PoE for RJ45 ports in this range',poeOn:'PoE on',poeOff:'PoE off',roleConflict:'This role change contradicts an existing power connection. No changes saved.',emptyRange:'No eligible RJ45 ports in this range.',reconnected:'Cable reconnected; attributes preserved.',cancel:'Cancel',bulkHint:'Start positions refer to the ordered list of free ports, not the printed port number.'},
 de:{reconnect:'Neu verbinden: freien Zielport wählen. Das bisherige Kabel bleibt bis zum Speichern bestehen.',reconnectBlocked:'Dieses Kabel kann hier nicht neu verbunden werden. Belegung, Status und Kunde prüfen.',batchPoe:'PoE für RJ45-Ports in diesem Bereich',poeOn:'PoE ein',poeOff:'PoE aus',roleConflict:'Diese Rollenänderung widerspricht einer bestehenden Stromverbindung. Keine Änderung gespeichert.',emptyRange:'Keine geeigneten RJ45-Ports in diesem Bereich.',reconnected:'Kabel neu verbunden; Eigenschaften erhalten.',cancel:'Abbrechen',bulkHint:'Startpositionen beziehen sich auf die geordnete Liste freier Ports, nicht auf die aufgedruckte Portnummer.'},
 es:{reconnect:'Reconectar: elige un puerto de destino libre. El cable actual se conserva hasta guardar la nueva conexión.',reconnectBlocked:'No se puede reconectar este cable aquí. Revisa ocupación, estado y cliente.',batchPoe:'PoE de puertos RJ45 en este rango',poeOn:'PoE encendido',poeOff:'PoE apagado',roleConflict:'El cambio de rol contradice una conexión de alimentación existente. No se guardó ningún cambio.',emptyRange:'No hay puertos RJ45 elegibles en este rango.',reconnected:'Cable reconectado; atributos conservados.',cancel:'Cancelar',bulkHint:'Las posiciones de inicio corresponden a la lista ordenada de puertos libres, no al número impreso del puerto.'}
};
export function rc8CorePatches(source){
 for(const l of ['de','es'])if(Object.keys(RC8_CORE_WORDS[l]).sort().join('|')!==Object.keys(RC8_CORE_WORDS.en).sort().join('|'))throw Error('Core i18n '+l);
 source=once(source,'function RackClick() {',readFileSync(new URL('./src/rc8-core.jsxinc',import.meta.url),'utf8')+'\nconst RC8_CORE_WORDS='+JSON.stringify(RC8_CORE_WORDS)+';\nfunction RackClick() {\n const [rc8Reconnect,setRc8Reconnect]=useState(null);');
 source=once(source,'rack={rack} allConns={allConns} colors={cm} selection={sp}','rack={rack} project={project} allConns={allConns} colors={cm} selection={sp}');
 source=once(source,'  const cm = {}; allConns.forEach',`  useEffect(()=>{
   const valid=x=>{const p=project.racks.flatMap(r=>r.devs).find(d=>d.id===x.did)?.ports.find(p=>p.id===x.pid);return p&&!['disabled','faulty'].includes(p.status)};
   if(sp&&!valid(sp))setSp(null);if(crossSel&&!valid(crossSel))setCrossSel(null);
   if(rc8Reconnect&&(!valid(rc8Reconnect)||view!=='rack'||!rc8AllLinks(project).some(c=>c.id===rc8Reconnect.connectionId)))setRc8Reconnect(null);
  },[project,sp,crossSel,rc8Reconnect,view]);
  const cm = {}; allConns.forEach`);
 source=once(source,'    const nl = prompt(t("promptQuickLabel")',`    const occupied=rc8AllLinks(project).filter(c=>(c.fd===did&&c.fp===pid)||(c.td===did&&c.tp===pid));
    if(occupied.length){if(occupied.length!==1||['disabled','faulty'].includes(port.status)){noti(RC8_CORE_WORDS[lang].reconnectBlocked,'error');return;}setRc8Reconnect({did,pid,connectionId:occupied[0].id});setSp(null);setCrossSel(null);setSc(null);return;}
    const nl = prompt(t("promptQuickLabel")`);
 source=once(source,'  }, [devs, t]);','  }, [devs, t, project, lang]);');
 source=once(source,'if (e.key === "Escape") { setSc(null);','if (e.key === "Escape") { setRc8Reconnect(null);setSc(null);');
 source=once(source,'  const onPort = useCallback((did, pid) => {',`  const onPort = useCallback((did, pid) => {
    if(rc8Reconnect){
      if(rc8Reconnect.did===did&&rc8Reconnect.pid===pid){setRc8Reconnect(null);return;}
      try{const result=rc8ReconnectProject(project,rc8Reconnect,{did,pid});
        if(result.reserved&&!confirm(t('confirmReserved')))return;
        pushUndo('Reconnect cable');setProject(result.project);setRc8Reconnect(null);setSc(null);setSp(null);setCrossSel(null);noti(RC8_CORE_WORDS[lang].reconnected,'success');
      }catch{noti(RC8_CORE_WORDS[lang].reconnectBlocked,'error');}return;
    }`);
 source=once(source,'[sp, devs, conns, allConns, crossSel, activeRackId, project, pushUndo, groupColors, nextCableColor]','[sp, devs, conns, allConns, crossSel, activeRackId, project, pushUndo, groupColors, nextCableColor, rc8Reconnect, lang]');
 source=once(source,'      <div className="ir-layout">',`      {rc8Reconnect&&<div className="ir-connect-hint" role="status">{RC8_CORE_WORDS[lang].reconnect}<button onClick={()=>setRc8Reconnect(null)}>{RC8_CORE_WORDS[lang].cancel}</button></div>}
      <div className="ir-layout">`);
 source=once(source,'  const batchPortColor = useCallback',`  const batchPortPoe=(devId,from,to,value)=>{const dev=devs.find(d=>d.id===devId);const eligible=dev?.ports.filter(p=>p.gn>=from&&p.gn<=to&&['rj45','rj45_poe'].includes(p.type))||[];if(!eligible.length){noti(RC8_CORE_WORDS[lang].emptyRange,'info');return;}pushUndo('Batch PoE');const ids=new Set(eligible.map(p=>p.id));setDevs(ds=>ds.map(d=>d.id!==devId?d:{...d,ports:d.ports.map(p=>ids.has(p.id)?{...p,poe:value,type:value?'rj45_poe':'rj45'}:p)}));setSp(null);setCrossSel(null);};
  const batchPortColor = useCallback`);
 source=once(source,'otherRacks, onMoveToRack, onBatchStatus, onBatchColor, onSaveTemplate','otherRacks, onMoveToRack, onBatchStatus, onBatchPoe, lang, onBatchColor, onSaveTemplate');
 source=once(source,'onBatchStatus={batchPortStatus} onBatchColor','onBatchStatus={batchPortStatus} onBatchPoe={batchPortPoe} lang={lang} onBatchColor');
 source=once(source,'      <div onClick={() => setShowBatchColor(!showBatchColor)}',`      {showBatch&&<div className="rc8-batch-poe"><small>{RC8_CORE_WORDS[lang].batchPoe}</small>{[true,false].map(value=><button key={String(value)} onClick={()=>{onBatchPoe(dev.id,batchRange.from,batchRange.to,value);onClose();}}>{RC8_CORE_WORDS[lang][value?'poeOn':'poeOff']}</button>)}</div>}
      <div onClick={() => setShowBatchColor(!showBatchColor)}`);
 // Reject contradictory edits without silently deleting documented links.
 if(source.split("onApply={(values,roles)=>{pushUndo('Port faces');").length!==3)throw Error('Expected two role editors');
 source=source.replaceAll("onApply={(values,roles)=>{pushUndo('Port faces');",`onApply={(values,roles)=>{const edited={...irFaceDevice,ports:irFaceDevice.ports.map(p=>({...p,rackclickPowerRole:roles[p.id]}))};const lookup=(did,pid)=> (did===edited.id?edited:project.racks.flatMap(r=>r.devs).find(d=>d.id===did))?.ports.find(p=>p.id===pid);if(rc8AllLinks(project).some(c=>(c.fd===edited.id||c.td===edited.id)&&!irPowerPairAllowed(lookup(c.fd,c.fp),lookup(c.td,c.tp)))){noti(RC8_CORE_WORDS[lang].roleConflict,'error');return;}pushUndo('Port faces');`);
 source=source.replaceAll('setProject(top.project);','setRc8Reconnect(null);setProject(top.project);');
 source=once(source,'function BulkConnectModal({ devs, conns, allConns, onBulk, onClose, t })','function BulkConnectModal({ devs, conns, allConns, onBulk, onClose, t, lang })');
 source=once(source,'onBulk={doBulkConnect} onClose','lang={lang} onBulk={doBulkConnect} onClose');
 source=once(source,'⚡ BULK CONNECT (1:1)</div>','⚡ BULK CONNECT (1:1)</div><p className="rc8-bulk-hint">{RC8_CORE_WORDS[lang].bulkHint}</p>');
 // Legacy backup counter must not subtract non-PoE watts either.
 source=source.replaceAll('dev.ports.reduce((s,p)=>s+(p.watts||0),0)','irPoeStats(dev).sum');
 return source;
}

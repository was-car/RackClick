import json
from pathlib import Path
from qa_support import sync_playwright
R=Path(__file__).resolve().parents[1];out=R/'evidence/power-dialogs';out.mkdir(exist_ok=True);rows=[];errors=[]
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context();p=c.new_page();p.on('pageerror',lambda e:errors.append(str(e)));p.on('dialog',lambda d:d.accept());p.goto((R/'dist/RackClick-v0.9.0-rc6-Offline.html').as_uri())
 for lang in ['en','de','es']:
  for width in [1440,390]:
   p.evaluate('l=>{localStorage.setItem(SAVE_KEY,JSON.stringify(irDemo(l)));localStorage.setItem(LANG_KEY,l)}',lang);p.set_viewport_size({'width':width,'height':1000});p.reload();p.locator('.ir-client-card').first.click()
   if width==390:p.locator('.ir-mobile-nav').click()
   p.locator('.ir-racks button').first.click();p.locator('[data-face="rear"]').click();p.locator('[data-devid="demo-c1-r1-pdu"] .ir-device-actions button').nth(2).click();p.locator('dialog[open]').wait_for()
   # Accessible selectors exist for face and role for every power port.
   assert p.locator('dialog select').count()==18
   assert p.locator('dialog').evaluate('(d)=>d.scrollWidth<=d.clientWidth+1')
   assert p.evaluate('document.documentElement.scrollWidth<=innerWidth+1')
   p.screenshot(path=str(out/f'{lang}-{width}.png'),full_page=True);p.keyboard.press('Escape');rows.append({'lang':lang,'width':width,'pass':True})
 assert not errors;c.close();b.close()
(out/'summary.json').write_text(json.dumps({'rows':rows,'errors':errors},indent=2));print('POWER DIALOGS PASS',len(rows))

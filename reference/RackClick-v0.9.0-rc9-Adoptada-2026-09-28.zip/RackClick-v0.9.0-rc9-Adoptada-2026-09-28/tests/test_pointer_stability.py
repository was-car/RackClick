import json,os
from pathlib import Path
from qa_support import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=Path(os.environ.get('RACKCLICK_HTML',ROOT/'dist/RackClick-v0.9.0-rc6-Offline.html')).resolve().as_uri()
g={'version':'0.8','name':'Pointer QA','racks':[{'id':'r','name':'Rack','size':12,'location':'Lab','devs':[{'id':'d','name':'Switch','u':1,'preset':'sw24','ports':[{'id':'p1','gn':1,'type':'rj45'},{'id':'p2','gn':2,'type':'rj45'}]}],'conns':[]}],'crossConns':[]}
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context();p=c.new_page();p.add_init_script('localStorage.setItem("rackclick_autosave_v08",'+json.dumps(json.dumps(g))+')');p.goto(HTML);p.locator('.ir-racks button').first.click()
 port=p.locator('[data-vport="p1"]');before=port.bounding_box();port.click();after=port.bounding_box()
 assert abs(before['x']-after['x'])<.5 and abs(before['y']-after['y'])<.5
 print('PASS first Click-Click selection keeps exact port position')
 p.keyboard.press('Escape');p.once('dialog',lambda d:d.accept('Dose-01'));port.dblclick();p.wait_for_timeout(600)
 assert json.loads(p.evaluate('localStorage.getItem(SAVE_KEY)'))['racks'][0]['devs'][0]['ports'][0]['label']=='Dose-01'
 assert not p.get_by_text('✎ EDIT DEVICE',exact=True).count()
 print('PASS double-click labels port without opening device editor')
 c.close();b.close()

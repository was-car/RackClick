"""Behavioral regression for AUD-009/012/013/014/017.
Runs against immutable rc6 or generated rc7. Output names identify the artifact.
"""
import argparse, copy, json, re, sys, traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from qa_support import sync_playwright

ap=argparse.ArgumentParser()
ap.add_argument('--html',required=True)
ap.add_argument('--fixture',required=True)
ap.add_argument('--output',required=True)
a=ap.parse_args()
html=Path(a.html).resolve();fixture=json.loads(Path(a.fixture).read_text());results=[]

def project(page):
    page.wait_for_timeout(180)
    return page.evaluate('JSON.parse(localStorage.getItem(SAVE_KEY))')

def same(a,b):return a['racks']==b['racks'] and a['crossConns']==b['crossConns']

def record(name,condition,actual):
    results.append({'id':name,'fixed_behavior':bool(condition),'actual':actual})
    print(name,'PASS' if condition else 'REPRODUCED FAILURE',actual,flush=True)

def menu(page):
    page.locator('.ir-terminal[data-vport="sw-a-p1"]').click(button='right')
    return page.locator('.ir-context')

with sync_playwright() as w:
    browser=w.chromium.launch()
    for scenario in ['reorder','watts','note','cross-note','patch-status','height','move-full','delete','manager']:
        context=browser.new_context(accept_downloads=True)
        context.route(re.compile(r'^https?://'),lambda route:route.abort())
        page=context.new_page();page.set_default_timeout(5500)
        page.on('dialog',lambda dialog:dialog.accept())
        errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
        try:
            page.goto(html.as_uri())
            if scenario=='move-full':
                seeded=copy.deepcopy(fixture);seeded['racks'][1]['size']=sum(d['u'] for d in seeded['racks'][1]['devs'])
                page.evaluate('v=>localStorage.setItem(SAVE_KEY,JSON.stringify(v))',seeded)
                page.reload();page.locator('.ir-racks button').first.click()
            elif scenario=='manager':
                seeded=copy.deepcopy(fixture);location={'client':'Customer A','site':'Site A','building':'Building A','room':'Server room'}
                seeded['rackclickLocations']=[location];seeded['rackclickClientMeta']=[{'client':'Customer A','technician':'Tech preserved'}]
                for rack in seeded['racks']:rack['rackclickLocation']=location.copy()
                page.evaluate('v=>localStorage.setItem(SAVE_KEY,JSON.stringify(v))',seeded)
                page.reload();page.locator('.ir-client-card').first.click()
            else:
                page.evaluate('v=>localStorage.setItem(SAVE_KEY,JSON.stringify(v))',fixture)
                page.reload();page.locator('.ir-racks button').first.click()
            if scenario=='reorder':
                before=project(page)
                page.locator('.ir-device-row[data-devid="sw-a"]').get_by_role('button',name='Move down').click()
                changed=project(page)['racks'][0]['devs'][1]['id']=='sw-a'
                page.keyboard.press('Control+z');restored=same(project(page),before)
                page.keyboard.press('Control+y');redone=project(page)['racks'][0]['devs'][1]['id']=='sw-a'
                record('AUD-012-move-undo',changed and restored and redone,f'changed={changed}, undo={restored}, redo={redone}')
            if scenario=='watts':
                before=project(page)
                menu(page).locator('input[type=number]').fill('0');page.locator('.ir-rack-title h1').click()
                zero=project(page)['racks'][0]['devs'][0]['ports'][0].get('watts')==0
                page.keyboard.press('Control+z');restored=same(project(page),before)
                page.keyboard.press('Control+y');redone=project(page)['racks'][0]['devs'][0]['ports'][0].get('watts')==0
                menu(page).locator('input[type=number]').fill('-5');page.locator('.ir-rack-title h1').click()
                negative_rejected=project(page)['racks'][0]['devs'][0]['ports'][0].get('watts')==0
                page.reload();persisted=project(page)['racks'][0]['devs'][0]['ports'][0].get('watts')==0
                page.locator('.ir-racks button').first.click() if page.locator('.ir-terminal').count()==0 else None
                menu(page).locator('input[type=number]').fill('15.4');page.locator('.ir-rack-title h1').click()
                fractional=project(page)['racks'][0]['devs'][0]['ports'][0].get('watts')==15.4
                page.keyboard.press('Control+z');fractional_undo=project(page)['racks'][0]['devs'][0]['ports'][0].get('watts')==0
                record('AUD-013-watts-undo-0-negative',zero and restored and redone and negative_rejected and persisted and fractional and fractional_undo,f'zero={zero}, undo={restored}, redo={redone}, reject={negative_rejected}, reload={persisted}, 15.4={fractional}, fraction_undo={fractional_undo}')
            if scenario=='note':
                before=project(page);orig=before['racks'][0]['conns'][0].get('note')
                page.locator('.ir-connection-card').first.click();field=page.locator('input[placeholder="z.B. Cat6a 15m blau, LWL OS2, Trunk..."]')
                field.fill('');field.press_sequentially('Cable QA 123');field.blur();edited=project(page)['racks'][0]['conns'][0].get('note')=='Cable QA 123'
                page.keyboard.press('Control+z');restored=project(page)['racks'][0]['conns'][0].get('note')==orig
                ui_closed=page.get_by_text('Connection',exact=True).count()==0
                page.keyboard.press('Control+y');redone=project(page)['racks'][0]['conns'][0].get('note')=='Cable QA 123'
                page.reload();persisted=project(page)['racks'][0]['conns'][0].get('note')=='Cable QA 123'
                record('AUD-012-note-undo',edited and restored and redone and persisted and ui_closed,f'edited={edited}, undo={restored}, redo={redone}, reload={persisted}, stale_panel_closed={ui_closed}')
            if scenario=='cross-note':
                before=project(page);orig=before['crossConns'][0].get('note')
                page.locator('.ir-connection-card').nth(3).click();field=page.locator('input[placeholder="z.B. Cat6a 15m blau, LWL OS2, Trunk..."]')
                field.fill('Cross QA');field.blur();edited=project(page)['crossConns'][0].get('note')=='Cross QA'
                page.keyboard.press('Control+z');restored=project(page)['crossConns'][0].get('note')==orig
                page.keyboard.press('Control+y');redone=project(page)['crossConns'][0].get('note')=='Cross QA'
                record('AUD-012-cross-note-undo',edited and restored and redone,f'edited={edited}, undo={restored}, redo={redone}')
            if scenario=='patch-status':
                before=project(page);orig=before['racks'][0]['conns'][0].get('patchStatus')
                page.locator('.ir-connection-card').first.click();page.get_by_role('button',name='✅ Done',exact=True).click()
                edited=project(page)['racks'][0]['conns'][0].get('patchStatus')=='done'
                page.keyboard.press('Control+z');restored=project(page)['racks'][0]['conns'][0].get('patchStatus')==orig
                page.keyboard.press('Control+y');redone=project(page)['racks'][0]['conns'][0].get('patchStatus')=='done'
                record('AUD-012-patch-status-undo',edited and restored and redone,f'edited={edited}, undo={restored}, redo={redone}')
            if scenario=='height':
                before=project(page)
                page.locator('.ir-device-row[data-devid="sw-a"] .ir-device-actions button[title="Edit"]').click()
                modal=page.get_by_text('✎ EDIT DEVICE',exact=True).locator('..')
                modal.locator('input[type=number]').first.fill('100');modal.get_by_role('button',name='Save',exact=True).click()
                unchanged=same(project(page),before)
                still_open=modal.count()>0
                record('AUD-014-device-U',unchanged and still_open,f'project_unchanged={unchanged}, editor_open={still_open}')
            if scenario=='move-full':
                before=project(page)
                page.locator('.ir-device-row[data-devid="sw-a"] .ir-device-actions button[title="Device options"]').click()
                page.locator('.ir-context').get_by_text(re.compile('Rack B')).click()
                after=project(page);unchanged=same(after,before)
                record('AUD-014-move-full-rack',unchanged,f'unchanged={unchanged}, rack_B_U={sum(d["u"] for d in after["racks"][1]["devs"])}/{after["racks"][1]["size"]}')
            if scenario=='delete':
                before=project(page)
                page.locator('.ir-device-row[data-devid="sw-a"] input[type=checkbox]').check()
                field=page.locator('input[placeholder*="Search..."]').last
                field.fill('abc');field.press('Home');field.press('Delete')
                text=field.input_value();intact=same(project(page),before)
                record('AUD-017-delete-in-text',text=='bc' and intact,f'text={text!r}, inventory_intact={intact}')
            if scenario=='manager':
                old=project(page)
                page.locator('.ir-manage').click();dialog=page.locator('dialog[open]')
                dialog.locator('.ir-location-list button').filter(has_text=re.compile('^Edit$')).first.click()
                dialog.locator('[data-field="client"]').fill('Renamed from manager')
                dialog.locator('form button').click();dialog.locator('footer').get_by_role('button',name='Save',exact=True).click()
                after=project(page)
                meta=next((m for m in after.get('rackclickClientMeta',[]) if m.get('client')=='Renamed from manager'),None)
                old_name=old['racks'][0]['rackclickLocation']['client']
                old_meta=any(m.get('client')==old_name for m in after.get('rackclickClientMeta',[]))
                rack=after['racks'][0]['rackclickLocation']['client']=='Renamed from manager'
                page.reload();survive=any(m.get('client')=='Renamed from manager' and m.get('technician')=='Tech preserved' for m in project(page).get('rackclickClientMeta',[]))
                record('AUD-009-manager-rename-meta',rack and meta and meta.get('technician')=='Tech preserved' and not old_meta and survive,f'rack={rack}, meta={meta}, old_orphan={old_meta}, reload={survive}')
            if errors:record('JS-'+scenario,False,errors)
        except Exception as error:
            record('EXCEPTION-'+scenario,False,repr(error))
            (Path(a.output).parent/(scenario+'-failure.png')).parent.mkdir(parents=True,exist_ok=True)
            page.screenshot(path=str(Path(a.output).parent/(scenario+'-failure.png')),full_page=True)
            traceback.print_exc()
        finally:context.close()
    browser.close()
Path(a.output).parent.mkdir(parents=True,exist_ok=True)
Path(a.output).write_text(json.dumps({'html':str(html),'results':results},ensure_ascii=False,indent=2))
if len(results)!=9 or any(not r['fixed_behavior'] for r in results):sys.exit(1)

"""Atomic reconnect oracle: actual compiled helper, synthetic ports, no user data."""
import json, hashlib
from pathlib import Path
from qa_support import sync_playwright
R=Path(__file__).resolve().parents[1];H=R/'dist'/f'RackClick-v{(R/"VERSION").read_text().strip()}-Offline.html'
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context();p=c.new_page();p.goto(H.as_uri())
 results=p.evaluate('''()=>{
 const rows=[],ck=(name,ok)=>{rows.push({name,passed:!!ok});if(!ok)throw Error(name)};
 const port=(id,gn,status='free',type='rj45')=>({id,gn,status,type,poe:false,watts:15,color:'#123456'});
 const d=(id,ports)=>({id,name:id,u:1,ports});
 const a=d('a',[port('a1',1),port('a2',2)]),b=d('b',[port('b1',1),port('b2',2)]),z=d('z',[port('z1',1)]);
 const link={id:'c1',fd:'a',fp:'a1',td:'b',tp:'b1',fn:'a',tn:'b',fpn:1,tpn:1,fpt2:'rj45',tpt2:'rj45',color:'#aabbcc',note:'Hostile < & text',patchStatus:'verified',createdAt:'fixed'};
 const project={version:'0.8',name:'Synthetic',racks:[{id:'r1',name:'R1',size:24,rackclickLocation:{client:'A',site:'Site',building:'Building',room:'Room'},devs:[a,b],conns:[link]},{id:'r2',name:'R2',size:24,rackclickLocation:{client:'A',site:'Site',building:'Building',room:'Room'},devs:[z],conns:[]}],crossConns:[]};
 const before=JSON.stringify(project),intent={did:'a',pid:'a1',connectionId:'c1'};
 const local=rc8ReconnectProject(project,intent,{did:'b',pid:'b2'});const c=local.project.racks[0].conns[0];
 ck('Local reconnect atomic original unchanged',JSON.stringify(project)===before&&c.tp==='b2'&&local.project.racks[0].conns.length===1);
 ck('Cable identity and attributes preserved',['id','color','note','patchStatus','createdAt'].every(k=>c[k]===link[k]));
 ck('Device and port records unchanged',JSON.stringify(local.project.racks.map(r=>r.devs))===JSON.stringify(project.racks.map(r=>r.devs)));
 const cross=rc8ReconnectProject(project,intent,{did:'z',pid:'z1'}).project;
 ck('Local to cross exactly one link',cross.racks[0].conns.length===0&&cross.crossConns.length===1&&cross.crossConns[0].rackFrom==='r1'&&cross.crossConns[0].rackTo==='r2');
 const back=rc8ReconnectProject(cross,intent,{did:'b',pid:'b2'}).project;
 ck('Cross to local clears rack endpoint fields',back.crossConns.length===0&&back.racks[0].conns.length===1&&!('rackFrom' in back.racks[0].conns[0]));
 for(const status of ['disabled','faulty']){const x=structuredClone(project);x.racks[0].devs[1].ports[1].status=status;const raw=JSON.stringify(x);let rejected=false;try{rc8ReconnectProject(x,intent,{did:'b',pid:'b2'})}catch{rejected=true}ck(status+' rejects without mutation',rejected&&raw===JSON.stringify(x));}
 let x=structuredClone(project);x.racks[0].devs[1].ports[1].status='reserved';ck('Reserved candidate requires confirmation',rc8ReconnectProject(x,intent,{did:'b',pid:'b2'}).reserved===true);
 x=structuredClone(project);x.racks[1].rackclickLocation.client='B';let rejected=false;try{rc8ReconnectProject(x,intent,{did:'z',pid:'z1'})}catch{rejected=true}ck('Cross-client destination rejected',rejected);
 x=structuredClone(project);x.racks[0].conns.push({...link,id:'c2',td:'z',tp:'z1'});rejected=false;try{rc8ReconnectProject(x,intent,{did:'b',pid:'b2'})}catch{rejected=true}ck('Ambiguous double-occupied source rejected intact',rejected&&x.racks[0].conns.length===2);
 x=structuredClone(project);x.racks[0].devs[1].ports[1].type='power';rejected=false;try{rc8ReconnectProject(x,intent,{did:'b',pid:'b2'})}catch{rejected=true}ck('Power/data mismatch rejected',rejected);
 return rows;
 }''');c.close();b.close()
for r in results: print('PASS',r['name'])
out=R/'evidence/rc8/core';out.mkdir(parents=True,exist_ok=True);(out/'atomic-results.json').write_text(json.dumps({'sha256':hashlib.sha256(H.read_bytes()).hexdigest(),'results':results},indent=2))

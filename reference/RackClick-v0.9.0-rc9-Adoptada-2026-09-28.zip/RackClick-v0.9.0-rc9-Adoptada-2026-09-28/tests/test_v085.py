"""Browser tests against the delivered candidate, without test hooks in the app."""
import json, os, re
from pathlib import Path
from qa_support import sync_playwright, cache_cdn
ROOT=Path(__file__).resolve().parents[1]
HTML=Path(os.environ.get('RACKCLICK_HTML',ROOT/'rackclick-v0.8.6.html')).resolve().as_uri()
ADDED=json.loads((ROOT/'evidence/i18n-added.json').read_text())
PAYLOAD='A & <img src=x onerror="window.__ATTACK=1"> " \' Ω'
def text(prefix):return prefix+' '+PAYLOAD

def seed(hostile=False):
 val=text if hostile else lambda x:x
 devices=[]
 for i in (1,2):
  devices.append(dict(id=f'd{i}',name=val(f'Device{i}'),icon='↔',color='#2a9d8f',u=1,preset='sw24',ports=[dict(id=f'p{i}',gn=1,type='rj45',status='free',label=val(f'Label{i}'))]))
 conn=dict(id='c1',fd='d1',td='d2',fp='p1',tp='p2',fn=devices[0]['name'],tn=devices[1]['name'],fpn=1,tpn=1,fpt=val('FromType'),tpt=val('ToType'),fpt2='rj45',tpt2='rj45',note=val('Cable'),color='#aabbcc',createdAt='2026-09-24')
 project = dict(version='0.8',name=val('Project'),technician=val('Technician'),racks=[dict(id='r1',name=val('Rack'),location=val('Room'),size=12,devs=devices,conns=[conn]),dict(id='r2',name=val('OtherRack'),location='',size=12,devs=[],conns=[])],crossConns=[],changeLog=[])
 if hostile:
  project['racks'][1]['devs']=[project['racks'][0]['devs'].pop()]
  project['racks'][0]['conns']=[]
  conn.update(rackFrom='r1',rackTo='r2');project['crossConns']=[conn]
 return project

def boot(browser,lang='en',hostile=False):
 ctx=browser.new_context(accept_downloads=True);ctx.set_default_timeout(8000);ctx.route('https://cdnjs.cloudflare.com/**',cache_cdn)
 p=ctx.new_page();data=seed(hostile)
 p.add_init_script('localStorage.setItem("rackclick_autosave_v08",'+json.dumps(json.dumps(data))+');localStorage.setItem("rackclick_lang",'+json.dumps(lang)+');')
 p.goto(HTML);p.get_by_text(data['racks'][0]['name'],exact=True).first.wait_for();return ctx,p,data

def quota(p,key,fail=True):
 p.evaluate('''([key,fail])=>{if(!window.__origSet){window.__origSet=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k===window.__failKey)throw new DOMException('QA','QuotaExceededError');return window.__origSet.call(this,k,v)}}window.__failKey=fail?key:null}''',[key,fail])

def ok(name):print('PASS',name,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch()
 for index,lang in enumerate(('en','de','es')):
  ctx,p,data=boot(b,lang)
  actual=p.evaluate('I18N')
  for key,values in ADDED.items():
   assert actual[lang][key]==values[index]
   assert set(re.findall(r'\{\w+\}',values[0]))==set(re.findall(r'\{\w+\}',values[index]))
  ok(f'i18n {lang}: 32 values and placeholder parity')
  # Native confirm includes translated language and interpolated rack name.
  p.get_by_text('Rack',exact=True).first.click();p.locator('text=✎').first.click()
  assert p.get_by_text('✎ EDIT RACK',exact=True).is_visible()
  messages=[];p.once('dialog',lambda d:(messages.append(d.message),d.dismiss()))
  p.get_by_role('button',name=re.compile(re.escape(actual[lang]['deleteRack']))).click()
  assert messages and messages[0]==ADDED['confirmDeleteRack'][index].replace('{name}','Rack')
  p.keyboard.press('Escape');assert p.get_by_text('✎ EDIT RACK',exact=True).count()==0
  ok(f'confirm and Escape {lang}')
  # Save as template: failure, retry, then failed and successful deletion.
  quota(p,'rackclick_custom_templates')
  p.locator('.ir-device-row[data-devid="d1"]').first.click(button='right')
  p.get_by_text(actual[lang]['saveAsTemplate'],exact=False).click()
  assert ADDED['notiTemplatesFailed'][index] in p.inner_text('body')
  assert p.evaluate("localStorage.getItem('rackclick_custom_templates')") is None
  quota(p,'rackclick_custom_templates',False)
  p.locator('.ir-device-row[data-devid="d1"]').first.click(button='right')
  p.get_by_text(actual[lang]['saveAsTemplate'],exact=False).click()
  assert ADDED['notiTemplateSaved'][index].replace('{name}','Device1') in p.inner_text('body')
  saved=p.evaluate("localStorage.getItem('rackclick_custom_templates')");assert len(json.loads(saved))==1
  p.get_by_role('button',name=p.evaluate('I18N[localStorage.getItem(LANG_KEY)||"en"].addDevice'),exact=True).click()
  row=p.locator('.ir-right button').filter(has_text=re.compile('Device1')).first.locator('..')
  print('TEMPLATE ROW',row.evaluate('(el)=>el.outerHTML')[:1500],flush=True)
  quota(p,'rackclick_custom_templates');row.get_by_role('button',name='×',exact=True).click()
  assert p.evaluate("localStorage.getItem('rackclick_custom_templates')")==saved
  assert row.get_by_role('button',name='×',exact=True).is_visible()
  quota(p,'rackclick_custom_templates',False);row.get_by_role('button',name='×',exact=True).click()
  assert p.evaluate("localStorage.getItem('rackclick_custom_templates')")=='{}'
  ok(f'templates {lang}: failed create/delete and successful retries')
  quota(p,'rackclick_fav_presets');p.locator('.rc8-favorite[aria-pressed=false]').first.click()
  assert ADDED['notiFavoritesFailed'][index] in p.inner_text('body')
  assert p.evaluate("localStorage.getItem('rackclick_fav_presets')") is None
  assert p.locator('.rc8-favorite[aria-pressed=true]').count()==0
  quota(p,'rackclick_fav_presets',False);p.locator('.rc8-favorite[aria-pressed=false]').first.click()
  saved=p.evaluate("localStorage.getItem('rackclick_fav_presets')");assert len(json.loads(saved))==1
  quota(p,'rackclick_fav_presets');p.locator('.rc8-favorite[aria-pressed=true]').first.click()
  assert p.evaluate("localStorage.getItem('rackclick_fav_presets')")==saved
  assert p.locator('.rc8-favorite[aria-pressed=true]').count()>0
  ok(f'favorites {lang}: failed add/remove, successful retry')
  ctx.close()
 ctx,p,data=boot(b,hostile=True);p.get_by_text(data['racks'][0]['name'],exact=True).first.click()
 assert p.evaluate("htmlEsc('&<>\"\\\'')")=='&amp;&lt;&gt;&quot;&#39;'
 ok('htmlEsc five delimiters')
 # Attribute context: only a single title attribute may result.
 attr=p.evaluate('''value=>{const el=document.createElement('div');el.innerHTML='<span title="'+htmlEsc(value)+'"></span>';return [el.firstChild.attributes.length,el.firstChild.title]}''',PAYLOAD)
 assert attr==[1,PAYLOAD];ok('htmlEsc attribute context')
 # The original PDF assertions cover the retained classic exporter. RC8 modern
 # PDF routing is exercised separately by test-reports-browser.py.
 p.locator('.ir-settings').click()
 p.get_by_label('Classic view (recovery only)',exact=True).check()
 p.keyboard.press('Escape')
 p.locator('.ir-client-card').first.click()
 p.locator('.ir-racks button').first.click()
 p.evaluate("window.open=()=>({document:{write:html=>window.__exportHTML=html}})")
 for label,fields in [('🏷️ Label',['Rack','Room','Project','Technician']),('📄 PDF',['Rack','OtherRack','Room','Project','Technician','Device1','Device2','Label1','Label2','Cable','FromType','ToType'])]:
  p.get_by_role('button',name=label,exact=True).click();html=p.evaluate('window.__exportHTML')
  check=ctx.new_page();check.set_content(html)
  assert check.locator('img').count()==0 and not check.evaluate('Boolean(window.__ATTACK)')
  body=check.inner_text('body')
  for field in fields:assert text(field) in body,(label,field,body)
  check.close();ok(label+' preserves literal text and cannot inject elements')
 with p.expect_download() as dl:p.get_by_role('button',name='📊 XLS',exact=True).click()
 html=Path(dl.value.path()).read_text();check=ctx.new_page();check.set_content(html)
 assert check.locator('img').count()==0 and not check.evaluate('Boolean(window.__ATTACK)')
 for field in ['Rack','OtherRack','Room','Project','Technician','Device1','Device2','Label1','Label2','Cable','FromType','ToType']:assert text(field) in check.inner_text('body'),field
 ok('XLS literal text and no injected elements');check.close();ctx.close();b.close()
print('V085 TESTS PASS')

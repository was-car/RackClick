import{readFileSync}from'node:fs';import assert from'node:assert/strict';import{rc8UxPatches}from'../rc8-ux-patches.mjs';
const source=readFileSync(new URL('../evidence/integrated-source.jsx',import.meta.url),'utf8');
assert(source.includes('rc8-device-catalogue'));
assert(source.indexOf('{Object.keys(customTemplates).length > 0 && <div>')<source.indexOf('{CATS.map(cat => ('));
assert(!source.includes('Object.values(THEMES).map'));
assert(source.includes('rackclickFace=d.face'));
assert(source.includes('locations={irLocations(irScope)}'));
assert.throws(()=>rc8UxPatches(''),/RC8 UX/);
console.log('PASS RC8 UX invariants: collections order, 2 themes, custom faces, scoped suggestions, failed anchors');

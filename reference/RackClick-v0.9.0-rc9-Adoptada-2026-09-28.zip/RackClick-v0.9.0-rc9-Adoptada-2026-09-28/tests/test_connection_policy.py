"""UI integration for reserved cross-rack and bulk; real HTML, no app hooks."""
import json, os
from pathlib import Path
from qa_support import sync_playwright,cache_cdn
ROOT=Path(__file__).resolve().parents[1]
HTML=Path(os.environ.get('RACKCLICK_HTML',ROOT/'rackclick-v0.8.6.html')).resolve().as_uri()
def device(d,status):return dict(id=d,name=d,icon='↔',color='#abc123',u=1,preset='Custom',ports=[dict(id=d+'p',type='rj45',gn=1,status=status)])
def project(cross=True,status='reserved'):
 a=device('Switch',status);b=device('Patchpanel','reserved')
 r=dict(id='a',name='Rack A',size=12,location='',devs=[a],conns=[])
 s=dict(id='b',name='Rack B',size=12,location='',devs=[b],conns=[])
 if not cross:r['devs'].append(b);s['devs']=[]
 return dict(version='0.8',name='Policy',technician='',racks=[r,s],crossConns=[],changeLog=[])
def boot(b,data):
 c=b.new_context();c.set_default_timeout(10000);c.route('https://cdnjs.cloudflare.com/**',cache_cdn);p=c.new_page()
 p.add_init_script('localStorage.setItem("rackclick_autosave_v08",'+json.dumps(json.dumps(data))+');localStorage.setItem("rackclick_lang","en")')
 p.goto(HTML);p.get_by_text('Rack A',exact=True).first.click();return c,p
def state(p):
 p.wait_for_timeout(500);return json.loads(p.evaluate('localStorage.getItem(SAVE_KEY)'))
def port(p,d):return p.locator('.ir-device-row[data-devid="'+d+'"] [role="button"][tabindex="0"]').first
def check(n,c):assert c,n;print('PASS',n,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch()
 for status in ['reserved','disabled','faulty']:
  c,p=boot(b,project(status=status));port(p,'Switch').click(button='right')
  p.get_by_text('⬒ Rack B',exact=True).click();dialogs=[]
  p.once('dialog',lambda d:(dialogs.append(d.message),d.dismiss()));port(p,'Patchpanel').click()
  check('cross cancellation/block '+status,not state(p)['crossConns'])
  if status=='reserved':
   check('both reserved prompt only once',dialogs==['Reserved port — connect?'])
   p.once('dialog',lambda d:d.accept());port(p,'Patchpanel').click()
   check('cross accepted',len(state(p)['crossConns'])==1)
   p.keyboard.press('Control+z');check('cross undo',not state(p)['crossConns'])
  else:check('blocked origin without confirmation',not dialogs)
  c.close()
 c,p=boot(b,project(False));p.get_by_title('Bulk connect 1:1',exact=True).click()
 m=p.get_by_text('⚡ BULK CONNECT (1:1)',exact=True).locator('..')
 m.locator('select').nth(0).select_option('Switch');m.locator('select').nth(1).select_option('rj45')
 m.locator('select').nth(2).select_option('Patchpanel');m.locator('select').nth(3).select_option('rj45')
 messages=[];p.once('dialog',lambda d:(messages.append(d.message),d.dismiss()))
 m.get_by_role('button',name='⚡ Connect 1',exact=True).click()
 check('bulk reserved cancel once and unchanged',messages==['Reserved port — connect?'] and not state(p)['racks'][0]['conns'])
 p.once('dialog',lambda d:d.accept());m.get_by_role('button',name='⚡ Connect 1',exact=True).click()
 check('bulk reserved accepted',len(state(p)['racks'][0]['conns'])==1)
 p.keyboard.press('Control+z');check('bulk undo',not state(p)['racks'][0]['conns']);c.close();b.close()
print('CONNECTION POLICY PASS')

"""New GUI and minimal topology fixes: independent observable expectations."""
import copy,json,os,re,tempfile,hashlib
from pathlib import Path
from qa_support import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
VERSION=(ROOT/'VERSION').read_text().strip()
HTML=Path(os.environ.get('RACKCLICK_HTML',ROOT/'dist'/f'RackClick-v{VERSION}-Offline.html')).resolve().as_uri()
G=json.loads((ROOT/'fixtures/golden-test.json').read_text())
SAVE='rackclick_autosave_v08';count=0

def check(name,condition):
 global count
 assert condition,name
 count+=1;print('PASS',name,flush=True)
def boot(b,data):
 c=b.new_context(accept_downloads=True);p=c.new_page();p.set_default_timeout(15000)
 p.add_init_script('if(!localStorage.getItem('+json.dumps(SAVE)+'))localStorage.setItem('+json.dumps(SAVE)+','+json.dumps(json.dumps(data))+');')
 p.goto(HTML);p.locator('.ir-nav').wait_for();return c,p
def state(p):p.wait_for_timeout(900);return json.loads(p.evaluate('localStorage.getItem(SAVE_KEY)'))
with sync_playwright() as pw:
 b=pw.chromium.launch();c,p=boot(b,G);errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 result=p.evaluate('''g=>{let checks={};const snap=JSON.stringify(g);const merged=irAppendProject(g,g);
 checks.counts=merged.racks.length===6&&merged.crossConns.length===6;
 const old=new Set(g.racks.flatMap(r=>r.devs.flatMap(d=>d.ports.map(p=>p.id))));
 checks.identity=merged.racks.slice(3).every(r=>r.devs.every(d=>d.ports.every(p=>!old.has(p.id))));
 checks.ownership=merged.crossConns.slice(3).every(c=>merged.racks.find(r=>r.id===c.rackFrom).devs.some(d=>d.id===c.fd&&d.ports.some(p=>p.id===c.fp))&&merged.racks.find(r=>r.id===c.rackTo).devs.some(d=>d.id===c.td&&d.ports.some(p=>p.id===c.tp)));
 checks.attrs=merged.racks.slice(3).every((r,i)=>r.devs.every((d,j)=>d.ports.every((p,k)=>{const {id,...a}=p,{id:_,...b}=g.racks[i].devs[j].ports[k];return JSON.stringify(a)===JSON.stringify(b)})));
 const moving=g.racks[0].devs[0].id,target=g.racks[1].id,moved=irMoveDevice(g,moving,target);
 checks.move=moved.racks[1].devs.some(d=>d.id===moving)&&!moved.racks[0].devs.some(d=>d.id===moving);
 checks.direction=moved.crossConns.every(c=>moved.racks.find(r=>r.id===c.rackFrom).devs.some(d=>d.id===c.fd)&&moved.racks.find(r=>r.id===c.rackTo).devs.some(d=>d.id===c.td));
 checks.links=[...moved.racks.flatMap(r=>r.conns),...moved.crossConns].length===[...g.racks.flatMap(r=>r.conns),...g.crossConns].length;
 checks.pure=JSON.stringify(g)===snap;
 const bad=structuredClone(g);bad.crossConns[0].fd='fw-c';try{irAssertTopology(bad);checks.reject=false}catch{checks.reject=true}
 const dup=structuredClone(g);dup.crossConns.push({...dup.crossConns[0],id:'synthetic-double'});checks.double=irAssertTopology(dup)===dup;
 return checks}''',G)
 for k,v in result.items():check('Topology '+k,v)
 # Exercise real file input and output; no state setter hooks.
 with tempfile.TemporaryDirectory() as td:
  f=Path(td)/'golden.json';f.write_text(json.dumps(G));bad=Path(td)/'broken.json';bad.write_text('{broken')
  before=state(p)
  with p.expect_file_chooser() as fc:p.get_by_role('button',name=re.compile('Import')).click()
  fc.value.set_files([str(f),str(bad)]);p.wait_for_timeout(500)
  check('Multi-file invalid import is atomic',state(p)['racks']==before['racks'] and state(p)['crossConns']==before['crossConns'])
  with p.expect_file_chooser() as fc:p.get_by_role('button',name=re.compile('Merge')).click()
  fc.value.set_files(str(f));s=state(p)
  check('UI merge preserves all cross links',len(s['racks'])==6 and len(s['crossConns'])==6)
  p.keyboard.press('Control+z');check('UI undo merge restores exact rack topology',state(p)['racks']==before['racks'] and state(p)['crossConns']==before['crossConns'])
  with p.expect_download() as dl:p.keyboard.press('Control+s')
  exported=json.loads(Path(dl.value.path()).read_text())
  check('Save keeps v0.8 schema and round-trip data',exported['version']=='0.8' and exported['racks']==G['racks'] and exported['crossConns']==G['crossConns'])
  with p.expect_file_chooser() as fc:p.get_by_role('button',name=re.compile('Load')).click()
  fc.value.set_files(str(f));check('Load keeps IDs and all attributes',state(p)['racks']==G['racks'])
 p.locator('.ir-racks button').first.click();p.wait_for_timeout(200)
 front_ids=p.locator('.ir-terminal').evaluate_all('(els)=>els.map(e=>e.dataset.vport)')
 p.get_by_role('button',name=re.compile('▤|▥')).first.click()
 rear_ids=p.locator('.ir-terminal').evaluate_all('(els)=>els.map(e=>e.dataset.vport)')
 check('Actual port union across faces / no hidden or duplicated port',set(front_ids).isdisjoint(rear_ids) and set(front_ids+rear_ids)=={q['id'] for d in G['racks'][0]['devs'] for q in d['ports']})
 p.get_by_role('button',name=re.compile('▤|▥')).first.click()
 p.locator('.ir-device-head input').nth(0).check();p.locator('.ir-device-head input').nth(1).check()
 check('Multi-selection accumulates',p.locator('.ir-device-head input:checked').count()==2)
 p.locator('.ir-device-head input').nth(0).uncheck();check('Multi-selection deselects',p.locator('.ir-device-head input:checked').count()==1)
 p.get_by_role('button',name='Clear',exact=True).click()
 p.locator('.ir-terminal').first.focus();p.keyboard.press('Shift+F10');menu=p.locator('.ir-context');check('Keyboard context menu opens',menu.is_visible())
 p.keyboard.press('Escape')
 # Real SVG geometry includes every type; valid local zero-width cable filter.
 filters=p.locator('#ir-shadow');check('Zero-width cable uses userSpaceOnUse',filters.get_attribute('filterUnits')=='userSpaceOnUse')
 check('True version in document title',f'v{VERSION}' in p.title())
 with p.expect_download(timeout=60000) as dl:p.get_by_title('Export rack as PNG (3x)',exact=True).click()
 png=Path(dl.value.path()).read_bytes();(ROOT/'evidence/rack-export-3x.png').write_bytes(png)
 check('PNG 3x export has valid nonempty image',png[:8]==b'\x89PNG\r\n\x1a\n' and len(png)>20000)
 check('No JS errors in integration journey',not errors)
 c.close()
 double=json.loads((ROOT/'fixtures/golden-double-occupancy.json').read_text());c,p=boot(b,double);p.locator('.ir-racks button').first.click()
 check('Double occupancy is visibly declared',p.get_by_text(p.evaluate('IR_WORDS.en.duplicate'),exact=True).is_visible())
 saved=state(p);check('Double occupancy preserves local and cross data',saved['racks']==double['racks'] and saved['crossConns']==double['crossConns']);c.close()
 # All 33 generic presets are added through visible controls with full identities.
 empty={'version':'0.8','name':'Preset laboratory','racks':[{'id':'lab','name':'Rack Laboratory','size':96,'location':'Test','devs':[],'conns':[]}],'crossConns':[],'changeLog':[]}
 c,p=boot(b,empty);p.locator('.ir-racks button').first.click();presets=p.evaluate('Object.entries(PRESETS).map(([key,p])=>({key,label:p.label,u:p.u,ports:p.ports.reduce((s,g)=>s+g.n,0)}))')
 for i,preset in enumerate(presets):
  p.get_by_role('button',name='+ NEW DEVICE',exact=True).click()
  p.locator('.rc8-device-catalogue button').filter(has_text=re.compile(re.escape(preset['label'])+r'\s*$')).click()
  p.wait_for_timeout(100)
  check('Preset '+preset['key'],p.locator('.ir-device-row').count()==i+1)
 data=state(p);devices=data['racks'][0]['devs']
 check('All 33 preset port groups match catalog',len(devices)==33 and all(len(d['ports'])==x['ports'] for d,x in zip(devices,presets)))
 ids=[p['id'] for d in devices for p in d['ports']];check('All preset port IDs unique',len(ids)==len(set(ids)))
 c.close();b.close()
print('INTEGRATED TESTS PASS',count)

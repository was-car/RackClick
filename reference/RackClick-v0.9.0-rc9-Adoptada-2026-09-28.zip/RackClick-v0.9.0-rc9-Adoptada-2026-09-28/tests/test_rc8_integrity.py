import json, os, sys, hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from qa_support import sync_playwright

CAND=Path(__file__).resolve().parents[1]
VERSION=(CAND/'VERSION').read_text().strip()
HTML=Path(os.environ.get('RACKCLICK_HTML',str(CAND/'dist'/f'RackClick-v{VERSION}-Offline.html'))).resolve()
assert HTML.is_file(), f'Candidate HTML absent: {HTML}'
assert VERSION=='0.9.0-rc8', f'Expected RC8 VERSION, got {VERSION}'

BASE=Path(os.environ.get('RACKCLICK_BASELINE_RC6','/workspace/scratch/b7ec76a90284/RackClick-v0.9.0-rc6-Reportes-2026-09-26'))
BASE_HTML=Path(os.environ.get('RACKCLICK_BASELINE_HTML',str(BASE/'dist/RackClick-v0.9.0-rc6-Offline.html'))).resolve()
SAVE='rackclick_autosave_v08'
OLD='rackclick_quarantine'
GOLD=json.loads((CAND/'fixtures/golden-test.json').read_text())
OUT=CAND/'evidence/rc8/integrity'
OUT.mkdir(parents=True,exist_ok=True)
ROWS=[]
def run_case(browser,root,seed,init='',action=None):
 c=browser.new_context(accept_downloads=True);p=c.new_page()
 script='''if(!sessionStorage.auditSeed){const values='''+json.dumps(seed)+''';for(const [k,v] of Object.entries(values))localStorage.setItem(k,v);sessionStorage.auditSeed='1';}'''+init
 p.add_init_script(script);p.goto((BASE_HTML if root==BASE else HTML).as_uri())
 p.wait_for_timeout(350)
 result=action(p) if action else {'body':p.inner_text('body')}
 c.close();return result

def outcome(k,base,fix):
 ROWS.append({'id':k,'rc6':base,'rc8':fix});print(k,'RC6',base.get('pass'),'RC8',fix.get('pass'),flush=True)

def cases(browser,root):
 old=json.dumps({'createdAt':'2026-01-01','reason':'old','keys':{'autosave':'OLD-UNRECOVERABLE-DATA'}})
 def episodes(p):
  keys=p.evaluate('()=>Object.keys(localStorage).filter(k=>k.startsWith("rackclick_quarantine_episode_"))')
  raw=p.evaluate('localStorage.getItem("rackclick_quarantine")')
  return {'oldExact':raw==old,'newKeys':keys,'newRaw':[p.evaluate('(k)=>localStorage.getItem(k)',k) for k in keys]}
 e=run_case(browser,root,{SAVE:'CORRUPT-NEW',OLD:old},action=episodes)
 e['pass']=e['oldExact'] and len(e['newKeys'])==1 and json.loads(e['newRaw'][0])['keys']['autosave']=='CORRUPT-NEW'
 results={'AUD-001':e}
 # An unreadable save must never be treated as absent if writes remain possible.
 def storage(p):
  raw=p.evaluate('window.auditRead.call(localStorage,"rackclick_autosave_v08")')
  return {'savedEqual':json.loads(raw)['racks']==GOLD['racks'],'body':p.inner_text('body')[-500:]}
 s=run_case(browser,root,{SAVE:json.dumps(GOLD)},init="window.auditRead=Storage.prototype.getItem;Storage.prototype.getItem=function(){throw new DOMException('No read','SecurityError')};",action=storage)
 s['pass']=s['savedEqual'] and ('Autosave is paused' in s['body'] or root==BASE)
 results['AUD-002']=s
 # Quota failure must not claim safe, and must not let a subsequent edit overwrite evidence.
 def quota(p):
  before=p.evaluate('localStorage.getItem("rackclick_autosave_v08")')
  rawDownload=None
  if root!=BASE:
   with p.expect_download() as dl:p.get_by_role('button',name='Download raw storage').click()
   rawDownload=json.loads(Path(dl.value.path()).read_text())['keys'][SAVE]
  p.get_by_role('button',name='Settings',exact=True).click()
  after=p.evaluate('localStorage.getItem("rackclick_autosave_v08")')
  body=p.inner_text('body')
  return {'before':before,'unchanged':after==before,'falseClaim':'Data secured in quarantine' in body,'paused':'Autosave is paused' in body,'rawDownloadExact':rawDownload==before}
 q=run_case(browser,root,{SAVE:'CORRUPT-QUOTA'},init="const oldSet=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){if(k.startsWith('rackclick_quarantine'))throw new DOMException('Full','QuotaExceededError');return oldSet.call(this,k,v)};",action=quota)
 q['pass']=q['unchanged'] and not q['falseClaim'] and q['paused'] and q['rawDownloadExact'];results['AUD-003-quota']=q
 # Removal failure: no phantom success, episode stays available in Settings.
 def deletion(p):
  p.get_by_role('button',name='Settings',exact=True).click()
  p.evaluate("()=>{Storage.prototype.removeItem=function(){throw new DOMException('Denied','SecurityError')}}")
  p.once('dialog',lambda d:d.accept())
  p.get_by_role('button',name='Delete quarantine').first.click()
  p.wait_for_timeout(100)
  body=p.inner_text('body')
  return {'stillStored':p.evaluate('localStorage.getItem("rackclick_quarantine")') is not None,'stillVisible':p.get_by_role('button',name='Delete quarantine').count()>0,'phantomSuccess':'Quarantine deleted' in body}
 d=run_case(browser,root,{SAVE:'CORRUPT', 'rackclick_backup_1':json.dumps(GOLD)},action=deletion)
 d['pass']=d['stillStored'] and d['stillVisible'] and not d['phantomSuccess'];results['AUD-003-delete']=d
 # Malformed name must be retained in raw quarantine, with safe fallback, not a render crash.
 invalid=json.loads(json.dumps(GOLD));invalid['racks'][0]['devs'][0]['name']={'bad':'object'};raw=json.dumps(invalid)
 def invalid_name(p):
  p.locator('.ir-racks button').first.click();p.wait_for_timeout(200)
  body=p.inner_text('body')
  quarantined=p.evaluate('localStorage.getItem("rackclick_quarantine")')
  return {'errorBoundary':'Download full rescue' in body,'quarantineRaw':json.loads(quarantined)['keys']['autosave']==raw if quarantined else False,'safeMode':'RackClick' in body}
 v=run_case(browser,root,{SAVE:raw},action=invalid_name)
 v['pass']=not v['errorBoundary'] and v['quarantineRaw'] and v['safeMode'];results['AUD-007']=v
 return results
def rescue_and_episodes(browser):
 old=json.dumps({'createdAt':'2026-01-01','reason':'previous','keys':{'autosave':'OLD-UNRECOVERABLE-DATA'}})
 c=browser.new_context(accept_downloads=True);p=c.new_page()
 seed={SAVE:'CORRUPT-NEW',OLD:old}
 p.add_init_script('if(!sessionStorage.auditSeed){const values='+json.dumps(seed)+';for(const [k,v] of Object.entries(values))localStorage.setItem(k,v);sessionStorage.auditSeed="1";}')
 p.goto(HTML.as_uri());p.wait_for_timeout(250)
 keys=p.evaluate('()=>Object.keys(localStorage).filter(k=>k.startsWith("rackclick_quarantine_episode_"))')
 assert len(keys)==1
 p.get_by_role('button',name='Settings',exact=True).click()
 assert p.locator('.ir-recovery-episodes button').count()==6
 with p.expect_download() as dl:p.get_by_role('button',name='Download bundle').first.click()
 assert Path(dl.value.path()).read_text()==old
 with p.expect_download() as dl:p.get_by_role('button',name='Download bundle').last.click()
 assert Path(dl.value.path()).read_text()==p.evaluate('(k)=>localStorage.getItem(k)',keys[0])
 # Rendering error in a separate React tree exercises the genuine ErrorBoundary UI.
 p.evaluate('()=>{const n=document.createElement("div");n.id="audit-root";n.style.cssText="position:fixed;z-index:999999;inset:0;overflow:auto;background:white";document.body.appendChild(n);const root=ReactDOM.createRoot(n);function Explode(){throw new Error("audit sentinel")};root.render(React.createElement(ErrorBoundary,null,React.createElement(Explode)))}')
 p.wait_for_selector('#audit-root button')
 with p.expect_download() as dl:p.locator('#audit-root button').first.click()
 rescue=json.loads(Path(dl.value.path()).read_text())
 assert rescue['keys'][OLD]==old and rescue['keys'][keys[0]]==p.evaluate('(k)=>localStorage.getItem(k)',keys[0])
 assert rescue['_meta']['appVersion']==VERSION and len(rescue['keys'])==14
 c.close()
 print('AUD-001: two episodes independently downloadable; ErrorBoundary 14 raw keys PASS')
with sync_playwright() as p:
 b=p.chromium.launch()
 baseline_available=BASE_HTML.is_file()
 base=cases(b,BASE) if baseline_available else {}
 fix=cases(b,CAND);rescue_and_episodes(b);b.close()
if not baseline_available:print('RC6 original unavailable: baseline not rerun; historical failures in rc6-baseline-results.json')
for key in fix:outcome(key,base.get(key,{'pass':None,'status':'NOT_RERUN'}),fix[key])
(OUT/'execution.json').write_text(json.dumps({'version':VERSION,'html':str(HTML),'sha256':hashlib.sha256(HTML.read_bytes()).hexdigest(),'baseline_rerun':baseline_available,'persistent_context':True,'browser':'chromium','platform':sys.platform},indent=2))
(OUT/'results.json').write_text(json.dumps(ROWS,indent=2,ensure_ascii=False))
if not all(r['rc8']['pass'] for r in ROWS):raise SystemExit('Candidate regression failed')
print('ALL INTEGRITY CANDIDATE CASES PASS')

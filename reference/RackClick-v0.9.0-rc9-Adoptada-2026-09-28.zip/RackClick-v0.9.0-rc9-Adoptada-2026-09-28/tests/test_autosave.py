#!/usr/bin/env python3
"""Tests de autosave honesto A1–A4 — v0.8.3 (Paso 4)
Simulación de cuota: monkey-patch de Storage.prototype.setItem que lanza
QuotaExceededError cuando window.__SIMULATE_QUOTA__ === true (conmutable)."""
import json, os
from pathlib import Path
from qa_support import sync_playwright, cache_cdn

HTML = Path(os.environ.get("RACKCLICK_HTML", "rackclick-v0.8.6.html")).resolve().as_uri()

HEALTHY = json.dumps({"version": "0.8", "name": "AutoTest", "technician": "", "createdAt": "2026-01-01", "updatedAt": "2026-01-01",
    "racks": [{"id": "r1", "name": "RackA", "location": "", "size": 12, "devs": [], "conns": []}], "crossConns": [], "changeLog": []})

QUOTA_PATCH = """
(() => {
  const orig = Storage.prototype.setItem;
  Storage.prototype.setItem = function(k, v) {
    if (window.__SIMULATE_QUOTA__) {
      const e = new Error("QuotaExceededError (simulado)"); e.name = "QuotaExceededError"; throw e;
    }
    return orig.apply(this, arguments);
  };
})();
"""

def get_save(p):
    return p.evaluate("() => localStorage.getItem('rackclick_autosave_v08')")

def racks_in_save(p):
    try:
        return len(json.loads(get_save(p))["racks"])
    except Exception:
        return None

def add_rack(p, name):
    p.once("dialog", lambda d: d.accept(name))
    p.get_by_text("+ Add Rack", exact=True).click()
    p.wait_for_timeout(1200)

R = []
with sync_playwright() as pw:
    browser = pw.chromium.launch()
    ctx = browser.new_context(accept_downloads=True)
    p = ctx.new_page()
    p.add_init_script(f"localStorage.setItem('rackclick_autosave_v08', {json.dumps(HEALTHY)});")
    p.add_init_script(QUOTA_PATCH)
    p.context.route("https://cdnjs.cloudflare.com/**", cache_cdn)
    p.goto(HTML)
    p.wait_for_timeout(4500)

    # ── A1: operación normal ──
    body = p.inner_text("body")
    ind_ok = (p.locator('[title="Autosave"]').is_visible() and "✓" in p.locator('[title="Autosave"]').inner_text())
    no_banner = "Automatic saving is failing" not in body
    n0 = racks_in_save(p)
    add_rack(p, "R-A1")
    body = p.inner_text("body")
    a1 = ind_ok and no_banner and (p.locator('[title="Autosave"]').is_visible() and "✓" in p.locator('[title="Autosave"]').inner_text()) and racks_in_save(p) == n0 + 1
    R.append(("A1", f"Normal: indicador ✓ visible, sin banner, SAVE_KEY actualizado ({n0}→{racks_in_save(p)} racks)", a1))

    # ── A2: cuota llena → banner + indicador ✗ + SAVE_KEY intacto + export EN MEMORIA ──
    save_before = get_save(p)
    backups_before = p.evaluate("() => [localStorage.getItem('rackclick_backup_1'), localStorage.getItem('rackclick_backup_2'), localStorage.getItem('rackclick_backup_3'), localStorage.getItem('rackclick_backup_meta')]")
    p.evaluate("() => { window.__SIMULATE_QUOTA__ = true; }")
    add_rack(p, "R-A2")  # el proyecto en memoria pasa a 3 racks; el autosave FALLA
    body = p.inner_text("body")
    banner = "Automatic saving is failing" in body and "Export JSON now" in body
    ind_fail = (p.locator('[title="Autosave"]').is_visible() and "✗" in p.locator('[title="Autosave"]').inner_text()) and "Autosave FAILING" in body
    save_untouched = get_save(p) == save_before  # SAVE_KEY no cambió (y sin rotación)
    # Export desde memoria: debe contener los 3 racks actuales, no los 2 de localStorage
    with p.expect_download() as dl:
        p.locator("button", has_text="Export JSON now").click()
    exported = json.loads(open(dl.value.path()).read())
    export_from_memory = len(exported["racks"]) == 3 and any(r["name"] == "R-A2" for r in exported["racks"])
    a2 = banner and ind_fail and save_untouched and export_from_memory
    R.append(("A2", f"Cuota: banner={banner}, indicador ✗={ind_fail}, SAVE_KEY intacto={save_untouched}, export en memoria (3 racks incl. R-A2)={export_from_memory}", a2))

    # ── A2b: verificar que NO hubo rotación de backups durante el fallo ──
    backups_after = p.evaluate("() => [localStorage.getItem('rackclick_backup_1'), localStorage.getItem('rackclick_backup_2'), localStorage.getItem('rackclick_backup_3'), localStorage.getItem('rackclick_backup_meta')]")
    no_rotation = backups_before == backups_after  # ni un byte cambió durante el fallo
    R.append(("A2b", f"Rotación NO ejecutada durante el fallo (backups + meta byte-idénticos antes/después)={no_rotation}", no_rotation))

    # ── A3: recuperación ──
    p.evaluate("() => { window.__SIMULATE_QUOTA__ = false; }")
    add_rack(p, "R-A3")
    body = p.inner_text("body")
    banner_gone = "Automatic saving is failing" not in body
    ind_ok2 = (p.locator('[title="Autosave"]').is_visible() and "✓" in p.locator('[title="Autosave"]').inner_text())
    save_now = racks_in_save(p)
    a3 = banner_gone and ind_ok2 and save_now == 4
    R.append(("A3", f"Recuperación: banner desaparece={banner_gone}, indicador ✓={ind_ok2}, SAVE_KEY={save_now} racks", a3))
    browser.close()

    # ── A4: modo seguro → sin banner falso, indicador neutro ──
    browser = pw.chromium.launch()
    p = browser.new_context().new_page()
    seed4 = {"rackclick_autosave_v08": '{"version":"0.8","name":"Roto","racks":"no-es-array"}',
             "rackclick_backup_1": "{{{", "rackclick_backup_2": "{{{", "rackclick_backup_3": "{{{"}
    p.add_init_script(f"const s = {json.dumps(seed4)}; for (const [k,v] of Object.entries(s)) localStorage.setItem(k,v);")
    p.context.route("https://cdnjs.cloudflare.com/**", cache_cdn)
    p.goto(HTML)
    p.wait_for_timeout(5000)
    body = p.inner_text("body")
    no_false_banner = "Automatic saving is failing" not in body
    no_false_fail = "✗" not in p.locator('[title="Autosave"]').inner_text()
    neutral = "✓" not in p.locator('[title="Autosave"]').inner_text()  # ok === null: ni check ni cruz
    save_still_corrupt = get_save(p) == seed4["rackclick_autosave_v08"]
    a4 = no_false_banner and no_false_fail and neutral and save_still_corrupt
    R.append(("A4", f"Modo seguro: sin banner falso={no_false_banner}, sin ✗ falso={no_false_fail}, indicador neutro={neutral}, autosave intacto={save_still_corrupt}", a4))
    browser.close()

print("=" * 78)
for name, desc, ok in R:
    print(f"  [{name}] {'✓ PASS' if ok else '✗ FAIL'} — {desc}")
allok = all(r[2] for r in R)
print("\n" + ("✅ AUTOSAVE TESTS: PASS" if allok else "❌ FALLOS"))
exit(0 if allok else 1)

"""Synthetic project only. Timing evidence describes this machine, not all PCs."""
import json,os,time
from pathlib import Path
from qa_support import sync_playwright
ROOT=Path(__file__).resolve().parents[1];HTML=Path(os.environ.get('RACKCLICK_HTML',ROOT/'dist/RackClick-v0.9.0-rc6-Offline.html')).resolve().as_uri()
g={'version':'0.8','name':'1000-port synthetic laboratory','racks':[],'crossConns':[],'changeLog':[]}
for i in range(10):
 r={'id':f'r{i}','name':f'Rack {i+1:02}','location':'Synthetic test','size':48,'devs':[],'conns':[]}
 for d in range(2):r['devs'].append({'id':f'd{i}-{d}','name':f'DEV-{i}-{d}','u':2,'preset':'Switch 48P','icon':'⇋','color':'#2a9d8f','ports':[{'id':f'p{i}-{d}-{n}','gn':n+1,'type':'rj45','status':'free'} for n in range(50)]})
 for n in range(50):r['conns'].append({'id':f'c{i}-{n}','fd':f'd{i}-0','fp':f'p{i}-0-{n}','td':f'd{i}-1','tp':f'p{i}-1-{n}','fn':f'DEV-{i}-0','tn':f'DEV-{i}-1','fpn':n+1,'tpn':n+1,'fpt':'RJ45','tpt':'RJ45','fpt2':'rj45','tpt2':'rj45'})
 g['racks'].append(r)
(ROOT/'fixtures/large-synthetic.json').write_text(json.dumps(g,indent=2))
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context();p=c.new_page();p.add_init_script('if(!localStorage.getItem("rackclick_autosave_v08"))localStorage.setItem("rackclick_autosave_v08",'+json.dumps(json.dumps(g))+')');start=time.perf_counter();p.goto(HTML);p.locator('.ir-racks button').first.wait_for();load=(time.perf_counter()-start)*1000
 p.locator('.ir-racks button').first.click();p.locator('.ir-terminal').first.wait_for();p.wait_for_timeout(200)
 interaction=p.evaluate('''()=>new Promise(resolve=>{const button=document.querySelector('.ir-device-head input');const start=performance.now();button.click();requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(performance.now()-start)))})''')
 result={'load_ms':round(load,2),'interaction_two_frames_ms':round(interaction,2),'racks':10,'ports':1000,'connections':500,'browser':'Chromium 153 headless','environment':'Linux execution workspace; excludes browser launch','thresholds_met':load<2000 and interaction<100}
 (ROOT/'evidence/performance.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert result['thresholds_met'];c.close();b.close()

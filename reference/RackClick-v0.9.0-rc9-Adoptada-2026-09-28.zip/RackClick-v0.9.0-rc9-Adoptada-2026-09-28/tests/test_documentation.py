"""Read-only smoke test for offline manuals and the manual QA form."""
import json,hashlib
from pathlib import Path
from qa_support import sync_playwright
R=Path(__file__).resolve().parents[1];rows=[];errors=[];requests=[]
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context(accept_downloads=True);p=c.new_page();p.on('pageerror',lambda e:errors.append(str(e)));p.route('http*://**',lambda r:(requests.append(r.request.url),r.abort()))
 for name in ['Manual-Uso-ES-DE.html','Manual-Tecnico-Operacion-ES-DE.html','Pack-Pruebas-ES-DE.html']:
  f=R/'docs'/name
  for lang in ['es','de']:
   for width in [1440,390]:
    p.set_viewport_size({'width':width,'height':1000});p.goto(f.as_uri());p.locator('#language').select_option(lang);p.wait_for_timeout(100)
    assert p.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),(name,width)
    p.locator('img').evaluate_all('(xs)=>Promise.all(xs.map(x=>{x.loading="eager";return x.decode()}))')
    assert p.locator('img').evaluate_all('(xs)=>xs.every(x=>x.complete&&x.naturalWidth>0)'),name
    broken=p.locator('a[href^="#"]').evaluate_all('(xs)=>xs.filter(x=>x.hash.length>1&&!document.getElementById(decodeURIComponent(x.hash.slice(1)))).map(x=>x.hash)');assert not broken,(name,broken)
    rows.append({'file':name,'lang':lang,'width':width,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'pass':True})
    if lang=='es':p.screenshot(path=str(R/'evidence'/('doc-'+f.stem+'-'+str(width)+'.png')),full_page=False)
 assert not errors and not requests
 c.close();b.close()
(R/'evidence/docs-qa.json').write_text(json.dumps({'rows':rows,'errors':errors,'requests':requests},indent=2));print('DOCUMENTATION PASS',len(rows))

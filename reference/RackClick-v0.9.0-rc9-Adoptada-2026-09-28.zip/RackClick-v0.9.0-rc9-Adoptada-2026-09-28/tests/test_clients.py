import json,os,re,tempfile,hashlib
from pathlib import Path
from qa_support import sync_playwright
ROOT=Path(__file__).resolve().parents[1];VERSION=(ROOT/'VERSION').read_text().strip();HTML=ROOT/'dist'/f'RackClick-v{VERSION}-Offline.html';SAVE='rackclick_autosave_v08';count=0

def check(name,v):
 global count
 assert v,name
 count+=1;print('PASS',name,flush=True)
def state(p):p.wait_for_timeout(250);return json.loads(p.evaluate('localStorage.getItem(SAVE_KEY)'))
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context(accept_downloads=True);p=c.new_page();p.set_default_timeout(10000);p.on('dialog',lambda d:d.accept(d.default_value) if d.type=='prompt' else d.accept());errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto(HTML.as_uri());p.locator('.ir-all-clients').click();p.get_by_role('button',name='10 demo clients',exact=True).click();p.locator('.ir-client-card').first.wait_for()
 check('10 client cards at infrastructure root',p.locator('.ir-client-card').count()==10)
 check('No rack grid at root',p.locator('[data-devid]').count()==0 and p.locator('.ir-racks button').count()==0)
 original=state(p);check('68 racks with 1 / 5 / 17 cases',[sum(r.get('rackclickLocation',{}).get('client')==['Lindenwerk Architektur', 'Nordhafen Logistik', 'Sonnenfeld Medizin', 'Bergstrom Fertigung', 'Elbwinkel Handel', 'Falkenhof Bildung', 'Westbogen Hotel', 'Kieselpark Medien', 'Morgenwald Verwaltung', 'Sternbruck Campus'][i] for r in original['racks']) for i in range(10)]==[1,2,3,4,5,6,8,10,12,17])
 check('All demo endpoints valid / unoccupied twice',p.evaluate('p=>{irAssertTopology(p);const ids=new Set;for(const c of [...p.racks.flatMap(r=>r.conns),...p.crossConns])for(const id of [c.fp,c.tp]){if(ids.has(id))return false;ids.add(id)}return p.crossConns.every(c=>irClientOf(p.racks.find(r=>r.id===c.rackFrom))===irClientOf(p.racks.find(r=>r.id===c.rackTo)))}',original))
 p.screenshot(path=str(ROOT/'evidence/clients-en.png'),full_page=True)
 p.locator('.ir-client-card').filter(has=p.get_by_role('heading',name='Elbwinkel Handel',exact=True)).click()
 check('Only selected client racks in sidebar',p.locator('.ir-racks button').count()==5)
 check('Scoped pure projection excludes other clients',p.evaluate('p=>{const s=irClientProject(p,"Elbwinkel Handel");return s.racks.length===5&&s.racks.every(r=>irClientOf(r)==="Elbwinkel Handel")&&s.crossConns.every(c=>s.racks.some(r=>r.id===c.rackFrom)&&s.racks.some(r=>r.id===c.rackTo))}',original))
 p.get_by_placeholder('Technician',exact=True).fill('Technician C5');p.get_by_placeholder('Technician',exact=True).blur();changed=state(p)
 check('Technician scoped to client metadata',changed.get('technician','')==original.get('technician','') and next(m for m in changed['rackclickClientMeta'] if m['client']=='Elbwinkel Handel')['technician']=='Technician C5')
 with p.expect_download() as dl:p.keyboard.press('Control+s')
 exported=json.loads(Path(dl.value.path()).read_text());check('Client export contains only 5 racks',len(exported['racks'])==5 and exported['name']=='Elbwinkel Handel' and exported['technician']=='Technician C5')
 foreign=[r for r in changed['racks'] if r['rackclickLocation']['client']!='Elbwinkel Handel']
 # Reimport an exported client using real file chooser. All locations and ports must survive.
 with tempfile.TemporaryDirectory() as td:
  file=Path(td)/'client.json';file.write_text(json.dumps(exported))
  with p.expect_file_chooser() as fc:p.get_by_role('button',name=re.compile('Load')).first.click()
  fc.value.set_files(str(file));after=state(p)
  check('Client reload preserves all locations / rack content', [r for r in after['racks'] if r['rackclickLocation']['client']=='Elbwinkel Handel']==exported['racks'])
  check('Client reload leaves all other racks byte-identical', [r for r in after['racks'] if r['rackclickLocation']['client']!='Elbwinkel Handel']==foreign)
 p.get_by_role('button',name=re.compile('Report')).first.click();p.locator('.ir-client-report').wait_for();check('New report is client-scoped',p.locator('.ir-report-section').count()==5 and p.locator('.ir-print-rack').count()==5)
 p.screenshot(path=str(ROOT/'evidence/report-en.png'),full_page=True)
 # Playwright's Page.pdf is a Chromium-only API. Firefox still validates the
 # report DOM and its five client-scoped rack sections above.
 if os.environ.get('RACKCLICK_BROWSER')!='firefox':
  p.pdf(path=str(ROOT/'evidence/report-client5.pdf'),print_background=True)
 p.get_by_role('button',name='Classic report (fallback)',exact=True).click();check('Classic report remains explicitly accessible',p.locator('.ir-client-report').count()==0)
 p.get_by_role('button',name=re.compile('Back|Zurück')).first.click()
 p.locator('.ir-racks button').first.click();p.screenshot(path=str(ROOT/'evidence/rack-en.png'),full_page=True)
 # Clone/rename client does not change another customer's inventory.
 p.locator('.ir-all-clients').click();p.locator('.ir-client-card').filter(has=p.get_by_role('heading',name='Lindenwerk Architektur',exact=True)).click();check('Switching client scopes sidebar to one rack',p.locator('.ir-racks button').count()==1)
 p.get_by_text('+ Add Rack',exact=True).click()
 # Dialog autoaccept uses defaults. Creation must belong to client1.
 after=state(p);check('New rack belongs only to selected client',len([r for r in after['racks'] if r['rackclickLocation']['client']=='Lindenwerk Architektur'])==2 and len([r for r in after['racks'] if r['rackclickLocation']['client']=='Elbwinkel Handel'])==5)
 p.keyboard.press('Control+z');check('Undo client rack addition',len([r for r in state(p)['racks'] if r['rackclickLocation']['client']=='Lindenwerk Architektur'])==1)
 p.locator('.ir-all-clients').click();p.get_by_role('combobox',name='Language',exact=True).select_option('de');check('10 cards in German',p.locator('.ir-client-card').count()==10 and p.get_by_role('heading',name='Sternbruck Campus',exact=True).count()==1)
 de=state(p);check('Generated names translated while custom technician retained',any(r['name']=='Hauptverteiler' for r in de['racks']) and next(m for m in de['rackclickClientMeta'] if m['client']=='Elbwinkel Handel')['technician']=='Technician C5')
 p.screenshot(path=str(ROOT/'evidence/clients-de.png'),full_page=True)
 p.get_by_role('combobox',name='Language',exact=True).select_option('es');check('10 cards in Spanish',p.get_by_role('heading',name='Sternbruck Campus',exact=True).count()==1)
 p.screenshot(path=str(ROOT/'evidence/clients-es.png'),full_page=True)
 with p.expect_download() as dl:p.get_by_role('button',name='Exportar respaldo completo',exact=True).click()
 complete=json.loads(Path(dl.value.path()).read_text());check('Full backup retains all clients',len(complete['racks'])==68)
 # Pure negative boundaries and translation preservation.
 checks=p.evaluate('p=>{const r={};const a=irClientProject(p,"Elbwinkel Handel");r.replace=JSON.stringify(irReplaceClient(p,"Elbwinkel Handel",a).racks.filter(x=>irClientOf(x)!=="Elbwinkel Handel"))===JSON.stringify(p.racks.filter(x=>irClientOf(x)!=="Elbwinkel Handel"));const edited=structuredClone(p);edited.racks[0].name="My custom rack";r.custom=irTranslateDemo(edited,"en").racks[0].name==="My custom rack";const bad=structuredClone(p);bad.rackclickClientMeta={};try{irAssertTopology(bad);r.bad=false}catch{r.bad=true}return r}',complete)
 for name,v in checks.items():check('Pure '+name,v)
 p.reload();p.locator('.ir-client-card').first.wait_for();check('Reload opens client directory',p.locator('.ir-client-card').count()==10)
 check('Zero own JS errors',not errors)
 for lang in ['en','de','es']:
  fixture=p.evaluate('l=>irDemo(l)',lang);(ROOT/'fixtures'/('demo-10-clients-'+lang+'.json')).write_text(json.dumps(fixture,ensure_ascii=False,indent=2))
 c.close();b.close()
print('CLIENT TESTS PASS',count,hashlib.sha256(HTML.read_bytes()).hexdigest())

"""rc6: report parity and reusable hardware layout, on persistent browser profile."""
import json,re,hashlib
from pathlib import Path
from qa_support import sync_playwright
ROOT=Path(__file__).resolve().parents[1];HTML=ROOT/'dist'/('RackClick-v'+(ROOT/'VERSION').read_text().strip()+'-Offline.html');checks=[]
def check(n,v):
 assert v,n
 checks.append(n);print('PASS',n,flush=True)
def state(p):
 p.wait_for_timeout(300);return p.evaluate('JSON.parse(localStorage.getItem(SAVE_KEY))')
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context();p=c.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.on('dialog',lambda d:d.accept());p.goto(HTML.as_uri())
 data=p.evaluate('irDemo("en")');data['racks']=data['racks'][1:3];data['rackclickLocations']=[r['rackclickLocation'] for r in data['racks']];data['crossConns']=[x for x in data['crossConns'] if x['rackFrom']==data['racks'][0]['id']]
 d=data['racks'][0]['devs'][0];d['name']='TEMPLATE-QA';d['ports'][0].update(rackclickFace='rear',portColor='#abcdef',label='Uplink',status='reserved',watts=15);d['ports'][1]['rackclickFace']='front'
 p.evaluate('v=>localStorage.setItem(SAVE_KEY,JSON.stringify(v))',data);p.reload();p.locator('.ir-client-card').first.click()
 p.get_by_role('button',name=re.compile('Report')).first.click();p.locator('.ir-client-report').wait_for();check('Client report keeps both racks',p.locator('.ir-report-section').count()==2)
 client_svg=p.locator('.ir-print-rack').first.evaluate('e=>e.outerHTML');client_table=p.locator('.ir-report-section table').first.inner_text();p.locator('.ir-client-report nav button').first.click();p.locator('.ir-racks button').first.click();p.locator('button',has_text='📊').first.click();p.locator('.ir-client-report').wait_for()
 check('Rack report renders one rack in same approved component',p.locator('.ir-report-section').count()==1)
 check('Rack report diagram byte identical to corresponding client diagram',p.locator('.ir-print-rack').first.evaluate('e=>e.outerHTML')==client_svg)
 check('Rack report table preserves local and cross-rack links',p.locator('.ir-report-section table').first.inner_text()==client_table and 'SW-AGG-01' in client_table)
 p.screenshot(path=str(ROOT/'evidence/report-rack-rc6.png'),full_page=True)
 p.locator('.ir-client-report nav button').first.click();p.locator('.ir-device-row[data-devid="'+d['id']+'"]').first.click(button='right',position={'x':10,'y':10});p.get_by_text('Save as Template',exact=False).click()
 saved=p.evaluate('JSON.parse(localStorage.getItem(TEMPLATES_KEY))');tpl=next(iter(saved.values()));check('Saved template carries exact ordered port faces and manual color',tpl['rackclickPortLayout'][0]['rackclickFace']=='rear' and tpl['rackclickPortLayout'][1]['rackclickFace']=='front' and tpl['rackclickPortLayout'][0]['portColor']=='#abcdef')
 check('Template excludes operational state and endpoint identity',all(not any(k in port for k in ['id','watts','status']) for port in tpl['rackclickPortLayout']))
 p.reload();p.locator('.ir-client-card').first.click();p.locator('.ir-racks button').first.click();before=state(p);p.get_by_role('button',name='+ NEW DEVICE',exact=True).click();p.locator('.ir-right button').filter(has_text='TEMPLATE-QA').first.click();after=state(p);new=after['racks'][0]['devs'][-1]
 check('Template remains usable after reload',len(after['racks'][0]['devs'])==len(before['racks'][0]['devs'])+1)
 check('New instance matches static port layout with fresh IDs',all({k:v for k,v in port.items() if k!='id'}==layout for port,layout in zip(new['ports'],tpl['rackclickPortLayout'])) and len(new['ports'])==len(tpl['rackclickPortLayout']) and not set(x['id'] for x in new['ports'])&set(x['id'] for x in d['ports']))
 check('Instantiation does not copy cables or change other racks',after['racks'][0]['conns']==before['racks'][0]['conns'] and after['crossConns']==before['crossConns'] and after['racks'][1:]==before['racks'][1:])
 check('Legacy templates without layout retain their ports',p.evaluate('()=>irTemplatePorts({label:"Custom",ports:[{t:"rj45",n:2}]},"old","en").map(p=>p.id).join() === "old-p1,old-p2"'))
 check('No application errors',not errors);c.close();b.close()
(ROOT/'evidence/reports-templates.json').write_text(json.dumps({'sha256':hashlib.sha256(HTML.read_bytes()).hexdigest(),'checks':checks},indent=2))

"""F2-A1 browser regression. --baseline records expected N03/N08/rescue failures.
No modified HTML or application test hooks. The same assertions run on both builds.
"""
import argparse, copy, json, os, re
from pathlib import Path
from qa_support import sync_playwright, cache_cdn
ROOT=Path(__file__).resolve().parents[1]
args=argparse.ArgumentParser();args.add_argument('--baseline',action='store_true');args=args.parse_args()
HTML=Path(os.environ.get('RACKCLICK_HTML',ROOT/('rollback/rackclick-v0.8.5.html' if args.baseline else 'rackclick-v0.8.6.html'))).resolve().as_uri()
G=json.loads((ROOT/'fixtures/golden-test.json').read_text(encoding='utf-8'))
SAVE='rackclick_autosave_v08'
failures=[]
def check(name,condition,expected_failure=False):
 if not condition:
  if args.baseline and expected_failure: print('REPRODUCED',name,flush=True);failures.append(name);return
  raise AssertionError(name)
 if args.baseline and expected_failure: raise AssertionError('Baseline did NOT reproduce '+name)
 print('PASS',name,flush=True)
def boot(b,data=G):
 ctx=b.new_context(accept_downloads=True);ctx.set_default_timeout(30000);ctx.route('https://cdnjs.cloudflare.com/**',cache_cdn)
 p=ctx.new_page();p.add_init_script('if(localStorage.getItem('+json.dumps(SAVE)+')===null){localStorage.setItem('+json.dumps(SAVE)+','+json.dumps(json.dumps(data))+');localStorage.setItem("rackclick_lang","en")}')
 p.goto(HTML,wait_until="domcontentloaded",timeout=60000);p.get_by_text(data['racks'][0]['name'],exact=True).first.wait_for();return ctx,p
def reload_saved(p):
 # Accept only the unload dialog, scoped to navigation. Other confirmations
 # retain their explicit accept/dismiss handlers in each behavioral test.
 def accept_unload(dialog):
  if dialog.type != 'beforeunload':
   raise AssertionError('Unexpected dialog during reload: '+dialog.type)
  dialog.accept()
 p.on('dialog',accept_unload)
 try:
  p.reload(wait_until='domcontentloaded',timeout=60000)
 finally:
  p.remove_listener('dialog',accept_unload)

def state(p):
 p.wait_for_timeout(950);return json.loads(p.evaluate('(k)=>localStorage.getItem(k)',SAVE))
def edit(p):
 p.locator('.ir-device-row[data-devid="sw-a"] .ir-device-actions button[title="Edit"]').click()
 return p.get_by_text('✎ EDIT DEVICE',exact=True).locator('..')
def save(p,m):m.get_by_role('button',name=p.evaluate('I18N.en.saveBtn'),exact=True).click()
with sync_playwright() as pw:
 b=pw.chromium.launch();ctx,p=boot(b)
 # Ordered backup selection with deliberately contradictory project timestamps.
 result=p.evaluate('''g=>{localStorage.clear();localStorage.setItem(SAVE_KEY,'{bad');
 BACKUP_KEYS.forEach((k,i)=>localStorage.setItem(k,JSON.stringify({...g,name:'slot-'+i,updatedAt:'2026-01-0'+(3-i)})));
 localStorage.setItem(BACKUP_META,JSON.stringify({slot:2,lastBackup:1}));
 return bootLoadProject(()=>({name:'EMPTY'})).name}''',G)
 check('N08 newest circular slot 2, not fixed slot 0',result=='slot-2',True);ctx.close()
 ctx,p=boot(b);p.get_by_text(G['racks'][0]['name'],exact=True).first.click()
 before=state(p);m=edit(p);m.get_by_text('🔌 Port Configuration',exact=False).click()
 # First group 2 -> 3; existing SFP IDs must not shift; all old attrs identical.
 m.locator('input[type=number][max="96"]').first.fill('3');save(p,m);after=state(p)
 old=before['racks'][0]['devs'][0]['ports'];new=after['racks'][0]['devs'][0]['ports'];lookup={x['id']:x for x in new}
 check('N03 IDs and all attributes survive group growth',all(lookup.get(x['id'])==x for x in old),True)
 check('N03 cross endpoints preserved',after['crossConns']==before['crossConns'])
 if not args.baseline:
  check('P growth creates exactly one unique ID',len(new)==len(old)+1 and len(lookup)==len(new))
  p.keyboard.press('Control+z');undone=state(p)
  check('P undo restores devices and local/cross connections',all(undone[k]==before[k] for k in ['racks','crossConns']))
  p.keyboard.press('Control+y');redone=state(p)
  check('P redo restores entire edit',all(redone[k]==after[k] for k in ['racks','crossConns']))
  reload_saved(p);p.get_by_text(G['racks'][0]['name'],exact=True).first.wait_for()
  check('P IDs and attrs survive reload',state(p)['racks']==after['racks'])
 ctx.close()
 if not args.baseline:
  from golden_oracle import inspect
  expected=json.loads((ROOT/'fixtures/golden-expected.json').read_text(encoding='utf-8'))
  observed=inspect(G)
  check('G approved totals and no ownership/occupation errors',observed['totals']==expected['totals'] and not observed['issues'])
  for rid,counts in observed['racks'].items():
   check('G local oracle '+rid,all(counts[k]==v for k,v in expected['racks'][rid].items() if k in counts))
  for kind in ('ownership','occupation','duplicate'):
   bad=copy.deepcopy(G)
   if kind=='ownership':bad['crossConns'][0]['fd']='fw-c'
   elif kind=='occupation':bad['crossConns'].append(copy.deepcopy(bad['crossConns'][0]))
   else:bad['racks'][0]['devs'][0]['ports'][1]['id']='sw-a-p1'
   check('G oracle rejects '+kind,bool(inspect(bad)['issues']))
  ctx,p=boot(b)
  matrix=p.evaluate('''g=>{
    const results=[];
    for(const slot of [0,1,2]) for(const corrupt of [false,true]) {
      localStorage.clear();localStorage.setItem(SAVE_KEY,'{bad');
      BACKUP_KEYS.forEach((k,i)=>localStorage.setItem(k,JSON.stringify({...g,name:'slot-'+i})));
      localStorage.setItem(BACKUP_META,JSON.stringify({slot}));
      if(corrupt)localStorage.setItem(BACKUP_KEYS[slot],'{bad');
      results.push(bootLoadProject(()=>({name:'EMPTY'})).name==='slot-'+((slot-(corrupt?1:0)+3)%3));
    }
    for(const meta of [null,'{bad','{}','{"slot":-1}','{"slot":3}','{"slot":"2"}']) {
      localStorage.clear();localStorage.setItem(SAVE_KEY,'{bad');
      BACKUP_KEYS.forEach((k,i)=>localStorage.setItem(k,JSON.stringify({...g,name:'slot-'+i})));
      if(meta!==null)localStorage.setItem(BACKUP_META,meta);
      localStorage.setItem(QUARANTINE_KEY,'old-evidence');
      const before=JSON.stringify({...localStorage});
      results.push(bootLoadProject(()=>({name:'EMPTY'})).name==='EMPTY' && BOOT_SUPPRESS_FIRST_AUTOSAVE && BOOT_REPORT.type==='ambiguous' && before===JSON.stringify({...localStorage}));
    }
    return results;
  }''',G)
  check('B all slots, wrap, corrupt newest and six ambiguous metadata cases',len(matrix)==12 and all(matrix));ctx.close()
  # No-op edit, explicit destructive edit, cancellation, one-step undo and redo.
  ctx,p=boot(b);p.get_by_text(G['racks'][0]['name'],exact=True).first.click();before=state(p)
  m=edit(p);save(p,m);check('P no-op edit preserves duplicate gn and every port',state(p)['racks'][0]['devs'][0]['ports']==before['racks'][0]['devs'][0]['ports'])
  m=edit(p);m.get_by_text('🔌 Port Configuration',exact=False).click();m.locator('input[type=number][max="96"]').nth(1).fill('1')
  messages=[];p.once('dialog',lambda d:(messages.append(d.message),d.dismiss()));save(p,m)
  check('P deletion names exact ID and link impact; cancel leaves topology intact','sw-a-p4' in messages[0] and '1 connections' in messages[0] and state(p)['racks']==before['racks'])
  p.once('dialog',lambda d:d.accept());save(p,m);removed=state(p)
  check('P explicit removal deletes only selected port and its cross link',len(removed['crossConns'])==2 and 'sw-a-p4' not in [x['id'] for x in removed['racks'][0]['devs'][0]['ports']] and not inspect(removed)['issues'])
  p.keyboard.press('Control+z');check('P undo deletion restores ports/attributes/connections',state(p)['racks']==before['racks'] and state(p)['crossConns']==before['crossConns'])
  p.keyboard.press('Control+y');check('P redo deletion restores chosen result',state(p)['crossConns']==removed['crossConns']);ctx.close()
  # Explicit groups retain IDs despite same type + same gn; invalid input cannot mutate data.
  ctx,p=boot(b)
  invariant=p.evaluate('''g=>{const d=g.racks[0].devs[0];const before=JSON.stringify(d);
    const groups=d.ports.map(p=>({t:p.type,n:1,ids:[p.id]}));
    const noop=JSON.stringify(reconcilePorts(d,groups,d.ports))===JSON.stringify(d.ports);
    groups.push({t:'rj45',n:2});const expanded=reconcilePorts(d,groups,d.ports);
    let rejected=0;
    for(const gs of [[{t:'rj45',n:1,ids:['foreign']}],[{t:'rj45',n:1,ids:['sw-a-p1','sw-a-p1']}],[{t:'rj45',n:Infinity}]])try{reconcilePorts(d,gs,d.ports)}catch{rejected++}
    return noop && expanded.length===d.ports.length+2 && new Set(expanded.map(p=>p.id)).size===expanded.length && rejected===3 && before===JSON.stringify(d);
  }''',G)
  check('P duplicate gn identity, new-group IDs, invalid groups and pure reconciliation',invariant);ctx.close()
  # UI policy: one confirm, cancellation inert, both endpoint positions, all locales.
  for lang in ('en','de','es'):
   for reserved_first in (True,False):
    data=copy.deepcopy(G);data['crossConns']=[]
    r=data['racks'][0];r['conns']=[];r['devs']=r['devs'][:1]
    ports=r['devs'][0]['ports'];ports[5]['status']='free';ports[6]['status']='reserved'
    ctx,p=boot(b,data)
    p.evaluate('(l)=>localStorage.setItem(LANG_KEY,l)',lang);reload_saved(p);p.get_by_text(r['name'],exact=True).first.click()
    buttons=p.locator('.ir-device-row[data-devid="sw-a"] [role="button"][tabindex="0"]')
    first,last=(6,5) if reserved_first else (5,6)
    p.locator('[data-vport="'+ports[first]['id']+'"]').click();messages=[]
    p.once('dialog',lambda d:(messages.append(d.message),d.dismiss()));p.locator('[data-vport="'+ports[last]['id']+'"]').click()
    check('C reserved cancel '+lang+str(reserved_first),len(messages)==1 and messages[0]==p.evaluate('I18N[localStorage.getItem(LANG_KEY)].confirmReserved') and not state(p)['racks'][0]['conns'])
    p.once('dialog',lambda d:d.accept());p.locator('[data-vport="'+ports[last]['id']+'"]').click()
    check('C reserved accept '+lang+str(reserved_first),len(state(p)['racks'][0]['conns'])==1)
    p.keyboard.press('Control+z');check('C undo reserved connect',not state(p)['racks'][0]['conns'])
    p.keyboard.press('Escape');p.locator('[data-vport="'+ports[7]['id']+'"]').click();p.locator('[data-vport="'+ports[5]['id']+'"]').click();p.locator('[data-vport="'+ports[8]['id']+'"]').click()
    check('C disabled/faulty remain blocked',not state(p)['racks'][0]['conns']);ctx.close()
 # Exercise the actual ErrorBoundary download method, capturing the actual file.
 ctx,p=boot(b);raw='{"reason":"sentinel","keys":{"raw":"{broken"}}'
 p.evaluate('(v)=>localStorage.setItem(QUARANTINE_KEY,v)',raw)
 with p.expect_download() as d:
  p.evaluate('new ErrorBoundary({}).downloadFullRescue()')
 bundle=json.loads(Path(d.value.path()).read_text(encoding='utf-8'))
 check('R rescue contains 13 keys and byte-identical quarantine',len(bundle['keys'])==13 and bundle['keys'].get('rackclick_quarantine')==raw,True)
 ctx.close();b.close()
if args.baseline:check('baseline three failures reproduced',len(failures)==3)
print('F2-A1 BASELINE REPRODUCTION PASS' if args.baseline else 'F2-A1 TESTS PASS')

import json,os,re,hashlib
from pathlib import Path
from qa_support import sync_playwright
ROOT=Path(__file__).resolve().parents[1];VERSION=(ROOT/'VERSION').read_text().strip();HTML=ROOT/'dist'/f'RackClick-v{VERSION}-Offline.html';count=0

def check(name,value):
 global count
 assert value,name
 count+=1;print('PASS',name,flush=True)
def state(p):
 p.wait_for_timeout(350);return p.evaluate('JSON.parse(localStorage.getItem(SAVE_KEY))')
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context(accept_downloads=True);p=c.new_page();p.set_default_timeout(10000);p.on('dialog',lambda d:d.accept());errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto(HTML.as_uri());p.locator('.ir-all-clients').click();p.get_by_role('button',name='10 demo clients',exact=True).click();p.locator('.ir-client-card').first.click();p.locator('.ir-racks button').first.click()
 check('Explicit front/rear controls',p.locator('[data-face="front"]').get_attribute('aria-pressed')=='true' and p.locator('[data-face="rear"]').is_visible())
 before=state(p);p.locator('[data-face="rear"]').click();check('Rear selection changes no project data',state(p)==before)
 power=p.evaluate('p=>p.racks.flatMap(r=>r.devs.flatMap(d=>d.ports.filter(p=>p.type==="power")))',before)
 check('Power ports have explicit role and rear face',all(x.get('rackclickFace')=='rear' and x.get('rackclickPowerRole') in ['inlet','outlet'] for x in power))
 check('All demos have UPS and PDU without overfull racks',all(any(d['preset']=='PDU' for d in r['devs']) and any(d['preset']=='UPS 2U' for d in r['devs']) and sum(d['u'] for d in r['devs'])<=r['size'] for r in before['racks']))
 check('Power links valid, unique endpoints',p.evaluate('p=>p.racks.every(r=>{const ports=new Map(r.devs.flatMap(d=>d.ports.map(p=>[p.id,p]))),seen=new Set;return r.conns.filter(c=>c.fpt2==="power"||c.tpt2==="power").every(c=>{const a=ports.get(c.fp),b=ports.get(c.tp);if(!a||!b||!irPowerPairAllowed(a,b)||seen.has(a.id)||seen.has(b.id))return false;seen.add(a.id);seen.add(b.id);return true})})',before))
 check('Power summary lists rack power links',p.locator('.ir-power-summary>div button').count()==7)
 check('Power wires visible on rear',p.locator('[data-wire="demo-c1-r1-power-0"]').count()==1)
 check('Bottom-to-top cables stay between endpoint heights',p.locator('[data-wire="demo-c1-r1-power-2"]').evaluate('e=>{const n=e.getAttribute("d").match(/-?[0-9.]+/g).map(Number);return n[3]<=Math.max(n[1],n[7])&&n[3]>=Math.min(n[1],n[7])&&n[5]<=Math.max(n[1],n[7])&&n[5]>=Math.min(n[1],n[7])}'))
 p.screenshot(path=str(ROOT/'evidence/power-rear-en.png'),full_page=True)
 # Role editing uses real dialog. Editing free UPS inlet is reversible and preserves IDs/links.
 ups=next(d for d in before['racks'][0]['devs'] if d['preset']=='UPS 2U');port=next(x for x in ups['ports'] if x['rackclickPowerRole']=='inlet')
 p.get_by_role('button',name='Configure faces '+ups['name'],exact=True).click();dlg=p.locator('dialog[open]');dlg.get_by_role('combobox',name='Power port role '+port['id'],exact=True).select_option('unspecified');dlg.get_by_role('button',name='Save',exact=True).click();after=state(p)
 check('Explicit power role edit persists and preserves cables', 'rackclickPowerRole' not in next(x for d in after['racks'][0]['devs'] if d['id']==ups['id'] for x in d['ports'] if x['id']==port['id']) and after['racks'][0]['conns']==before['racks'][0]['conns'])
 p.keyboard.press('Control+z');check('Undo restores power metadata',state(p)['racks']==before['racks'])
 p.keyboard.press('Control+y');check('Redo restores chosen metadata',state(p)['racks']==after['racks']);p.keyboard.press('Control+z')
 # Controlled new topology: remove one synthetic power link from a COPY, reload, then connect using exactly two clicks.
 fixture=json.loads(json.dumps(before));r=fixture['racks'][0];link=next(x for x in r['conns'] if x['id']=='demo-c1-r1-power-2');r['conns'].remove(link)
 p.evaluate('p=>localStorage.setItem(SAVE_KEY,JSON.stringify(p))',fixture);p.reload();p.locator('.ir-client-card').first.click();p.locator('.ir-racks button').first.click();p.locator('[data-face="rear"]').click()
 for pid in [link['fp'],link['tp']]:p.locator('[data-vport="'+pid+'"]').click()
 connected=state(p);check('Two clicks connect declared outlet to server inlet',len(connected['racks'][0]['conns'])==len(r['conns'])+1)
 p.keyboard.press('Control+z');check('Undo power connection',state(p)['racks'][0]['conns']==r['conns'])
 # Mixing power with data rejected through UI.
 server=next(d for d in r['devs'] if d['preset']=='Server 2U');data=next(x for x in server['ports'] if x['type']=='rj45')
 p.locator('[data-vport="'+link['fp']+'"]').click();p.locator('[data-vport="'+data['id']+'"]').click();check('Power to network blocked in UI',state(p)['racks'][0]['conns']==r['conns']);p.keyboard.press('Escape')
 check('Role policy rejects matching known roles and accepts unspecified',p.evaluate('()=>!irPowerPairAllowed({type:"power",rackclickPowerRole:"inlet"},{type:"power",rackclickPowerRole:"inlet"})&&!irPowerPairAllowed({type:"power",rackclickPowerRole:"outlet"},{type:"power",rackclickPowerRole:"outlet"})&&irPowerPairAllowed({type:"power"},{type:"power",rackclickPowerRole:"inlet"})'))
 check('Bad metadata rejected by import and boot presentation validators',p.evaluate('p=>{p.racks[0].devs[0].ports[0].rackclickPowerRole="outlet";let n=0;for(const f of [irAssertTopology,irAssertPresentation])try{f(p)}catch{n++}return n===2}',fixture))
 with p.expect_download() as dl:p.keyboard.press('Control+s')
 export=json.loads(Path(dl.value.path()).read_text());check('Export includes exact power endpoints',export['racks'][0]['devs']==r['devs'])
 p.reload();p.locator('.ir-client-card').first.click();p.locator('.ir-racks button').first.click();p.locator('[data-face="rear"]').click();check('Power data survives persistent reload',state(p)['racks'][0]['devs']==r['devs'])
 # Immutable report component from rc4.
 prior=ROOT.parent/'RackClick-v0.9.0-rc4-Clientes-2026-09-26/src/clients.jsxinc'
 if prior.exists():
  a=prior.read_text().split('function IRClientReport')[1].split('function irDemo')[0];bb=(ROOT/'src/clients.jsxinc').read_text().split('function IRClientReport')[1].split('function irDemo')[0];check('Approved client report component unchanged',a==bb)
 check('No JS errors',not errors);c.close();b.close()
print('POWER PASS',count,hashlib.sha256(HTML.read_bytes()).hexdigest())

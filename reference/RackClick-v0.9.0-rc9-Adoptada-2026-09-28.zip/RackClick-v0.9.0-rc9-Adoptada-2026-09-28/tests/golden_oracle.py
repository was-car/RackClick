"""Independent, read-only oracle. Does not call RackClick validation or reports."""
from collections import Counter

def inspect(project):
    endpoints={};devices={};racks={};issues=[];occupied=Counter();links=[]
    for r in project['racks']:
        if r['id'] in racks:issues.append('duplicate rack')
        racks[r['id']]=r
        for d in r['devs']:
            if d['id'] in devices:issues.append('duplicate device')
            devices[d['id']]=r['id']
            for p in d['ports']:
                if p['id'] in endpoints:issues.append('duplicate port')
                endpoints[p['id']]=(r['id'],d['id'],p)
        links.extend((r['id'],r['id'],c) for c in r['conns'])
    links.extend((c['rackFrom'],c['rackTo'],c) for c in project['crossConns'])
    cids=set()
    for fr,tr,c in links:
        if c['id'] in cids:issues.append('duplicate connection')
        cids.add(c['id'])
        for rid,did,pid in [(fr,c['fd'],c['fp']),(tr,c['td'],c['tp'])]:
            if pid not in endpoints or endpoints[pid][:2]!=(rid,did):issues.append('endpoint ownership')
            occupied[pid]+=1
    if any(n>1 for n in occupied.values()):issues.append('double occupation')
    result={}
    for rid,r in racks.items():
        ports=[p for d in r['devs'] for p in d['ports']]
        result[rid]={'ports':len(ports),'usedU':sum(d['u'] for d in r['devs']),
          'occupiedLocalPorts':sum(p['id'] in occupied for p in ports),
          'localConnections':len(r['conns']),
          'crossConnections':sum(rid in (c['rackFrom'],c['rackTo']) for c in project['crossConns']),
          'unconnectedPorts':sum(p['id'] not in occupied for p in ports),
          'connectableFreePorts':sum(p['id'] not in occupied and p.get('status','free')=='free' for p in ports),
          'connectableWithConfirmation':sum(p['id'] not in occupied and p.get('status')=='reserved' for p in ports)}
    return {'racks':result,'totals':{'racks':len(racks),'devices':len(devices),'ports':len(endpoints),'localConnections':sum(len(r['conns']) for r in racks.values()),'crossConnections':len(project['crossConns']),'uniqueOccupiedPorts':len(occupied)},'issues':issues}

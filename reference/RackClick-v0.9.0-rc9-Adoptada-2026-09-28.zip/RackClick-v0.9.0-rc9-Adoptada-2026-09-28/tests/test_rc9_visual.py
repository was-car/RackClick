from pathlib import Path
import os,sys,json,hashlib
from qa_support import sync_playwright
R=Path(__file__).resolve().parents[1];H=R/'dist/RackClick-v0.9.0-rc9-Offline.html';E=R/'evidence/rc9';E.mkdir(parents=True,exist_ok=True);checks=[]
def ck(name,ok):
 assert ok,name
 checks.append(name);print('PASS',name,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context();p=c.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.on('dialog',lambda d:d.accept());p.goto(H.as_uri());fixture=p.evaluate("irDemo('en')");client=fixture['racks'][0]['rackclickLocation']['client'];racks=[r for r in fixture['racks'] if r['rackclickLocation']['client']==client];racks[0]['name']='QA <img src=x onerror=alert(1)> & "RACK"';fixture['rackclickClientMeta']=[{'client':client,'technician':'QA <Techniker>'}]
 for lang,label in [('en','All rack labels'),('de','Alle Rack-Etiketten'),('es','Etiquetas de todos los racks')]:
  p.evaluate('([v,l])=>{localStorage.setItem(SAVE_KEY,JSON.stringify(v));localStorage.setItem(LANG_KEY,l)}',[fixture,lang]);p.reload();before=p.evaluate('localStorage.getItem(SAVE_KEY)');p.locator('.ir-client-card').first.click();p.get_by_role('button',name=label,exact=True).click();p.locator('.ir-batch-label').first.wait_for();ck(lang+' etiquetas solo del cliente',p.locator('.ir-batch-label').count()==len(racks));ck(lang+' texto hostil literal sin elementos inyectados',p.locator('.ir-label-title').first.inner_text()=='RACK: '+racks[0]['name'] and p.locator('.ir-batch-label img').count()==0);ck(lang+' ID y técnico en etiqueta',p.locator('.ir-label-id').first.inner_text()==racks[0]['id'].upper() and 'QA <Techniker>' in p.locator('.ir-label-footer').first.inner_text());ck(lang+' versión real', 'v0.9.0-rc9' in p.locator('.ir-label-footer').first.inner_text());ck(lang+' etiquetas no cambian datos',p.evaluate('localStorage.getItem(SAVE_KEY)')==before)
  if lang=='de':
   p.screenshot(path=str(E/'etiquetas-lote.png'),full_page=True);p.emulate_media(media='print');p.pdf(path=str(E/'etiquetas-lote.pdf'),format='A4',print_background=True);ck('Impresión sin cortar cada etiqueta',p.locator('.ir-batch-label').first.evaluate('(e)=>getComputedStyle(e).breakInside')=='avoid');p.emulate_media(media='screen')
   for width in [390,1440]:
    p.set_viewport_size({'width':width,'height':1050});ck('Etiquetas ancho '+str(width),p.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   p.set_viewport_size({'width':1440,'height':1050})
 # Individual label reference geometry remains intact.
 p.goto(H.as_uri());p.locator('.ir-client-card').first.click();p.locator('.ir-racks button').first.click()
 with p.expect_popup() as pop:p.locator('button[title="Print rack label/tag"]').click()
 q=pop.value;q.wait_for_load_state();q.screenshot(path=str(E/'etiqueta-individual.png'));ref=q.locator('.label').evaluate('(e)=>({border:getComputedStyle(e).borderTopWidth,radius:getComputedStyle(e).borderRadius,width:e.getBoundingClientRect().width})');q.close()
 for theme in ['dark','light']:
  p.evaluate('(theme)=>document.documentElement.dataset.rcTheme=theme',theme);on=p.locator('path[data-poe="on"]').first;ck('PoE amarillo '+theme,on.evaluate('(e)=>getComputedStyle(e).fill')=='rgb(250, 204, 21)');p.screenshot(path=str(E/('poe-'+theme+'.png')),full_page=True)
 p.locator('.ir-client-link').first.click();p.get_by_role('button',name='Etiquetas de todos los racks',exact=True).click();actual=p.locator('.ir-batch-label').first.evaluate('(e)=>({border:getComputedStyle(e).borderTopWidth,radius:getComputedStyle(e).borderRadius,width:e.getBoundingClientRect().width})');ck('Geometría igual a etiqueta individual',actual==ref);ck('Sin errores de aplicación',not errors)
 p.evaluate("()=>{localStorage.setItem(SAVE_KEY,JSON.stringify(irDemo('de')));localStorage.setItem(LANG_KEY,'de')}");p.reload();p.locator('.ir-client-card').last.click();p.get_by_role('button',name='Alle Rack-Etiketten',exact=True).click();ck('Cliente grande: 17 etiquetas',p.locator('.ir-batch-label').count()==17);p.screenshot(path=str(E/'etiquetas-cliente17.png'),full_page=True);p.emulate_media(media='print');ck('Controles no se imprimen',not p.locator('nav').is_visible());ck('Papel blanco incluso con tema oscuro',p.locator('html').evaluate('(e)=>getComputedStyle(e).backgroundColor')=='rgb(255, 255, 255)');p.pdf(path=str(E/'etiquetas-cliente17.pdf'),format='A4',print_background=True);b.close()
(E/'resultados.json').write_text(json.dumps({'sha256':hashlib.sha256(H.read_bytes()).hexdigest(),'checks':checks,'status':'PASS','scope':'Cambios RC9 dirigidos, Chromium/Linux; sin adopción'},ensure_ascii=False,indent=2))

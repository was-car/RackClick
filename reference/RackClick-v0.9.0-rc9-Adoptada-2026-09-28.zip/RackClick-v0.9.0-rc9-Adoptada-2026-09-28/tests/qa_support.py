"""Legacy assertions, independent persistent profile per case, offline only."""
from contextlib import contextmanager
from pathlib import Path
import os, tempfile, shutil, re
from playwright.sync_api import sync_playwright as _sync_playwright

@contextmanager
def sync_playwright():
    with _sync_playwright() as pw:
        contexts, profiles, requests = [], [], []
        browser_type = pw.firefox if os.environ.get('RACKCLICK_BROWSER')=='firefox' else pw.chromium
        class PersistentBrowser:
            def new_context(self, **kw):
                profile = tempfile.mkdtemp(prefix='rackclick-qa-')
                profiles.append(profile)
                opts = dict(headless=True, viewport={'width':1440,'height':1050})
                executable = os.environ.get('RACKCLICK_FIREFOX') if browser_type==pw.firefox else os.environ.get('RACKCLICK_CHROMIUM')
                if executable: opts['executable_path'] = executable
                if browser_type==pw.chromium: opts['args'] = ['--no-sandbox', '--disable-dev-shm-usage']
                opts.update(kw)
                ctx = browser_type.launch_persistent_context(profile, **opts)
                # A glob such as https://** missed nested URLs in the original
                # harness. Anchor at the scheme so any path depth is blocked.
                ctx.route(re.compile(r'^http://'), lambda r: (requests.append(r.request.url), r.abort()))
                ctx.route(re.compile(r'^https://'), lambda r: (requests.append(r.request.url), r.abort()))
                contexts.append(ctx)
                return ctx
            def close(self):
                for ctx in contexts:
                    try: ctx.close()
                    except Exception: pass
        pw.chromium.launch = lambda **kw: PersistentBrowser()
        try: yield pw
        finally:
            PersistentBrowser().close()
            for profile in profiles: shutil.rmtree(profile, ignore_errors=True)
            assert not requests, 'Unexpected runtime network requests: '+str(requests)

def cache_cdn(route):
    raise AssertionError('Offline candidate tried loading CDN: '+route.request.url)

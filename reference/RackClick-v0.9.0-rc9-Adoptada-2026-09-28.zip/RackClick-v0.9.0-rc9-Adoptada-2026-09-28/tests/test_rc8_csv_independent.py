"""Independent real-download global CSV check; no product changes."""
import csv,json,io,hashlib
from pathlib import Path
from qa_support import sync_playwright
R=Path(__file__).resolve().parents[1];H=R/'dist/RackClick-v0.9.0-rc8-Offline.html';O=R/'evidence/rc8/independent/chromium';results=[]
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context(accept_downloads=True);p=c.new_page();p.goto(H.as_uri());fixture=p.evaluate('irDemo("en")');p.evaluate('d=>{localStorage.setItem(SAVE_KEY,JSON.stringify(d));localStorage.setItem(LANG_KEY,"en")}',fixture);p.reload()
 with p.expect_download() as dl:p.get_by_role('button',name='All clients connections CSV',exact=True).click()
 rows=list(csv.reader(io.StringIO(Path(dl.value.path()).read_text(encoding='utf-8-sig'))));expected=sum(len(r['conns']) for r in fixture['racks'])+len(fixture['crossConns']);clients={r['rackclickLocation']['client'] for r in fixture['racks']};results=[{'name':'Client column and all ten clients present','pass':rows[0][0]=='Client' and {r[0] for r in rows[1:]}==clients},{'name':'Every local/cross link once in global CSV','pass':len(rows)-1==expected},{'name':'All rows uniform twelve columns','pass':all(len(r)==12 for r in rows)}];print(results);c.close();b.close()
(O/'csv-independent.json').write_text(json.dumps({'sha256':hashlib.sha256(H.read_bytes()).hexdigest(),'results':results,'expectedRows':expected},indent=2));assert all(x['pass'] for x in results)

#!/usr/bin/env python3
"""Tests de arranque T1–T8 — v0.8.2 (Paso 3)"""
import json, hashlib, os
from pathlib import Path
from qa_support import sync_playwright, cache_cdn

sha = lambda s: hashlib.sha256(s.encode()).hexdigest()
HTML = Path(os.environ.get("RACKCLICK_HTML", "rackclick-v0.8.6.html")).resolve().as_uri()

HEALTHY = json.dumps({"version": "0.8", "name": "Sano-T", "technician": "", "createdAt": "2026-01-01", "updatedAt": "2026-01-01",
    "racks": [{"id": "r1", "name": "RackSano", "location": "", "size": 12, "devs": [], "conns": []}], "crossConns": [], "changeLog": []})
BACKUP_GOOD = json.dumps({"version": "0.8", "name": "DesdeBackup2", "technician": "", "createdAt": "2026-01-01", "updatedAt": "2026-01-01",
    "racks": [{"id": "r2", "name": "RackBackup", "location": "", "size": 24, "devs": [], "conns": []}], "crossConns": [], "changeLog": []})
CORRUPT_UNPARSEABLE = "{{{esto no es json"
CORRUPT_V07 = json.dumps({"version": "0.7", "name": "Viejo", "racks": [{"id": "x", "name": "R", "size": 12, "devs": [], "conns": []}]})
REPAIRABLE = json.dumps({"version": "0.8", "name": "Reparable", "racks": [
    {"id": "r3", "name": "RackRep", "size": 12, "devs": [
        {"id": "d1", "name": "DevOK", "u": 1, "ports": [{"id": "p1", "gn": 1, "type": "rj45"}]},
        {"id": "d2", "name": "DevRoto", "u": 1, "ports": "no-es-array"}
    ], "conns": []}], "crossConns": [], "changeLog": []})
STRUCT_BROKEN = json.dumps({"version": "0.8", "name": "Roto", "racks": "no-es-array"})

def boot(pw, seed, wait=4500):
    browser = pw.chromium.launch()
    ctx = browser.new_context(accept_downloads=True)
    page = ctx.new_page()
    if seed:
        page.add_init_script(f"const s = {json.dumps(seed)}; for (const [k,v] of Object.entries(s)) localStorage.setItem(k,v);")
    page.context.route("https://cdnjs.cloudflare.com/**", cache_cdn)
    page.goto(HTML)
    page.wait_for_timeout(wait)
    return browser, page

def ls(page):
    return page.evaluate("() => { const o={}; for (let i=0;i<localStorage.length;i++){const k=localStorage.key(i); o[k]=localStorage.getItem(k);} return o; }")

R = []
with sync_playwright() as pw:
    # ── T1: autosave sano → carga idéntica, sin cuarentena ──
    b, p = boot(pw, {"rackclick_autosave_v08": HEALTHY})
    body = p.inner_text("body")
    store = ls(p)
    inputs = p.evaluate("() => [...document.querySelectorAll('input')].map(i => i.value)")
    t1 = ("RackSano" in body and "Sano-T" in inputs
          and "rackclick_quarantine" not in store
          and "Safe mode" not in body and "Modo seguro" not in body)
    # el autosave del montaje reescribe SAVE_KEY (comportamiento normal, igual que v0.8.1)
    reloaded = json.loads(store["rackclick_autosave_v08"])
    t1 = t1 and reloaded["name"] == "Sano-T" and reloaded["racks"][0]["name"] == "RackSano"
    R.append(("T1", "Autosave sano → carga idéntica, sin notificación ni cuarentena", t1)); b.close()

    # ── T2: autosave imparseable + backup_2 sano → recupera, cuarentena byte-idéntica ──
    b, p = boot(pw, {"rackclick_autosave_v08": CORRUPT_UNPARSEABLE, "rackclick_backup_2": BACKUP_GOOD}, wait=0)
    try:
        p.wait_for_selector("text=recovered from backup", timeout=10000)
        noti_seen = True
    except Exception:
        noti_seen = False
    p.wait_for_timeout(2500)
    body = p.inner_text("body"); store = ls(p)
    q = json.loads(store.get("rackclick_quarantine", "{}"))
    inputs2 = p.evaluate("() => [...document.querySelectorAll('input')].map(i => i.value)")
    t2 = ("RackBackup" in body and "DesdeBackup2" in inputs2
          and q.get("reason") == "autosave-invalid"
          and q["keys"]["autosave"] == CORRUPT_UNPARSEABLE
          and q["keys"]["rackclick_backup_2"] == BACKUP_GOOD
          and noti_seen)
    R.append(("T2", "Autosave imparseable + backup_2 sano → recuperado, cuarentena con crudos byte-idénticos", t2)); b.close()

    # ── T3: autosave v0.7 → misma ruta ──
    b, p = boot(pw, {"rackclick_autosave_v08": CORRUPT_V07, "rackclick_backup_1": BACKUP_GOOD})
    body = p.inner_text("body"); store = ls(p)
    q = json.loads(store.get("rackclick_quarantine", "{}"))
    t3 = "RackBackup" in body and q.get("keys", {}).get("autosave") == CORRUPT_V07
    R.append(("T3", "Autosave version 0.7 → tratado como inválido, backup recuperado", t3)); b.close()

    # ── T4: todo roto → modo seguro, bundle completo ──
    seed4 = {"rackclick_autosave_v08": STRUCT_BROKEN, "rackclick_backup_1": CORRUPT_UNPARSEABLE,
             "rackclick_backup_2": CORRUPT_V07, "rackclick_backup_3": "{{{"}
    b, p = boot(pw, seed4, wait=0)
    try:
        p.wait_for_selector("text=Safe mode", timeout=10000); noti4 = True
    except Exception:
        noti4 = False
    p.wait_for_timeout(2500)
    body = p.inner_text("body"); store = ls(p)
    q = json.loads(store.get("rackclick_quarantine", "{}"))
    t4 = (q.get("reason") == "all-invalid"
          and q["keys"]["autosave"] == STRUCT_BROKEN
          and q["keys"]["rackclick_backup_1"] == CORRUPT_UNPARSEABLE
          and q["keys"]["rackclick_backup_2"] == CORRUPT_V07
          and q["keys"]["rackclick_backup_3"] == "{{{"
          and "Rack 1" in body  # proyecto vacío funcional
          and noti4)
    R.append(("T4", "Todo corrupto → modo seguro + bundle de 4 crudos + notificación", t4)); b.close()

    # ── T5: reparable → arranca reparado, original en cuarentena ──
    b, p = boot(pw, {"rackclick_autosave_v08": REPAIRABLE})
    body = p.inner_text("body"); store = ls(p)
    q = json.loads(store.get("rackclick_quarantine", "{}"))
    saved = json.loads(store["rackclick_autosave_v08"])
    devs = saved["racks"][0]["devs"]
    t5 = (q.get("reason") == "repaired-at-boot"
          and q["keys"]["autosave"] == REPAIRABLE
          and len(devs) == 1 and devs[0]["name"] == "DevOK"  # DevRoto filtrado
          and "RackRep" in body)
    R.append(("T5", "Corrupción reparable → arranca reparado (dev inválido filtrado), original en cuarentena", t5)); b.close()

    # ── T6: primer uso → sin cuarentena, sin notificación ──
    b, p = boot(pw, None)
    body = p.inner_text("body"); store = ls(p)
    inputs6 = p.evaluate("() => [...document.querySelectorAll('input')].map(i => i.value)")
    t6 = ("rackclick_quarantine" not in store
          and "New Project" in inputs6
          and "Safe mode" not in body and "quarantine" not in body.lower())
    R.append(("T6", "Primer uso → proyecto vacío, sin cuarentena ni notificación", t6)); b.close()

    # ── T7: UI de cuarentena — descarga bundle, descarga autosave crudo, eliminar con confirm ──
    b, p = boot(pw, {"rackclick_autosave_v08": CORRUPT_UNPARSEABLE, "rackclick_backup_1": BACKUP_GOOD})
    store_before = ls(p)
    p.locator("button", has_text="⚙️").first.click()
    p.wait_for_timeout(500)
    body = p.inner_text("body")
    ui_visible = "CUARENTENA" in body or "QUARANTINE" in body or "QUARANTÄNE" in body
    with p.expect_download() as dl:
        p.locator("button", has_text="Download bundle").first.click()
    bundle_file = open(dl.value.path()).read()
    bundle_matches = bundle_file == store_before["rackclick_quarantine"]
    with p.expect_download() as dl2:
        p.locator("button", has_text="autosave").first.click()
    raw_file = open(dl2.value.path()).read()
    raw_matches = raw_file == CORRUPT_UNPARSEABLE  # crudo, sin envolver
    # Eliminar: primero cancelar el confirm → no borra; luego aceptar → borra
    p.once("dialog", lambda d: d.dismiss())
    p.locator("button", has_text="Delete quarantine").first.click()
    p.wait_for_timeout(400)
    still_there = "rackclick_quarantine" in ls(p)
    p.once("dialog", lambda d: d.accept())
    p.locator("button", has_text="Delete quarantine").first.click()
    p.wait_for_timeout(400)
    gone = "rackclick_quarantine" not in ls(p)
    t7 = ui_visible and bundle_matches and raw_matches and still_there and gone
    R.append(("T7", f"UI cuarentena: visible={ui_visible}, bundle exacto={bundle_matches}, autosave crudo sin envolver={raw_matches}, cancelar respeta={still_there}, aceptar elimina={gone}", t7)); b.close()

    # ── T8: MODO SEGURO NO SOBRESCRIBE — la condición clave del usuario ──
    b, p = boot(pw, seed4, wait=6000)  # 6s: mucho después del primer render
    store = ls(p)
    autosave_untouched = store.get("rackclick_autosave_v08") == STRUCT_BROKEN
    q_exists = "rackclick_quarantine" in store
    body = p.inner_text("body")
    in_safe_mode = "Rack 1" in body
    # Acción real del usuario: + Add Rack (usa prompt() → aceptar con nombre)
    p.once("dialog", lambda d: d.accept("RackNuevo"))
    p.get_by_text("+ Add Rack", exact=True).click()
    p.wait_for_timeout(1500)
    store2 = ls(p)
    resumed = False
    try:
        after = json.loads(store2["rackclick_autosave_v08"])
        resumed = after.get("version") == "0.8" and len(after.get("racks", [])) == 2
    except Exception:
        resumed = False
    t8 = autosave_untouched and q_exists and in_safe_mode and resumed
    R.append(("T8", f"SafeMode: autosave INTACTO tras 6s (={autosave_untouched}), cuarentena existe (={q_exists}), y autosave REANUDA tras acción real (={resumed})", t8)); b.close()

print("=" * 78)
for name, desc, ok in R:
    print(f"  [{name}] {'✓ PASS' if ok else '✗ FAIL'} — {desc}")
allok = all(r[2] for r in R)
print("\n" + ("✅ BOOT TESTS: 8/8 PASS" if allok else "❌ FALLOS DETECTADOS"))
exit(0 if allok else 1)

"""Run shipped tests, fail honestly, retain per-suite output and artifact hash."""
import os,sys,subprocess,json,hashlib,time,concurrent.futures
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];os.chdir(ROOT)
version=(ROOT/'VERSION').read_text().strip();html=ROOT/'dist'/f'RackClick-v{version}-Offline.html'
os.environ['RACKCLICK_HTML']=str(html);os.environ['PYTHONUTF8']='1'
results=[];folder=ROOT/'evidence';folder.mkdir(exist_ok=True)
MARKERS={
 'boot':'BOOT TESTS: 8/8 PASS','autosave':'AUTOSAVE TESTS: PASS',
 'snapshot':'SNAPSHOT TESTS: PASS','qa':'QA TESTS: PASS',
 'v085':'V085 TESTS PASS','f2a1':'F2-A1 TESTS PASS',
 'connection_policy':'CONNECTION POLICY PASS','integrated':'INTEGRATED TESTS PASS',
 'pointer_stability':'PASS double-click labels port without opening device editor',
 'performance':'"thresholds_met": true','infrastructure':'INFRASTRUCTURE PASS',
 'clients':'CLIENT TESTS PASS','power':'POWER PASS',
 'reports_templates':'PASS No application errors'
}
def run_suite(name):
 print('Running',name,flush=True);start=time.time()
 run=subprocess.run([sys.executable,'-X','utf8',str(ROOT/'tests'/f'test_{name}.py')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
 (folder/f'tests-{name}.txt').write_text(run.stdout,encoding='utf-8')
 complete=MARKERS[name] in run.stdout
 passed=run.returncode==0 and complete
 print(name, 'PASS' if passed else 'INCOMPLETE/FAIL',flush=True)
 return {'suite':name,'exit':run.returncode,'completionMarker':MARKERS[name],
         'completionVerified':complete,'passed':passed,'seconds':round(time.time()-start,2)}
with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
 results=list(pool.map(run_suite,['boot','autosave','snapshot','qa','v085','f2a1','connection_policy','integrated','pointer_stability','performance','infrastructure','clients','power','reports_templates']))
report={'version':version,'htmlSHA256':hashlib.sha256(html.read_bytes()).hexdigest(),'browser':os.environ.get('RACKCLICK_BROWSER','chromium'),'results':results}
(folder/'qa-summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
sys.exit(1 if any(not r['passed'] for r in results) else 0)

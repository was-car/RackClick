"""Actual offline UI downloads for the four rc7 export corrections."""
import csv
import copy
import io
import json
import os
import re
import unittest
from pathlib import Path

from PIL import Image
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
VERSION = (ROOT / 'VERSION').read_text().strip()
HTML = (ROOT / 'dist' / f'RackClick-v{VERSION}-Offline.html').as_uri()
GOLDEN = json.loads((ROOT / 'fixtures' / 'golden-test.json').read_text())


class ExportCorrections(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runner = sync_playwright().start()
        launch = {'headless': True}
        target = os.environ.get('RACKCLICK_BROWSER', 'chromium')
        if target not in ('chromium', 'firefox'):
            raise ValueError('RACKCLICK_BROWSER must be chromium or firefox')
        executable = os.environ.get('RACKCLICK_FIREFOX' if target == 'firefox' else 'RACKCLICK_CHROMIUM')
        if executable:
            launch['executable_path'] = executable
        cls.browser = getattr(cls.runner, target).launch(**launch)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.runner.stop()

    def setUp(self):
        self.context = self.browser.new_context(accept_downloads=True)
        self.requests = []
        self.context.route(re.compile(r'^https?://'), lambda route: route.abort())
        self.context.on('request', lambda request: self.requests.append(request.url) if request.url.startswith(('http://','https://')) else None)
        self.page = self.context.new_page()
        seed_data = copy.deepcopy(GOLDEN)
        seed_data['racks'][0]['conns'][0]['patchStatus'] = 'planned'
        seed_data['crossConns'][0]['patchStatus'] = 'progress'
        seed = json.dumps(seed_data)
        self.page.add_init_script(f'''if(!sessionStorage.rcSeed){{localStorage.setItem("rackclick_autosave_v08",{json.dumps(seed)});sessionStorage.rcSeed="1";}}''')
        self.page.goto(HTML)
        self.page.locator('.ir-racks button').first.click()
        self.page.locator('.ir-physical-note').wait_for()

    def tearDown(self):
        self.assertEqual(self.requests, [], f'Unexpected network requests: {self.requests}')
        self.context.close()

    def _download(self, click):
        with self.page.expect_download(timeout=90000) as received:
            click()
        return Path(received.value.path()).read_bytes()

    def test_rack_json_warns_about_cross_links_before_download(self):
        self.assertTrue(GOLDEN['crossConns'])
        downloads=[]
        self.page.on('download',lambda download:downloads.append(download.suggested_filename))
        messages = []
        def cancel(dialog):
            messages.append(dialog.message)
            dialog.dismiss()
        self.page.once('dialog', cancel)
        self.page.get_by_title('Export rack JSON', exact=True).click()
        self.assertRegex(messages[0], r'cross-rack.*project JSON')
        self.page.wait_for_timeout(100)
        self.assertEqual(downloads,[])
        self.page.once('dialog', lambda dialog: dialog.accept())
        data = json.loads(self._download(lambda: self.page.get_by_title('Export rack JSON', exact=True).click()))
        self.assertEqual(data['version'], '0.8-rack')
        self.assertNotIn('crossConns', data)  # Explicitly announced local-only schema.

    def test_csv_modern_reports_include_cross_links(self):
        self.page.get_by_role('button', name=re.compile(r'Report$')).click()
        rack_csv = self._download(lambda: self.page.get_by_role('button', name='Export CSV').click()).decode('utf-8-sig')
        self.assertIn('Cross-Rack', rack_csv)
        self.assertIn('→', rack_csv)
        self.page.get_by_role('button', name='Back').first.click()
        self.page.locator('.ir-client-tree button').first.click() if self.page.locator('.ir-client-tree button').count() else None
        # Project report button from the client screen rather than classic fallback.
        self.page.get_by_role('button', name=re.compile(r'Report$')).first.click()
        project_csv = self._download(lambda: self.page.get_by_role('button', name='Export CSV').click()).decode('utf-8-sig')
        rows = list(csv.reader(io.StringIO(project_csv)))
        self.assertGreaterEqual(len(rows), 2)
        self.assertEqual(len(rows[0]), 11)
        self.assertIn('→', project_csv)

    def test_csv_local_rows_roundtrip_through_import(self):
        self.page.get_by_role('button', name=re.compile(r'Report$')).click()
        exported=self._download(lambda:self.page.get_by_role('button', name='Export CSV').click()).decode('utf-8-sig')
        values=list(csv.reader(io.StringIO(exported)))
        # Golden also has two physically distinct RJ45 gn=1 ports on SW-A.
        # CSV lacks an immutable port ID; this ambiguous row must be rejected.
        local=[row for row in values[1:] if not row[8] and row[3]=='rj45_poe']
        self.assertEqual(len(local),2)
        output=io.StringIO(newline='');writer=csv.writer(output,lineterminator='\r\n');writer.writerows([values[0],*local])

        clean=copy.deepcopy(GOLDEN)
        for rack in clean['racks']: rack['conns']=[]
        clean['crossConns']=[]
        context=self.browser.new_context(accept_downloads=True)
        attempted=[]
        context.route(re.compile(r'^https?://'),lambda route:route.abort())
        context.on('request',lambda request:attempted.append(request.url) if request.url.startswith(('http://','https://')) else None)
        page=context.new_page()
        page.add_init_script(f'''if(!sessionStorage.csvSeed){{localStorage.setItem("rackclick_autosave_v08",{json.dumps(json.dumps(clean))});sessionStorage.csvSeed="1";}}''')
        try:
            page.goto(HTML);page.locator('.ir-racks button').first.click()
            with page.expect_file_chooser() as chooser:
                page.get_by_title('Import connections from CSV').click()
            chooser.value.set_files({'name':'rack-local.csv','mimeType':'text/csv','buffer':output.getvalue().encode('utf-8-sig')})
            page.wait_for_function('(count)=>document.querySelectorAll(".ir-connection-card").length>=count',arg=len(local),timeout=7000)
            with page.expect_download() as received:
                page.keyboard.press('Control+s')
            result=json.loads(Path(received.value.path()).read_bytes())
            got=result['racks'][0]['conns']
            self.assertEqual(len(got),len(local))
            self.assertEqual([c['note'] for c in got],[c['note'] for c in GOLDEN['racks'][0]['conns'][:2]])
            self.assertEqual(result['crossConns'],[])
            self.assertEqual(attempted,[])
        finally:
            context.close()

    def test_csv_client_scope_and_cross_rows_once(self):
        scoped=copy.deepcopy(GOLDEN)
        locations=[]
        for index,rack in enumerate(scoped['racks']):
            place={'client':'Client Alpha' if index<2 else 'Client Beta','site':'Site 1','building':'Building A','room':'Room 1'}
            rack['rackclickLocation']=place
            if place not in locations: locations.append(place)
        scoped['rackclickLocations']=locations
        context=self.browser.new_context(accept_downloads=True)
        attempted=[]
        context.route(re.compile(r'^https?://'),lambda route:route.abort())
        context.on('request',lambda req:attempted.append(req.url) if req.url.startswith(('http://','https://')) else None)
        page=context.new_page()
        page.add_init_script(f'''if(!sessionStorage.clientSeed){{localStorage.setItem("rackclick_autosave_v08",{json.dumps(json.dumps(scoped))});sessionStorage.clientSeed="1";}}''')
        try:
            page.goto(HTML)
            page.locator('.ir-client-card').filter(has=page.get_by_role('heading',name='Client Alpha')).click()
            page.get_by_role('button',name=re.compile('Report$')).first.click()
            with page.expect_download() as received: page.get_by_role('button',name='Export CSV').click()
            rows=list(csv.reader(io.StringIO(Path(received.value.path()).read_text(encoding='utf-8-sig'))))
            local_count=sum(len(r['conns']) for r in scoped['racks'][:2])
            self.assertEqual(len(rows)-1,local_count+1) # x1 A→B appears once, x2/x3 cross client omitted.
            self.assertEqual(sum(bool(row[8]) for row in rows[1:]),1)
            self.assertNotIn('Rack C','\n'.join(','.join(row) for row in rows[1:]))
            self.assertEqual(attempted,[])
        finally:
            context.close()

    def test_png_transparency_is_real_and_opaque_is_opaque(self):
        opaque = self._download(lambda: self.page.get_by_title('Export rack as PNG HD (4x)', exact=True).click())
        transparent = self._download(lambda: self.page.get_by_title('Export rack as PNG transparent (4x)', exact=True).click())
        a = Image.open(io.BytesIO(opaque)); b = Image.open(io.BytesIO(transparent))
        self.assertEqual(a.size, b.size)
        self.assertEqual(b.mode, 'RGBA')
        self.assertEqual(b.getextrema()[-1][0], 0)
        self.assertEqual(b.getextrema()[-1][1], 255)
        self.assertEqual(a.getextrema()[-1][0], 255)
        self.assertNotEqual(opaque, transparent)

    def test_qr_discloses_decorative_status_before_download(self):
        messages=[]
        downloads=[]
        self.page.on('download',lambda download:downloads.append(download.suggested_filename))
        self.page.once('dialog',lambda d:(messages.append(d.message),d.dismiss()))
        self.page.get_by_title('QR Code').click()
        self.assertIn('Decorative QR', messages[0])
        self.page.wait_for_timeout(100)
        self.assertEqual(downloads,[])
        self.page.once('dialog',lambda d:d.accept())
        with self.page.expect_download() as received:
            self.page.get_by_title('QR Code').click()
        payload=Path(received.value.path()).read_bytes()
        self.assertTrue(received.value.suggested_filename.startswith('decorative-qr-not-scannable-'))
        self.assertTrue(payload.startswith(b'\x89PNG\r\n\x1a\n'))
        image=Image.open(io.BytesIO(payload)).convert('RGB')
        self.assertGreater(image.width, image.height)
        ink=sum(1 for y in range(image.height-35,image.height-12) for x in range(image.width) if sum(image.getpixel((x,y)))<180)
        self.assertGreater(ink,20,'Decorative warning must be visible in PNG itself')

    def test_german_and_spanish_export_disclosures(self):
        for lang, fragment, status in [('de', 'Dekorativer QR', 'Geplant'), ('es', 'QR decorativo', 'Planificado')]:
            self.page.evaluate('(lang) => localStorage.setItem("rackclick_lang", lang)', lang)
            self.page.reload()
            self.page.locator('.ir-racks button').first.click()
            warnings=[]
            self.page.once('dialog', lambda dialog: (warnings.append(dialog.message), dialog.dismiss()))
            self.page.get_by_title('QR Code').click()
            self.assertIn(fragment, warnings[0])
            self.page.get_by_role('button', name=re.compile(r'(Report|Bericht|Informe)$')).click()
            content=self._download(lambda:self.page.get_by_role('button', name='Export CSV').click()).decode('utf-8-sig')
            self.assertIn('From Device', content.splitlines()[0])  # Import contract is stable.
            self.assertIn(status, content)
            self.page.get_by_role('button', name=re.compile(r'^(Back|Zurück|Volver)$')).first.click()


if __name__ == '__main__': unittest.main(verbosity=2)

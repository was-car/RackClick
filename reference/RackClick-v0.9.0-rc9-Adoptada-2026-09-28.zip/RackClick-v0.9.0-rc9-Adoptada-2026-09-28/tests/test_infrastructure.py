"""Observable UI tests: hierarchy, physical faces, persistence and legacy roundtrip."""
import os,json,re,tempfile,hashlib
from pathlib import Path
from qa_support import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=Path(os.environ.get('RACKCLICK_HTML', ROOT/'dist/RackClick-v0.9.0-rc6-Offline.html')).resolve()
G=json.loads((ROOT/'fixtures/golden-test.json').read_text());SAVE='rackclick_autosave_v08';count=0

def check(msg,value):
 global count
 assert value,msg
 count+=1;print('PASS',msg,flush=True)
def state(p):
 p.wait_for_timeout(800);return json.loads(p.evaluate('localStorage.getItem(SAVE_KEY)'))
with sync_playwright() as pw:
 b=pw.chromium.launch();c=b.new_context();p=c.new_page();errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.on('dialog',lambda d:d.accept('Payamps IT'))
 p.add_init_script('if(!localStorage.getItem('+json.dumps(SAVE)+'))localStorage.setItem('+json.dumps(SAVE)+','+json.dumps(json.dumps(G))+');')
 p.goto(HTML.as_uri());p.locator('.ir-nav').wait_for()
 before=state(p);p.get_by_role('button',name='Systemhaus name',exact=True).click();check('Organization saved with project',state(p)['rackclickSystemhaus']=='Payamps IT')
 p.locator('.ir-manage').click();dialog=p.locator('dialog[open]')
 for key,value in [('client','Client A'),('site','Stuttgart'),('building','A'),('room','Serverraum')]:dialog.locator('[data-field="'+key+'"]').fill(value)
 dialog.get_by_role('button',name='Add location',exact=True).click();dialog.get_by_role('button',name='Cancel',exact=True).last.click();check('Cancel adds no metadata',not state(p).get('rackclickLocations'))
 p.locator('.ir-manage').click()
 for customer,city in [('Client A','Stuttgart'),('Client B','Bretten')]:
  for key,value in [('client',customer),('site',city),('building','A'),('room','Serverraum')]:dialog.locator('[data-field="'+key+'"]').fill(value)
  dialog.get_by_role('button',name='Add location',exact=True).click()
 sels=dialog.locator('.ir-assignment select');sels.nth(0).select_option(index=1);sels.nth(1).select_option(index=2)
 # The dialog draft must not be invalidated by global undo.
 dialog.get_by_role('heading',name='Assign rack',exact=True).click();p.keyboard.press('Control+z')
 check('Dialog prevents underlying global undo',state(p)['rackclickSystemhaus']=='Payamps IT')
 dialog.get_by_role('button',name='Save',exact=True).click();saved=state(p)
 check('Two clients persist and retain all links',len(saved['rackclickLocations'])==2 and saved['crossConns']==G['crossConns'])
 check('Assignments retain every device',all(a['devs']==b['devs'] for a,b in zip(saved['racks'],G['racks'])))
 p.keyboard.press('Control+z');check('Undo hierarchy',not state(p).get('rackclickLocations'));p.keyboard.press('Control+y');check('Redo hierarchy',len(state(p)['rackclickLocations'])==2)
 p.locator('.ir-manage').click();dialog.get_by_role('button',name='Remove location',exact=True).first.click();check('Cannot remove occupied location',dialog.get_by_role('alert').count()==1);dialog.get_by_role('button',name='Cancel',exact=True).last.click()
 print('PRE-RELOAD',len(state(p).get('rackclickLocations',[])),flush=True);p.reload();p.locator('.ir-nav').wait_for();p.wait_for_timeout(400);check('Hierarchy survives reload',p.locator('.ir-client-card').count()==3 and p.get_by_role('heading',name='Client A',exact=True).count()==1 and p.get_by_role('heading',name='Client B',exact=True).count()==1)
 p.locator('.ir-client-card').filter(has=p.get_by_role('heading',name='Client A',exact=True)).click();p.locator('.ir-racks button').first.click();p.wait_for_timeout(200)
 check('Breadcrumb contains actual hierarchy','Client A' in p.locator('.ir-breadcrumb').inner_text() and 'Serverraum' in p.locator('.ir-breadcrumb').inner_text())
 front=p.locator('[data-vport]').evaluate_all('(xs)=>xs.map(x=>x.dataset.vport)');order=p.locator('.ir-device-row[data-devid]').evaluate_all('(xs)=>xs.map(x=>x.dataset.devid)')
 p.get_by_role('button',name=re.compile('▤|▥')).first.click();rear=p.locator('[data-vport]').evaluate_all('(xs)=>xs.map(x=>x.dataset.vport)')
 check('Each port on one face; all preserved',set(front).isdisjoint(rear) and set(front+rear)=={q['id'] for d in G['racks'][0]['devs'] for q in d['ports']})
 check('Rear retains physical vertical order',order==p.locator('.ir-device-row[data-devid]').evaluate_all('(xs)=>xs.map(x=>x.dataset.devid)'))
 check('Rear chassis details visible',p.locator('.ir-rear-hardware').count()>0)
 check('Other face cable stubs present',p.locator('.ir-wires path[stroke-dasharray]').count()>0)
 target=G['racks'][0]['devs'][2];pid=target['ports'][0]['id']
 p.get_by_role('button',name='Configure faces '+target['name'],exact=True).click();p.locator('dialog select').first.select_option('front');dialog.get_by_role('button',name='Save',exact=True).click();changed=state(p)
 check('Explicit face saved without ID change',changed['racks'][0]['devs'][2]['ports'][0]['rackclickFace']=='front' and changed['racks'][0]['devs'][2]['ports'][0]['id']==pid)
 check('Face edit preserves connections',changed['crossConns']==saved['crossConns'] and [r['conns'] for r in changed['racks']]==[r['conns'] for r in saved['racks']])
 p.keyboard.press('Control+z');check('Undo face exact ports',state(p)['racks'][0]['devs'][2]['ports']==G['racks'][0]['devs'][2]['ports']);p.keyboard.press('Control+y')
 p.locator('.ir-all-clients').click()
 with p.expect_download() as dl:p.get_by_role('button',name='Export full backup',exact=True).click()
 exported=json.loads(Path(dl.value.path()).read_text());check('Export includes hierarchy and face',exported['racks'][0]['devs'][2]['ports'][0]['rackclickFace']=='front' and len(exported['rackclickLocations'])==2 and exported['version']=='0.8')
 # Original adopted validators and the original spread-based Save retain extensions.
 original=(ROOT/'src/rack-click-v0.8.6.jsx').read_text();start=original.index('const validateRack =');end=original.index('\n};',original.index('const validateProject ='))+3
 legacy=p.evaluate("([code,data])=>{const p=structuredClone(data);const validate=Function('p',code+';return validateProject(p)');if(validate(p))return false;const saved={...p,updatedAt:data.updatedAt};return JSON.stringify(saved.racks)===JSON.stringify(data.racks)&&JSON.stringify(saved.crossConns)===JSON.stringify(data.crossConns)&&saved.rackclickSystemhaus===data.rackclickSystemhaus&&JSON.stringify(saved.rackclickLocations)===JSON.stringify(data.rackclickLocations)}",[original[start:end],exported])
 check('Original v086 validation and Save pattern preserve extension and topology',legacy)
 check('Invalid metadata refused',p.evaluate('g=>{for(const mutate of [x=>x.rackclickLocations={},x=>x.racks[0].rackclickLocation={client:3},x=>x.racks[0].devs[0].ports[0].rackclickFace="wrong"]){const x=structuredClone(g);mutate(x);try{irAssertTopology(x);return false}catch{}}return true}',G))
 p.locator('.ir-client-card').filter(has=p.get_by_role('heading',name='Client A',exact=True)).click();p.locator('.ir-racks button').first.click();p.get_by_role('button',name=re.compile('▤|▥')).first.click();p.screenshot(path=str(ROOT/'evidence/rc3-front.png'),full_page=True)
 p.get_by_role('button',name=re.compile('▤|▥')).first.click();p.screenshot(path=str(ROOT/'evidence/rc3-rear.png'),full_page=True)
 check('No own JS errors',not errors)
 c.close();b.close()
print('INFRASTRUCTURE PASS',count,hashlib.sha256(HTML.read_bytes()).hexdigest())

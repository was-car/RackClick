import{fileURLToPath,pathToFileURL}from'node:url';import os from'node:os';import path from'node:path';
import{createRequire}from'node:module';import fs from'node:fs';
const require=createRequire(import.meta.url),{chromium}=require(process.env.RACKCLICK_PLAYWRIGHT||'playwright');
const root=fileURLToPath(new URL('../',import.meta.url)).replace(/\/$/,''),pdir=fs.mkdtempSync(path.join(os.tmpdir(),'rc7-ui-')),out=[];
const context=await chromium.launchPersistentContext(pdir,{headless:true,...(process.env.RACKCLICK_CHROMIUM?{executablePath:process.env.RACKCLICK_CHROMIUM}:{}),args:process.env.RACKCLICK_CHROMIUM_ARGS?.split(' ')||[],viewport:{width:1440,height:900}}),page=await context.newPage();let errors=[],requests=[];page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());await context.route(/^https?:/,r=>{requests.push(r.request().url());return r.abort()});
try {
 await page.goto(pathToFileURL(path.join(root,'dist','RackClick-v0.9.0-rc7-Offline.html')).href);
 for(const lang of ['en','de','es'])for(const theme of ['dark','light'])for(const width of [1440,1024,390]){
  await page.evaluate(([lang,theme])=>{let data=irDemo(lang);data.racks[0].devs[0].poeBudget=100;data.racks[0].devs[0].ports[0].watts=15;localStorage.setItem('rackclick_autosave_v08',JSON.stringify(data));localStorage.setItem('rackclick_lang',lang);localStorage.setItem('rackclick_theme',theme);localStorage.setItem('rackclick_custom_templates',JSON.stringify({ux_tpl:{label:'UX-Patchpanel',icon:'▥',color:'#2a9d8f',u:1,ports:[{t:'rj45',n:4}]}}));localStorage.setItem('rackclick_fav_presets',JSON.stringify(['pp24']))},[lang,theme]);await page.setViewportSize({width,height:900});await page.reload();await page.locator('.ir-client-card').first().waitFor();
  if(width===390)await page.locator('.ir-mobile-nav').click();await page.locator('.ir-settings').click();
  const collection=page.locator('.ir-settings-collections');await collection.waitFor();const text=await collection.innerText();if(!text.includes('UX-Patchpanel')||!text.includes('Patch Panel 24P'))throw Error(`Settings collection ${lang}/${theme}/${width}: ${text}`);
  const expected={en:'Light',de:'Hell',es:'Claro'}[lang];if(theme==='light'&&!await page.getByRole('button',{name:expected,exact:true}).count())throw Error('Theme label '+lang);
  await page.screenshot({path:root+`/evidence/ux-rc7/settings-${lang}-${theme}-${width}.png`,fullPage:true});
  await page.keyboard.press('Escape');if(width===390)await page.locator('.ir-mobile-nav').click();await page.locator('.ir-client-card').first().click();
  if(width===390)await page.locator('.ir-mobile-nav').click();await page.locator('.ir-racks button').first().click();
  const checks={en:'Move up',de:'Nach oben',es:'Subir'};if(await page.locator('.ir-device-actions button').first().getAttribute('aria-label')!==checks[lang])throw Error('aria-label device '+lang);
  if(!await page.locator('.ir-poe-summary').count())throw Error('PoE summary absent '+lang);
  out.push({lang,theme,width,settings:true,themeLabel:true,aria:true,poe:true});
 }
} finally {await context.close();fs.rmSync(pdir,{recursive:true,force:true});fs.writeFileSync(root+'/evidence/ux-rc7/interactions.json',JSON.stringify({out,errors,requests},null,2));}
console.log(JSON.stringify({cases:out.length,errors,requests}));

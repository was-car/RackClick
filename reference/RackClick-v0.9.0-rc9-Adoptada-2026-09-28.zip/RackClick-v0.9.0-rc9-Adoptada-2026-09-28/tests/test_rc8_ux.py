"""RC8 user-observed catalogue/location/toolbar regressions; real browser, no network."""
import json,tempfile,os
from pathlib import Path
from qa_support import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=ROOT/'dist'/('RackClick-v'+(ROOT/'VERSION').read_text().strip()+'-Offline.html')
OUT=ROOT/'evidence/rc8/ux';OUT.mkdir(parents=True,exist_ok=True)
results=[]
def check(name,result):
 assert result,name
 results.append({'name':name,'result':'PASS'});print('PASS',name,flush=True)
with tempfile.TemporaryDirectory() as profile,sync_playwright() as pw:
 c=pw.chromium.launch_persistent_context(profile,headless=True,executable_path=os.environ.get('RACKCLICK_CHROMIUM'),args=['--no-sandbox','--disable-dev-shm-usage'],viewport={'width':1440,'height':1000},accept_downloads=True)
 p=c.pages[0];p.set_default_timeout(15000);errors=[];requests=[]
 p.on('pageerror',lambda e:errors.append(str(e)));p.on('dialog',lambda d:d.accept())
 def block(r):requests.append(r.request.url);r.abort()
 c.route('http://**/*',block);c.route('https://**/*',block)
 p.goto(HTML.as_uri())
 p.evaluate("localStorage.setItem('rackclick_autosave_v08',JSON.stringify(irDemo('en')));localStorage.setItem('rackclick_theme','silver')")
 p.reload();p.locator('.ir-client-card').first.wait_for()
 check('Custom port-face creation preserves distinct front and rear metadata',p.evaluate("(()=>{let p=mkP([{t:'rj45',n:2,face:'rear'},{t:'usb_a',n:1,face:'front'}],'qa');return p[0].rackclickFace==='rear'&&p[1].rackclickFace==='rear'&&p[2].rackclickFace==='front'&&new Set(p.map(x=>x.id)).size===3})()"))
 check('Legacy silver preference maps to light',p.locator('html').get_attribute('data-rc-theme')=='light')
 p.locator('.ir-manage').click();actions=p.locator('.rc8-infra-actions');actions.wait_for()
 p.locator('dialog').evaluate('(e)=>e.scrollTop=e.scrollHeight')
 check('Infrastructure actions remain visible at end of long list',actions.evaluate('(e)=>{let b=e.getBoundingClientRect();return b.top>=0&&b.bottom<innerHeight}'))
 p.screenshot(path=str(OUT/'infrastructure-sticky.png'))
 actions.get_by_role('button',name='Cancel',exact=True).click()
 p.locator('.ir-client-card').first.click();p.locator('.ir-racks button').first.click()
 p.get_by_role('button',name='+ NEW DEVICE',exact=True).click()
 check('Generic Switch 8,16 and AP available',all(p.get_by_role('button',name=x,exact=False).count()>0 for x in ['Switch 8P','Switch 16P','Access Point (AP)']))
 star=p.locator('.rc8-favorite').first;check('Favorite star visible and keyboard reachable',star.is_visible() and star.get_attribute('tabindex')=='0')
 star.click();check('Favorite toggles with visible pressed state',p.locator('.rc8-favorite').first.get_attribute('aria-pressed')=='true')
 color=p.locator('.rc8-device-catalogue button:not(:disabled)').first.evaluate('(e)=>getComputedStyle(e).color')
 check('Light favorite catalogue text uses accessible dark amber',color=='rgb(138, 74, 0)')
 check('Light normal preset text uses theme foreground',p.locator('.rc8-device-catalogue button').filter(has_text='Switch 16P').evaluate('(e)=>getComputedStyle(e).color')=='rgb(29, 45, 59)')
 p.screenshot(path=str(OUT/'catalogue-light.png'),full_page=True)
 check('Search draws coherent icon instead of emoji placeholder',p.locator('.rc8-search').count()>0 and all('🔍' not in (x.get_attribute('placeholder') or '') for x in p.locator('.rc8-search').all()))
 for width in [1440,1024,390]:
  p.set_viewport_size({'width':width,'height':1000});p.wait_for_timeout(150)
  check('Rack viewport contains horizontal scroll '+str(width),p.locator('.ir-rack-scroll').evaluate('(e)=>{let b=e.getBoundingClientRect();return b.left>=0&&b.right<=innerWidth+1}'))
 check('No own JS error',not errors);check('Zero runtime network',not requests)
 c.close()
(OUT/'results.json').write_text(json.dumps({'results':results},indent=2))

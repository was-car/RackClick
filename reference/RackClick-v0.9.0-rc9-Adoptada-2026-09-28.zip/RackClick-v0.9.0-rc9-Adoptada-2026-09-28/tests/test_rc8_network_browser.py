"""RC8 network/UI smoke against compiled candidate, persistent profile, blocked network."""
import json,tempfile,os,re
from pathlib import Path
from qa_support import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=ROOT/'dist'/('RackClick-v'+(ROOT/'VERSION').read_text().strip()+'-Offline.html')
OUT=ROOT/'evidence/rc8/network';OUT.mkdir(parents=True,exist_ok=True)
BROWSER=os.environ.get('RACKCLICK_BROWSER','chromium')
results=[]
def check(name,result):
 assert result,name
 results.append({'name':name,'result':'PASS'})
 print('PASS',name,flush=True)
with tempfile.TemporaryDirectory() as profile,sync_playwright() as pw:
 opts={'headless':True}
 if BROWSER=='chromium':opts['args']=['--no-sandbox','--disable-dev-shm-usage']
 executable=os.environ.get('RACKCLICK_FIREFOX' if BROWSER=='firefox' else 'RACKCLICK_CHROMIUM')
 if executable:opts['executable_path']=executable
 c=getattr(pw,BROWSER).launch_persistent_context(profile,**opts,viewport={'width':1440,'height':1000},accept_downloads=True)
 p=c.pages[0];p.set_default_timeout(15000);errors=[];network=[]
 p.on('pageerror',lambda e:errors.append(str(e)))
 def block(route):
  network.append(route.request.url);route.abort()
 c.route(re.compile(r'^https?://'),block)
 p.on('dialog',lambda d:d.accept())
 p.goto(HTML.as_uri());p.locator('.ir-all-clients').click();p.get_by_role('button',name='10 demo clients',exact=True).click();p.locator('.ir-client-card').first.click();p.locator('.ir-racks button').first.click()
 title=p.locator('.ir-device-name').first.get_attribute('title')
 check('Device hover exists without opening editor',bool(title) and 'Serial number' in title and 'Firmware' in title)
 pt=p.locator('[data-vport]').first
 check('Port hover contains label/watts/status without clicking',all(x in pt.locator('title').text_content() for x in ['Label / outlet','Documented watts','Status']))
 check('PoE mark drawn on network interfaces',p.locator('[data-poe]').count()>0)
 p.locator('[data-face="rear"]').click()
 check('Power connections hover includes endpoints/note/patch status',all(x in p.locator('.ir-power-summary>div button').first.get_attribute('title') for x in ['Cable note','Patch status','→']))
 p.screenshot(path=str(OUT/('rear-tooltips-'+BROWSER+'.png')),full_page=True)
 check('No own JS errors',not errors);check('Zero HTTP requests',not network)
 c.close()
(OUT/('browser-results-'+BROWSER+'.json')).write_text(json.dumps({'browser':BROWSER,'results':results},indent=2))

"""Prove the offline test harness actually rejects a nested HTTP path."""
from qa_support import sync_playwright

def main():
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch()
            page = browser.new_context().new_page()
            try:
                page.goto('https://example.invalid/deep/path/asset.js', timeout=5000)
            except Exception:
                pass  # The route intentionally aborts navigation.
            browser.close()
    except AssertionError as exc:
        assert 'https://example.invalid/deep/path/asset.js' in str(exc), str(exc)
        print('PASS nested network request aborted and failed the offline gate')
        return
    raise AssertionError('Network guard failed to observe nested URL')

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Test funcional de Snapshots — fix v0.8.3
S1 crear · S2 aparece en Settings · S3 restaurar · S4 eliminar · S5 autosave sigue OK"""
import json, os
from pathlib import Path
from qa_support import sync_playwright, cache_cdn

HTML = Path(os.environ.get("RACKCLICK_HTML", "rackclick-v0.8.6.html")).resolve().as_uri()
HEALTHY = json.dumps({"version": "0.8", "name": "SnapTest", "racks": [{"id": "r1", "name": "RackS", "location": "", "size": 12, "devs": [], "conns": []}], "crossConns": [], "changeLog": []})

R = []
with sync_playwright() as pw:
    b = pw.chromium.launch()
    p = b.new_context().new_page()
    console_errors = []
    p.on("pageerror", lambda e: console_errors.append(str(e)[:120]))
    p.add_init_script(f"localStorage.setItem('rackclick_autosave_v08', {json.dumps(HEALTHY)});")
    p.context.route("https://cdnjs.cloudflare.com/**", cache_cdn)
    p.goto(HTML); p.wait_for_timeout(4500)

    # S1: crear snapshot desde el botón 📸 (con prompt) — SIN error de referencia
    p.once("dialog", lambda d: d.accept("Snap-QA"))
    p.locator("button", has_text="📸").first.click()
    p.wait_for_timeout(800)
    no_ref_error = not any("saveSnapshot is not defined" in e for e in console_errors)
    snaps_ls = p.evaluate("() => localStorage.getItem('rackclick_snapshots')")
    created = snaps_ls is not None and "Snap-QA" in snaps_ls
    R.append(("S1", f"Clic 📸 crea snapshot sin ReferenceError (errores={console_errors[:1] or 'ninguno'}), guardado en SNAPSHOTS_KEY={created}", no_ref_error and created))

    # S2: aparece en Settings
    p.locator("button", has_text="⚙️").first.click(); p.wait_for_timeout(400)
    p.get_by_text("📸", exact=False).first.click(); p.wait_for_timeout(300)  # expandir sección si colapsada
    body = p.inner_text("body")
    in_settings = "Snap-QA" in body
    R.append(("S2", f"Snapshot visible en la sección Snapshots de Settings", in_settings))

    # S3: restaurar — primero modifico el proyecto (añado rack), luego restauro al estado del snapshot
    p.keyboard.press("Escape"); p.wait_for_timeout(300)
    p.once("dialog", lambda d: d.accept("RackExtra"))
    p.get_by_text("+ Add Rack", exact=True).click(); p.wait_for_timeout(1000)
    racks_now = len(json.loads(p.evaluate("() => localStorage.getItem('rackclick_autosave_v08')"))["racks"])
    p.locator("button", has_text="⚙️").first.click(); p.wait_for_timeout(400)
    p.once("dialog", lambda d: d.accept())  # confirm de restauración
    p.locator("button", has_text="Restore").or_(p.locator("button", has_text="Wiederherstellen")).or_(p.locator("button", has_text="Restaurar")).first.click()
    p.wait_for_timeout(1200)
    racks_restored = len(json.loads(p.evaluate("() => localStorage.getItem('rackclick_autosave_v08')"))["racks"])
    restored_ok = racks_now == 2 and racks_restored == 1
    R.append(("S3", f"Restaurar: {racks_now} racks → {racks_restored} (estado del snapshot)", restored_ok))

    # S4: eliminar snapshot
    p.locator("button", has_text="⚙️").first.click() if "Snap-QA" not in p.inner_text("body") else None
    p.wait_for_timeout(300)
    del_btn = p.locator("button", has_text="Delete").or_(p.locator("button", has_text="Löschen")).or_(p.locator("button", has_text="Eliminar"))
    # el botón correcto está junto al snapshot; usamos el que esté en la fila del snapshot
    before_del = p.evaluate("() => localStorage.getItem('rackclick_snapshots')")
    del_btn.first.click(); p.wait_for_timeout(600)
    after_del = p.evaluate("() => localStorage.getItem('rackclick_snapshots')")
    deleted = "Snap-QA" in (before_del or "") and "Snap-QA" not in (after_del or "[]")
    R.append(("S4", f"Eliminar snapshot: desaparece de SNAPSHOTS_KEY", deleted))

    # S5: autosave honesto sigue OK (indicador ✓ presente, sin banner)
    body = p.inner_text("body")
    s5 = (p.locator('[title="Autosave"]').is_visible() and "✓" in p.locator('[title="Autosave"]').inner_text()) and "Automatic saving is failing" not in body
    R.append(("S5", "Autosave honesto intacto (indicador ✓, sin banner)", s5))
    # S6: failed create must preserve both storage and the visible snapshot list.
    p.keyboard.press("Escape")
    p.evaluate("""() => {window.__originalSet = Storage.prototype.setItem;
      Storage.prototype.setItem = function(k,v) {
        if(k === 'rackclick_snapshots' && window.__failSnapshots) throw new DOMException('Test quota','QuotaExceededError');
        return window.__originalSet.call(this,k,v);
      }; window.__failSnapshots=true; }""")
    before = p.evaluate("localStorage.getItem('rackclick_snapshots')")
    p.once("dialog", lambda d: d.accept("GHOST-S6"))
    p.locator("button", has_text="📸").first.click(); p.wait_for_timeout(200)
    error = "Could not save the snapshot change" in p.inner_text("body")
    p.locator("button", has_text="⚙️").first.click(); p.wait_for_timeout(200)
    same = p.evaluate("localStorage.getItem('rackclick_snapshots')") == before
    R.append(("S6", "Quota on create: error, no phantom snapshot, unchanged storage", error and same and "GHOST-S6" not in p.inner_text("body")))
    # S7: persist one, then fail its deletion. The row must remain visible.
    p.keyboard.press("Escape"); p.evaluate("window.__failSnapshots=false")
    p.once("dialog", lambda d: d.accept("KEEP-S7"))
    p.locator("button", has_text="📸").first.click(); p.wait_for_timeout(200)
    p.locator("button", has_text="⚙️").first.click(); p.wait_for_timeout(200)
    before = p.evaluate("localStorage.getItem('rackclick_snapshots')")
    p.evaluate("window.__failSnapshots=true")
    p.get_by_text("KEEP-S7", exact=True).locator("..").get_by_role("button", name="Delete", exact=True).click()
    p.wait_for_timeout(200)
    same = p.evaluate("localStorage.getItem('rackclick_snapshots')") == before
    body = p.inner_text("body")
    R.append(("S7", "Quota on delete: error, row retained, unchanged storage", same and "KEEP-S7" in body and "Could not save the snapshot change" in body))
    b.close()

print("=" * 78)
for name, desc, ok in R:
    print(f"  [{name}] {'✓ PASS' if ok else '✗ FAIL'} — {desc}")
allok = all(r[2] for r in R)
print("\n" + ("✅ SNAPSHOT TESTS: PASS" if allok else "❌ FALLOS"))
exit(0 if allok else 1)

"""Representative catalogue/editor/settings visual/contrast scan. Not exhaustive states."""
import json,tempfile,os,re
from pathlib import Path
from qa_support import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence/rc8/ux/matrix';OUT.mkdir(parents=True,exist_ok=True)
HTML=ROOT/'dist'/('RackClick-v'+(ROOT/'VERSION').read_text().strip()+'-Offline.html')
legacy=(ROOT/'tests/contrast_rc7.mjs').read_text();SCAN=legacy.split('metrics:await p.evaluate(')[1].split('})})}')[0]+'}'
# Same RC7 metric: leaf HTML text, excludes gradients/opacity/SVG and large-text relaxation.
results=[];errors=[];requests=[]
with tempfile.TemporaryDirectory() as profile,sync_playwright() as pw:
 c=pw.chromium.launch_persistent_context(profile,headless=True,executable_path=os.environ.get('RACKCLICK_CHROMIUM'),args=['--no-sandbox','--disable-dev-shm-usage'],viewport={'width':1440,'height':1000})
 p=c.pages[0];p.set_default_timeout(12000);p.on('dialog',lambda d:d.accept());p.on('pageerror',lambda e:errors.append(str(e)))
 def block(r):requests.append(r.request.url);r.abort()
 c.route(re.compile(r'^https?://'),block);p.goto(HTML.as_uri())
 words=p.evaluate('IR_WORDS');keys=set(words['en']);assert all(set(words[l])==keys for l in ['de','es'])
 catalogue=p.evaluate('RC8_CATALOGUE');assert all(set(catalogue[l])==set(catalogue['en']) and set(catalogue[l]['categories'])==set(catalogue['en']['categories']) for l in ['de','es'])
 for lang in ['en','de','es']:
  for theme in ['dark','light']:
   for width in [1440,1024,390]:
    p.set_viewport_size({'width':width,'height':1000})
    p.evaluate("([lang,theme])=>{localStorage.setItem('rackclick_autosave_v08',JSON.stringify(irDemo(lang)));localStorage.setItem('rackclick_lang',lang);localStorage.setItem('rackclick_theme',theme)}",[lang,theme]);p.reload();p.locator('.ir-client-card').first.wait_for()
    prefix=f'{lang}-{theme}-{width}'
    def scan(view):
     p.wait_for_timeout(100)
     issues=p.evaluate(SCAN)
     overflow=p.evaluate('document.documentElement.scrollWidth>innerWidth+1')
     results.append({'case':prefix,'view':view,'contrastFindings':issues,'pageHorizontalOverflow':overflow})
    scan('clients');p.locator('.ir-client-card').first.click();scan('project')
    if width==390:p.locator('.ir-mobile-nav').click()
    p.locator('.ir-racks button').first.click()
    if width==390 and p.locator('.ir-nav.open').count():p.locator('.ir-mobile-nav').click()
    scan('rack');p.locator('.ir-device-name').first.click();scan('device-editor');p.keyboard.press('Escape')
    p.get_by_role('button',name={'en':'+ NEW DEVICE','de':'+ NEUES GERÄT','es':'+ NUEVO EQUIPO'}[lang],exact=True).click();scan('catalogue')
    assert p.locator('.rc8-device-name').get_attribute('placeholder')==catalogue[lang]['nameOptional']
    assert p.locator('.rc8-catalogue-note').text_content()==catalogue[lang]['generic']
    p.locator('.rc8-device-catalogue').screenshot(path=str(OUT/(prefix+'-catalogue.png')))
    if width==390:p.locator('.ir-mobile-nav').click()
    p.locator('.ir-settings').click();scan('settings')
    print('SCANNED',prefix,flush=True)
 c.close()
(OUT/'scan.json').write_text(json.dumps({'scope':'Representative six views × 3languages × 2themes × 3widths; legacy contrast algorithm excludes gradients, opacity and SVG. Not whole UI certification.','i18nKeys':len(keys),'results':results,'errors':errors,'requests':requests},ensure_ascii=False,indent=2))
print(json.dumps({'scans':len(results),'contrastFindings':sum(len(x['contrastFindings']) for x in results),'overflow':sum(x['pageHorizontalOverflow'] for x in results),'errors':errors,'requests':requests}))

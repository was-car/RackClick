import{readFile}from'node:fs/promises';
export async function integrityPatches(source,patch){
 source=source.replace('  const lastSavedRef = useRef(JSON.stringify(project));','  const irProjectRef=useRef(project);irProjectRef.current=project;\n  const lastSavedRef = useRef(JSON.stringify(project));');
 const replaceBlock=(start,end,replacement)=>{const a=source.indexOf(start),b=source.indexOf(end,a);if(a<0||b<0)throw Error('Integrity anchor missing '+start);source=source.slice(0,a)+replacement+source.slice(b)};
 source=source.replace('/* ═══════ CONSTANTS ═══════ */',(await readFile('src/integrity.jsxinc','utf8'))+'\n/* ═══════ CONSTANTS ═══════ */');
 replaceBlock('function bootQuarantine(reason, rawMap) {','function bootTryParse(raw) {',`let BOOT_AUTOSAVE_BLOCKED = false;
let BOOT_RECOVERY_REASON = null;
function bootQuarantine(reason, rawMap) {
  try {
    // Never overwrite either the v0.8.x quarantine or another episode.
    let key=QUARANTINE_KEY;
    if (localStorage.getItem(key)!==null) {
      do { key=IR_QUARANTINE_PREFIX+Date.now()+'-'+Math.random().toString(36).slice(2); }
      while (localStorage.getItem(key)!==null);
    }
    const raw=JSON.stringify({createdAt:new Date().toISOString(),reason,keys:rawMap});
    localStorage.setItem(key,raw);
    if(localStorage.getItem(key)!==raw)throw Error('Quarantine readback failed');
    return true;
  } catch {
    BOOT_AUTOSAVE_BLOCKED=true;
    BOOT_RECOVERY_REASON='quarantineFailed';
    return false;
  }
}

`);
 source=source.replace('  if (!p || typeof p !== "object" || p.version !== "0.8") return { ok: false };','  if (!p || typeof p !== "object" || p.version !== "0.8" || !irBootSafeShape(p)) return { ok: false };');
 replaceBlock('  let rawSave = null;\n  try { rawSave = localStorage.getItem(SAVE_KEY); } catch {}','  // Primer uso: no hay nada guardado',`  let rawSave=null,metaRaw=null;
  const rawMap={autosave:null};
  let unreadable=false;
  try{rawSave=localStorage.getItem(SAVE_KEY);rawMap.autosave=rawSave}catch{unreadable=true}
  BACKUP_KEYS.forEach(bk=>{try{rawMap[bk]=localStorage.getItem(bk)}catch{rawMap[bk]=null;unreadable=true}});
  try{metaRaw=localStorage.getItem(BACKUP_META)}catch{unreadable=true}
  if(unreadable){
    BOOT_AUTOSAVE_BLOCKED=true;
    BOOT_RECOVERY_REASON='unreadable';
    BOOT_REPORT={type:'unreadable'};
    return emptyFactory();
  }

`);
 source=source.replace('  try { meta = JSON.parse(localStorage.getItem(BACKUP_META)); } catch {}','  try { meta = JSON.parse(metaRaw); } catch {}');
 source=source.replace('  const [quarantineInfo, setQuarantineInfo] = useState(() => { try { const s = localStorage.getItem(QUARANTINE_KEY); if (!s) return null; const q = JSON.parse(s); return { createdAt: q.createdAt, reason: q.reason, hasAutosave: !!(q.keys && typeof q.keys.autosave === "string") }; } catch { return null; } });',
  '  const [quarantineEpisodes,setQuarantineEpisodes]=useState(()=>{try{return irQuarantineEntries()}catch{return []}});');
 source=source.replace('if (r.type === "repaired") noti(t("notiBootRepaired"), "info");','if (r.type === "repaired") noti(r.quarantineSaved?t("notiBootRepaired"):IR_RECOVERY_WORDS[lang].notSaved,r.quarantineSaved?"info":"error");')
 .replace('else if (r.type === "backup") noti(t("notiBootBackup") + " (" + r.backupKey + ")", "info");','else if (r.type === "backup") noti(r.quarantineSaved?t("notiBootBackup") + " (" + r.backupKey + ")":IR_RECOVERY_WORDS[lang].notSaved,r.quarantineSaved?"info":"error");')
 .replace('else if (r.type === "safeMode") noti(t("notiBootSafeMode"), "error");','else if (r.type === "safeMode") noti(r.quarantineSaved?t("notiBootSafeMode"):IR_RECOVERY_WORDS[lang].notSaved,"error");\n    else if(r.type==="unreadable")noti(IR_RECOVERY_WORDS[lang].unreadable,"error");');
 replaceBlock('  const downloadQuarantine = (autosaveOnly) => {','  const rack = project.racks.find(r => r.id === activeRackId);',`  const downloadQuarantine = (autosaveOnly,key=QUARANTINE_KEY) => {
    try {
      const s=localStorage.getItem(key);if(s===null)throw Error('Episode unavailable');
      let content=s,suffix='quarantine';
      if(autosaveOnly){const q=JSON.parse(s);if(typeof q.keys?.autosave!=='string')throw Error('Autosave unavailable');content=q.keys.autosave;suffix='quarantine-autosave'}
      rcDownload(content,'rackclick-'+suffix+'-'+key.replace(/[^a-zA-Z0-9_-]/g,'-')+'-'+rcTimestamp()+'.json');
    }catch{noti(IR_RECOVERY_WORDS[lang].readFailed,'error')}
  };
  const deleteQuarantine = (key=QUARANTINE_KEY) => {
    if(!confirm(t('quarantineDeleteConfirm')))return;
    try{
      localStorage.removeItem(key);
      if(localStorage.getItem(key)!==null)throw Error('Deletion not confirmed');
      setQuarantineEpisodes(irQuarantineEntries());
      noti(t('notiQuarantineDeleted'),'info');
    }catch{noti(IR_RECOVERY_WORDS[lang].deleteFailed,'error')}
  };
`);
 source=source.replace('    if (BOOT_SUPPRESS_FIRST_AUTOSAVE) { BOOT_SUPPRESS_FIRST_AUTOSAVE = false; return; }',
  '    if(BOOT_AUTOSAVE_BLOCKED){setAutosaveStatus(s=>({...s,ok:null}));return;}\n    if (BOOT_SUPPRESS_FIRST_AUTOSAVE) { BOOT_SUPPRESS_FIRST_AUTOSAVE = false; return; }');
 replaceBlock('          {/* Quarantine (v0.8.2) */}','        </div>\n      </div>}',`          {/* Distinct raw recovery episodes, no automatic deletion. */}
          {quarantineEpisodes.length>0 && <div className="ir-recovery-episodes" style={{marginBottom:12,border:'1px solid #ef4444',padding:10,borderRadius:8}}>
            <strong>{t('quarantine')} · {IR_RECOVERY_WORDS[lang].quarantineCount}: {quarantineEpisodes.length}</strong>
            {quarantineEpisodes.map((episode,index)=><div key={episode.key} style={{padding:8,borderBottom:'1px solid #ef444466'}}>
              <div>{index+1}. {episode.createdAt||episode.key} · {episode.reason||'raw data'}</div>
              <button onClick={()=>downloadQuarantine(false,episode.key)}>{t('quarantineDownload')}</button>
              {episode.hasAutosave&&<button onClick={()=>downloadQuarantine(true,episode.key)}>{t('quarantineDownloadAutosave')}</button>}
              <button onClick={()=>deleteQuarantine(episode.key)}>{t('quarantineDelete')}</button>
            </div>)}
          </div>}
`);
 source=source.replaceAll('<div className="ir-breadcrumb">',`{BOOT_RECOVERY_REASON&&<div className="ir-recovery-block" role="alert" style={{background:'#7f1d1d',color:'#fff',padding:'12px 20px',fontSize:13,fontWeight:700}}>
    {IR_RECOVERY_WORDS[lang][BOOT_RECOVERY_REASON]} <button onClick={saveJSON}>{IR_RECOVERY_WORDS[lang].exportMemory}</button>
    {BOOT_RECOVERY_REASON==='quarantineFailed'&&<button onClick={irDownloadCurrentRescue}>{IR_RECOVERY_WORDS[lang].exportRaw}</button>}
    <button onClick={()=>location.reload()}>{IR_RECOVERY_WORDS[lang].reload}</button>
  </div>}<div className="ir-breadcrumb">`);
 source=source.replace('    RESCUE_KEYS.forEach(k => { bundle.keys[k] = rcReadRaw(k); });',`    RESCUE_KEYS.forEach(k => { bundle.keys[k] = rcReadRaw(k); });
    try { for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k?.startsWith(IR_QUARANTINE_PREFIX))bundle.keys[k]=rcReadRaw(k)} } catch {}`);
 replaceBlock('    setProject(prev => {\n      let p = { ...prev, racks:', '    setDevCtx(null); noti(`📦', '    setProject(prev => irMoveDevice(prev,devId,targetRackId));\n');
 replaceBlock('  const importRackJSON = () => {','  const mergeProject = () => {',`  const importRackJSON = () => {
    const inp=document.createElement('input');inp.type='file';inp.accept='.json';inp.multiple=true;
    inp.onchange=async e=>{const files=[...e.target.files];if(!files.length)return;
      try{const incoming=await Promise.all(files.map(async f=>irImportedProject(JSON.parse(await f.text()),f.name)));
        if(irProjectRef.current!==project)throw Error('Project changed during import');let next=project;for(const p of incoming)next=irAppendProject(next,p);
        pushUndo('Import racks');setProject(next);noti(t('notiImportedFile',{name:files.map(f=>f.name).join(', ')}),'success');
      }catch{noti(t('notiFailedFile',{name:files.map(f=>f.name).join(', ')}),'error')}
    };inp.click();
  };
`);
 replaceBlock('          validateProject(d);\n          const existingNames', '          noti(t("notiMergedCounts"', `          if(irProjectRef.current!==project)throw Error('Project changed during import');const next=irAppendProject(project,d);pushUndo('Merge project');setProject(next);
          const added=d.racks.length,newXC=d.crossConns||[];
`);
 replaceBlock('  const importCSV = () => {','  /* #41 Rack Label',`  const importCSV = () => {
    if(!rack)return;const inp=document.createElement('input');inp.type='file';inp.accept='.csv,.txt';
    inp.onchange=async e=>{const f=e.target.files[0];if(!f)return;try{
      const text=await f.text();if(irProjectRef.current!==project)throw Error('Project changed during import');const links=irCSVConnections(text,rack,project);
      if(!allowNewPairs(links.map(c=>[[c.fd,c.fp],[c.td,c.tp]])))return;
      pushUndo('Import CSV');setConns(prev=>[...prev,...links]);noti(t('notiCsvCounts',{added:links.length,skipped:0}),'success');
    }catch{noti(t('notiFailedCsv'),'error')}};inp.click();
  };
`);
 source=source.replace('          pushUndo("Load project");', '          if(irProjectRef.current!==project)throw Error("Project changed during import");\n          pushUndo("Load project");');
 // Reject malformed manual loads before any mutation. Boot repair/quarantine unchanged.
 source=source.replace('const vErr = validateProject(d);', 'irAssertTopology(d);const vErr = validateProject(d);');
 source=source.replace('validateRack(rack);\n            setProject(prev => ({ ...prev, racks: [...prev.racks, rack] })); setActiveRackId(rid);',`const appended=irAppendProject(project,{version:'0.8',racks:[rack],crossConns:[]});
            setProject(appended); setActiveRackId(appended.racks[appended.racks.length-1].id);`);
 source=source.replace('conns: r.conns.filter(c => !touches(c)) }),','conns: r.conns.filter(c => !touches(c)).map(c=>irRenameLink(c,dev.id,rest.name||dev.name)) }),');
 source=source.replace('crossConns: (prev.crossConns || []).filter(c => !touches(c))','crossConns: (prev.crossConns || []).filter(c => !touches(c)).map(c=>irRenameLink(c,dev.id,rest.name||dev.name))');
 source=source.replace('const usedP = connSet.size;', 'const usedP = devs.reduce((n,d)=>n+d.ports.filter(p=>connSet.has(p.id)).length,0);');
 return source;
}

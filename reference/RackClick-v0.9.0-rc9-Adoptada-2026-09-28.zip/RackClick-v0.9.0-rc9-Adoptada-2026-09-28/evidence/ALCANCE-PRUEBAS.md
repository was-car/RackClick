# Alcance de verificación RC9

Pruebas dirigidas de presentación, datos y salida: tests/test_rc9_visual.py sobre el hash final indicado en rc9/resultados.json. Build negativo y reproducible sobre el artefacto final.

Regresión de informes/plantillas y núcleo de reconexión: ejecutadas sobre 11730c65908e3f31a95f7c5ee015a1dfcf644f45aea8dd89470dfaf7fb657cc8, antes de añadir únicamente la regla CSS de papel blanco para impresión de etiquetas. El JavaScript no cambió después de esa regresión. Sus salidas se conservan sin atribuirles una nueva ejecución sobre otro hash.

La inspección de PDF detectó fondo oscuro en el margen de impresión, corregido mediante una regla limitada a la página de etiquetas. La prueba final verifica papel blanco, ocultación de controles y 17 etiquetas.

Chromium 153 en Linux. Sin ejecución de Windows/Firefox en esta entrega. No se declara una batería histórica completa ni revisión independiente nueva. No se cambian los resultados de QA de Wascar ni se declara adopción.

const { useState, useCallback, useRef, useEffect } = React;

/* Integrated presentation: all mutations belong to the adopted core. */
const IR_WORDS={
 en:{power:"Power connections",role:"Power port role",inlet:"Inlet",outlet:"Outlet",unspecified:"Unspecified",powerHint:"Generic power documentation. No load, voltage, autonomy or A/B redundancy calculation.",badPower:"Power ports connect only to power ports; two declared inlets or outlets cannot be joined.",view:"Rack view",infrastructure:'INFRASTRUCTURE',project:'Project',local:'OFFLINE · CANDIDATE',systemhaus:'Systemhaus name',settings:'Settings',physical:'PHYSICAL RACK',overview:'Rack overview',inspect:'Port inspector',unknown:'Not documented',next:'Next cable color',automatic:'Automatic',cables:'Cables',schema:'JSON v0.8 does not store port faces. Both views retain every interface; physical placement is schematic.',duplicate:'Multiple connections on one port. Data preserved.',edit:'Edit',remove:'Delete',up:'Move up',down:'Move down',options:'Device options',select:'Select device',collapse:'Collapse / expand',drag:'Drag to reorder',details:'Port actions',watt:'Documented watts',route:'Selected route',clear:'Clear selection',empty:'Add a device to begin',saved:'Autosave',fallback:'Classic view (recovery only)',unverified:'Generic chassis · schematic interfaces',restore:'Reset color',connections:'Connections',devices:'Devices',free:'Free U',ports:'Ports',projectTools:'Project tools',rackTools:'Rack tools',name:'Name',newDevice:'New device',noTelemetry:'NO TELEMETRY',rear:'Rear',front:'Front',manage:"Manage infrastructure",client:"Customer",site:"Site",building:"Building",room:"Room",addLocation:"Add location",assign:"Assign rack",unassigned:"Unassigned",save:"Save",cancel:"Cancel",removeLocation:"Remove location",inUse:"Location in use: move its racks first.",faces:"Configure faces",autoFace:"Automatic (schematic)",portFace:"Port face",otherFace:"Other face",cableNote:"Cable note",noPorts:"No ports documented on this face",hierarchyHelp:"Systemhaus and location hierarchy are saved in this project JSON. Offline grouping is not access control.",poeSummary:"PoE budget / documented watts",poeUnknown:"ports without watts",searchHits:"results",noSearch:"No results for",manageTemplates:"Saved templates",manageFavorites:"Favorites",noTemplates:"No saved templates",noFavorites:"No favorites",removeFavorite:"Remove favorite",removeTemplate:"Remove template",themeDark:"Dark",themeSemidark:"Semi-dark",themeSilver:"Silver",themeLight:"Light"},
 de:{power:"Stromverbindungen",role:"Stromanschluss-Rolle",inlet:"Eingang",outlet:"Ausgang",unspecified:"Nicht festgelegt",powerHint:"Generische Stromdokumentation. Keine Berechnung von Last, Spannung, Laufzeit oder A/B-Redundanz.",badPower:"Stromanschlüsse nur mit Stromanschlüssen verbinden; zwei deklarierte Eingänge oder Ausgänge sind gesperrt.",view:"Rackansicht",infrastructure:'INFRASTRUKTUR',project:'Projekt',local:'OFFLINE · KANDIDAT',systemhaus:'Name des Systemhauses',settings:'Einstellungen',physical:'PHYSISCHES RACK',overview:'Rackübersicht',inspect:'Portinspektor',unknown:'Nicht dokumentiert',next:'Farbe des nächsten Kabels',automatic:'Automatisch',cables:'Kabel',schema:'JSON v0.8 speichert keine Portseiten. Beide Ansichten behalten alle Schnittstellen; die Position ist schematisch.',duplicate:'Mehrere Verbindungen an einem Port. Daten bleiben erhalten.',edit:'Bearbeiten',remove:'Löschen',up:'Nach oben',down:'Nach unten',options:'Geräteoptionen',select:'Gerät auswählen',collapse:'Ein-/ausklappen',drag:'Zum Sortieren ziehen',details:'Portaktionen',watt:'Dokumentierte Watt',route:'Ausgewählte Verbindung',clear:'Auswahl aufheben',empty:'Zuerst ein Gerät hinzufügen',saved:'Autosave',fallback:'Klassische Ansicht (nur Rückfall)',unverified:'Generisches Gehäuse · schematische Schnittstellen',restore:'Farbe zurücksetzen',connections:'Verbindungen',devices:'Geräte',free:'Freie HE',ports:'Ports',projectTools:'Projektwerkzeuge',rackTools:'Rackwerkzeuge',name:'Name',newDevice:'Neues Gerät',noTelemetry:'KEINE TELEMETRIE',rear:'Rückseite',front:'Vorderseite',manage:"Infrastruktur verwalten",client:"Kunde",site:"Standort",building:"Gebäude",room:"Raum",addLocation:"Ort hinzufügen",assign:"Rack zuordnen",unassigned:"Nicht zugeordnet",save:"Speichern",cancel:"Abbrechen",removeLocation:"Ort entfernen",inUse:"Ort belegt: Racks zuerst neu zuordnen.",faces:"Portseiten einstellen",autoFace:"Automatisch (schematisch)",portFace:"Portseite",otherFace:"Andere Seite",cableNote:"Kabelnotiz",noPorts:"Keine Ports auf dieser Seite dokumentiert",hierarchyHelp:"Systemhaus und Standorthierarchie werden im Projekt-JSON gespeichert. Offline-Gruppierung ist keine Zugriffskontrolle.",poeSummary:"PoE-Budget / dokumentierte Watt",poeUnknown:"Ports ohne Wattangabe",searchHits:"Treffer",noSearch:"Keine Treffer für",manageTemplates:"Gespeicherte Vorlagen",manageFavorites:"Favoriten",noTemplates:"Keine gespeicherten Vorlagen",noFavorites:"Keine Favoriten",removeFavorite:"Favorit entfernen",removeTemplate:"Vorlage entfernen",themeDark:"Dunkel",themeSemidark:"Halbdunkel",themeSilver:"Silber",themeLight:"Hell"},
 es:{power:"Conexiones de alimentación",role:"Función del puerto eléctrico",inlet:"Entrada",outlet:"Salida",unspecified:"Sin especificar",powerHint:"Documentación eléctrica genérica. No calcula carga, tensión, autonomía ni redundancia A/B.",badPower:"Alimentación solo se conecta con alimentación; no se unen dos entradas o dos salidas declaradas.",view:"Vista del rack",infrastructure:'INFRAESTRUCTURA',project:'Proyecto',local:'OFFLINE · CANDIDATA',systemhaus:'Nombre del Systemhaus',settings:'Ajustes',physical:'RACK FÍSICO',overview:'Resumen del rack',inspect:'Inspector de puerto',unknown:'No documentado',next:'Color de la próxima conexión',automatic:'Automático',cables:'Cables',schema:'JSON v0.8 no guarda la cara de los puertos. Ambas vistas conservan todas las interfaces; su posición es esquemática.',duplicate:'Varias conexiones en un puerto. Datos conservados.',edit:'Editar',remove:'Eliminar',up:'Subir',down:'Bajar',options:'Opciones del equipo',select:'Seleccionar equipo',collapse:'Plegar / desplegar',drag:'Arrastrar para reordenar',details:'Acciones del puerto',watt:'Watts documentados',route:'Conexión seleccionada',clear:'Quitar selección',empty:'Añade un equipo para comenzar',saved:'Autosave',fallback:'Vista clásica (solo respaldo)',unverified:'Chasis genérico · interfaces esquemáticas',restore:'Restablecer color',connections:'Conexiones',devices:'Equipos',free:'U libres',ports:'Puertos',projectTools:'Herramientas del proyecto',rackTools:'Herramientas del rack',name:'Nombre',newDevice:'Nuevo equipo',noTelemetry:'SIN TELEMETRÍA',rear:'Trasera',front:'Frontal',manage:"Gestionar infraestructura",client:"Cliente",site:"Sede",building:"Edificio",room:"Sala",addLocation:"Añadir ubicación",assign:"Asignar rack",unassigned:"Sin asignar",save:"Guardar",cancel:"Cancelar",removeLocation:"Eliminar ubicación",inUse:"Ubicación ocupada: reasigna primero sus racks.",faces:"Configurar caras",autoFace:"Automático (esquemático)",portFace:"Cara del puerto",otherFace:"Otra cara",cableNote:"Nota del cable",noPorts:"Sin puertos documentados en esta cara",hierarchyHelp:"El Systemhaus y la jerarquía se guardan en el JSON del proyecto. Agrupar offline no establece permisos de acceso.",poeSummary:"Presupuesto PoE / watts documentados",poeUnknown:"puertos sin watts",searchHits:"resultados",noSearch:"Sin resultados para",manageTemplates:"Plantillas guardadas",manageFavorites:"Favoritos",noTemplates:"No hay plantillas",noFavorites:"No hay favoritos",removeFavorite:"Quitar favorito",removeTemplate:"Eliminar plantilla",themeDark:"Oscuro",themeSemidark:"Semioscuro",themeSilver:"Plateado",themeLight:"Claro"}
};
const RC8_CATALOGUE={"en":{"nameOptional":"Device name (optional)","create":"Create","portGroup":"+ Port Group","generic":"Generic editable templates; verify the actual device. AP uses a 1U documentation slot.","categories":{"Patch Panels":"Patch Panels","Switches":"Switches","Servers":"Servers","Storage":"Storage","Network":"Network","Power":"Power","Spacers":"Spacers"}},"de":{"nameOptional":"Gerätename (optional)","create":"Erstellen","portGroup":"+ Portgruppe","generic":"Generische editierbare Vorlagen; reales Gerät prüfen. AP belegt einen 1U-Dokumentationsplatz.","categories":{"Patch Panels":"Patchpanel","Switches":"Switches","Servers":"Server","Storage":"Speicher","Network":"Netzwerk","Power":"Stromversorgung","Spacers":"Zubehör"}},"es":{"nameOptional":"Nombre del equipo (opcional)","create":"Crear","portGroup":"+ Grupo de puertos","generic":"Plantillas genéricas editables; verifica el equipo real. AP ocupa un espacio documental de 1U.","categories":{"Patch Panels":"Paneles de parcheo","Switches":"Switches","Servers":"Servidores","Storage":"Almacenamiento","Network":"Red","Power":"Alimentación","Spacers":"Accesorios"}}};
function IRIcon({name,size=18}){const paths={search:'M10 3a7 7 0 100 14 7 7 0 100-14M15 15l6 6',star:'M12 2l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z',save:'M4 3h13l3 3v15H4zM8 3v6h8V3M8 21v-8h8v8',snapshot:'M3 7h5l2-3h4l2 3h5v14H3zM8 14a4 4 0 108 0 4 4 0 10-8 0',folder:'M3 5h7l3 3h8v13H3z',download:'M12 3v12M6 10l6 6 6-6M3 17v4h18v-4',upload:'M12 16V4M6 10l6-6 6 6M3 17v4h18v-4',report:'M4 20V4M4 20h17M8 16v-5M13 16V7M18 16v-8',file:'M5 3h9l5 5v13H5zM14 3v6h5M8 13h8M8 17h8',image:'M3 4h18v16H3zM4 17l5-6 5 5 3-3 4 5M15 8h1',tag:'M3 3h8l10 10-8 8L3 11zM7 7h1',qr:'M3 3h6v6H3zM15 3h6v6h-6zM3 15h6v6H3zM14 14h3v3h4v4h-7z',merge:'M4 4v3c0 5 16 5 16 10v3M16 17l4 4 3-4M20 4v3c0 5-16 5-16 10v3',remove:'M4 6h16M9 6V3h6v3M6 6v15h12V6M10 10v7M14 10v7',bulb:'M9 19h6M9 22h6M8 16c-6-6-1-14 4-14s10 8 4 14z',user:'M4 21v-3c0-6 16-6 16 0v3M8 6a4 4 0 108 0 4 4 0 10-8 0',rack:'M4 3h16v18H4zM4 9h16M4 15h16M8 6h2M8 12h2M8 18h2',home:'M3 11l9-8 9 8M5 10v11h14V10M9 21v-7h6v7',edit:'M4 20l1-5L16 4l4 4L9 19zM14 6l4 4',menu:'M3 6h18M3 12h18M3 18h18',close:'M5 5l14 14M19 5L5 19',settings:'M12 3v3M12 18v3M3 12h3M18 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2M8 12a4 4 0 108 0 4 4 0 10-8 0',up:'M5 15l7-7 7 7',down:'M5 9l7 7 7-7',drag:'M8 5h1M15 5h1M8 12h1M15 12h1M8 19h1M15 19h1',options:'M5 12h1M11 12h1M17 12h1',link:'M9 15l6-6M7 14l-3 3 3 3 5-5M12 9l5-5 3 3-3 3'};return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d={paths[name]||paths.rack}/></svg>}
function irLocationKey(l){return JSON.stringify(['client','site','building','room'].map(k=>l?.[k]||''))}
function irLocations(project){const map=new Map;for(const l of [...(project.rackclickLocations||[]),...project.racks.map(r=>r.rackclickLocation).filter(Boolean)])map.set(irLocationKey(l),l);return [...map.values()]}
function IntegratedNav({project,rack,view,onRack,onProject,onSettings,lang,systemhaus,onRename,onManage}){
 const w=IR_WORDS[lang]||IR_WORDS.en,[open,setOpen]=React.useState(false),locations=irLocations(project),clients=[...new Set(locations.map(l=>l.client))];
 const rackButton=r=><button key={r.id} className={view==='rack'&&rack?.id===r.id?'active':''} onClick={()=>{onRack(r.id);setOpen(false)}}><IRIcon name="rack"/><span><b>{r.name}</b><small>{r.location||w.unknown}</small></span></button>;
 return <><button className="ir-mobile-nav" aria-label={w.infrastructure} onClick={()=>setOpen(!open)}><IRIcon name="menu"/>RackClick</button><aside className={'ir-nav '+(open?'open':'')}><a className="ir-brand" href="#" onClick={e=>{e.preventDefault();onProject();setOpen(false)}}><IRIcon name="rack" size={24}/><b>Rack<span>Click</span></b></a><div className="ir-eyebrow">SYSTEMHAUS</div><button className="ir-org" aria-label={w.systemhaus} onClick={onRename}><span>RC</span><strong>{systemhaus}</strong><IRIcon name="edit"/></button><div className="ir-eyebrow ir-nav-label">{w.infrastructure}</div><button className="ir-manage" onClick={onManage}><IRIcon name="edit"/>{w.manage}</button><button className={'ir-project '+(view==='project'?'active':'')} onClick={()=>{onProject();setOpen(false)}}><IRIcon name="home"/>{project.name}</button><div className="ir-racks">{clients.map(client=><details open key={client} className="ir-client"><summary>{client}</summary>{locations.filter(l=>l.client===client).map(l=><div className="ir-location" key={irLocationKey(l)}><small>{[l.site,l.building,l.room].filter(Boolean).join(' / ')||w.client}</small>{project.racks.filter(r=>r.rackclickLocation&&irLocationKey(r.rackclickLocation)===irLocationKey(l)).map(rackButton)}</div>)}</details>)}{project.racks.some(r=>!r.rackclickLocation)&&<><small>{clients.length?w.unassigned:''}</small>{project.racks.filter(r=>!r.rackclickLocation).map(rackButton)}</>}</div><button className="ir-settings" onClick={()=>{onSettings();setOpen(false)}}><IRIcon name="settings"/>{w.settings}</button><div className="ir-nav-foot"><span>{w.local}</span><p>v{RC_VERSION}</p><small>JSON v0.8 · HTML</small></div></aside></>}
function IRInfrastructure({project,onApply,onClose,lang}){
 const w=IR_WORDS[lang]||IR_WORDS.en,[draft,setDraft]=React.useState(()=>JSON.parse(JSON.stringify(project))),[form,setForm]=React.useState({client:'',site:'',building:'',room:''}),[editing,setEditing]=React.useState(null),[error,setError]=React.useState(''),ref=React.useRef(null),locations=irLocations(draft);
 React.useEffect(()=>{ref.current.showModal()},[]);
 function saveLocation(e){
  e.preventDefault();const l=Object.fromEntries(Object.entries(form).map(([k,v])=>[k,v.trim()]));if(!l.client)return;
  const key=irLocationKey(l);
  setDraft(p=>{
   const current=irLocations(p),previous=editing?current.find(x=>irLocationKey(x)===editing):null;
   const remaining=current.filter(x=>irLocationKey(x)!==editing);
   const oldClient=previous?.client;
   const renamedClient=oldClient&&oldClient!==l.client&&!remaining.some(x=>x.client===oldClient);
   let meta=p.rackclickClientMeta||[];
   if(renamedClient){
    const destination=meta.find(m=>m.client===l.client);
    meta=destination?meta.filter(m=>m.client!==oldClient):meta.map(m=>m.client===oldClient?{...m,client:l.client}:m);
   }
   return {...p,rackclickLocations:[...remaining.filter(x=>irLocationKey(x)!==key),l],
    racks:p.racks.map(r=>editing&&r.rackclickLocation&&irLocationKey(r.rackclickLocation)===editing?{...r,rackclickLocation:l}:r),
    ...(renamedClient?{rackclickClientMeta:meta,changeLog:(p.changeLog||[]).map(entry=>entry.client===oldClient?{...entry,client:l.client}:entry)}:{})};
  });
  setEditing(null);setForm({client:'',site:'',building:'',room:''});setError('');
 }

 return <dialog ref={ref} className="ir-dialog" onCancel={onClose}><header><h2>{w.manage}</h2><button onClick={onClose} aria-label={w.cancel}>×</button></header><footer className="rc8-infra-actions"><button onClick={onClose}>{w.cancel}</button><button onClick={()=>{onApply(draft);onClose()}}>{w.save}</button></footer><p>{w.hierarchyHelp}</p><form onSubmit={saveLocation} className="ir-location-form">{['client','site','building','room'].map(k=><label key={k}>{w[k]}<input data-field={k} required={k==='client'} maxLength={100} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})}/></label>)}<button type="submit">{editing?w.save:w.addLocation}</button></form>{error&&<p role="alert">{error}</p>}<div className="ir-location-list">{locations.map(l=><div key={irLocationKey(l)}><span>{[l.client,l.site,l.building,l.room].filter(Boolean).join(' / ')}</span><button onClick={()=>{setForm({...l});setEditing(irLocationKey(l))}}>{w.edit}</button><button onClick={()=>{const key=irLocationKey(l);if(draft.racks.some(r=>r.rackclickLocation&&irLocationKey(r.rackclickLocation)===key)){setError(w.inUse);return}setDraft({...draft,rackclickLocations:locations.filter(x=>irLocationKey(x)!==key)});if(editing===key){setEditing(null);setForm({client:'',site:'',building:'',room:''})}}}>{w.removeLocation}</button></div>)}</div><h3>{w.assign}</h3>{draft.racks.map(r=><label className="ir-assignment" key={r.id}>{r.name}<select aria-label={w.assign+' '+r.name} value={r.rackclickLocation?irLocationKey(r.rackclickLocation):''} onChange={e=>{const l=locations.find(l=>irLocationKey(l)===e.target.value);setDraft({...draft,racks:draft.racks.map(x=>{if(x.id!==r.id)return x;const {rackclickLocation,...rest}=x;return l?{...rest,rackclickLocation:{...l}}:rest})})}}><option value="">{w.unassigned}</option>{locations.map(l=><option key={irLocationKey(l)} value={irLocationKey(l)}>{[l.client,l.site,l.building,l.room].filter(Boolean).join(' / ')}</option>)}</select></label>)}</dialog>
}
function IRFaceEditor({device,onApply,onClose,lang}){const w=IR_WORDS[lang]||IR_WORDS.en,[values,setValues]=React.useState(()=>Object.fromEntries(device.ports.map(p=>[p.id,p.rackclickFace||'auto']))),[roles,setRoles]=React.useState(()=>Object.fromEntries(device.ports.filter(p=>p.type==='power').map(p=>[p.id,p.rackclickPowerRole||'unspecified']))),ref=React.useRef(null);React.useEffect(()=>{ref.current.showModal()},[]);return <dialog ref={ref} className="ir-dialog" onCancel={onClose}><header><h2>{w.faces} · {device.name}</h2><button onClick={onClose}>×</button></header><p>{w.autoFace} · {w.unverified}</p>{device.ports.map(p=><label className="ir-assignment" key={p.id}>{PT[p.type]?.label||p.type} #{p.gn}<select aria-label={w.portFace+' '+p.id} value={values[p.id]} onChange={e=>setValues({...values,[p.id]:e.target.value})}><option value="auto">{w.autoFace}</option><option value="front">{w.front}</option><option value="rear">{w.rear}</option></select>{p.type==='power'&&<select aria-label={w.role+' '+p.id} value={roles[p.id]} onChange={e=>setRoles({...roles,[p.id]:e.target.value})}><option value="unspecified">{w.unspecified}</option><option value="inlet">{w.inlet}</option><option value="outlet">{w.outlet}</option></select>}</label>)}<footer><button onClick={onClose}>{w.cancel}</button><button onClick={()=>{onApply(values,roles);onClose()}}>{w.save}</button></footer></dialog>}
function irPortFace(d,p){if(['front','rear'].includes(p.rackclickFace))return p.rackclickFace;const family=(d.preset||'').toLowerCase();return /server|srv|nas|storage|san|ups/.test(family)||p.type==='power'?'rear':'front'}
// PoE budget covers enabled RJ45 PoE documentation only; mains watts never count.
function irPoeEnabled(p){return (p.type==='rj45'||p.type==='rj45_poe')&&(p.poe===true||(p.type==='rj45_poe'&&p.poe!==false))}
function irPoeStats(d){const eligible=d.ports.filter(irPoeEnabled),known=eligible.filter(p=>typeof p.watts==='number'&&Number.isFinite(p.watts)&&p.watts>=0);return {sum:known.reduce((n,p)=>n+p.watts,0),unknown:eligible.length-known.length,eligible:eligible.length}}
function irPoeSummary(d,w){const x=irPoeStats(d);return `${x.sum} W / ${d.poeBudget} W · ${x.unknown} ${w.poeUnknown}`}
const IR_HOVER_WORDS={
 en:{sn:'Serial number',ip:'IP address',model:'Model',firmware:'Firmware',notes:'Notes',status:'Status',label:'Label / outlet',local:'Local',cross:'Cross-rack',patch:'Patch status',free:'Free',reserved:'Reserved',disabled:'Disabled',faulty:'Faulty',planned:'Planned',progress:'In progress',done:'Done',tested:'Tested',none:'Not documented'},
 de:{sn:'Seriennummer',ip:'IP-Adresse',model:'Modell',firmware:'Firmware',notes:'Notizen',status:'Status',label:'Label / Dose',local:'Lokal',cross:'Rackübergreifend',patch:'Patch-Status',free:'Frei',reserved:'Reserviert',disabled:'Deaktiviert',faulty:'Defekt',planned:'Geplant',progress:'In Bearbeitung',done:'Fertig',tested:'Geprüft',none:'Nicht dokumentiert'},
 es:{sn:'Número de serie',ip:'Dirección IP',model:'Modelo',firmware:'Firmware',notes:'Notas',status:'Estado',label:'Etiqueta / toma',local:'Local',cross:'Entre racks',patch:'Estado de patch',free:'Libre',reserved:'Reservado',disabled:'Deshabilitado',faulty:'Defectuoso',planned:'Planificado',progress:'En curso',done:'Terminado',tested:'Probado',none:'No documentado'}
};
function irDeviceTooltip(d,lang){const h=IR_HOVER_WORDS[lang]||IR_HOVER_WORDS.en,w=IR_WORDS[lang]||IR_WORDS.en,n=d.notes||{};return [d.name,d.preset,`${d.u} U`,...['sn','ip','model','firmware'].map(k=>`${h[k]}: ${n[k]||w.unknown}`),`${h.notes}: ${n.text||w.unknown}`,d.poeBudget>0?`${w.poeSummary}: ${irPoeSummary(d,w)}`:null].filter(Boolean).join('\n')}
function irEndpointText(c,side,project,rack){const rid=side==='f'?c.rackFrom:c.rackTo,rs=project?.racks||[rack],r=rid?rs.find(r=>r.id===rid):rs.find(r=>r.devs.some(d=>d.ports.some(p=>p.id===c[side+'p']))),d=r?.devs.find(d=>d.id===c[side+'d'])||r?.devs.find(d=>d.ports.some(p=>p.id===c[side+'p'])),p=d?.ports.find(p=>p.id===c[side+'p']);return `${r?.name||rid||rack.name} / ${d?.name||c[side+'n']||'?'} · #${d?.portPrefix||''}${p?.gn??c[side+'pn']??'?'}${p?.label?' · '+p.label:''}`}
function irConnectionTooltip(c,project,rack,lang){const h=IR_HOVER_WORDS[lang]||IR_HOVER_WORDS.en,w=IR_WORDS[lang]||IR_WORDS.en;return `${c.rackFrom&&c.rackTo&&c.rackFrom!==c.rackTo?h.cross:h.local}: ${irEndpointText(c,'f',project,rack)} → ${irEndpointText(c,'t',project,rack)}\n${w.cableNote}: ${c.note||w.unknown}\n${h.patch}: ${h[c.patchStatus||'none']||c.patchStatus}`}
function irPortTooltip(d,p,allConns,project,rack,lang){const h=IR_HOVER_WORDS[lang]||IR_HOVER_WORDS.en,w=IR_WORDS[lang]||IR_WORDS.en,links=allConns.filter(c=>c.fp===p.id||c.tp===p.id);return [`${d.name} · ${PT[p.type]?.label||p.type} #${d.portPrefix||''}${p.gn}`,`${h.label}: ${p.label||w.unknown}`,`${w.watt}: ${typeof p.watts==='number'&&Number.isFinite(p.watts)?p.watts+' W':w.unknown}`,`${h.status}: ${h[p.status||'free']||p.status}`,p.type==='power'?`${w.role}: ${w[p.rackclickPowerRole]||w.unspecified}`:['rj45','rj45_poe'].includes(p.type)?`PoE: ${irPoeEnabled(p)?'ON':'OFF'}`:null,links.length>1?w.duplicate:null,...links.map(c=>irConnectionTooltip(c,project,rack,lang))].filter(Boolean).join('\n')}

function IntegratedInspector({rack,allConns,inspected,nextColor,onNextColor,onContext,lang}){const w=IR_WORDS[lang]||IR_WORDS.en;const d=rack.devs.find(d=>d.id===inspected?.did),p=d?.ports.find(p=>p.id===inspected?.pid),occupied=new Set(allConns.flatMap(c=>[c.fp,c.tp])),localIds=new Set(rack.devs.flatMap(d=>d.ports.map(p=>p.id)));return <section className="ir-inspector"><div className="ir-eyebrow">{p?w.inspect:w.overview}</div><h2>{p?d.name:rack.name}</h2>{p?<><strong>{PT[p.type]?.label||p.type} · {(d.portPrefix||'')+p.gn}</strong><dl><dt>{w.watt}</dt><dd>{p.watts===undefined?w.unknown:p.watts+' W'}</dd><dt>{w.portFace}</dt><dd>{irPortFace(d,p)==='rear'?w.rear:w.front}{!p.rackclickFace?' · '+w.autoFace:''}</dd><dt>PoE</dt><dd>{irPoeEnabled(p)?'ON':'OFF'}</dd><dt>{w.name}</dt><dd>{p.label||'—'}</dd><dt>{w.connections}</dt><dd>{allConns.filter(c=>c.fp===p.id||c.tp===p.id).length}</dd></dl>{d.poeBudget>0&&<p className="ir-poe-summary"><strong>{w.poeSummary}</strong><span>{irPoeSummary(d,w)}</span></p>}<button onClick={e=>onContext(e,d.id,p.id)}><IRIcon name="edit"/>{w.details}</button></>:<dl><dt>{w.devices}</dt><dd>{rack.devs.length}</dd><dt>{w.connections}</dt><dd>{allConns.length}</dd><dt>{w.free}</dt><dd>{rack.size-rack.devs.reduce((s,d)=>s+d.u,0)}</dd><dt>{w.ports}</dt><dd>{[...occupied].filter(id=>localIds.has(id)).length} / {localIds.size}</dd></dl>}{!p&&rack.devs.filter(d=>d.poeBudget>0).map(d=><p className="ir-poe-summary" key={d.id}><strong>{d.name} · {w.poeSummary}</strong><span>{irPoeSummary(d,w)}</span></p>)}{p&&allConns.filter(c=>c.fp===p.id||c.tp===p.id).map(c=><div className="ir-link-detail" key={c.id}><strong>{c.fn} #{c.fpn} → {c.tn} #{c.tpn}</strong><p>{w.cableNote}: {c.note||'—'}</p></div>)}<div className="ir-next"><label>{w.next}</label><div className="ir-swatches">{IR_COLORS.map(c=><button key={c} title={c} aria-label={w.next+' '+c} aria-pressed={nextColor===c} style={{background:c,color:'#071a1a'}} onClick={()=>onNextColor(c)}>{nextColor===c?'✓':''}</button>)}</div><button className="ir-auto" aria-pressed={!nextColor} onClick={()=>onNextColor(null)}>{w.automatic}</button></div></section>}
const IR_COLORS=['#34d399','#60a5fa','#fbbf24','#f472b6','#a78bfa','#22d3ee','#fb923c'];
function IRPortShape({type,role}){if(type==='rj45'||type==='rj45_poe'||type==='mgmt')return <><path d="M5 6H35V27H27V32H13V27H5Z"/>{Array.from({length:8},(_,i)=><path className="ir-pin" key={i} d={`M${8+i*3.2} 7v8`}/>)}</>;if(['sfp','sfp28','qsfp'].includes(type))return <><rect x="3" y="10" width="34" height="17" rx="1"/><path d="M7 24h26M10 27v4h20v-4"/><path className="ir-pin" d="M8 11h24"/></>;if(type==='usb_c')return <><rect x="3" y="12" width="34" height="16" rx="8"/><path d="M10 20h20"/></>;if(type==='usb_a')return <><rect x="3" y="10" width="34" height="20"/><path className="ir-pin" d="M8 16h24"/></>;if(type==='power')return <><path d="M8 6h24l5 6v22H3V12Z"/>{role==='outlet'?<g className="ir-power-sockets"><rect x="10" y="18" width="4" height="8"/><rect x="26" y="18" width="4" height="8"/><rect x="18" y="10" width="4" height="8"/></g>:role==='inlet'?<path className="ir-pin" d="M12 18v7M28 18v7M20 12v7"/>:<path className="ir-power-neutral" d="M12 20h16M20 12v16" fill="none" stroke="currentColor"/>}</>;return <><path d="M5 10h30l-4 20H9Z"/>{Array.from({length:5},(_,i)=><circle key={i} cx={11+i*4.5} cy="19" r="1"/>)}</>}
function irLayout(d,face){
 const groups=[];for(const p of d.ports.filter(p=>irPortFace(d,p)===face)){let g=groups.find(g=>g.type===(p.type==='rj45_poe'?'rj45':p.type));if(!g){g={type:p.type==='rj45_poe'?'rj45':p.type,ports:[]};groups.push(g)}g.ports.push(p)}
 const preset=(d.preset||'').toLowerCase();
 const family=/server|srv|nas|storage|san/.test(preset)?'storage':/ups/.test(preset)?'ups':/blank|spacer|cable|shelf|bl[12]u|sp[12]u|cbl/.test(preset)?'blank':/switch|^sw/.test(preset)?'switch':'panel';
 const deco=family==='storage'?(face==='front'?60:72):family==='ups'?38:0, ports=[];
 const dense=groups.find(g=>g.ports.length>=20), auxiliaries=dense?groups.filter(g=>g!==dense).flatMap(g=>g.ports):[];
 let bottom=26+deco;
 if(dense){const pitch=auxiliaries.length?29:37,pw=auxiliaries.length?24:30;
  dense.ports.forEach((p,i)=>ports.push({...p,px:40+(i%24)*pitch,py:26+deco+Math.floor(i/24)*44,pw}));
  const x=auxiliaries.length?760:40;
  auxiliaries.forEach((p,i)=>ports.push({...p,px:x+(i%4)*43,py:26+deco+Math.floor(i/4)*44,pw:28}));
  bottom+=Math.max(Math.ceil(dense.ports.length/24),Math.ceil(auxiliaries.length/4))*44;
 }else{let x=40,y=26+deco;
  for(const g of groups){for(const p of g.ports){if(x+42>920){x=40;y+=50}ports.push({...p,px:x,py:y,pw:34});x+=56}x+=24}
  bottom=y+45;
 }
 return{ports,height:Math.max(d.u*70,bottom+12),family,deco};
}
function IntegratedPhysicalRack({project,rack,allConns,colors,selection,onPort,onContext,onLabel,onEdit,onDelete,onDeviceContext,face,zoom,lang,id,onMove,onSelect,selectedDevs,collapsedDevs,onCollapse,onDrop,onDragStart,onDragEnter,onDragEnd,onTouchDragStart,onTouchDragMove,onTouchDragEnd,search,flashPorts,wireFocus,onWireFocus,ptColors,onFaces,onFace}){
const w=IR_WORDS[lang]||IR_WORDS.en,root=React.useRef(null),[wires,setWires]=React.useState([]),[bounds,setBounds]=React.useState({width:1,height:1}),[show,setShow]=React.useState(true);const connectionClickTimer=React.useRef(null);React.useEffect(()=>()=>clearTimeout(connectionClickTimer.current),[]);const timer=React.useRef(null),long=React.useRef(false),deviceTimer=React.useRef(null),deviceLong=React.useRef(false),deviceStart=React.useRef(null);const devices=rack.devs;const counts={};allConns.forEach(c=>{counts[c.fp]=(counts[c.fp]||0)+1;counts[c.tp]=(counts[c.tp]||0)+1});const duplicate=rack.devs.some(d=>d.ports.some(p=>counts[p.id]>1));const positions=React.useCallback(()=>{const el=root.current;if(!el)return;const r=el.getBoundingClientRect(),points=new Map;el.querySelectorAll('[data-ir-hit]').forEach(p=>{const b=p.getBoundingClientRect();points.set(p.getAttribute('data-ir-hit'),{x:b.left+b.width/2-r.left,y:b.top+b.height/2-r.top})});setBounds({width:el.offsetWidth,height:el.offsetHeight});setWires(allConns.flatMap(c=>{const a=points.get(c.fp),b=points.get(c.tp);if(!a&&!b)return[];if(!a||!b){const pt=a||b,other=a?c.tn:c.fn;return[{id:c.id,color:colors[c.id]||'#34d399',stub:true,label:other+' · '+(c.note||''),path:`M${pt.x} ${pt.y} C${pt.x+24} ${pt.y+28} ${r.width-22} ${pt.y+28} ${r.width-14} ${pt.y+12}`}]}const bend=Math.max(28,Math.abs(b.y-a.y)*.6)*(b.y>=a.y?1:-1);return[{id:c.id,color:colors[c.id]||'#34d399',path:`M${a.x} ${a.y} C${a.x} ${a.y+bend} ${b.x} ${b.y-bend} ${b.x} ${b.y}`}]}))},[rack,allConns,face,zoom,collapsedDevs]);React.useLayoutEffect(()=>{positions();const ro=new ResizeObserver(positions);if(root.current)ro.observe(root.current);window.addEventListener('resize',positions);return()=>{ro.disconnect();window.removeEventListener('resize',positions);clearTimeout(timer.current);clearTimeout(deviceTimer.current)}},[positions]);let u=1;return <div className="ir-rack-section"><div className="ir-rack-title"><div><div className="ir-eyebrow">{w.physical}</div><h1>{rack.name}<small>{rack.size} U</small></h1><p>{rack.location||w.unknown}</p></div><button aria-pressed={show} onClick={()=>setShow(!show)}>{w.cables} {show?'ON':'OFF'}</button></div>{duplicate&&<div className="ir-warning" role="status">{w.duplicate}</div>}<div className="ir-face-switch" role="group" aria-label={w.view}>{["front","rear"].map(f=><button key={f} data-face={f} aria-pressed={face===f} onClick={()=>onFace(f)}>{w[f]}</button>)}</div><div className="ir-physical-note" title={w.autoFace}>{w.autoFace} · {face==='rear'?w.rear:w.front}</div><div className="ir-rack-scroll"><div id={id} className="ir-export" style={{minWidth:Math.min(640,840*zoom/100),width:zoom>100?(zoom+'%'):'100%'}}><div className="ir-rack-label"><b>{rack.name}</b><span>{face==='rear'?w.rear:w.front} · {rack.size} U</span></div><div ref={root} className="ir-stack" onTouchMove={onTouchDragMove} onTouchEnd={onTouchDragEnd}>{devices.map((d,i)=>{const l=irLayout(d,face),start=u;u+=d.u;const collapsed=collapsedDevs.has(d.id),dim=search&&!`${d.name} ${d.preset} ${JSON.stringify(d.notes||{})} ${d.ports.map(p=>p.label||'').join(' ')}`.toLowerCase().includes(search.toLowerCase());return <div className={'ir-device-row '+(selectedDevs.has(d.id)?'selected ':'')+(dim?'dim':'')} data-devid={d.id} key={d.id} onContextMenu={e=>{if(!e.target.closest?.("[data-vport]")){e.preventDefault();onDeviceContext(e,d)}}} draggable onDragStart={e=>{if(e.target.closest?.('[data-vport]')){e.preventDefault();return}e.dataTransfer.setData('text/plain',d.id);onDragStart(d.id)}} onDragOver={e=>e.preventDefault()} onDragEnter={()=>onDragEnter(d.id)} onDrop={e=>{e.preventDefault();onDrop(e.dataTransfer.getData('text/plain'),d.id)}} onDragEnd={onDragEnd}><div className="ir-units">{Array.from({length:d.u},(_,j)=><span key={j}>{start+j}</span>)}</div><div className="ir-device"><div className="ir-device-head"><button className="ir-drag" title={w.drag} onTouchStart={e=>onTouchDragStart(d.id,e)}><IRIcon name="drag"/></button><input type="checkbox" aria-label={w.select+' '+d.name} checked={selectedDevs.has(d.id)} onChange={()=>onSelect(d.id,true)}/><button className="ir-device-name" title={irDeviceTooltip(d,lang)} onClick={()=>{if(deviceLong.current){deviceLong.current=false;return}onEdit(d)}} onPointerDown={e=>{if(e.pointerType!=="touch")return;clearTimeout(deviceTimer.current);deviceLong.current=false;deviceStart.current={x:e.clientX,y:e.clientY};const x=e.clientX,y=e.clientY;deviceTimer.current=setTimeout(()=>{deviceLong.current=true;onDeviceContext({clientX:x,clientY:y,preventDefault:()=>{}},d)},550)}} onPointerMove={e=>{if(e.pointerType==="touch"&&deviceStart.current&&Math.hypot(e.clientX-deviceStart.current.x,e.clientY-deviceStart.current.y)>10)clearTimeout(deviceTimer.current)}} onPointerUp={()=>clearTimeout(deviceTimer.current)} onPointerCancel={()=>{clearTimeout(deviceTimer.current);deviceLong.current=false}}><b>{d.name}</b><small>{d.preset}</small></button><div className="ir-device-actions"><button aria-label={w.up} title={w.up} disabled={i===0} onClick={()=>onMove(d.id,-1)}><IRIcon name="up"/></button><button aria-label={w.down} title={w.down} disabled={i===devices.length-1} onClick={()=>onMove(d.id,1)}><IRIcon name="down"/></button><button aria-label={w.faces+' '+d.name} title={w.faces} onClick={()=>onFaces(d)}><IRIcon name="rack"/></button><button aria-label={w.edit+" "+d.name} title={w.edit} onClick={()=>onEdit(d)}><IRIcon name="edit"/></button><button aria-label={w.options+" "+d.name} title={w.options} onClick={e=>onDeviceContext(e,d)}><IRIcon name="options"/></button><button aria-label={w.collapse+" "+d.name} title={w.collapse} onClick={()=>onCollapse(d.id)}>{collapsed?'+':'−'}</button><button aria-label={w.remove+" "+d.name} title={w.remove} onClick={()=>onDelete(d.id)}><IRIcon name="close"/></button></div></div>{!collapsed&&<svg className="ir-face" viewBox={`0 0 960 ${l.height}`} role="group" aria-label={d.name}><rect x="1" y="1" width="958" height={l.height-2} rx="4" className="ir-chassis"/>{[[10,10],[950,10],[10,l.height-10],[950,l.height-10]].map(([x,y],i)=><circle key={i} cx={x} cy={y} r="3" fill="#12171e" stroke="#8696a7" strokeWidth="1"/>)}{l.family==='storage'&&face==='front'&&Array.from({length:8},(_,i)=><g key={i} transform={`translate(${38+i*108},12)`}><rect width="97" height="39" rx="3" fill="#121923" stroke="#697b8e"/><rect x="7" y="8" width="77" height="23" fill="#303d4a"/><path d="M87 7v25" stroke="#98a4ae"/></g>)}{l.family==='storage'&&face==='rear'&&<g className="ir-rear-hardware">{[55,135,215].map(x=><g key={x}><rect x={x} y="12" width="70" height="57" rx="4" fill="#121923" stroke="#697b8e"/><circle cx={x+35} cy="40" r="23" fill="none" stroke="#8797a7"/>{Array.from({length:8},(_,i)=><path key={i} d={`M${x+35} 40l18 -5 -9 17Z`} transform={`rotate(${i*45} ${x+35} 40)`} fill="#475566"/>)}<circle cx={x+35} cy="40" r="6" fill="#111923"/></g>)}<rect x="320" y="16" width="570" height="44" fill="#161e27" stroke="#697b8e"/>{Array.from({length:4},(_,i)=><path key={i} d={`M335 ${24+i*9}h535`} stroke="#8192a3"/>)}</g>}{l.family==='ups'&&face==='front'&&<><rect x="30" y="12" width="148" height="32" rx="3" fill="#0e171b" stroke="#7d8c9f"/><text className="ir-small" x="104" y="32" textAnchor="middle">{w.noTelemetry}</text>{Array.from({length:12},(_,i)=><path key={i} d={`M210 ${13+i*2.6}h650`} stroke="#6d7d8f"/>)}</>}{!l.ports.length&&<><path d={`M30 28H920M30 ${l.height-28}H920`} stroke="#526273"/><text x="480" y={l.height/2+5} textAnchor="middle" className="ir-empty-device">{w.noPorts}</text></>}{l.ports.map(p=>{const cn=allConns.find(c=>c.fp===p.id||c.tp===p.id),color=p.portColor||(cn&&colors[cn.id])||ptColors[p.type],selected=selection?.pid===p.id;return <g key={p.id} data-vport={p.id} role="button" tabIndex={0} aria-label={`${d.name} ${w.ports} ${p.gn} ${PT[p.type]?.label||p.type}`} onClick={e=>{e.stopPropagation();if(e.detail>1)return;if(long.current){long.current=false;return}clearTimeout(connectionClickTimer.current);if(cn){connectionClickTimer.current=setTimeout(()=>onPort(d.id,p.id),280)}else onPort(d.id,p.id)}} onDoubleClick={e=>{e.preventDefault();e.stopPropagation();clearTimeout(connectionClickTimer.current);onLabel(e,d.id,p.id)}} onContextMenu={e=>{e.preventDefault();onContext(e,d.id,p.id)}} onKeyDown={e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();onPort(d.id,p.id)}if(e.key==='F10'&&e.shiftKey){e.preventDefault();const b=e.currentTarget.getBoundingClientRect();onContext({clientX:b.left,clientY:b.bottom,preventDefault:()=>{}},d.id,p.id)}}} onPointerDown={e=>{if(e.pointerType==='touch'){long.current=false;const x=e.clientX,y=e.clientY;timer.current=setTimeout(()=>{long.current=true;onContext({clientX:x,clientY:y,preventDefault:()=>{}},d.id,p.id)},500)}}} onPointerUp={()=>clearTimeout(timer.current)} onPointerCancel={()=>clearTimeout(timer.current)} onPointerMove={e=>{if(e.pointerType==='touch'&&Math.abs(e.movementX)+Math.abs(e.movementY)>4)clearTimeout(timer.current)}} className={'ir-terminal '+(selected?'selected ':'')+(flashPorts.has(p.id)?'flash':'')}><title>{irPortTooltip(d,p,allConns,project,rack,lang)}</title><text x={p.px+p.pw/2} y={p.py-4} textAnchor="middle" className="ir-port-number">{p.gn}</text><g transform={`translate(${p.px} ${p.py}) scale(${p.pw/40})`} className="ir-port-shape"><IRPortShape type={p.type} role={p.rackclickPowerRole}/></g><rect data-ir-hit={p.id} x={p.px} y={p.py} width={p.pw} height={p.pw} rx="2" fill="transparent" stroke={selected?'#fff':p.status==='disabled'||p.status==='faulty'?'#fb7185':p.status==='reserved'?'#fbbf24':color||'transparent'} strokeWidth={selected?2:1} strokeDasharray={p.status==='reserved'?'3 2':undefined}/>{["rj45","rj45_poe"].includes(p.type)&&<path data-poe={irPoeEnabled(p)?"on":"off"} d={`M${p.px+p.pw-6} ${p.py+4}l-4 7h4l-3 7 7-10h-4l3-4Z`} fill={irPoeEnabled(p)?"currentColor":"none"} stroke="currentColor" strokeWidth="1"/>}{cn&&<circle cx={p.px+p.pw-2} cy={p.py+2} r="1.7" fill="#34d399"/>}{p.label&&<circle cx={p.px+2} cy={p.py+p.pw-2} r="1.5" fill="#e6edf3"/>}{counts[p.id]>1&&<text x={p.px+p.pw} y={p.py+12} className="ir-dup">!</text>}</g>})}</svg>}</div></div>})}{!devices.length&&<div className="ir-empty">{w.empty}</div>}{rack.size>=u&&<div className="ir-blank"><span>{u}–{rack.size}</span><b>{rack.size-u+1} U</b></div>}{show&&<svg className="ir-wires" width={bounds.width} height={bounds.height} aria-hidden="true"><defs><filter id="ir-shadow" filterUnits="userSpaceOnUse" x="-100" y="-100" width={bounds.width+200} height={bounds.height+200}><feDropShadow dx="0" dy="2" stdDeviation="1.5" floodColor="#000" floodOpacity=".8"/></filter></defs>{wires.map(c=><path key={c.id} data-wire={c.id} d={c.path} stroke={c.color} fill="none" strokeWidth={wireFocus===c.id?3.5:2} opacity={wireFocus&&wireFocus!==c.id? .2:.9} strokeDasharray={c.stub?'5 3':undefined} filter="url(#ir-shadow)"><title>{c.label||c.id}</title></path>)}</svg>}</div>{face==='rear'&&<IRPowerSummary project={project} rack={rack} connections={allConns} lang={lang} onSelect={onWireFocus}/>}<div className="ir-rack-bottom">{w.unverified} · {allConns.length} {w.connections.toLowerCase()}</div></div></div></div>}
/* Visible SVG equivalents keep legacy accessible labels and test selectors. */
function irElement(type,props,...children){
 if(type==='input'&&typeof props?.placeholder==='string'&&/🔍/.test(props.placeholder)){props={...props,placeholder:props.placeholder.replace(/🔍\s*/g,''),className:((props.className||'')+' rc8-search')};}

 const symbols={'💾':'save','📸':'snapshot','📂':'folder','📥':'download','📤':'upload','📊':'report','📄':'file','🧾':'image','🏷️':'tag','📱':'qr','⚙️':'settings','🔀':'merge','🗑':'remove','🔌':'link','🔗':'link','📋':'file','📜':'file','💡':'bulb','👷':'user'};
 if(type==='button'||type==='span')children=children.map(child=>{
  if(typeof child!=='string')return child;
  const symbol=Object.keys(symbols).find(s=>child.trimStart().startsWith(s));if(!symbol)return child;
  const at=child.indexOf(symbol);return React.createElement(React.Fragment,null,child.slice(0,at),React.createElement(IRIcon,{name:symbols[symbol],size:16}),React.createElement('span',{className:'ir-accessible-symbol'},symbol),child.slice(at+symbol.length));
 });
 return React.createElement(type,props,...children);
}

/* v0.9 integration safety: pure operations; the adopted source stays immutable. */
/* Preserve each boot failure as its own raw localStorage value. The original
   rackclick_quarantine key stays byte-identical for v0.8.x rollback. */
const IR_QUARANTINE_PREFIX = 'rackclick_quarantine_episode_';
function irQuarantineEntries(){
 const keys=[];
 for(let i=0;i<localStorage.length;i++){
  const key=localStorage.key(i);
  if(key===QUARANTINE_KEY||key?.startsWith(IR_QUARANTINE_PREFIX))keys.push(key);
 }
 return keys.map(key=>{
  const raw=localStorage.getItem(key);if(raw===null)return null;
  let data={};try{data=JSON.parse(raw)||{}}catch{}
  return {key,createdAt:data.createdAt,reason:data.reason,
   hasAutosave:typeof data.keys?.autosave==='string'};
 }).filter(Boolean).sort((a,b)=>a.key===QUARANTINE_KEY?-1:b.key===QUARANTINE_KEY?1:a.key.localeCompare(b.key));
}
function irBootSafeShape(p){
 if(!Array.isArray(p.racks))return true; // validateProject handles missing arrays.
 const text=(v)=>v===undefined||v===null||typeof v==='string';
 for(const r of p.racks){
  if(!r||!text(r.name))return false;
  if(Array.isArray(r.devs))for(const d of r.devs){
   if(!d||!text(d.name)||!text(d.icon)||!text(d.preset)||!text(d.color))return false;
   if(Array.isArray(d.ports))for(const port of d.ports){
    if(!port||!text(port.type)||!text(port.label)||!text(port.status))return false;
   }
  }
  if(Array.isArray(r.conns))for(const c of r.conns){
   if(!c||!text(c.fn)||!text(c.tn)||!text(c.note)||!text(c.color))return false;
  }
 }
 return true;
}
const IR_RECOVERY_WORDS={
 en:{unreadable:'Storage could not be read. Autosave is paused; reload after restoring browser access. The existing project was not overwritten.',quarantineFailed:'Recovery data could not be saved. Autosave is paused; export your data and free storage before reloading.',quarantineCount:'Recovery episodes',deleteFailed:'Recovery data could not be deleted. It remains available.',readFailed:'Recovery data could not be read.',exportMemory:'Export visible project',exportRaw:'Download raw storage',reload:'Retry reading storage',notSaved:'Recovery data was not secured.'},
 de:{unreadable:'Speicher konnte nicht gelesen werden. Autosave ist angehalten; nach Wiederherstellung des Browserzugriffs neu laden. Das gespeicherte Projekt wurde nicht überschrieben.',quarantineFailed:'Rettungsdaten konnten nicht gespeichert werden. Autosave ist angehalten; Daten exportieren und Speicher freigeben.',quarantineCount:'Rettungsvorgänge',deleteFailed:'Rettungsdaten konnten nicht gelöscht werden. Sie bleiben verfügbar.',readFailed:'Rettungsdaten konnten nicht gelesen werden.',exportMemory:'Sichtbares Projekt exportieren',exportRaw:'Rohdaten herunterladen',reload:'Speicher erneut lesen',notSaved:'Rettungsdaten wurden nicht gesichert.'},
 es:{unreadable:'No se pudo leer el almacenamiento. El autoguardado está detenido; recarga tras restablecer el acceso. No se sobrescribió el proyecto guardado.',quarantineFailed:'No se pudieron guardar los datos de rescate. El autoguardado está detenido; exporta tus datos y libera espacio.',quarantineCount:'Episodios de rescate',deleteFailed:'No se pudieron eliminar los datos de rescate. Permanecen disponibles.',readFailed:'No se pudieron leer los datos de rescate.',exportMemory:'Exportar proyecto visible',exportRaw:'Descargar datos crudos',reload:'Reintentar lectura del almacenamiento',notSaved:'Los datos de rescate no quedaron asegurados.'}
};
function irDownloadCurrentRescue(){
 const keys={};RESCUE_KEYS.forEach(k=>{keys[k]=rcReadRaw(k)});
 try{for(let i=0;i<localStorage.length;i++){
  const key=localStorage.key(i);
  if(key?.startsWith(IR_QUARANTINE_PREFIX))keys[key]=rcReadRaw(key);
 }}catch{}
 rcDownload(JSON.stringify({_meta:{type:'rackclick-rescue-bundle',appVersion:RC_VERSION,
  createdAt:new Date().toISOString(),note:'Raw localStorage values; null means unreadable or absent.'},keys},null,2),
  'rackclick-RESCATE-'+rcTimestamp()+'.json');
}
function irAssertTopology(p){
 irAssertPresentation(p);
 if(!p||p.version!=='0.8'||!Array.isArray(p.racks)||!Array.isArray(p.crossConns||[]))throw Error('Invalid project');
 const str=(o,k,required=false)=>{if(o[k]===undefined&&!required)return;if(typeof o[k]!=='string')throw Error('Invalid text '+k)};
 const num=(o,k,required=false,min=0)=>{if(o[k]===undefined&&!required)return;if(typeof o[k]!=='number'||!Number.isFinite(o[k])||o[k]<min)throw Error('Invalid number '+k)};
 for(const k of ['name','technician','createdAt','updatedAt','rackclickSystemhaus'])str(p,k);
 if(p.logo!==undefined&&p.logo!==null){str(p,'logo');if(p.logo&&!/^data:image\/(png|jpe?g|gif|webp|svg\+xml);base64,/.test(p.logo))throw Error('Logo must be embedded')}
 if(p.changeLog!==undefined){if(!Array.isArray(p.changeLog))throw Error('Invalid log');for(const entry of p.changeLog){if(!entry||typeof entry!=='object')throw Error('Invalid log');for(const k of ['ts','action','tech'])str(entry,k)}}
 const location=l=>{if(!l||typeof l!=='object'||Array.isArray(l)||typeof l.client!=='string'||!l.client.trim())throw Error('Invalid location');for(const k of ['client','site','building','room']){str(l,k,true);if(l[k].length>100)throw Error('Location too long')}};
 if(p.rackclickLocations!==undefined){if(!Array.isArray(p.rackclickLocations))throw Error('Invalid locations');p.rackclickLocations.forEach(location)}
 const racks=new Set,devices=new Map,ports=new Map,links=new Set;
 const take=(set,id)=>{if(typeof id!=='string'||!id||set.has(id))throw Error('Duplicate or missing ID');set.add(id)};
 for(const r of p.racks){if(!r||typeof r!=='object')throw Error('Invalid rack');str(r,'name',true);if(r.rackclickLocation!==undefined)location(r.rackclickLocation);str(r,'location');num(r,'size',true,1);take(racks,r.id);if(!Array.isArray(r.devs)||!Array.isArray(r.conns))throw Error('Invalid rack');
  for(const d of r.devs){if(!d||typeof d!=='object')throw Error('Invalid device');str(d,'name',true);for(const k of ['icon','color','preset','portPrefix'])str(d,k);num(d,'u',true,1);num(d,'poeBudget');if(d.notes!==undefined){if(!d.notes||typeof d.notes!=='object'||Array.isArray(d.notes))throw Error('Invalid notes');for(const k of ['sn','serial','ip','model','firmware','text','notes'])str(d.notes,k)}if(devices.has(d.id)||typeof d.id!=='string'||!d.id||!Array.isArray(d.ports))throw Error('Invalid device');devices.set(d.id,r.id);
   for(const port of d.ports){if(!port||typeof port!=='object')throw Error('Invalid port');if(port.rackclickPowerRole!==undefined&&(port.type!=='power'||!['inlet','outlet'].includes(port.rackclickPowerRole)))throw Error('Invalid power role');if(port.rackclickFace!==undefined&&!['front','rear'].includes(port.rackclickFace))throw Error('Invalid port face');str(port,'label');str(port,'status');if(port.portColor!==undefined&&port.portColor!==null)str(port,'portColor');num(port,'gn',true,1);num(port,'watts');if(port.poe!==undefined&&typeof port.poe!=='boolean')throw Error('Invalid PoE');if(ports.has(port.id)||typeof port.id!=='string'||!port.id||typeof port.type!=='string')throw Error('Invalid port');ports.set(port.id,{did:d.id,rid:r.id})}
  }
 }
 const check=(c,from,to)=>{if(!c||typeof c!=='object')throw Error('Invalid connection');for(const k of ['fn','tn'])str(c,k,true);for(const k of ['fpt','tpt','fpt2','tpt2','note','color','patchStatus','createdAt'])str(c,k);num(c,'fpn');num(c,'tpn');take(links,c.id);if([c.fd,c.td,c.fp,c.tp,from,to].some(id=>typeof id!=='string'||!id)||!racks.has(from)||!racks.has(to)||!ports.has(c.fp)||!ports.has(c.tp)||!devices.has(c.fd)||!devices.has(c.td))throw Error('Missing endpoint');if(ports.get(c.fp)?.did!==c.fd||ports.get(c.tp)?.did!==c.td||devices.get(c.fd)!==from||devices.get(c.td)!==to)throw Error('Endpoint ownership mismatch')};
 for(const r of p.racks)for(const c of r.conns)check(c,r.id,r.id);
 for(const c of p.crossConns||[])check(c,c.rackFrom,c.rackTo);
 return p;
}
function irAppendProject(current,incoming){
 irAssertTopology(incoming);
 const rmap=new Map,dmap=new Map,pmap=new Map;
 incoming.racks.forEach(r=>{rmap.set(r.id,gid());r.devs.forEach(d=>{const id=gid();dmap.set(d.id,id);d.ports.forEach((p,i)=>pmap.set(p.id,id+'-p'+(i+1)))})});
 const mapLink=c=>({...c,id:gid(),fd:dmap.get(c.fd),td:dmap.get(c.td),fp:pmap.get(c.fp),tp:pmap.get(c.tp)});
 const names=new Set(current.racks.map(r=>r.name));
 const racks=incoming.racks.map(r=>{let name=r.name,n=2;while(names.has(name))name=r.name+' ('+(n++)+')';names.add(name);return{...r,id:rmap.get(r.id),name,devs:r.devs.map(d=>({...d,id:dmap.get(d.id),ports:d.ports.map(p=>({...p,id:pmap.get(p.id)}))})),conns:r.conns.map(mapLink)}});
 const cross=(incoming.crossConns||[]).map(c=>({...mapLink(c),rackFrom:rmap.get(c.rackFrom),rackTo:rmap.get(c.rackTo)}));
 return irAssertTopology({...current,...(incoming.rackclickLocations?{rackclickLocations:[...(current.rackclickLocations||[]),...incoming.rackclickLocations]}:{}),racks:[...current.racks,...racks],crossConns:[...(current.crossConns||[]),...cross]});
}
function irMoveDevice(project,id,target){
 const source=project.racks.find(r=>r.devs.some(d=>d.id===id));
 if(!source||!project.racks.some(r=>r.id===target))throw Error('Rack missing');
 if(source.id===target)return project;
 const device=source.devs.find(d=>d.id===id),owners=new Map;
 const racks=project.racks.map(r=>({...r,devs:r.id===source.id?r.devs.filter(d=>d.id!==id):r.id===target?[...r.devs,device]:r.devs,conns:[]}));
 racks.forEach(r=>r.devs.forEach(d=>owners.set(d.id,r.id)));
 const crossConns=[];
 for(const c of [...project.racks.flatMap(r=>r.conns),...(project.crossConns||[])]){
  const from=owners.get(c.fd),to=owners.get(c.td);const {rackFrom,rackTo,...local}=c;
  if(from===to)racks.find(r=>r.id===from).conns.push(local);else crossConns.push({...c,rackFrom:from,rackTo:to});
 }
 return irAssertTopology({...project,racks,crossConns});
}
function irImportedProject(data,name){
 if(data.version==='0.8')return irAssertTopology(data);
 if(Array.isArray(data.devs)){const rack={id:gid(),name:data.note||name.replace(/\.json$/i,''),location:'',size:data.rackSize||24,devs:data.devs,conns:data.conns||[]};const p={version:'0.8',name,racks:[rack],crossConns:[]};irAssertTopology(p);return p}
 throw Error('Unknown file');
}
function irRenameLink(c,id,name){return{...c,...(c.fd===id?{fn:name}:{}),...(c.td===id?{tn:name}:{})}}
function irCSVConnections(text,rack,project){
 const rows=[];let row=[],cell='',quoted=false;
 for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++}else quoted=!quoted}
  else if(c===','&&!quoted){row.push(cell.trim());cell=''}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell.trim());if(row.some(Boolean))rows.push(row);row=[];cell=''}else cell+=c}
 if(quoted)throw Error('Unterminated CSV quote');row.push(cell.trim());if(row.some(Boolean))rows.push(row);
 if(rows.length<2)throw Error('Empty CSV');const h=rows.shift().map(s=>s.replace(/^\uFEFF/,'').toLowerCase());
 const index=re=>h.findIndex(s=>re.test(s)),fi=index(/from.*dev/),ti=index(/to.*dev/),fp=index(/from.*port/),tp=index(/to.*port/),ft=index(/from.*type/),tt=index(/to.*type/),ni=index(/cable|note/),xi=index(/cross/);
 if([fi,ti,fp,tp].some(i=>i<0))throw Error('Required CSV columns missing');
 const endpoint=(name,num,type)=>{const ds=rack.devs.filter(d=>d.name===name);if(ds.length!==1)throw Error('Ambiguous device');const d=ds[0];const ps=d.ports.filter(p=>p.gn===Number(num)&&(!type||p.type===type||PT[p.type]?.label===type));if(ps.length!==1)throw Error('Ambiguous port: include From Type / To Type');return[d,ps[0]]};
 const links=[...project.racks.flatMap(r=>r.conns),...(project.crossConns||[])],occupied=new Set(links.flatMap(c=>[c.fp,c.tp])),pending=[];
 for(const r of rows){if(xi>=0&&r[xi])throw Error('Cross-rack CSV requires project JSON');const [fd,f]=endpoint(r[fi],r[fp],ft>=0?r[ft]:''),[td,t]=endpoint(r[ti],r[tp],tt>=0?r[tt]:'');
  if(f.id===t.id||occupied.has(f.id)||occupied.has(t.id)||[f,t].some(p=>['disabled','faulty'].includes(p.status)))throw Error('Unavailable endpoint');
  occupied.add(f.id);occupied.add(t.id);pending.push({id:gid(),fd:fd.id,fp:f.id,td:td.id,tp:t.id,fn:fd.name,tn:td.name,fpn:f.gn,tpn:t.gn,fpt:PT[f.type]?.label||f.type,tpt:PT[t.type]?.label||t.type,fpt2:f.type,tpt2:t.type,note:ni>=0?r[ni]:'',createdAt:new Date().toISOString()});
 }
 return pending;
}

function irAssertPresentation(p){
 if(p.rackclickDemoLanguage!==undefined&&!['en','de','es'].includes(p.rackclickDemoLanguage))throw Error('Demo language');
 if(p.rackclickClientMeta!==undefined){if(!Array.isArray(p.rackclickClientMeta))throw Error('Client metadata');const names=new Set;for(const m of p.rackclickClientMeta){if(!m||typeof m.client!=='string'||!m.client.trim()||m.client.length>100||names.has(m.client))throw Error('Client');names.add(m.client);if(m.technician!==undefined&&typeof m.technician!=='string')throw Error('Technician');if(m.logo!==undefined&&(typeof m.logo!=='string'||!/^data:image\/(png|jpe?g|gif|webp|svg\+xml);base64,/.test(m.logo)))throw Error('Logo')}}
 const loc=l=>{if(!l||typeof l!=='object'||Array.isArray(l))throw Error('Location');for(const k of ['client','site','building','room'])if(typeof l[k]!=='string'||l[k].length>100)throw Error('Location');if(!l.client.trim())throw Error('Client')};
 if(p.rackclickSystemhaus!==undefined&&(typeof p.rackclickSystemhaus!=='string'||p.rackclickSystemhaus.length>80))throw Error('Systemhaus');
 if(p.rackclickLocations!==undefined){if(!Array.isArray(p.rackclickLocations))throw Error('Locations');p.rackclickLocations.forEach(loc)}
 if(Array.isArray(p.racks))for(const r of p.racks){if(r?.rackclickLocation!==undefined)loc(r.rackclickLocation);if(Array.isArray(r?.devs))for(const d of r.devs)if(Array.isArray(d?.ports))for(const port of d.ports){if(port?.rackclickPowerRole!==undefined&&(port.type!=='power'||!['inlet','outlet'].includes(port.rackclickPowerRole)))throw Error('Power role');if(port?.rackclickFace!==undefined&&!['front','rear'].includes(port.rackclickFace))throw Error('Face')}}
 return p;
}

const CW={"en":{"clients":"Clients","infrastructure":"Infrastructure","openClient":"Open client","allClients":"All clients","backupAll":"Export full backup","loadAll":"Load full backup","demo10":"10 demo clients","demoConfirm":"Replace the complete infrastructure with 10 synthetic clients? Export a full backup first. You can undo.","replaceClient":"Replace this client’s inventory? Other clients remain unchanged.","replaceAll":"Replace the complete infrastructure? Export a full backup first.","boundary":"Connections between clients exist. Export the full backup to preserve them; single-client export/replacement is blocked.","saveClient":"Save client JSON","clientOnly":"Active client only","manual":"User manual","print":"Print / PDF","back":"Back","classic":"Classic report (fallback)","modern":"New report","report":"Client report","technician":"Technician","rack":"Rack","racks":"Racks","devices":"Devices","connections":"Connections","ports":"Ports","note":"Cable / note","from":"From","to":"To","synthetic":"Synthetic infrastructure","generic":"Generic illustration · documented topology, no telemetry","empty":"No racks assigned yet. Add a rack inside this client.","unassigned":"Unassigned inventory","client":"Client","site":"Site","building":"Building","room":"Server room","mainRack":"Main distribution","floorRack":"Floor distribution","basement":"Basement","ground":"Ground floor","office":"Office","copper":"Copper patch cable","fiber":"Fiber uplink · illustrative","readonly":"No sign-in or permissions in this offline file.","demoUpdate":"Translate generated demo text","demoUpdateConfirm":"Translate only unchanged generated demo names and notes? Your edits stay unchanged.","standalone":"Standalone legacy project","restoreAll":"Restore full snapshot","saveSnapshot":"Snapshot of complete infrastructure","renameClient":"Rename client","clientExists":"Client name already exists.","snapshotAll":"Snapshots cover all clients. Restoring replaces the complete infrastructure.","scenario1":"Small office","scenario2":"Office building","scenario3":"Retail","scenario4":"Workshop","scenario5":"School","scenario6":"Hotel","scenario7":"Healthcare practice","scenario8":"Warehouse","scenario9":"Campus","scenario10":"Hosting laboratory","capacity":"The device does not fit in this rack. Check the available U.","wattsRange":"Documented watts must be between 0 and 90."},"de":{"clients":"Kunden","infrastructure":"Infrastruktur","openClient":"Kunden öffnen","allClients":"Alle Kunden","backupAll":"Gesamtsicherung exportieren","loadAll":"Gesamtsicherung laden","demo10":"10 Demokunden","demoConfirm":"Gesamte Infrastruktur durch 10 synthetische Kunden ersetzen? Zuerst Gesamtsicherung exportieren. Rückgängig ist möglich.","replaceClient":"Inventar dieses Kunden ersetzen? Andere Kunden bleiben unverändert.","replaceAll":"Gesamte Infrastruktur ersetzen? Zuerst Gesamtsicherung exportieren.","boundary":"Kundenübergreifende Verbindungen vorhanden. Gesamtsicherung exportieren; Einzelkundenexport/-ersatz ist gesperrt.","saveClient":"Kunden-JSON speichern","clientOnly":"Nur aktiver Kunde","manual":"Bedienungshandbuch","print":"Drucken / PDF","back":"Zurück","classic":"Klassischer Bericht (Rückfall)","modern":"Neuer Bericht","report":"Kundenbericht","technician":"Techniker","rack":"Rack","racks":"Racks","devices":"Geräte","connections":"Verbindungen","ports":"Ports","note":"Kabel / Notiz","from":"Von","to":"Nach","synthetic":"Synthetische Infrastruktur","generic":"Generische Darstellung · dokumentierte Topologie, keine Telemetrie","empty":"Noch keine Racks zugeordnet. Im Kunden ein Rack hinzufügen.","unassigned":"Nicht zugeordnetes Inventar","client":"Kunde","site":"Standort","building":"Gebäude","room":"Serverraum","mainRack":"Hauptverteiler","floorRack":"Etagenverteiler","basement":"Keller","ground":"Erdgeschoss","office":"Büro","copper":"Kupfer-Patchkabel","fiber":"Glasfaser-Uplink · schematisch","readonly":"Keine Anmeldung oder Berechtigungen in dieser Offline-Datei.","demoUpdate":"Demotexte übersetzen","demoUpdateConfirm":"Nur unveränderte generierte Demonamen und Notizen übersetzen? Eigene Änderungen bleiben erhalten.","standalone":"Eigenständiges Legacy-Projekt","restoreAll":"Gesamtsnapshot wiederherstellen","saveSnapshot":"Snapshot der gesamten Infrastruktur","renameClient":"Kunden umbenennen","clientExists":"Kundenname ist bereits vorhanden.","snapshotAll":"Snapshots enthalten alle Kunden. Wiederherstellen ersetzt die gesamte Infrastruktur.","scenario1":"Kleinbüro","scenario2":"Bürogebäude","scenario3":"Einzelhandel","scenario4":"Werkstatt","scenario5":"Schule","scenario6":"Hotel","scenario7":"Praxis","scenario8":"Lager","scenario9":"Campus","scenario10":"Hosting-Labor","capacity":"Das Gerät passt nicht in dieses Rack. Freie HE prüfen.","wattsRange":"Dokumentierte Watt müssen zwischen 0 und 90 liegen."},"es":{"clients":"Clientes","infrastructure":"Infraestructura","openClient":"Abrir cliente","allClients":"Todos los clientes","backupAll":"Exportar respaldo completo","loadAll":"Cargar respaldo completo","demo10":"10 clientes de ejemplo","demoConfirm":"¿Sustituir toda la infraestructura por 10 clientes sintéticos? Exporta antes un respaldo completo. Puedes deshacer.","replaceClient":"¿Sustituir el inventario de este cliente? Los demás clientes se conservan.","replaceAll":"¿Sustituir toda la infraestructura? Exporta antes un respaldo completo.","boundary":"Hay conexiones entre clientes. Exporta el respaldo completo para conservarlas; se bloquea exportar o sustituir ese cliente por separado.","saveClient":"Guardar JSON del cliente","clientOnly":"Solo el cliente activo","manual":"Manual de uso","print":"Imprimir / PDF","back":"Volver","classic":"Informe clásico (respaldo)","modern":"Informe nuevo","report":"Informe del cliente","technician":"Técnico","rack":"Rack","racks":"Racks","devices":"Equipos","connections":"Conexiones","ports":"Puertos","note":"Cable / nota","from":"Origen","to":"Destino","synthetic":"Infraestructura sintética","generic":"Ilustración genérica · topología documentada, sin telemetría","empty":"Todavía no hay racks asignados. Añade un rack dentro de este cliente.","unassigned":"Inventario sin asignar","client":"Cliente","site":"Sede","building":"Edificio","room":"Sala técnica","mainRack":"Distribuidor principal","floorRack":"Distribuidor de planta","basement":"Sótano","ground":"Planta baja","office":"Oficina","copper":"Latiguillo de cobre","fiber":"Enlace de fibra · ilustrativo","readonly":"Este archivo offline no tiene inicio de sesión ni permisos.","demoUpdate":"Traducir textos generados del demo","demoUpdateConfirm":"¿Traducir solo nombres y notas generados que no hayas editado? Tus cambios se conservan.","standalone":"Proyecto legacy independiente","restoreAll":"Restaurar snapshot completo","saveSnapshot":"Snapshot de toda la infraestructura","renameClient":"Renombrar cliente","clientExists":"Ese nombre de cliente ya existe.","snapshotAll":"Los snapshots incluyen todos los clientes. Restaurar sustituye toda la infraestructura.","scenario1":"Oficina pequeña","scenario2":"Edificio de oficinas","scenario3":"Comercio","scenario4":"Taller","scenario5":"Escuela","scenario6":"Hotel","scenario7":"Consulta","scenario8":"Almacén","scenario9":"Campus","scenario10":"Laboratorio de hosting","capacity":"El equipo no cabe en este rack. Comprueba las U disponibles.","wattsRange":"Los watts documentados deben estar entre 0 y 90."}};
const IR_DEMO_CLIENTS=["Lindenwerk Architektur", "Nordhafen Logistik", "Sonnenfeld Medizin", "Bergstrom Fertigung", "Elbwinkel Handel", "Falkenhof Bildung", "Westbogen Hotel", "Kieselpark Medien", "Morgenwald Verwaltung", "Sternbruck Campus"];
/* Client isolation is a scope inside one offline portfolio, not an authorization boundary. */
function irClientOf(r){return r.rackclickLocation?.client||null}
function irClientList(p){return [...new Set(irLocations(p).map(l=>l.client))]}
function irClientProject(p,client){
 if(client===null&&irClientList(p).length===0)return p;
 const racks=p.racks.filter(r=>irClientOf(r)===client),ids=new Set(racks.map(r=>r.id)),meta=(p.rackclickClientMeta||[]).find(m=>m.client===client)||{};
 return {...p,name:client||p.name,technician:meta.technician||'',logo:meta.logo,changeLog:(p.changeLog||[]).filter(e=>e.client===client),racks,crossConns:(p.crossConns||[]).filter(c=>ids.has(c.rackFrom)&&ids.has(c.rackTo)),rackclickLocations:irLocations(p).filter(l=>l.client===client),rackclickClientMeta:client?[meta].filter(m=>m.client):[]};
}
function irBoundary(p,client){const ids=new Set(p.racks.filter(r=>irClientOf(r)===client).map(r=>r.id));return (p.crossConns||[]).filter(c=>ids.has(c.rackFrom)!==ids.has(c.rackTo))}
function irLocateNew(p,client,racks){const location=irLocations(p).find(l=>l.client===client)||{client,site:'',building:'',room:''};return racks.map(r=>{const {rackclickLocation,...rest}=r;return client?{...rest,rackclickLocation:{...(rackclickLocation||location),client}}:rest})}
function irReplaceClient(p,client,incoming){
 irAssertTopology(incoming);if(irBoundary(p,client).length)throw Error('Inter-client connections');
 const ids=new Set(p.racks.filter(r=>irClientOf(r)===client).map(r=>r.id));
 const base={...p,racks:p.racks.filter(r=>!ids.has(r.id)),crossConns:(p.crossConns||[]).filter(c=>!ids.has(c.rackFrom)&&!ids.has(c.rackTo))};
 const idsIn=p=>p.racks.flatMap(r=>[r.id,...r.devs.flatMap(d=>[d.id,...d.ports.map(p=>p.id)]),...r.conns.map(c=>c.id)]).concat((p.crossConns||[]).map(c=>c.id));const occupied=new Set(idsIn(base));
 const fresh=idsIn(incoming).some(id=>occupied.has(id))?irAppendProject({version:'0.8',name:incoming.name,racks:[],crossConns:[]},incoming):incoming;
 const result={...base,...(client?{rackclickLocations:[...irLocations(p),...irLocations(incoming).map(l=>({...l,client}))]}:{}),racks:[...base.racks,...irLocateNew(p,client,fresh.racks)],crossConns:[...base.crossConns,...fresh.crossConns]};
 if(client)result.rackclickClientMeta=[...(p.rackclickClientMeta||[]).filter(m=>m.client!==client),{client,technician:incoming.technician||'',...(incoming.logo?{logo:incoming.logo}:{})}];
 else{result.technician=incoming.technician||'';result.logo=incoming.logo;if(!irClientList(p).length)result.name=incoming.name}
 return irAssertTopology(result);
}
function irAppendClient(p,client,incoming){const added=irAppendProject(p,{...incoming,rackclickLocations:client?irLocations(incoming).map(l=>({...l,client})):undefined,racks:irLocateNew(p,client,incoming.racks)});return irAssertTopology(added)}
function irRenameClient(p,oldName,newName){if(oldName===newName)return p;if(irClientList(p).includes(newName))throw Error('Duplicate client');return {...p,rackclickLocations:irLocations(p).map(l=>l.client===oldName?{...l,client:newName}:l),racks:p.racks.map(r=>irClientOf(r)===oldName?{...r,rackclickLocation:{...r.rackclickLocation,client:newName}}:r),rackclickClientMeta:(p.rackclickClientMeta||[]).map(m=>m.client===oldName?{...m,client:newName}:m),changeLog:(p.changeLog||[]).map(e=>e.client===oldName?{...e,client:newName}:e)} }
function irDownloadData(data,name){const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name.replace(/[\\/:*?"<>|]/g,'-')+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000)}
function IRClientNavigation({project,client,onClient,onHome,onRack,view,rack,systemhaus,onRename,onManage,onSettings,lang}){
 const w=CW[lang],iw=IR_WORDS[lang],[open,setOpen]=React.useState(false),clients=irClientList(project),scope=irClientProject(project,client);
 return <><button className="ir-mobile-nav" onClick={()=>setOpen(!open)} aria-label={w.infrastructure}><IRIcon name="menu"/>RackClick</button><aside className={'ir-nav '+(open?'open':'')}><a href="#" className="ir-brand" onClick={e=>{e.preventDefault();onHome();setOpen(false)}}><IRIcon name="rack"/><b>Rack<span>Click</span></b></a><div className="ir-eyebrow">SYSTEMHAUS</div><button className="ir-org" aria-label={iw.systemhaus} onClick={onRename}><strong>{systemhaus}</strong><IRIcon name="edit"/></button><div className="ir-eyebrow">{w.infrastructure}</div><button className="ir-manage" onClick={onManage}><IRIcon name="settings"/>{iw.manage}</button><button className="ir-all-clients" onClick={()=>{onHome();setOpen(false)}}>{w.allClients}</button><div className="ir-client-tree">{clients.map(name=><div key={name}><button className={'ir-client-link '+(client===name&&view!=='clients'?'active':'')} onClick={()=>{onClient(name);setOpen(false)}}><IRIcon name="home"/>{name}</button>{client===name&&view!=='clients'&&<div className="ir-racks">{scope.racks.map(r=><button key={r.id} className={rack?.id===r.id&&view==='rack'?'active':''} onClick={()=>{onRack(r.id);setOpen(false)}}><IRIcon name="rack"/><span>{r.name}<small>{[r.rackclickLocation?.site,r.rackclickLocation?.building,r.rackclickLocation?.room].filter(Boolean).join(' / ')}</small></span></button>)}</div>}</div>)}{project.racks.some(r=>!irClientOf(r))&&<div><button className="ir-client-link" onClick={()=>{onClient(null);setOpen(false)}}>{clients.length?w.unassigned:project.name}</button>{client===null&&view!=='clients'&&<div className="ir-racks">{scope.racks.map(r=><button key={r.id} onClick={()=>{onRack(r.id);setOpen(false)}}><IRIcon name="rack"/>{r.name}</button>)}</div>}</div>}</div><button className="ir-settings" onClick={onSettings}><IRIcon name="settings"/>{iw.settings}</button><div className="ir-nav-foot">OFFLINE · v{RC_VERSION}</div></aside></>;
}
function IRClientsHome({project,onClient,onDemo,onExport,onLoad,onManage,lang,onLanguage,status}){const w=CW[lang],clients=irClientList(project);return <main className="ir-clients-home"><header><div><div className="ir-eyebrow">SYSTEMHAUS / {w.infrastructure}</div><h1>{w.clients}</h1><p>{w.readonly}</p></div><select aria-label="Language" value={lang} onChange={e=>onLanguage(e.target.value)}><option value="en">English</option><option value="de">Deutsch</option><option value="es">Español</option></select></header><div className="ir-home-actions"><button onClick={onManage}>{IR_WORDS[lang].manage}</button><button onClick={onExport}>{w.backupAll}</button><button onClick={()=>irReportCSV(project,lang,true)}>{(RC8_REPORT_WORDS[lang]||RC8_REPORT_WORDS.en).csvAll}</button><button onClick={onLoad}>{w.loadAll}</button><button onClick={onDemo}>{w.demo10}</button><span role="status">{status.ok===false?'✗':status.ok===true?'✓':'—'} {IR_WORDS[lang].saved}</span></div><div className="ir-client-cards">{[...clients,...(project.racks.some(r=>!irClientOf(r))?[null]:[])].map(name=>{const p=irClientProject(project,name);return <button className="ir-client-card" key={name||'unassigned'} onClick={()=>onClient(name)}><div className="ir-client-card-icon"><IRIcon name="home" size={26}/></div><h2>{name||(clients.length?w.unassigned:project.name)}</h2><p>{p.racks.length} {w.racks} · {p.racks.reduce((n,r)=>n+r.devs.length,0)} {w.devices}</p><span>{w.openClient} →</span></button>})}</div></main>}
function IRReportRack({rack,lang}){const w=CW[lang];let y=0;const blocks=rack.devs.map(d=>{const l=irLayout(d,'front'),top=y;y+=l.height+27;return {d,l,top}}),points=new Map;for(const {l,top}of blocks)for(const p of l.ports)points.set(p.id,{x:p.px+p.pw/2,y:top+26+p.py+p.pw/2});return <svg className="ir-print-rack" viewBox={`0 0 960 ${Math.max(90,y)}`} role="img" aria-label={rack.name}><title>{rack.name}</title>{blocks.map(({d,l,top})=><g key={d.id} transform={`translate(0 ${top})`}><text x="12" y="18" className="report-device">{d.name} · {d.u} U</text><rect x="1" y="24" width="958" height={l.height} rx="4" fill="#eef2f5" stroke="#56687a"/>{l.family==='storage'&&Array.from({length:8},(_,i)=><rect key={i} x={38+i*108} y="36" width="97" height="39" rx="3" fill="#d2dae2" stroke="#56687a"/>)}{l.ports.map(p=><g key={p.id} transform="translate(0 26)"><text x={p.px} y={p.py-3}>{p.gn}</text><g className="ir-report-port" transform={`translate(${p.px} ${p.py}) scale(${p.pw/40})`}><IRPortShape type={p.type}/></g></g>)}{!l.ports.length&&<text x="30" y={l.height/2+28}>{IR_WORDS[lang].noPorts}</text>}</g>)}{rack.conns.map(c=>{const a=points.get(c.fp),b=points.get(c.tp);if(!a||!b)return null;return <path key={c.id} d={`M${a.x} ${a.y} C${a.x+30} ${a.y+40} ${b.x+30} ${b.y-40} ${b.x} ${b.y}`} stroke={c.color||'#08794e'} strokeWidth="2" fill="none"/>})}</svg>}
const IR_EXPORT_HEADERS={rack:'Rack',from:'From Device',fromPort:'From Port#',fromType:'From Type',to:'To Device',toPort:'To Port#',toType:'To Type',note:'Cable/Note',cross:'Cross-Rack',patch:'Patch Status',created:'Created'};
const IR_EXPORT_PATCH={
 en:{none:'—',planned:'Planned',progress:'In Progress',done:'Done',tested:'Tested'},
 de:{none:'—',planned:'Geplant',progress:'In Bearbeitung',done:'Abgeschlossen',tested:'Getestet'},
 es:{none:'—',planned:'Planificado',progress:'En curso',done:'Terminado',tested:'Probado'}
};
function irReportCSV(project,lang,includeClient=false){
 // Column names remain stable so a downloaded CSV can be imported again.
 const w=IR_EXPORT_HEADERS,patch=IR_EXPORT_PATCH[lang]||IR_EXPORT_PATCH.en;
 const racks=project.racks||[],byId=new Map(racks.map(r=>[r.id,r.name]));
 const rows=[[w.rack,w.from,w.fromPort,w.fromType,w.to,w.toPort,w.toType,w.note,w.cross,w.patch,w.created]];
 const rw=RC8_REPORT_WORDS[lang]||RC8_REPORT_WORDS.en;const clientByRack=new Map(racks.map(r=>[r.id,irClientOf(r)||rw.unassigned]));if(includeClient)rows[0].unshift(rw.client);
 const add=(c,rack,cross,rackId)=>rows.push([...(includeClient?[clientByRack.get(rackId)||rw.unassigned]:[]),rack,c.fn,c.fpn,c.fpt,c.tn,c.tpn,c.tpt,c.note||'',cross,patch[c.patchStatus]||patch.none,c.createdAt||'']);
 for(const rack of racks)for(const c of rack.conns||[])add(c,rack.name,'',rack.id);
 for(const c of project.crossConns||[]){
  if(!byId.has(c.rackFrom)&&!byId.has(c.rackTo))continue;
  const from=byId.get(c.rackFrom)||c.rackFrom,to=byId.get(c.rackTo)||c.rackTo;
  add(c,from,from+' → '+to,c.rackFrom);
 }
 // Prefix spreadsheet formula metacharacters without altering application data.
 const cell=v=>{const value=String(v??'');return '"'+(/^[\s]*[=+@-]/.test(value)?"'"+value:value).replace(/"/g,'""')+'"'};
 const csv='\uFEFF'+rows.map(row=>row.map(cell).join(',')).join('\r\n');
 const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
 const link=document.createElement('a');link.href=url;
 link.download='rackclick-'+String(project.name||'report').replace(/[^a-z0-9_-]+/gi,'-')+'-connections.csv';
 document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);
}
function irDecorativeQR(text,lang){
 const raw=generateQR(text);
 return new Promise((resolve,reject)=>{
  const image=new Image();image.onload=()=>{
   const canvas=document.createElement('canvas');canvas.width=Math.max(320,image.width+32);canvas.height=image.height+66;
   const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);
   ctx.drawImage(image,(canvas.width-image.width)/2,12);
   ctx.fillStyle='#111';ctx.font='bold 14px sans-serif';ctx.textAlign='center';
   ctx.fillText(lang==='de'?'DEKORATIV · NICHT SCANNBAR':lang==='es'?'DECORATIVO · NO ESCANEABLE':'DECORATIVE · NOT SCANNABLE',canvas.width/2,canvas.height-20);
   resolve(canvas.toDataURL('image/png'));
  };image.onerror=reject;image.src=raw;
 });
}
const RC8_REPORT_WORDS={"en":{"csvAll":"All clients connections CSV","client":"Client","unassigned":"Unassigned","labels":"All rack labels","csv":"Client connections CSV","logo":"Client logo","labelsHint":"Labels for this client only. Print or save as PDF. No scannable QR code is included.","rackId":"Rack ID","empty":"This client has no racks."},"de":{"csvAll":"Verbindungen aller Kunden CSV","client":"Kunde","unassigned":"Nicht zugeordnet","labels":"Alle Rack-Etiketten","csv":"Kundenverbindungen CSV","logo":"Kundenlogo","labelsHint":"Etiketten nur für diesen Kunden. Drucken oder als PDF speichern. Kein scannbarer QR-Code enthalten.","rackId":"Rack-ID","empty":"Dieser Kunde hat keine Racks."},"es":{"csvAll":"Conexiones de todos los clientes CSV","client":"Cliente","unassigned":"Sin asignar","labels":"Etiquetas de todos los racks","csv":"Conexiones del cliente CSV","logo":"Logo del cliente","labelsHint":"Etiquetas solo de este cliente. Imprime o guarda como PDF. No incluye códigos QR escaneables.","rackId":"ID del rack","empty":"Este cliente no tiene racks."}};
// React text children and attributes escape user data; no HTML string insertion.
// Only embedded raster logos are displayed: no remote requests or active SVG.
function irSafeReportLogo(value){return typeof value==='string'&&/^data:image\/(?:png|jpeg|jpg|gif|webp|bmp);base64,[a-z0-9+/=\s]+$/i.test(value)?value:null}
function IRClientLabels({project,lang,onBack}){const w=CW[lang],rw=RC8_REPORT_WORDS[lang]||RC8_REPORT_WORDS.en;return <main className="ir-client-report ir-client-labels"><nav className="ir-no-print"><button onClick={onBack}>{w.back}</button><button onClick={()=>window.print()}>{w.print}</button></nav><header><b>RackClick <small>v{RC_VERSION}</small></b><h1>{rw.labels} · {project.name}</h1><p className="ir-no-print">{rw.labelsHint}</p></header>{project.racks.length===0&&<p>{rw.empty}</p>}<div className="ir-label-grid">{project.racks.map(r=><section key={r.id} className="ir-batch-label"><div className="ir-label-title">RACK: {r.name}</div><div className="ir-label-location">{r.location||[r.rackclickLocation?.site,r.rackclickLocation?.building,r.rackclickLocation?.room].filter(Boolean).join(' / ')||'—'}</div><div className="ir-label-info"><span>{(r.devs||[]).length} {w.devices}</span><span>{r.size}U</span><span>{(r.conns||[]).length} {w.connections}</span></div><div className="ir-label-id">{String(r.id).toUpperCase()}</div><div className="ir-label-footer">RackClick v{RC_VERSION} | {project.name} | {project.technician||'—'} | {new Date().toLocaleDateString('de-DE')}</div></section>)}</div></main>}
function IRClientReport({project,lang,onBack,onClassic,showClientBrand=true}){const w=CW[lang];return <main className="ir-client-report"><nav className="ir-no-print"><button onClick={onBack}>{w.back}</button><button onClick={()=>window.print()}>{w.print}</button><button onClick={()=>irReportCSV(project,lang)} aria-label={(RC8_REPORT_WORDS[lang]||RC8_REPORT_WORDS.en).csv}>CSV</button><button onClick={onClassic}>{w.classic}</button></nav><header>{showClientBrand&&irSafeReportLogo(project.logo)&&<img className="ir-report-client-logo" src={irSafeReportLogo(project.logo)} alt={(RC8_REPORT_WORDS[lang]||RC8_REPORT_WORDS.en).logo}/>}<b>RackClick <small>v{RC_VERSION}</small></b><h1>{w.report} · {project.name}</h1><p>{w.technician}: {project.technician||'—'} · {project.racks.length} {w.racks}</p><p>{w.generic}</p></header>{project.racks.map(r=><section className="ir-report-section" key={r.id}><h2>{r.name} · {r.size} U</h2><p>{[r.rackclickLocation?.site,r.rackclickLocation?.building,r.rackclickLocation?.room,r.location].filter(Boolean).join(' / ')}</p><IRReportRack rack={r} lang={lang}/><h3>{w.connections}</h3><table><thead><tr><th>{w.from}</th><th>{w.to}</th><th>{w.note}</th></tr></thead><tbody>{[...r.conns,...project.crossConns.filter(c=>c.rackFrom===r.id||c.rackTo===r.id)].map(c=><tr key={c.id}><td>{c.fn} #{c.fpn}</td><td>{c.tn} #{c.tpn}</td><td>{c.note||'—'}</td></tr>)}</tbody></table></section>)}</main>}
function irDemo(lang='en'){
 const w=CW[lang],counts=[1,2,3,4,5,6,8,10,12,17],p={version:'0.8',name:w.synthetic,technician:'',racks:[],crossConns:[],rackclickLocations:[],rackclickDemoLanguage:lang,rackclickSystemhaus:'RackClick · IT-Systemhaus',changeLog:[]};
 function device(id,name,preset,u,groups){return {id,name,preset,u,icon:'▦',color:'#457b9d',ports:mkP(groups,id),notes:{text:w.generic}}}
 function link(a,pa,b,pb,id,note){return{id,fd:a.id,td:b.id,fp:pa.id,tp:pb.id,fn:a.name,tn:b.name,fpn:pa.gn,tpn:pb.gn,fpt:PT[pa.type]?.label||pa.type,tpt:PT[pb.type]?.label||pb.type,fpt2:pa.type,tpt2:pb.type,note,color:'#34d399'}}
 counts.forEach((count,ci)=>{const customer=IR_DEMO_CLIENTS[ci],tag='demo-c'+(ci+1),racks=[];
 for(let i=0;i<count;i++){const id=tag+'-r'+(i+1),place={client:customer,site:w.site+' '+(1+Math.floor(i/6)),building:w.building+' '+String.fromCharCode(65+Math.floor(i/4)),room:i===0?w.basement:w.room+' '+i};p.rackclickLocations.push(place);
 const panel=device(id+'-pp','PP-'+(i===0?'MAIN':'FLOOR')+'-'+(i+1),'Patch Panel 24P',1,[{t:'rj45',n:24}]);
 const sw=device(id+'-sw','SW-'+(i===0?'CORE':'ACCESS')+'-'+(i+1),i===0?'Switch 48P PoE':'Switch 24P PoE',1,[{t:'rj45_poe',n:i===0?48:24},{t:'sfp',n:4},{t:'mgmt',n:1}]);
 const rack={id,name:(i===0?w.mainRack:w.floorRack+' '+i),location:w['scenario'+(ci+1)]+' · '+place.room,size:i===0?24:12,devs:[panel,sw],conns:[],rackclickLocation:place};
 for(let j=0;j<(ci%3)+4;j++){panel.ports[j].label=w.office+' '+(101+j);rack.conns.push(link(panel,panel.ports[j],sw,sw.ports[j],id+'-patch'+j,w.copper+' · Cat 6A · '+(j+2)+' m'));if(j<2){sw.ports[j].watts=ci%2?7:15;sw.ports[j].poe=true}}
 if(i===0){const server=device(id+'-srv','SRV-APP-01','Server 2U',2,[{t:'rj45',n:4},{t:'sfp',n:2},{t:'mgmt',n:1}]),nas=device(id+'-nas','NAS-BACKUP','NAS 4U',4,[{t:'rj45',n:4},{t:'sfp',n:2},{t:'mgmt',n:1}]),ups=device(id+'-ups','UPS-2200','UPS 2U',2,[{t:'power',n:4},{t:'mgmt',n:1},{t:'usb_a',n:1}]),fw=device(id+'-fw','FW-EDGE','Firewall',1,[{t:'rj45',n:8},{t:'sfp',n:2}]);rack.devs.push(server,nas,ups,fw);
 for(const [j,d] of [server,nas].entries())rack.conns.push(link(sw,sw.ports.filter(p=>p.type==='sfp')[j],d,d.ports.find(p=>p.type==='sfp'),id+'-service'+j,w.fiber+' · 3 m'));
 rack.conns.push(link(sw,sw.ports[12],fw,fw.ports[0],id+'-edge',w.copper+' · LAN'));
 if(count>1){const agg=device(id+'-agg','SW-AGG-01','Switch SFP aggregation',2,[{t:'sfp',n:24},{t:'mgmt',n:1}]);rack.devs.push(agg);rack.conns.push(link(sw,sw.ports.filter(p=>p.type==='sfp')[2],agg,agg.ports[0],id+'-aggregation',w.fiber+' · 1 m'))}
 }
 racks.push(rack);p.racks.push(rack)}
 if(count>1){const agg=racks[0].devs.find(d=>d.name==='SW-AGG-01');for(let i=1;i<count;i++){const sw=racks[i].devs[1];p.crossConns.push({...link(agg,agg.ports[i],sw,sw.ports.find(p=>p.type==='sfp'),tag+'-uplink'+i,w.fiber+' · OS2 · '+(30+i*10)+' m'),rackFrom:racks[0].id,rackTo:racks[i].id})}}
 });irPowerDemo(p,lang);return irAssertTopology(p);
}
function irTranslateDemo(p,lang){if(!p.rackclickDemoLanguage||p.rackclickDemoLanguage===lang)return p;const old=irDemo(p.rackclickDemoLanguage),next=irDemo(lang);
 function walk(value,a,b){if(typeof value==='string'&&typeof a==='string'&&value===a&&typeof b==='string')return b;if(Array.isArray(value)){return value.map((v,i)=>{const j=v&&typeof v==='object'&&Array.isArray(a)?(v.id?a.findIndex(o=>o.id===v.id):v.client&&v.site!==undefined?a.findIndex(o=>irLocationKey(o)===irLocationKey(v)):i):i;return walk(v,a?.[j],b?.[j])})}if(value&&typeof value==='object'){return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,walk(v,a?.[k],b?.[k])]))}return value}
 const translated=walk(p,old,next);const clientMap=new Map(p.racks.map(r=>[irClientOf(r),irClientOf(translated.racks.find(x=>x.id===r.id)||r)]));if(p.rackclickClientMeta)translated.rackclickClientMeta=p.rackclickClientMeta.map(m=>({...m,client:clientMap.get(m.client)||m.client}));translated.changeLog=(translated.changeLog||[]).map(e=>({...e,...(e.client?{client:clientMap.get(e.client)||e.client}:{})}));translated.rackclickDemoLanguage=lang;return translated;
}

/* Optional power roles are descriptive. No electrical certification or telemetry. */
function irPowerPorts(ports,preset,lang){let n=0;const source=/pdu|ups/i.test(preset),w=IR_WORDS[lang];return ports.map(p=>p.type!=='power'?p:{...p,rackclickFace:'rear',rackclickPowerRole:source?(n++===0?'inlet':'outlet'):'inlet',label:source?(n===1?w.inlet:w.outlet+' '+(n-1)):'PSU '+(++n)})}
function irPowerPairAllowed(a,b){if(!a||!b)return false;if((a.type==='power')!==(b.type==='power'))return false;if(a.type!=='power')return true;return !(['inlet','outlet'].includes(a.rackclickPowerRole)&&a.rackclickPowerRole===b.rackclickPowerRole)}
function IRPowerSummary({project,rack,connections,lang,onSelect}){const w=IR_WORDS[lang],ports=new Map(rack.devs.flatMap(d=>d.ports.filter(p=>p.type==='power').map(p=>[p.id,{d,p}]))),links=connections.filter(c=>ports.has(c.fp)||ports.has(c.tp));if(!ports.size)return <section className="ir-power-summary"><h3>{w.power}</h3><p>{w.noPorts}</p></section>;return <section className="ir-power-summary"><h3>{w.power} · {links.length}</h3><p>{w.powerHint}</p><div>{links.map(c=><button key={c.id} title={irConnectionTooltip(c,project,rack,lang)} onClick={()=>onSelect(c.id)}><i style={{background:c.color||'#ef4444'}}/><span>{c.fn} · {ports.get(c.fp)?.p.label||'#'+c.fpn} → {c.tn} · {ports.get(c.tp)?.p.label||'#'+c.tpn}<small>{c.note||'—'}</small></span></button>)}</div><details><summary>{w.ports} · {ports.size}</summary>{[...ports].map(([id,{d,p}])=><p key={id}>{d.name} · #{p.gn} · {p.label||'—'} · {w[p.rackclickPowerRole]||w.unspecified}</p>)}</details></section>}
function irPowerDemo(p,lang){const w=IR_WORDS[lang];for(const rack of p.racks){
 for(const d of rack.devs){if(/patch/i.test(d.preset))continue;let count=d.ports.filter(p=>p.type==='power').length;const target=/ups/i.test(d.preset)?5:/server|nas/i.test(d.preset)?2:1;if(count<target)d.ports=[...d.ports,...mkP([{t:'power',n:target-count}],d.id+'-psu').map((p,i)=>({...p,gn:count+i+1}))];d.ports=irPowerPorts(d.ports,d.preset,lang)}
 let ups=rack.devs.find(d=>/ups/i.test(d.preset));if(!ups){const id=rack.id+'-ups';ups={id,name:'UPS-'+rack.id.split('-').at(-1),u:2,preset:'UPS 2U',icon:'▦',color:'#eab308',ports:irPowerPorts(mkP([{t:'power',n:5}],id),'UPS 2U',lang)};rack.devs.push(ups)}
 const id=rack.id+'-pdu',pdu={id,name:'PDU-'+rack.id.split('-').at(-1),u:1,preset:'PDU',icon:'▦',color:'#6b7280',ports:irPowerPorts(mkP([{t:'power',n:9}],id),'PDU',lang)};rack.devs.push(pdu);
 const make=(a,pa,b,pb,n)=>({id:rack.id+'-power-'+n,fd:a.id,fp:pa.id,td:b.id,tp:pb.id,fn:a.name,tn:b.name,fpn:pa.gn,tpn:pb.gn,fpt:'Power',tpt:'Power',fpt2:'power',tpt2:'power',note:w.power+' · '+pa.label+' → '+pb.label,color:'#f59e0b'});
 rack.conns.push(make(ups,ups.ports.find(x=>x.rackclickPowerRole==='outlet'),pdu,pdu.ports[0],0));let outlet=1;
 for(const d of rack.devs.filter(d=>d!==ups&&d!==pdu))for(const port of d.ports.filter(p=>p.type==='power')){if(outlet>=pdu.ports.length)throw Error('Demo PDU capacity');rack.conns.push(make(pdu,pdu.ports[outlet],d,port,outlet));outlet++}
 }}

// Templates describe hardware, not occupied endpoints or live operational state.
function irTemplateLayout(dev){return dev.ports.map(p=>Object.fromEntries(['type','gn','poe','label','portColor','rackclickFace','rackclickPowerRole'].filter(k=>p[k]!==undefined).map(k=>[k,p[k]])))}
function irTemplatePorts(template,id,lang){
 if(!Array.isArray(template.rackclickPortLayout))return irPowerPorts(mkP(template.ports,id),template.label,lang);
 return template.rackclickPortLayout.map((p,i)=>({...Object.fromEntries(['type','gn','poe','label','portColor','rackclickFace','rackclickPowerRole'].filter(k=>p[k]!==undefined).map(k=>[k,p[k]])),id:id+'-p'+(i+1)}));
}

/* ═══════ CONSTANTS ═══════ */
/* ─── THEMES ─── */
const THEMES = {
  dark:     { id: "dark",     label: "🌑 Oscuro",      bg: "#08080d", bg2: "#0d0d14", bg3: "#12121a", bdr: "#1a1a2e", bdr2: "#2a2c3e", txt: "#e0e0e0", dim: "#888", mut: "#555", vdim: "#333", inp: "#08080d", acc: "#10b981", portBg: "#0c0c14", portBd: "#1e1e2e", portTx: "#2a2a3a", rackBg: "#1a1c2e", rackHd: "#8a8ca0" },
  semidark: { id: "semidark", label: "🌘 Semi-Oscuro",  bg: "#181d2a", bg2: "#1e2436", bg3: "#252d3e", bdr: "#2d3650", bdr2: "#3a4565", txt: "#e4e6ef", dim: "#9aa0b8", mut: "#667085", vdim: "#4a5268", inp: "#181d2a", acc: "#10b981", portBg: "#1a2030", portBd: "#2d3650", portTx: "#4a5268", rackBg: "#232b3e", rackHd: "#9aa0b8" },
  silver:   { id: "silver",   label: "🌗 Plata",        bg: "#e8eaef", bg2: "#dfe1e8", bg3: "#d0d3dc", bdr: "#b8bcc8", bdr2: "#a0a5b2", txt: "#1a1e2e", dim: "#3d4356", mut: "#4a5164", vdim: "#6b7288", inp: "#f0f1f5", acc: "#047857", portBg: "#d5d8e0", portBd: "#8a90a2", portTx: "#3d4356", rackBg: "#d0d3dc", rackHd: "#2e3248" },
  light:    { id: "light",    label: "☀️ Claro",        bg: "#f6f7fb", bg2: "#ffffff", bg3: "#eef0f5", bdr: "#d0d4e0", bdr2: "#b8bcc8", txt: "#1f2937", dim: "#404a5c", mut: "#4b5563", vdim: "#77809a", inp: "#ffffff", acc: "#047857", portBg: "#eef0f5", portBd: "#a8aec0", portTx: "#3f4756", rackBg: "#e0e3eb", rackHd: "#2e3248" },
};
const THEME_KEY = "rackclick_theme";
const LANG_KEY = "rackclick_lang";
const I18N = {
  en: {
    confirmReserved:"Reserved port — connect?", confirmRemovePorts:"Remove ports {ports} and {count} connections?", notiPortEditInvalid:"Invalid port configuration. Nothing changed.", notiBackupAmbiguous:"Backup order unknown. Export rescue data and choose a copy manually. Autosave paused until a project change.",
    notiSnapshotsFailed:"Could not save the snapshot change. Nothing was changed.", notiTemplatesFailed:"Could not save the template change. Nothing was changed.", notiFavoritesFailed:"Could not save favorites. Nothing was changed.", notiTemplateSaved:"📌 Template \"{name}\" saved", notiUndoLabel:"↩ Undo: {label}", notiFixed:"⚠️ Repaired: {detail}", notiUnknownFile:"Unknown format: {name}", notiImportedFile:"📥 Imported: {name}", notiFailedFile:"Import failed: {name}", notiMergedCounts:"🔀 Merged: {count} racks, {cross} cross-rack connections from \"{name}\"", notiExportedRack:"📤 Exported \"{name}\"", notiCsvCounts:"📥 CSV: {added} connections added, {skipped} skipped", notiRackAreaMissing:"Rack export area not found.", notiCanvasMissing:"html2canvas is not loaded.", notiPngSaved:"PNG exported ✅", notiPngFailed:"PNG export failed: {detail}", notiDuplicatedRack:"📋 Duplicated \"{name}\"; copied connections: {count}", notiAddedPreset:"Added {name}", notiPoeOn:"⚡ PoE ON", notiPoeOff:"PoE OFF", notiPortRange:"⚡ Ports {from}–{to} → {status}", notiPortColors:"🎨 Ports {from}–{to}: color set", notiPortColorsCleared:"🎨 Ports {from}–{to}: color cleared", notiBulkConnections:"⚡ {count} connections created", notiPickDestination:"🔗 Pick destination port in {name}", confirmDeleteRack:"Delete rack \"{name}\" and all its devices?", confirmDuplicateRack:"Duplicate \"{name}\" WITH {count} connections?\n\nOK = with connections\nCancel = devices only", confirmNewProject:"⚠️ Delete everything and start a new project?", confirmClearLog:"Clear all log entries?", confirmMoveDevice:"Move \"{name}\" to \"{rack}\"?\n\nLocal connections to convert: {local}.\nCross-rack connections to update: {cross}.\n\nContinue?", confirmDeleteDevice:"Delete \"{name}\"? Active connections: {count}.\n\nUse Ctrl+Z to undo.", confirmDeleteDevices:"Delete {count} devices? Affected connections: {connections}.\n\nUse Ctrl+Z to undo.",
     devices: "DEVICES", freeU: "FREE U", links: "LINKS", portUsage: "PORT USAGE", addDevice: "+ NEW DEVICE", save: "Save", load: "Load", merge: "Merge", import: "Import", report: "Report", demo: "Demo", newProj: "New", search: "Search...", settings: "Settings", theme: "THEME / PANEL", portColors: "PORT TYPE COLORS", groupColors: "CONNECTION COLORS BY DEVICE GROUP", groupHint: "When connecting these device types, auto-assign this cable color.", resetAll: "Reset all to defaults", language: "LANGUAGE", favorites: "FAVORITES", myTemplates: "MY TEMPLATES", customDevice: "Custom Device", front: "Front", rear: "Rear", rearView: "REAR VIEW", label: "Label", connected: "Connected!", disconnected: "Disconnected", deleted: "deleted", exported: "exported", merged: "Merged", addRack: "+ Add Rack", noDevices: "\u2190 Add devices from sidebar", connections: "CONNECTIONS", globalSearch: "\ud83d\udd0d Global search: devices, ports, labels, connections...", rackSearch: "\ud83d\udd0d Search...", labelDose: "LABEL / DOSE", status: "STATUS", cancel: "Cancel", saveBtn: "Save", connect: "Connect", portType: "PORT TYPE", srcDevice: "SOURCE DEVICE", tgtDevice: "TARGET DEVICE", select: "Select...", count: "COUNT", preview: "PREVIEW", noOtherRacks: "No other racks", allPorts: "All ports", ports: "Ports", moveToRack: "Move to rack", batchStatus: "Batch port status", saveTemplate: "Save as template", name: "NAME", sizeU: "SIZE (U)", icon: "ICON", serialNumber: "SERIAL NUMBER", ipAddress: "IP ADDRESS", model: "MODEL", firmware: "FIRMWARE", notes: "NOTES", portGroups: "PORT GROUPS", rackName: "RACK NAME", location: "LOCATION", deleteRack: "Delete this rack", startAt: "START AT", free: "free", max: "max", connCreated: "connections", uFree: "U free", hintLClick: "L-click: connect", hintRClick: "R-click: status/PoE/label", hintDblClick: "Dbl-click: label", hintCrossRack: "cross-rack", hintBulk: "bulk", hintUndo: "Ctrl+Z: undo", hintSave: "Ctrl+S: save", hintEsc: "Esc: cancel", hintDel: "Del: delete selected", notiSaved: "Saved!", notiRemoved: "Removed", notiUpdated: "Updated", notiLoaded: "Project loaded", notiNewProj: "New project created", notiRackDel: "Rack deleted", notiRackUpd: "Rack updated", notiExportPdf: "PDF report opened \u2014 use Print \u2192 Save as PDF", notiExportXls: "Excel exported (3 sheets: Devices, Connections, Summary)", notiCrossRack: "Cross-rack connected!", notiLogoSet: "Logo set", notiLogoRemoved: "Logo removed", notiLogCleared: "Log cleared", notiLabelRemoved: "Label removed", notiTemplateRemoved: "Template removed", notiInvalidJson: "Invalid JSON file", notiUnknownFmt: "Unknown format", notiCsvEmpty: "CSV is empty", notiCsvCols: "CSV needs 'From Device' and 'To Device' columns", notiFailedMerge: "Failed to merge project", notiOnlyV08: "Only v0.8 projects can be merged", notiFailedCsv: "Failed to parse CSV", notiDemo: "Demo: 2 racks + port labels + cable notes", notiV07Import: "v0.7 imported as rack", notiCustomDev: "Added custom device", notiDevAdded: "added to rack", poeBudget: "PoE BUDGET (W)", color: "COLOR", notesSection: "DEVICE NOTES", freeNotes: "Free notes...", connectToRack: "CONNECT TO RACK", moveToRackHeader: "MOVE TO RACK", prefix: "PREFIX", portLabels: "PORT LABELS", fromRack: "FROM RACK", toRack: "TO RACK", cable: "CABLE", cableNote: "CABLE / NOTE", projectReport: "Project Report", rackReport: "Report", notiRedo: "Redo", notiMoved: "Moved to", saveAsTemplate: "Save as Template", batchPortStatus: "Batch Port Status", qrCode: "QR Code", snapshot: "Snapshot", snapshots: "Snapshots", restoreSnapshot: "Restore", deleteSnapshot: "Delete", noSnapshots: "No snapshots yet", snapshotName: "Snapshot name", notiSnapshotSaved: "Snapshot saved!", notiSnapshotRestored: "Snapshot restored!", portColor: "PORT COLOR", batchPortColor: "Batch Port Color", clearColor: "Clear", notiColorSet: "Color applied!", notiColorCleared: "Color cleared", notiBootRepaired: "Project repaired at startup \u2014 original saved to quarantine", notiBootBackup: "Autosave invalid \u2014 recovered from backup", notiBootSafeMode: "Safe mode: no saved project could be loaded. Data secured in quarantine", quarantine: "QUARANTINE", quarantineInfo: "Data from a failed startup is stored here", quarantineDownload: "Download bundle", quarantineDownloadAutosave: "Download autosave only", quarantineCreatedAt: "Created", quarantineReason: "Reason", quarantineDelete: "Delete quarantine", quarantineDeleteConfirm: "Delete quarantined data permanently?", notiQuarantineDeleted: "Quarantine deleted", autosaveLabel: "Autosave", autosaveFailing: "Autosave FAILING", autosaveBannerTitle: "Automatic saving is failing (storage full)", autosaveBannerText: "Export your project NOW to avoid data loss", autosaveExportNow: "Export JSON now", autosaveLastOk: "last saved", notiRackCreated: "Rack created", promptRackName: "Rack name", notiDevicesRemoved: "devices removed", notiPortBlocked: "Port is disabled/faulty \u2014 no new connections", promptQuickLabel: "Port label / outlet" },
  de: {
    confirmReserved:"Reservierter Port — verbinden?", confirmRemovePorts:"Ports {ports} und {count} Verbindungen entfernen?", notiPortEditInvalid:"Ungültige Portkonfiguration. Keine Änderung.", notiBackupAmbiguous:"Backup-Reihenfolge unklar. Rettungsdaten exportieren und Kopie manuell wählen. Autosave bis zur Projektänderung pausiert.",
    notiSnapshotsFailed:"Die Snapshot-Änderung konnte nicht gespeichert werden. Es wurde nichts geändert.", notiTemplatesFailed:"Die Vorlagenänderung konnte nicht gespeichert werden. Es wurde nichts geändert.", notiFavoritesFailed:"Favoriten konnten nicht gespeichert werden. Es wurde nichts geändert.", notiTemplateSaved:"📌 Vorlage „{name}“ gespeichert", notiUndoLabel:"↩ Rückgängig: {label}", notiFixed:"⚠️ Repariert: {detail}", notiUnknownFile:"Unbekanntes Format: {name}", notiImportedFile:"📥 Importiert: {name}", notiFailedFile:"Import fehlgeschlagen: {name}", notiMergedCounts:"🔀 Zusammengeführt: {count} Racks, {cross} rackübergreifende Verbindungen aus „{name}“", notiExportedRack:"📤 „{name}“ exportiert", notiCsvCounts:"📥 CSV: {added} Verbindungen hinzugefügt, {skipped} übersprungen", notiRackAreaMissing:"Der Rack-Bereich für den Export wurde nicht gefunden.", notiCanvasMissing:"html2canvas ist nicht geladen.", notiPngSaved:"PNG exportiert ✅", notiPngFailed:"PNG-Export fehlgeschlagen: {detail}", notiDuplicatedRack:"📋 „{name}“ dupliziert; kopierte Verbindungen: {count}", notiAddedPreset:"{name} hinzugefügt", notiPoeOn:"⚡ PoE EIN", notiPoeOff:"PoE AUS", notiPortRange:"⚡ Ports {from}–{to} → {status}", notiPortColors:"🎨 Ports {from}–{to}: Farbe gesetzt", notiPortColorsCleared:"🎨 Ports {from}–{to}: Farbe entfernt", notiBulkConnections:"⚡ {count} Verbindungen erstellt", notiPickDestination:"🔗 Zielport in {name} auswählen", confirmDeleteRack:"Rack „{name}“ und alle Geräte darin löschen?", confirmDuplicateRack:"„{name}“ MIT {count} Verbindungen duplizieren?\n\nOK = mit Verbindungen\nAbbrechen = nur Geräte", confirmNewProject:"⚠️ Alles löschen und ein neues Projekt starten?", confirmClearLog:"Alle Protokolleinträge löschen?", confirmMoveDevice:"„{name}“ nach „{rack}“ verschieben?\n\nUmzuwandelnde lokale Verbindungen: {local}.\nZu aktualisierende rackübergreifende Verbindungen: {cross}.\n\nFortfahren?", confirmDeleteDevice:"„{name}“ löschen? Aktive Verbindungen: {count}.\n\nMit Strg+Z rückgängig machen.", confirmDeleteDevices:"{count} Geräte löschen? Betroffene Verbindungen: {connections}.\n\nMit Strg+Z rückgängig machen.",
     devices: "GER\u00c4TE", freeU: "FREI U", links: "VERB.", portUsage: "PORT-AUSLASTUNG", addDevice: "+ NEUES GER\u00c4T", save: "Speichern", load: "Laden", merge: "Zusammenf.", import: "Import", report: "Bericht", demo: "Demo", newProj: "Neu", search: "Suchen...", settings: "Einstellungen", theme: "DESIGN / PANEL", portColors: "PORT-TYP FARBEN", groupColors: "VERBINDUNGSFARBEN NACH GER\u00c4TEGRUPPE", groupHint: "Bei Verbindung dieser Ger\u00e4tetypen wird automatisch diese Kabelfarbe zugewiesen.", resetAll: "Alle auf Standard zur\u00fccksetzen", language: "SPRACHE", favorites: "FAVORITEN", myTemplates: "MEINE VORLAGEN", customDevice: "Eigenes Ger\u00e4t", front: "Vorne", rear: "Hinten", rearView: "R\u00dcCKANSICHT", label: "Etikett", connected: "Verbunden!", disconnected: "Getrennt", deleted: "gel\u00f6scht", exported: "exportiert", merged: "Zusammengef\u00fchrt", addRack: "+ Rack hinzuf\u00fcgen", noDevices: "\u2190 Ger\u00e4te aus Sidebar hinzuf\u00fcgen", connections: "VERBINDUNGEN", globalSearch: "\ud83d\udd0d Suche: Ger\u00e4te, Ports, Labels, Verbindungen...", rackSearch: "\ud83d\udd0d Suchen...", labelDose: "LABEL / DOSE", status: "STATUS", cancel: "Abbrechen", saveBtn: "Speichern", connect: "Verbinden", portType: "PORT-TYP", srcDevice: "QUELLGER\u00c4T", tgtDevice: "ZIELGER\u00c4T", select: "W\u00e4hlen...", count: "ANZAHL", preview: "VORSCHAU", noOtherRacks: "Keine weiteren Racks", allPorts: "Alle Ports", ports: "Ports", moveToRack: "In anderes Rack verschieben", batchStatus: "Port-Status f\u00fcr Bereich", saveTemplate: "Als Vorlage speichern", name: "NAME", sizeU: "GR\u00d6SSE (U)", icon: "ICON", serialNumber: "SERIENNUMMER", ipAddress: "IP-ADRESSE", model: "MODELL", firmware: "FIRMWARE", notes: "NOTIZEN", portGroups: "PORT-GRUPPEN", rackName: "RACK-NAME", location: "STANDORT", deleteRack: "Dieses Rack l\u00f6schen", startAt: "STARTEN AB", free: "frei", max: "max", connCreated: "Verbindungen", uFree: "U frei", hintLClick: "L-Klick: verbinden", hintRClick: "R-Klick: Status/PoE/Label", hintDblClick: "Doppelklick: Label", hintCrossRack: "Cross-Rack", hintBulk: "Bulk", hintUndo: "Strg+Z: r\u00fcckg.", hintSave: "Strg+S: speichern", hintEsc: "Esc: abbrechen", hintDel: "Entf: ausgew. l\u00f6schen", notiSaved: "Gespeichert!", notiRemoved: "Entfernt", notiUpdated: "Aktualisiert", notiLoaded: "Projekt geladen", notiNewProj: "Neues Projekt erstellt", notiRackDel: "Rack gel\u00f6scht", notiRackUpd: "Rack aktualisiert", notiExportPdf: "PDF-Bericht ge\u00f6ffnet \u2014 Drucken \u2192 Als PDF speichern", notiExportXls: "Excel exportiert (3 Bl\u00e4tter: Ger\u00e4te, Verbindungen, Zusammenfassung)", notiCrossRack: "Cross-Rack verbunden!", notiLogoSet: "Logo gesetzt", notiLogoRemoved: "Logo entfernt", notiLogCleared: "Log gel\u00f6scht", notiLabelRemoved: "Label entfernt", notiTemplateRemoved: "Vorlage entfernt", notiInvalidJson: "Ung\u00fcltige JSON-Datei", notiUnknownFmt: "Unbekanntes Format", notiCsvEmpty: "CSV ist leer", notiCsvCols: "CSV braucht 'From Device' und 'To Device' Spalten", notiFailedMerge: "Projekt-Zusammenf\u00fchrung fehlgeschlagen", notiOnlyV08: "Nur v0.8-Projekte k\u00f6nnen zusammengef\u00fchrt werden", notiFailedCsv: "CSV-Parsing fehlgeschlagen", notiDemo: "Demo: 2 Racks + Port-Labels + Kabelnotizen", notiV07Import: "v0.7 als Rack importiert", notiCustomDev: "Eigenes Ger\u00e4t hinzugef\u00fcgt", notiDevAdded: "zum Rack hinzugef\u00fcgt", poeBudget: "PoE-BUDGET (W)", color: "FARBE", notesSection: "GER\u00c4TENOTIZEN", freeNotes: "Freie Notizen...", connectToRack: "MIT RACK VERBINDEN", moveToRackHeader: "IN RACK VERSCHIEBEN", prefix: "PR\u00c4FIX", portLabels: "PORT-LABELS", fromRack: "VON RACK", toRack: "ZU RACK", cable: "KABEL", cableNote: "KABEL / NOTIZ", projectReport: "Projektbericht", rackReport: "Bericht", notiRedo: "Wiederherstellen", notiMoved: "Verschoben nach", saveAsTemplate: "Als Vorlage speichern", batchPortStatus: "Port-Status Batch", qrCode: "QR-Code", snapshot: "Snapshot", snapshots: "Snapshots", restoreSnapshot: "Wiederherstellen", deleteSnapshot: "Löschen", noSnapshots: "Noch keine Snapshots", snapshotName: "Snapshot-Name", notiSnapshotSaved: "Snapshot gespeichert!", notiSnapshotRestored: "Snapshot wiederhergestellt!", portColor: "PORT-FARBE", batchPortColor: "Port-Farbe (Batch)", clearColor: "Entfernen", notiColorSet: "Farbe gesetzt!", notiColorCleared: "Farbe entfernt", notiBootRepaired: "Projekt beim Start repariert \u2014 Original in Quarant\u00e4ne gesichert", notiBootBackup: "Autosave ung\u00fcltig \u2014 aus Backup wiederhergestellt", notiBootSafeMode: "Abgesicherter Modus: kein gespeichertes Projekt ladbar. Daten in Quarant\u00e4ne gesichert", quarantine: "QUARANT\u00c4NE", quarantineInfo: "Hier liegen Daten eines fehlgeschlagenen Starts", quarantineDownload: "Bundle herunterladen", quarantineDownloadAutosave: "Nur Autosave herunterladen", quarantineCreatedAt: "Erstellt", quarantineReason: "Grund", quarantineDelete: "Quarant\u00e4ne l\u00f6schen", quarantineDeleteConfirm: "Quarant\u00e4ne-Daten endg\u00fcltig l\u00f6schen?", notiQuarantineDeleted: "Quarant\u00e4ne gel\u00f6scht", autosaveLabel: "Autosave", autosaveFailing: "Autosave-FEHLER", autosaveBannerTitle: "Automatisches Speichern schl\u00e4gt fehl (Speicher voll)", autosaveBannerText: "Exportiere dein Projekt JETZT, um Datenverlust zu vermeiden", autosaveExportNow: "JSON jetzt exportieren", autosaveLastOk: "zuletzt gespeichert", notiRackCreated: "Rack erstellt", promptRackName: "Rack-Name", notiDevicesRemoved: "Ger\u00e4te entfernt", notiPortBlocked: "Port ist deaktiviert/defekt \u2014 keine neuen Verbindungen", promptQuickLabel: "Port-Label / Dose" },
  es: {
    confirmReserved:"Puerto reservado — ¿conectar?", confirmRemovePorts:"¿Eliminar puertos {ports} y {count} conexiones?", notiPortEditInvalid:"Configuración de puertos inválida. Sin cambios.", notiBackupAmbiguous:"Orden de backups desconocido. Exporta el rescate y elige una copia manualmente. Autoguardado pausado hasta cambiar el proyecto.",
    notiSnapshotsFailed:"No se pudo guardar el cambio de snapshots. No se cambió nada.", notiTemplatesFailed:"No se pudo guardar el cambio de plantillas. No se cambió nada.", notiFavoritesFailed:"No se pudieron guardar los favoritos. No se cambió nada.", notiTemplateSaved:"📌 Plantilla «{name}» guardada", notiUndoLabel:"↩ Deshacer: {label}", notiFixed:"⚠️ Reparado: {detail}", notiUnknownFile:"Formato desconocido: {name}", notiImportedFile:"📥 Importado: {name}", notiFailedFile:"Error al importar: {name}", notiMergedCounts:"🔀 Fusionados: {count} racks, {cross} conexiones entre racks de «{name}»", notiExportedRack:"📤 Exportado «{name}»", notiCsvCounts:"📥 CSV: {added} conexiones añadidas, {skipped} omitidas", notiRackAreaMissing:"No se encontró el área del rack para exportar.", notiCanvasMissing:"html2canvas no está cargado.", notiPngSaved:"PNG exportado ✅", notiPngFailed:"Error al exportar PNG: {detail}", notiDuplicatedRack:"📋 Duplicado «{name}»; conexiones copiadas: {count}", notiAddedPreset:"Añadido {name}", notiPoeOn:"⚡ PoE activado", notiPoeOff:"PoE desactivado", notiPortRange:"⚡ Puertos {from}–{to} → {status}", notiPortColors:"🎨 Puertos {from}–{to}: color establecido", notiPortColorsCleared:"🎨 Puertos {from}–{to}: color eliminado", notiBulkConnections:"⚡ {count} conexiones creadas", notiPickDestination:"🔗 Selecciona el puerto de destino en {name}", confirmDeleteRack:"¿Eliminar el rack «{name}» y todos sus dispositivos?", confirmDuplicateRack:"¿Duplicar «{name}» CON {count} conexiones?\n\nAceptar = con conexiones\nCancelar = solo dispositivos", confirmNewProject:"⚠️ ¿Borrar todo y comenzar un proyecto nuevo?", confirmClearLog:"¿Borrar todas las entradas del registro?", confirmMoveDevice:"¿Mover «{name}» a «{rack}»?\n\nConexiones locales que se convertirán: {local}.\nConexiones entre racks que se actualizarán: {cross}.\n\n¿Continuar?", confirmDeleteDevice:"¿Eliminar «{name}»? Conexiones activas: {count}.\n\nUsa Ctrl+Z para deshacer.", confirmDeleteDevices:"¿Eliminar {count} dispositivos? Conexiones afectadas: {connections}.\n\nUsa Ctrl+Z para deshacer.",
     devices: "EQUIPOS", freeU: "U LIBRE", links: "ENLACES", portUsage: "USO DE PUERTOS", addDevice: "+ NUEVO EQUIPO", save: "Guardar", load: "Cargar", merge: "Fusionar", import: "Importar", report: "Informe", demo: "Demo", newProj: "Nuevo", search: "Buscar...", settings: "Ajustes", theme: "TEMA / PANEL", portColors: "COLORES DE TIPO DE PUERTO", groupColors: "COLORES DE CONEXI\u00d3N POR GRUPO", groupHint: "Al conectar estos tipos de equipos, se asigna autom\u00e1ticamente este color de cable.", resetAll: "Restablecer todo", language: "IDIOMA", favorites: "FAVORITOS", myTemplates: "MIS PLANTILLAS", customDevice: "Equipo personalizado", front: "Frontal", rear: "Trasero", rearView: "VISTA TRASERA", label: "Etiqueta", connected: "\u00a1Conectado!", disconnected: "Desconectado", deleted: "eliminado", exported: "exportado", merged: "Fusionado", addRack: "+ Agregar Rack", noDevices: "\u2190 Agregar equipos desde barra lateral", connections: "CONEXIONES", globalSearch: "\ud83d\udd0d Buscar: equipos, puertos, etiquetas, conexiones...", rackSearch: "\ud83d\udd0d Buscar...", labelDose: "LABEL / DOSE", status: "ESTADO", cancel: "Cancelar", saveBtn: "Guardar", connect: "Conectar", portType: "TIPO DE PUERTO", srcDevice: "EQUIPO ORIGEN", tgtDevice: "EQUIPO DESTINO", select: "Seleccionar...", count: "CANTIDAD", preview: "VISTA PREVIA", noOtherRacks: "No hay otros racks", allPorts: "Todos los puertos", ports: "Puertos", moveToRack: "Mover a otro rack", batchStatus: "Estado de puertos por rango", saveTemplate: "Guardar como plantilla", name: "NOMBRE", sizeU: "TAMA\u00d1O (U)", icon: "ICONO", serialNumber: "N\u00daMERO DE SERIE", ipAddress: "DIRECCI\u00d3N IP", model: "MODELO", firmware: "FIRMWARE", notes: "NOTAS", portGroups: "GRUPOS DE PUERTOS", rackName: "NOMBRE DEL RACK", location: "UBICACI\u00d3N", deleteRack: "Eliminar este rack", startAt: "EMPEZAR EN", free: "libre", max: "m\u00e1x", connCreated: "conexiones", uFree: "U libre", hintLClick: "L-clic: conectar", hintRClick: "R-clic: estado/PoE/label", hintDblClick: "Doble clic: label", hintCrossRack: "cross-rack", hintBulk: "masivo", hintUndo: "Ctrl+Z: deshacer", hintSave: "Ctrl+S: guardar", hintEsc: "Esc: cancelar", hintDel: "Supr: eliminar sel.", notiSaved: "\u00a1Guardado!", notiRemoved: "Eliminado", notiUpdated: "Actualizado", notiLoaded: "Proyecto cargado", notiNewProj: "Nuevo proyecto creado", notiRackDel: "Rack eliminado", notiRackUpd: "Rack actualizado", notiExportPdf: "Informe PDF abierto \u2014 Imprimir \u2192 Guardar como PDF", notiExportXls: "Excel exportado (3 hojas: Equipos, Conexiones, Resumen)", notiCrossRack: "\u00a1Cross-rack conectado!", notiLogoSet: "Logo establecido", notiLogoRemoved: "Logo eliminado", notiLogCleared: "Log borrado", notiLabelRemoved: "Etiqueta eliminada", notiTemplateRemoved: "Plantilla eliminada", notiInvalidJson: "Archivo JSON inv\u00e1lido", notiUnknownFmt: "Formato desconocido", notiCsvEmpty: "CSV est\u00e1 vac\u00edo", notiCsvCols: "CSV necesita columnas 'From Device' y 'To Device'", notiFailedMerge: "Error al fusionar proyecto", notiOnlyV08: "Solo se pueden fusionar proyectos v0.8", notiFailedCsv: "Error al analizar CSV", notiDemo: "Demo: 2 racks + labels de puerto + notas de cable", notiV07Import: "v0.7 importado como rack", notiCustomDev: "Equipo personalizado a\u00f1adido", notiDevAdded: "a\u00f1adido al rack", poeBudget: "PRESUPUESTO PoE (W)", color: "COLOR", notesSection: "NOTAS DEL EQUIPO", freeNotes: "Notas libres...", connectToRack: "CONECTAR A RACK", moveToRackHeader: "MOVER A RACK", prefix: "PREFIJO", portLabels: "ETIQUETAS DE PUERTOS", fromRack: "RACK ORIGEN", toRack: "RACK DESTINO", cable: "CABLE", cableNote: "CABLE / NOTA", projectReport: "Informe del Proyecto", rackReport: "Informe", notiRedo: "Rehacer", notiMoved: "Movido a", saveAsTemplate: "Guardar como Plantilla", batchPortStatus: "Estado de Puertos (Lote)", qrCode: "Código QR", snapshot: "Instantánea", snapshots: "Instantáneas", restoreSnapshot: "Restaurar", deleteSnapshot: "Eliminar", noSnapshots: "Sin instantáneas aún", snapshotName: "Nombre", notiSnapshotSaved: "¡Instantánea guardada!", notiSnapshotRestored: "¡Instantánea restaurada!", portColor: "COLOR DE PUERTO", batchPortColor: "Color de Puertos (Lote)", clearColor: "Quitar", notiColorSet: "¡Color aplicado!", notiColorCleared: "Color eliminado", notiBootRepaired: "Proyecto reparado al arrancar \u2014 original guardado en cuarentena", notiBootBackup: "Autosave inv\u00e1lido \u2014 recuperado desde backup", notiBootSafeMode: "Modo seguro: ning\u00fan proyecto guardado pudo cargarse. Datos asegurados en cuarentena", quarantine: "CUARENTENA", quarantineInfo: "Aqu\u00ed se guardan datos de un arranque fallido", quarantineDownload: "Descargar bundle", quarantineDownloadAutosave: "Descargar solo autosave", quarantineCreatedAt: "Creado", quarantineReason: "Motivo", quarantineDelete: "Eliminar cuarentena", quarantineDeleteConfirm: "\u00bfEliminar definitivamente los datos en cuarentena?", notiQuarantineDeleted: "Cuarentena eliminada", autosaveLabel: "Autoguardado", autosaveFailing: "Autoguardado CON ERROR", autosaveBannerTitle: "El guardado autom\u00e1tico est\u00e1 fallando (almacenamiento lleno)", autosaveBannerText: "Exporta tu proyecto AHORA para evitar p\u00e9rdida de datos", autosaveExportNow: "Exportar JSON ahora", autosaveLastOk: "\u00faltimo guardado", notiRackCreated: "Rack creado", promptRackName: "Nombre del rack", notiDevicesRemoved: "dispositivos eliminados", notiPortBlocked: "Puerto deshabilitado/defectuoso \u2014 sin conexiones nuevas", promptQuickLabel: "Label del puerto / toma" },
};

/* ─── DEFAULT PORT TYPE COLORS (customizable) ─── */
const DEFAULT_PT_COLORS = {
  rj45: "#3b82f6", rj45_poe: "#3b82f6", sfp: "#a855f7", sfp28: "#ef4444",
  qsfp: "#10b981", mgmt: "#f59e0b", console: "#6b7280", power: "#ef4444",
  usb_a: "#9ca3af", usb_c: "#9ca3af",
};
const PT_COLOR_KEY = "rackclick_pt_colors";

/* ─── GROUP COLORS (connection color by device category pair) ─── */
const DEV_CATEGORIES = {
  "Patch Panel": ["pp24","pp48","ppf24"],
  "Switch": ["sw24","sw48","swsfp"],
  "Router": ["rtr"],
  "Firewall": ["fw"],
  "Server": ["srv1u","srv2u","srv4u"],
  "NAS/SAN": ["nas2u","nas4u","san"],
  "Other": [],
};
const GROUP_COLOR_KEY = "rackclick_group_colors";
const CC = [
  "#ef4444","#06b6d4","#f59e0b","#10b981","#f97316","#8b5cf6","#ec4899","#14b8a6",
  "#ea580c","#22d3ee","#f87171","#3b82f6","#fbbf24","#34d399","#fb923c","#a78bfa",
  "#f472b6","#2dd4bf","#c084fc","#67e8f9","#e11d48","#059669","#2563eb","#7c3aed",
  "#0d9488","#dc2626","#ca8a04","#c2410c","#0f766e","#9333ea","#4f46e5","#16a34a",
  "#0284c7","#b91c1c","#64748b","#1e3a5f","#fb7185","#818cf8","#fde047","#a5f3fc",
  "#fdba74","#6366f1","#7dd3fc","#86efac","#d97706","#be123c","#4338ca","#0891b2",
  "#4ade80","#e97451","#b45309","#1d4ed8","#2dd4bf","#d97706","#1e40af","#9f1239",
  "#0f766e","#be185d","#fb923c","#6d28d9",
];

const PT = {
  rj45:    { label: "RJ45",      shape: "sq",   color: "#3b82f6" },
  rj45_poe:{ label: "RJ45 PoE",  shape: "sq",   color: "#3b82f6", poe: true },
  sfp:     { label: "SFP/SFP+",  shape: "rect", color: "#a855f7" },
  sfp28:   { label: "SFP28",     shape: "rect", color: "#ef4444" },
  qsfp:    { label: "QSFP+",     shape: "wide", color: "#10b981" },
  mgmt:    { label: "MGMT",      shape: "circ", color: "#f59e0b" },
  console: { label: "Console",   shape: "circ", color: "#6b7280" },
  power:   { label: "Power",     shape: "sq",   color: "#ef4444" },
  usb_a:   { label: "USB-A",     shape: "sq",   color: "#9ca3af" },
  usb_c:   { label: "USB-C",     shape: "rect", color: "#9ca3af" },
};

const PS = {
  free:     { label: "Free",     color: null,      sym: "" },
  reserved: { label: "Reserved", color: "#f59e0b", sym: "R" },
  disabled: { label: "Disabled", color: "#ef4444", sym: "×" },
  faulty:   { label: "Faulty",   color: "#dc2626", sym: "!" },
};

const ICONS = ["▥","⇋","▦","▤","▩","◎","⛨","⚡","🔋","⇌","◻","⬒","☰","▣","⊞","⊡","▧","⬡"];

const PRESETS = {
  pp24:  { label: "Patch Panel 24P",     icon: "▥", color: "#2a9d8f", u: 1, ports: [{ t: "rj45", n: 24 }] },
  pp48:  { label: "Patch Panel 48P",     icon: "▥", color: "#2a9d8f", u: 2, ports: [{ t: "rj45", n: 48 }] },
  ppf24: { label: "Fiber Patch 24P",     icon: "▥", color: "#10b981", u: 1, ports: [{ t: "sfp", n: 24 }] },
  sw24:  { label: "Switch 24P",          icon: "⇋", color: "#e76f51", u: 1, ports: [{ t: "rj45", n: 24 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 },{ t: "console", n: 1 }] },
  sw24p: { label: "Switch 24P PoE",      icon: "⇋", color: "#e76f51", u: 1, ports: [{ t: "rj45_poe", n: 24 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 },{ t: "console", n: 1 }] },
  sw48:  { label: "Switch 48P",          icon: "⇋", color: "#e76f51", u: 1, ports: [{ t: "rj45", n: 48 },{ t: "sfp", n: 4 },{ t: "mgmt", n: 1 },{ t: "console", n: 1 }] },
  sw48p: { label: "Switch 48P PoE",      icon: "⇋", color: "#e76f51", u: 1, ports: [{ t: "rj45_poe", n: 48 },{ t: "sfp", n: 4 },{ t: "mgmt", n: 1 },{ t: "console", n: 1 }] },
  swsfp: { label: "Switch SFP+ 24P",     icon: "⇋", color: "#dc2626", u: 1, ports: [{ t: "sfp", n: 24 },{ t: "qsfp", n: 2 },{ t: "mgmt", n: 1 }] },
  srv1u: { label: "Server 1U",           icon: "▦", color: "#457b9d", u: 1, ports: [{ t: "rj45", n: 2 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 }] },
  srv2u: { label: "Server 2U",           icon: "▦", color: "#457b9d", u: 2, ports: [{ t: "rj45", n: 4 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 }] },
  srv4u: { label: "Server 4U (GPU)",     icon: "▦", color: "#0369a1", u: 4, ports: [{ t: "rj45", n: 2 },{ t: "sfp28", n: 2 },{ t: "qsfp", n: 2 },{ t: "mgmt", n: 1 }] },
  nas2u: { label: "NAS 2U",             icon: "▤", color: "#7c3aed", u: 2, ports: [{ t: "rj45", n: 2 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 }] },
  nas4u: { label: "NAS 4U",             icon: "▤", color: "#7c3aed", u: 4, ports: [{ t: "rj45", n: 4 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 }] },
  san:   { label: "SAN Storage",         icon: "▩", color: "#8b5cf6", u: 2, ports: [{ t: "sfp", n: 4 },{ t: "mgmt", n: 1 }] },
  rtr:   { label: "Router",             icon: "◎", color: "#b5838d", u: 1, ports: [{ t: "rj45", n: 4 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 },{ t: "console", n: 1 }] },
  fw:    { label: "Firewall",           icon: "⛨", color: "#d97706", u: 1, ports: [{ t: "rj45", n: 8 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 }] },
  pdu:   { label: "PDU",                icon: "⚡", color: "#6b7280", u: 1, ports: [{ t: "power", n: 8 }] },
  ups:   { label: "UPS 2U",             icon: "🔋", color: "#eab308", u: 2, ports: [{ t: "power", n: 4 },{ t: "mgmt", n: 1 },{ t: "usb_a", n: 1 }] },
  mc:    { label: "Media Converter",     icon: "⇌", color: "#06b6d4", u: 1, ports: [{ t: "rj45", n: 4 },{ t: "sfp", n: 4 }] },
  bl1u:  { label: "Blank 1U",            icon: "▬", color: "#333333", u: 1, ports: [] },
  bl2u:  { label: "Blank 2U",            icon: "▬", color: "#333333", u: 2, ports: [] },
  sp1u:  { label: "Spacer 1U",           icon: "┄", color: "#1a1a2e", u: 1, ports: [] },
  sp2u:  { label: "Spacer 2U",           icon: "┄", color: "#1a1a2e", u: 2, ports: [] },
  cbl1u: { label: "Cable Mgmt 1U",       icon: "⊞", color: "#444444", u: 1, ports: [] },
  shelf: { label: "Shelf 1U",            icon: "⊟", color: "#555555", u: 1, ports: [] },
};

// New catalog devices only: existing imported inventory remains untouched.
for(const key of ['sw24','sw24p','sw48','sw48p','swsfp','srv1u','srv2u','srv4u','nas2u','nas4u','san','rtr','fw','mc']) PRESETS[key].ports=[...PRESETS[key].ports,{t:'power',n:/srv|nas|san/.test(key)?2:1}];
PRESETS.pdu.ports=[{t:'power',n:9}];PRESETS.ups.ports=[{t:'power',n:5},{t:'mgmt',n:1},{t:'usb_a',n:1}];
Object.assign(PRESETS,{
 sw8:{label:'Switch 8P',icon:'⇋',color:'#e76f51',u:1,ports:[{t:'rj45',n:8},{t:'sfp',n:2}]},
 sw16:{label:'Switch 16P',icon:'⇋',color:'#e76f51',u:1,ports:[{t:'rj45',n:16},{t:'sfp',n:2}]},
 sw8p:{label:'Switch 8P PoE',icon:'⇋',color:'#e76f51',u:1,ports:[{t:'rj45_poe',n:8},{t:'sfp',n:2}]},
 rtr8:{label:'Router 8P',icon:'◎',color:'#b5838d',u:1,ports:[{t:'rj45',n:8},{t:'sfp',n:2},{t:'console',n:1}]},
 fw4:{label:'Firewall 4P',icon:'⛨',color:'#d97706',u:1,ports:[{t:'rj45',n:4},{t:'console',n:1}]},
 nas1u:{label:'NAS 1U',icon:'▤',color:'#7c3aed',u:1,ports:[{t:'rj45',n:2},{t:'usb_a',n:2}]},
 srv1u4:{label:'Server 1U 4LAN',icon:'▦',color:'#457b9d',u:1,ports:[{t:'rj45',n:4},{t:'mgmt',n:1},{t:'usb_a',n:2}]},
 ap:{label:'Access Point (AP)',icon:'◎',color:'#06b6d4',u:1,ports:[{t:'rj45',n:1}]}
});
const CATS = [
  { label: "Patch Panels",  keys: ["pp24","pp48","ppf24"] },
  { label: "Switches",      keys: ["sw8","sw8p","sw16","sw24","sw24p","sw48","sw48p","swsfp"] },
  { label: "Servers",       keys: ["srv1u","srv1u4","srv2u","srv4u"] },
  { label: "Storage",       keys: ["nas1u","nas2u","nas4u","san"] },
  { label: "Network",       keys: ["rtr","rtr8","fw","fw4","ap","mc"] },
  { label: "Power",         keys: ["pdu","ups"] },
  { label: "Spacers",       keys: ["bl1u","bl2u","sp1u","sp2u","cbl1u","shelf"] },
];

const RSZ = [6, 12, 16, 20, 24, 32, 42, 48];
const gid = () => Math.random().toString(36).substr(2, 9);
const FAV_KEY = "rackclick_fav_presets";
const htmlEsc = value => String(value ?? "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
const SAVE_KEY = "rackclick_autosave_v08";
const BACKUP_KEYS = ["rackclick_backup_1", "rackclick_backup_2", "rackclick_backup_3"];
const BACKUP_META = "rackclick_backup_meta";
const TEMPLATES_KEY = "rackclick_custom_templates";
const SNAPSHOTS_KEY = "rackclick_snapshots";
const PATCH_ST = { none: { label: "—", color: "#333" }, planned: { label: "📋 Planned", color: "#3b82f6" }, progress: { label: "🔧 In Progress", color: "#f59e0b" }, done: { label: "✅ Done", color: "#10b981" }, tested: { label: "🧪 Tested", color: "#8b5cf6" } };
const LOC_SUGGEST = ["Keller","UG","EG","OG1","OG2","OG3","OG4","OG5","DG","Serverraum","Technikraum","Gebäude A","Gebäude B","Gebäude C"];
const MAX_UNDO = 30;

/* ═══════ VALIDATION ═══════ */
const validateRack = (r) => {
  if (!r || typeof r !== "object") return "Rack is not an object";
  if (!r.id || typeof r.id !== "string") r.id = gid();
  if (!r.name || typeof r.name !== "string") r.name = "Unnamed Rack";
  if (!r.size || typeof r.size !== "number" || r.size < 1) r.size = 24;
  if (!Array.isArray(r.devs)) r.devs = [];
  if (!Array.isArray(r.conns)) r.conns = [];
  r.devs = r.devs.filter(d => d && typeof d === "object" && d.id && d.name && Array.isArray(d.ports));
  r.devs.forEach(d => { if (!d.u || typeof d.u !== "number") d.u = 1; if (!d.icon) d.icon = "▦"; if (!d.color) d.color = "#6b7280"; if (!d.preset) d.preset = "Custom"; d.ports = d.ports.filter(p => p && p.id && p.type); });
  const allPortIds = new Set(); r.devs.forEach(d => d.ports.forEach(p => allPortIds.add(p.id)));
  const allDevIds = new Set(r.devs.map(d => d.id));
  r.conns = r.conns.filter(c => c && c.id && c.fd && c.td && c.fp && c.tp && allDevIds.has(c.fd) && allDevIds.has(c.td) && allPortIds.has(c.fp) && allPortIds.has(c.tp));
  return null;
};
const validateProject = (d) => {
  if (!d || typeof d !== "object") return "Not a valid object";
  try{irAssertPresentation(d)}catch{return "Invalid presentation metadata"}
  if (d.version !== "0.8") return "Not a v0.8 project";
  if (!Array.isArray(d.racks) || d.racks.length === 0) return "No racks found";
  if (!d.name || typeof d.name !== "string") d.name = "Imported Project";
  const errors = [];
  d.racks.forEach((r, i) => { const e = validateRack(r); if (e) errors.push(`Rack ${i+1}: ${e}`); });
  if (!Array.isArray(d.crossConns)) d.crossConns = [];
  const allDevIds = new Set(); d.racks.forEach(r => r.devs.forEach(dev => allDevIds.add(dev.id)));
  const rackIds = new Set(d.racks.map(r => r.id));
  d.crossConns = d.crossConns.filter(c => c && c.id && c.fd && c.td && allDevIds.has(c.fd) && allDevIds.has(c.td) && rackIds.has(c.rackFrom) && rackIds.has(c.rackTo));
  return errors.length > 0 ? errors.join("; ") : null;
};

/* \u2550\u2550\u2550 BOOT LOADER (v0.8.2) \u2014 Validaci\u00f3n de arranque + modo seguro \u2550\u2550\u2550
   Reglas aprobadas (Paso 3):
   - La cuarentena se escribe ANTES de devolver cualquier proyecto.
   - Strings CRUDOS sin parsear, en una sola clave (bundle).
   - Cero removeItem/clear autom\u00e1ticos: eliminar cuarentena es acci\u00f3n
     expl\u00edcita del usuario en Settings.
   - En modo seguro (o si la escritura de cuarentena fall\u00f3), se suprime el
     PRIMER ciclo del autosave para no sobrescribir el estado anterior. */
const QUARANTINE_KEY = "rackclick_quarantine";
let BOOT_REPORT = null;
let BOOT_SUPPRESS_FIRST_AUTOSAVE = false;

let BOOT_AUTOSAVE_BLOCKED = false;
let BOOT_RECOVERY_REASON = null;
function bootQuarantine(reason, rawMap) {
  try {
    // Never overwrite either the v0.8.x quarantine or another episode.
    let key=QUARANTINE_KEY;
    if (localStorage.getItem(key)!==null) {
      do { key=IR_QUARANTINE_PREFIX+Date.now()+'-'+Math.random().toString(36).slice(2); }
      while (localStorage.getItem(key)!==null);
    }
    const raw=JSON.stringify({createdAt:new Date().toISOString(),reason,keys:rawMap});
    localStorage.setItem(key,raw);
    if(localStorage.getItem(key)!==raw)throw Error('Quarantine readback failed');
    return true;
  } catch {
    BOOT_AUTOSAVE_BLOCKED=true;
    BOOT_RECOVERY_REASON='quarantineFailed';
    return false;
  }
}

function bootTryParse(raw) {
  if (!raw) return { ok: false };
  let p;
  try { p = JSON.parse(raw); } catch { return { ok: false }; }
  if (!p || typeof p !== "object" || p.version !== "0.8" || !irBootSafeShape(p)) return { ok: false };
  const before = JSON.stringify(p);
  let err;
  try { err = validateProject(p); } catch { return { ok: false }; }
  if (err) return { ok: false };
  return { ok: true, project: p, repaired: JSON.stringify(p) !== before };
}

function bootLoadProject(emptyFactory) {
  let rawSave=null,metaRaw=null;
  const rawMap={autosave:null};
  let unreadable=false;
  try{rawSave=localStorage.getItem(SAVE_KEY);rawMap.autosave=rawSave}catch{unreadable=true}
  BACKUP_KEYS.forEach(bk=>{try{rawMap[bk]=localStorage.getItem(bk)}catch{rawMap[bk]=null;unreadable=true}});
  try{metaRaw=localStorage.getItem(BACKUP_META)}catch{unreadable=true}
  if(unreadable){
    BOOT_AUTOSAVE_BLOCKED=true;
    BOOT_RECOVERY_REASON='unreadable';
    BOOT_REPORT={type:'unreadable'};
    return emptyFactory();
  }

  // Primer uso: no hay nada guardado \u2014 arranque normal, sin informe ni cuarentena
  if (!rawSave && !BACKUP_KEYS.some(bk => rawMap[bk])) return emptyFactory();

  // [1] Autosave
  const rs = bootTryParse(rawSave);
  if (rs.ok && !rs.repaired) return rs.project; // ruta sana: id\u00e9ntica a v0.8.1

  if (rs.ok && rs.repaired) {
    const qOk = bootQuarantine("repaired-at-boot", rawMap);
    if (!qOk) BOOT_SUPPRESS_FIRST_AUTOSAVE = true;
    BOOT_REPORT = { type: "repaired", quarantineSaved: qOk };
    return rs.project;
  }

  // [2] Legacy cursor = last written slot. It orders copies, not proof of commit.
  let meta = null;
  try { meta = JSON.parse(metaRaw); } catch {}
  const validSlot = Number.isInteger(meta?.slot) && meta.slot >= 0 && meta.slot < BACKUP_KEYS.length;
  const candidates = BACKUP_KEYS.filter(bk => bootTryParse(rawMap[bk]).ok);
  if (!validSlot && candidates.length > 1) {
    // No arbitrary choice and no overwrite of existing recovery evidence.
    BOOT_SUPPRESS_FIRST_AUTOSAVE = true;
    BOOT_REPORT = { type: "ambiguous" };
    return emptyFactory();
  }
  const order = validSlot
    ? BACKUP_KEYS.map((_, i) => BACKUP_KEYS[(meta.slot - i + BACKUP_KEYS.length) % BACKUP_KEYS.length])
    : candidates;
  for (const bk of order) {
    const rb = bootTryParse(rawMap[bk]);
    if (rb.ok) {
      const qOk = bootQuarantine("autosave-invalid", rawMap);
      if (!qOk) BOOT_SUPPRESS_FIRST_AUTOSAVE = true;
      BOOT_REPORT = { type: "backup", backupKey: bk, quarantineSaved: qOk };
      return rb.project;
    }
  }

  // [3] Modo seguro
  const qOk = bootQuarantine("all-invalid", rawMap);
  BOOT_SUPPRESS_FIRST_AUTOSAVE = true; // SIEMPRE en modo seguro (regla aprobada T8)
  BOOT_REPORT = { type: "safeMode", quarantineSaved: qOk };
  return emptyFactory();
}

function reconcilePorts(dev, groups, allPorts) {
  if (!Array.isArray(groups)) throw new Error("port groups");
  const old = new Map(dev.ports.map(p => [p.id, p]));
  if (old.size !== dev.ports.length) throw new Error("duplicate port ID");
  const used = new Set(allPorts.map(p => p.id));
  const kept = new Map(), claimed = new Set(), added = [];
  let sequence = 1;
  for (const g of groups) {
    if (!PT[g.t] || !Number.isInteger(g.n) || g.n < 1 || g.n > 96) throw new Error("port group");
    const ids = g.ids || [];
    if (!Array.isArray(ids)) throw new Error("port IDs");
    ids.forEach(id => {
      if (!old.has(id) || claimed.has(id)) throw new Error("port ownership");
      claimed.add(id);
    });
    ids.slice(0, g.n).forEach(id => {
      const p = old.get(id);
      kept.set(id, p.type === g.t ? p : { ...p, type: g.t });
    });
    let gn = Math.max(0, ...ids.map(id => Number(old.get(id).gn) || 0));
    for (let i = ids.length; i < g.n; i++) {
      while (used.has(`${dev.id}-p${sequence}`)) sequence++;
      const id = `${dev.id}-p${sequence++}`; used.add(id);
      added.push({ id, gn: ++gn, type: g.t, ...(g.t === "rj45_poe" ? { poe: true } : {}) });
    }
  }
  return [...dev.ports.filter(p => kept.has(p.id)).map(p => kept.get(p.id)), ...added];
}

const mkP = (defs, did) => {
  const p = []; let seq = 1;
  defs.forEach(d => { for (let i = 0; i < d.n; i++) { const port = { id: `${did}-p${seq}`, gn: i + 1, type: d.t }; if (d.t === "rj45_poe") port.poe = true; if(d.face==="front"||d.face==="rear")port.rackclickFace=d.face; p.push(port); seq++; } });
  return p;
};

/* ═══════ PORT ═══════ */
function Port({ port, did, isSel, cc, cl, isCross, onClick, onCtx, flash, onDblClick, prefix }) {
  const pt = PT[port.type] || PT.rj45;
  const has = !!cc; const st = port.status || "free"; const psDef = PS[st] || PS.free; const isPoe = port.poe;
  const pf = prefix || "";
  const touchRef = useRef(null);
  const onTouchStart = (e) => { touchRef.current = setTimeout(() => { const t = e.touches[0]; onCtx({ preventDefault:()=>{}, stopPropagation:()=>{}, clientX: t.clientX, clientY: t.clientY }, did, port.id); touchRef.current = null; }, 500); };
  const onTouchEnd = () => { if (touchRef.current) { clearTimeout(touchRef.current); touchRef.current = null; } };
  let bg, bd;
  if (flash) { bg = "#00ff88"; bd = "#00ff88"; }
  else if (isSel) { bg = "#00ff88"; bd = "#00ff88"; }
  else if (has && isCross) { bg = cc; bd = "#a855f7"; }
  else if (has) { bg = cc; bd = cc; }
  else if (st === "reserved") { bg = "#0c0c14"; bd = "#f59e0b"; }
  else if (st === "disabled") { bg = "#1a0808"; bd = "#ef444488"; }
  else if (st === "faulty") { bg = "#1a0808"; bd = "#dc2626"; }
  else if (port.portColor) { bg = port.portColor + "33"; bd = port.portColor; }
  else { bg = "#0c0c14"; bd = "#1e1e2e"; }
  const w = pf ? Math.max(pt.shape === "wide" ? 26 : pt.shape === "rect" ? 20 : 16, 6 * (pf.length + String(port.gn).length) + 8) : pt.shape === "wide" ? 26 : pt.shape === "rect" ? 20 : 16;
  const br = pt.shape === "circ" ? 8 : 2;
  let title = `${pt.label} ${pf}#${port.gn}`;
  if (port.label) title += ` [${port.label}]`;
  if (cl) title += ` → ${cl}`;
  if (isCross) title += " 🔗";
  if (st !== "free") title += ` (${psDef.label})`;
  if (isPoe) title += " ⚡PoE";
  let display = pf ? `${pf}${port.gn}` : port.gn;
  if (!has && !isSel && st === "disabled") display = "×";
  else if (!has && !isSel && st === "faulty") display = "!";
  const hasLabel = !!port.label;
  return (
    <div role="button" aria-label={title} tabIndex={0}
      onClick={e => { e.stopPropagation(); if (e.detail > 1) return; onClick(did, port.id); }}
      onKeyDown={e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onClick(did, port.id); } }}
      onDoubleClick={e => { e.stopPropagation(); e.preventDefault(); if (onDblClick) onDblClick(e, did, port.id); }}
      /* v0.8.4: los dos clics del doble clic no deben togglear la selección */
      onContextMenu={e => { e.preventDefault(); e.stopPropagation(); onCtx(e, did, port.id); }}
      onTouchStart={onTouchStart} onTouchEnd={onTouchEnd} onTouchMove={onTouchEnd}
      title={title}
      style={{ width: w, height: 15, borderRadius: br, backgroundColor: bg,
        border: `1.5px ${st === "reserved" && !has && !isSel ? "dashed" : "solid"} ${bd}`,
        cursor: "pointer", transition: "all 0.1s",
        boxShadow: flash ? "0 0 12px #00ff88, 0 0 24px #00ff8866" : isSel ? "0 0 8px #00ff88" : has ? `0 0 5px ${cc}44` : st === "faulty" ? "0 0 4px #dc262666" : "none",
        display: "flex", alignItems: "center", justifyContent: "center", fontSize: "var(--ir-small)",
        color: isSel || has ? "#000" : st === "disabled" ? "#ef4444" : st === "faulty" ? "#dc2626" : st === "reserved" ? "#f59e0b" : "#2a2a3a",
        fontWeight: 800, fontFamily: "monospace", flexShrink: 0, userSelect: "none", position: "relative" }}>
      {display}
      {isPoe && !isSel && <div style={{ position: "absolute", top: -4, right: -3, fontSize: "var(--ir-small)", color: "#f59e0b", lineHeight: 1 }}>⚡</div>}
      {isCross && has && <div style={{ position: "absolute", bottom: -5, left: "50%", transform: "translateX(-50%)", fontSize: "var(--ir-small)", lineHeight: 1 }}>🔗</div>}
      {hasLabel && !has && !isSel && <div style={{ position: "absolute", bottom: -6, left: "50%", transform: "translateX(-50%)", fontSize: "var(--ir-small)", color: "#10b981", lineHeight: 1, whiteSpace: "nowrap", maxWidth: 24, overflow: "hidden" }}>•</div>}
      {port.portColor && !has && !isSel && <div style={{ position: "absolute", bottom: -1, left: 2, right: 2, height: 2, borderRadius: 1, background: port.portColor }} />}
    </div>
  );
}

/* ═══════ PORT CONTEXT MENU ═══════ */
function PortCtxMenu({ pos, port, onAction, onClose, otherRacks, onCrossConnect, t }) {
  const ref = useRef(null);
  const [labelVal, setLabelVal] = useState(port.label || "");
  useEffect(() => {
    const h = e => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    document.addEventListener("mousedown", h); return () => document.removeEventListener("mousedown", h);
  }, [onClose]);
  const pt = PT[port.type] || PT.rj45; const st = port.status || "free";
  const canPoe = port.type === "rj45" || port.type === "rj45_poe";
  const statuses = ["free", "reserved", "disabled", "faulty"];
  const hasOtherRacks = otherRacks && otherRacks.length > 0;
  return (
    <div className="ir-context" ref={ref} style={{ position: "fixed", left: Math.max(8,Math.min(pos.x,window.innerWidth-310)), top: Math.max(8,Math.min(pos.y,window.innerHeight-440)), zIndex: 1200, background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, borderRadius: 8, padding: 6, minWidth: 180, boxShadow: "0 8px 24px #000a", maxHeight: "80vh", overflowY: "auto" }}>
      <div style={{ fontSize: "var(--ir-small)", color: "#555", padding: "2px 8px", letterSpacing: 0.5 }}>{pt.label} #{port.gn}{port.label ? ` — ${port.label}` : ""}</div>
      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      <div style={{ fontSize: "var(--ir-small)", color: "#333", padding: "2px 8px", letterSpacing: 0.5 }}>{t("labelDose")}</div>
      <div style={{ padding: "2px 8px", display: "flex", gap: 4 }}>
        <input value={labelVal} onChange={e => setLabelVal(e.target.value)} placeholder="z.B. Büro 201, Dose A..." onKeyDown={e => { if (e.key === "Enter") { onAction("label", labelVal.trim()); onClose(); } }}
          style={{ flex: 1, background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "3px 6px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none" }} />
        <button onClick={() => { onAction("label", labelVal.trim()); onClose(); }}
          style={{ padding: "3px 6px", background: "#10b98115", border: "1px solid #10b98133", color: "#10b981", borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>✓</button>
      </div>
      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      <div style={{ fontSize: "var(--ir-small)", color: "#333", padding: "2px 8px", letterSpacing: 0.5 }}>{t("status")}</div>
      {statuses.map(s => {
        const def = PS[s]; const active = st === s || (s === "free" && !st);
        return (
          <div key={s} onClick={() => { onAction("status", s); onClose(); }}
            style={{ padding: "4px 8px", fontSize: "var(--ir-small)", cursor: "pointer", borderRadius: 4, display: "flex", alignItems: "center", gap: 6, background: active ? "#10b98112" : "transparent", color: active ? "#10b981" : "#888" }}
            onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#ffffff08"; }} onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}>
            <div style={{ width: 8, height: 8, borderRadius: 2, background: def.color || "#333", border: s === "free" ? "1px solid #333" : "none", flexShrink: 0 }} />
            {def.label}{active && <span style={{ marginLeft: "auto", fontSize: "var(--ir-small)" }}>✓</span>}
          </div>);
      })}
      {canPoe && <>
        <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
        <div onClick={() => { onAction("poe", !port.poe); onClose(); }}
          style={{ padding: "4px 8px", fontSize: "var(--ir-small)", cursor: "pointer", borderRadius: 4, display: "flex", alignItems: "center", gap: 6, color: port.poe ? "#f59e0b" : "#888" }}
          onMouseEnter={e => e.currentTarget.style.background = "#ffffff08"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
          ⚡ PoE {port.poe ? "ON" : "OFF"}{port.poe && <span style={{ marginLeft: "auto", fontSize: "var(--ir-small)", color: "#f59e0b" }}>✓</span>}
        </div>
        {port.poe && <div style={{ padding: "2px 8px", display: "flex", alignItems: "center", gap: 4 }} onClick={e => e.stopPropagation()}>
          <span style={{ fontSize: "var(--ir-small)", color: "#f59e0b" }}>W</span>
          <input type="number" min={0} max={90} value={port.watts??""} onFocus={() => onAction("wattsBegin")} onBlur={() => onAction("wattsEnd")} onChange={e => onAction("watts", e.target.value===""?undefined:Number(e.target.value))} placeholder="15.4" style={{ width: 50, background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#f59e0b", padding: "2px 4px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none" }} />
        </div>}
      </>}

      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      <div style={{ fontSize: "var(--ir-small)", color: "#333", padding: "2px 8px", letterSpacing: 0.5 }}>{`🎨 ${t("portColor")}`}</div>
      <div style={{ padding: "2px 8px", display: "flex", gap: 3, flexWrap: "wrap", alignItems: "center" }}>
        {["#3b82f6","#10b981","#f59e0b","#ef4444","#a855f7","#06b6d4","#ec4899","#f97316","#84cc16","#6366f1","#14b8a6","#e11d48"].map(c => (
          <div key={c} onClick={() => { onAction("portColor", c); onClose(); }}
            style={{ width: 14, height: 14, borderRadius: 3, background: c, cursor: "pointer", border: port.portColor === c ? "2px solid #fff" : "1px solid #333", flexShrink: 0 }} />
        ))}
        {port.portColor && <div onClick={() => { onAction("portColor", null); onClose(); }}
          style={{ padding: "2px 5px", fontSize: "var(--ir-small)", color: "#ef4444", cursor: "pointer", border: "1px solid #ef444433", borderRadius: 3, background: "#ef444408" }}>{t("clearColor")}</div>}
      </div>
      {hasOtherRacks && <>
        <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
        <div style={{ fontSize: "var(--ir-small)", color: "#333", padding: "2px 8px", letterSpacing: 0.5 }}>{`🔗 ${t("connectToRack")}`}</div>
        {otherRacks.map(r => (
          <div key={r.id} onClick={() => { onCrossConnect(r.id); onClose(); }}
            style={{ padding: "4px 8px", fontSize: "var(--ir-small)", cursor: "pointer", borderRadius: 4, color: "#a855f7", display: "flex", alignItems: "center", gap: 6 }}
            onMouseEnter={e => e.currentTarget.style.background = "#a855f708"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
            ⬒ {r.name}{r.location ? ` (${r.location})` : ""}
          </div>))}
      </>}
    </div>
  );
}

/* ═══════ PORT GROUP ═══════ */
function PortGroup({ ports, dev, allConns, sp, onPort, onCtx, cm, type, rackLookup, flashPorts, onDblClick, ptColors }) {
  const pt = PT[type] || PT.rj45;
  const ptCol = (ptColors && ptColors[type]) || pt.color;
  const gc = pid => {
    const c = allConns.find(x => (x.fd === dev.id && x.fp === pid) || (x.td === dev.id && x.tp === pid));
    if (!c) return {};
    const f = c.fd === dev.id; const isCross = !!c.rackFrom;
    let label = `${f ? c.tn : c.fn} ${(PT[f?c.tpt2:c.fpt2]||PT.rj45).label}#${f ? c.tpn : c.fpn}`;
    if (isCross) { const rn = rackLookup?.[f ? c.rackTo : c.rackFrom]; if (rn) label = `[${rn}] ${label}`; }
    return { color: cm[c.id], label, isCross };
  };
  const useTwoRows = ports.length >= 8 && (type === "rj45" || type === "rj45_poe" || type === "sfp" || type === "sfp28");
  const renderPort = p => { const { color, label, isCross } = gc(p.id); return <Port key={p.id} port={p} did={dev.id} isSel={sp?.did === dev.id && sp?.pid === p.id} cc={color} cl={label} isCross={isCross} onClick={onPort} onCtx={onCtx} flash={typeof flashPorts?.has === "function" && flashPorts.has(p.id)} onDblClick={onDblClick} prefix={dev.portPrefix} />; };
  if (useTwoRows) {
    const top = ports.filter((_, i) => i % 2 === 0), bot = ports.filter((_, i) => i % 2 === 1);
    return (<div style={{ display: "flex", alignItems: "flex-start", gap: 4 }}>
      <span style={{ fontSize: "var(--ir-small)", color: ptCol, fontWeight: 700, width: 40, flexShrink: 0, fontFamily: "monospace", paddingTop: 4 }}>{pt.label}</span>
      <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>{top.map(renderPort)}</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>{bot.map(renderPort)}</div>
      </div>
    </div>);
  }
  return (<div style={{ display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
    <span style={{ fontSize: "var(--ir-small)", color: ptCol, fontWeight: 700, width: 40, flexShrink: 0, fontFamily: "monospace" }}>{pt.label}</span>
    <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>{ports.map(renderPort)}</div>
  </div>);
}

/* ═══════ DEVICE ROW ═══════ */
function DevRow({ dev, allConns, sp, onPort, onCtx, onDel, onEdit, onMove, onDevCtx, cm, isFirst, isLast, dim, rackLookup, flashPorts, onDblClick, isSelected, onSelect, collapsed, onToggleCollapse, ptColors, onDragStart, onDragOver, onDrop, isDragSource, isDragOver, onDragEnter, onDragLeaveRow, onTouchDragStart }) {
  const devTouchRef = useRef(null);
  const onDevTouchStart = (e) => { devTouchRef.current = setTimeout(() => { const t = e.touches[0]; onDevCtx({ preventDefault:()=>{}, clientX: t.clientX, clientY: t.clientY }, dev); devTouchRef.current = null; }, 500); };
  const onDevTouchEnd = () => { if (devTouchRef.current) { clearTimeout(devTouchRef.current); devTouchRef.current = null; } };
  const h = Math.max(dev.u * 38, 48);
  const gr = {}; dev.ports.forEach(p => { (gr[p.type] = gr[p.type] || []).push(p); });
  const poeCount = dev.ports.filter(p => p.poe).length;
  const stCounts = {}; dev.ports.forEach(p => { const s = p.status || "free"; stCounts[s] = (stCounts[s] || 0) + 1; });
  const hasSpecial = poeCount > 0 || stCounts.reserved || stCounts.disabled || stCounts.faulty;
  const crossCount = allConns.filter(c => c.rackFrom && (c.fd === dev.id || c.td === dev.id)).length;
  const labelCount = dev.ports.filter(p => p.label).length;
  const dragBorder = isDragOver ? `2px solid #10b981` : `1px solid ${isSelected ? dev.color+"66" : dev.color+"28"}`;
  return (
    <div data-devid={dev.id} onContextMenu={e => { e.preventDefault(); onDevCtx(e, dev); }}
      onClick={e => { if (e.ctrlKey || e.metaKey) { e.preventDefault(); onSelect(dev.id, true); } }}
      onTouchStart={onDevTouchStart} onTouchEnd={onDevTouchEnd} onTouchMove={onDevTouchEnd}
      onDragOver={e => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; if (onDragEnter) onDragEnter(dev.id); }}
      onDragLeave={e => { if (!e.currentTarget.contains(e.relatedTarget)) { if (onDragLeaveRow) onDragLeaveRow(); } }}
      onDrop={e => { e.preventDefault(); const fromId = e.dataTransfer.getData("text/plain"); onDrop && onDrop(fromId, dev.id); }}
      style={{ minHeight: h, background: isDragOver ? "#10b98112" : isDragSource ? "#10b98108" : isSelected ? `${dev.color}25` : `linear-gradient(135deg, ${dev.color}0d, ${dev.color}05)`, border: dragBorder, borderRadius: 7, padding: "5px 10px 5px 0", display: "flex", flexDirection: "column", gap: 2, position: "relative", opacity: isDragSource ? 0.4 : dim ? 0.25 : 1, transition: isDragSource ? "opacity 0.2s" : "all 0.15s", boxShadow: isDragOver ? "0 0 12px #10b98133" : "none" }}>
      {isDragOver && <div style={{ position: "absolute", top: -2, left: 0, right: 0, height: 3, background: "#10b981", borderRadius: 2, zIndex: 2 }} />}
      <div style={{ position: "absolute", top: 0, left: 0, width: 4, height: "100%", background: dev.color, borderRadius: "7px 0 0 7px" }} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingLeft: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
          {/* Drag handle */}
          <div draggable onDragStart={e => { e.dataTransfer.setData("text/plain", dev.id); e.dataTransfer.effectAllowed = "move"; if (onDragStart) onDragStart(dev.id); }}
            onDragEnd={() => { if (onDragLeaveRow) onDragLeaveRow(); }}
            onTouchStart={e => onTouchDragStart && onTouchDragStart(dev.id, e)}
            style={{ cursor: "grab", padding: "4px 3px 4px 8px", display: "flex", alignItems: "center", justifyContent: "center", color: "#333", fontSize: "var(--ir-small)", lineHeight: 1, userSelect: "none", touchAction: "none", flexShrink: 0 }}
            role="button" aria-label="Drag to reorder" title="Drag to reorder">⋮⋮</div>
          <span onClick={e => { e.stopPropagation(); onSelect(dev.id, e.ctrlKey || e.metaKey); }} style={{ fontSize: "var(--ir-small)", cursor: "pointer", width: 14, height: 14, borderRadius: 3, border: `1px solid ${isSelected ? "#10b981" : "#1a1a2e"}`, background: isSelected ? "#10b981" : "transparent", display: "flex", alignItems: "center", justifyContent: "center", color: "#000", fontWeight: 900, flexShrink: 0 }}>{isSelected ? "✓" : ""}</span>
          <span style={{ fontSize: "var(--ir-small)" }}>{dev.icon}</span>
          <span style={{ fontSize: "var(--ir-small)", fontWeight: 800, color: dev.color, fontFamily: "monospace" }}>{dev.name}</span>
          <span style={{ fontSize: "var(--ir-small)", color: "#333", fontFamily: "monospace" }}>{dev.preset} · {dev.ports.length}P · {dev.u}U</span>
          {dev.poeBudget > 0 && (() => { const used = dev.ports.reduce((s, p) => s + (p.watts||0), 0); const pct = Math.round(used/dev.poeBudget*100); return (
            <span style={{ fontSize: "var(--ir-small)", color: pct > 90 ? "#ef4444" : pct > 70 ? "#f59e0b" : "#10b981", fontFamily: "monospace" }}>⚡{used}W/{dev.poeBudget}W ({pct}%)</span>
          ); })()}
          {hasSpecial && <span style={{ fontSize: "var(--ir-small)", color: "#555", fontFamily: "monospace" }}>
            {poeCount > 0 && <span style={{ color: "#f59e0b" }}>⚡{poeCount} </span>}
            {stCounts.reserved > 0 && <span style={{ color: "#f59e0b" }}>R:{stCounts.reserved} </span>}
            {stCounts.disabled > 0 && <span style={{ color: "#ef4444" }}>D:{stCounts.disabled} </span>}
            {stCounts.faulty > 0 && <span style={{ color: "#dc2626" }}>F:{stCounts.faulty}</span>}
          </span>}
          {crossCount > 0 && <span style={{ fontSize: "var(--ir-small)", color: "#a855f7" }}>🔗{crossCount}</span>}
          {labelCount > 0 && <span style={{ fontSize: "var(--ir-small)", color: "#10b981" }}>🏷{labelCount}</span>}
          {dev.notes && Object.values(dev.notes).some(v => v) && <span style={{ fontSize: "var(--ir-small)", color: "#a78bfa" }} title={[dev.notes.sn && `S/N: ${dev.notes.sn}`, dev.notes.ip && `IP: ${dev.notes.ip}`, dev.notes.model, dev.notes.firmware && `FW: ${dev.notes.firmware}`, dev.notes.text].filter(Boolean).join(" | ")}>📋</span>}
        </div>
        <div style={{ display: "flex", gap: 1, alignItems: "center" }}>
          {dev.ports.length > 0 && <button onClick={e => { e.stopPropagation(); onToggleCollapse(); }} role="button" aria-label={collapsed ? "Expand ports" : "Collapse ports"} aria-expanded={!collapsed} title={collapsed ? "Expand" : "Collapse"} style={{ background: "none", border: "none", color: "#333", cursor: "pointer", fontSize: "var(--ir-small)", padding: "2px 3px", lineHeight: 1 }}>{collapsed ? "▶" : "▾"}</button>}
          {!isFirst && <button onClick={e => { e.stopPropagation(); onMove(dev.id, -1); }} role="button" aria-label="Move up" title="Move up" style={{ background: "none", border: "none", color: "#333", cursor: "pointer", fontSize: "var(--ir-small)", padding: "2px 3px", lineHeight: 1 }}>▲</button>}
          {!isLast && <button onClick={e => { e.stopPropagation(); onMove(dev.id, 1); }} role="button" aria-label="Move down" title="Move down" style={{ background: "none", border: "none", color: "#333", cursor: "pointer", fontSize: "var(--ir-small)", padding: "2px 3px", lineHeight: 1 }}>▼</button>}
          <button onClick={e => { e.stopPropagation(); onEdit(dev); }} role="button" aria-label="Edit device" title="Edit" style={{ background: "none", border: "none", color: "#555", cursor: "pointer", fontSize: "var(--ir-small)", padding: "2px 4px" }}>✎</button>
          <button onClick={e => { e.stopPropagation(); onDel(dev.id); }} role="button" aria-label="Delete device" title="Delete" style={{ background: "none", border: "none", color: "#282828", cursor: "pointer", fontSize: 14, padding: "0 4px" }}>×</button>
        </div>
      </div>
      {!collapsed && dev.ports.length > 0 && <div style={{ paddingLeft: 8, display: "flex", flexDirection: "column", gap: 2 }}>
        {Object.entries(gr).map(([t, ports]) => <PortGroup key={t} ports={ports} dev={dev} allConns={allConns} sp={sp} onPort={onPort} onCtx={onCtx} cm={cm} type={t} rackLookup={rackLookup} flashPorts={flashPorts} onDblClick={onDblClick} ptColors={ptColors} />)}
      </div>}
    </div>
  );
}

/* ═══════ DEV CONTEXT MENU ═══════ */
function DevCtxMenu({ pos, dev, otherRacks, onMoveToRack, onBatchStatus, onBatchPoe, lang, onBatchColor, onSaveTemplate, onClose, t }) {
  const ref = useRef(null);
  const [showBatch, setShowBatch] = useState(false);
  const [batchRange, setBatchRange] = useState({ from: 1, to: dev.ports.length, status: "reserved" });
  const [showBatchColor, setShowBatchColor] = useState(false);
  const [batchColorRange, setBatchColorRange] = useState({ from: 1, to: dev.ports.length });
  useEffect(() => { const h = e => { if (ref.current && !ref.current.contains(e.target)) onClose(); }; document.addEventListener("mousedown", h); return () => document.removeEventListener("mousedown", h); }, [onClose]);
  return (
    <div className="ir-context" ref={ref} style={{ position: "fixed", left: Math.max(8,Math.min(pos.x,window.innerWidth-310)), top: Math.max(8,Math.min(pos.y,window.innerHeight-440)), zIndex: 1200, background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, borderRadius: 8, padding: 6, minWidth: 200, boxShadow: "0 8px 24px #000a", maxHeight: "70vh", overflowY: "auto" }}>
      <div style={{ fontSize: "var(--ir-small)", color: "#555", padding: "2px 8px", letterSpacing: 0.5 }}>{dev.icon} {dev.name} · {dev.ports.length}P</div>
      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      <div onClick={() => { onSaveTemplate(dev); onClose(); }} style={{ padding: "4px 8px", fontSize: "var(--ir-small)", cursor: "pointer", borderRadius: 4, color: "#10b981", display: "flex", alignItems: "center", gap: 6 }}
        onMouseEnter={e => e.currentTarget.style.background = "#10b98108"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
        {`📌 ${t("saveAsTemplate")}`}
      </div>
      <div onClick={() => setShowBatch(!showBatch)} style={{ padding: "4px 8px", fontSize: "var(--ir-small)", cursor: "pointer", borderRadius: 4, color: "#f59e0b", display: "flex", alignItems: "center", gap: 6 }}
        onMouseEnter={e => e.currentTarget.style.background = "#f59e0b08"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
        {`⚡ ${t("batchPortStatus")} ${showBatch ? "▼" : "▶"}`}
      </div>
      {showBatch && <div style={{ padding: "4px 8px", display: "flex", flexDirection: "column", gap: 4 }}>
        <div style={{ display: "flex", gap: 4, alignItems: "center", fontSize: "var(--ir-small)" }}>
          <span style={{ color: "#555" }}>{t("ports")}</span>
          <input type="number" min={1} max={dev.ports.length} value={batchRange.from} onChange={e => setBatchRange(p => ({ ...p, from: Math.max(1, +e.target.value) }))} style={{ width: 36, background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "2px 4px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit", textAlign: "center" }} />
          <span style={{ color: "#333" }}>—</span>
          <input type="number" min={1} max={dev.ports.length} value={batchRange.to} onChange={e => setBatchRange(p => ({ ...p, to: Math.min(dev.ports.length, +e.target.value) }))} style={{ width: 36, background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "2px 4px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit", textAlign: "center" }} />
        </div>
        <div style={{ display: "flex", gap: 3, flexWrap: "wrap" }}>
          {["free","reserved","disabled","faulty"].map(s => {
            const def = PS[s];
            return <button key={s} onClick={() => { onBatchStatus(dev.id, batchRange.from, batchRange.to, s); onClose(); }}
              style={{ padding: "3px 6px", background: s === "free" ? "#10b98112" : `${def.color}18`, border: `1px solid ${def.color || "#10b981"}33`, color: def.color || "#10b981", borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>
              {def.label} ({dev.ports.filter(p=>p.gn>=batchRange.from&&p.gn<=batchRange.to).length})
            </button>;
          })}
        </div>
        <div style={{ display: "flex", gap: 3 }}>
          <button onClick={() => { setBatchRange({ from: 1, to: dev.ports.length, status: "free" }); }}
            style={{ padding: "2px 5px", background: "none", border: `1px solid ${"#1a1a2e"}`, color: "#333", borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{t("allPorts")}</button>
        </div>
      </div>}

      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      {showBatch&&<div className="rc8-batch-poe"><small>{RC8_CORE_WORDS[lang].batchPoe}</small>{[true,false].map(value=><button key={String(value)} onClick={()=>{onBatchPoe(dev.id,batchRange.from,batchRange.to,value);onClose();}}>{RC8_CORE_WORDS[lang][value?'poeOn':'poeOff']}</button>)}</div>}
      <div onClick={() => setShowBatchColor(!showBatchColor)} style={{ padding: "4px 8px", fontSize: "var(--ir-small)", cursor: "pointer", borderRadius: 4, color: "#06b6d4", display: "flex", alignItems: "center", gap: 6 }}
        onMouseEnter={e => e.currentTarget.style.background = "#06b6d408"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
        {`🎨 ${t("batchPortColor")} ${showBatchColor ? "▼" : "▶"}`}
      </div>
      {showBatchColor && <div style={{ padding: "4px 8px", display: "flex", flexDirection: "column", gap: 4 }}>
        <div style={{ display: "flex", gap: 4, alignItems: "center", fontSize: "var(--ir-small)" }}>
          <span style={{ color: "#555" }}>{t("ports")}</span>
          <input type="number" min={1} max={dev.ports.length} value={batchColorRange.from} onChange={e => setBatchColorRange(p => ({ ...p, from: Math.max(1, +e.target.value) }))} style={{ width: 36, background: "#08080d", border: "1px solid #1a1a2e", color: "#e0e0e0", padding: "2px 4px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit", textAlign: "center" }} />
          <span style={{ color: "#333" }}>—</span>
          <input type="number" min={1} max={dev.ports.length} value={batchColorRange.to} onChange={e => setBatchColorRange(p => ({ ...p, to: Math.min(dev.ports.length, +e.target.value) }))} style={{ width: 36, background: "#08080d", border: "1px solid #1a1a2e", color: "#e0e0e0", padding: "2px 4px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit", textAlign: "center" }} />
          <button onClick={() => setBatchColorRange({ from: 1, to: dev.ports.length })}
            style={{ padding: "2px 5px", background: "none", border: "1px solid #1a1a2e", color: "#555", borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{t("allPorts")}</button>
        </div>
        <div style={{ display: "flex", gap: 3, flexWrap: "wrap", alignItems: "center" }}>
          {["#3b82f6","#10b981","#f59e0b","#ef4444","#a855f7","#06b6d4","#ec4899","#f97316","#84cc16","#6366f1","#14b8a6","#e11d48"].map(c => (
            <div key={c} onClick={() => { onBatchColor(dev.id, batchColorRange.from, batchColorRange.to, c); onClose(); }}
              style={{ width: 16, height: 16, borderRadius: 3, background: c, cursor: "pointer", border: "1px solid #333", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "var(--ir-small)", color: "#fff", fontWeight: 900 }}>
              {dev.ports.filter(p=>p.gn>=batchColorRange.from&&p.gn<=batchColorRange.to).length}
            </div>
          ))}
          <div onClick={() => { onBatchColor(dev.id, batchColorRange.from, batchColorRange.to, null); onClose(); }}
            style={{ padding: "3px 6px", fontSize: "var(--ir-small)", color: "#ef4444", cursor: "pointer", border: "1px solid #ef444433", borderRadius: 3, background: "#ef444408" }}>{`✕ ${t("clearColor")} (${dev.ports.filter(p=>p.gn>=batchColorRange.from&&p.gn<=batchColorRange.to).length})`}</div>
        </div>
      </div>}
      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      {otherRacks.length > 0 ? <>
        <div style={{ fontSize: "var(--ir-small)", color: "#333", padding: "2px 8px", letterSpacing: 0.5 }}>{`📦 ${t("moveToRackHeader")}`}</div>
        {otherRacks.map(r => { const rFreeU = r.size - r.devs.reduce((s,d) => s+d.u, 0); const canFit = rFreeU >= dev.u;
          return (<div key={r.id} onClick={() => { if (canFit) { onMoveToRack(dev.id, r.id); onClose(); } }}
            style={{ padding: "4px 8px", fontSize: "var(--ir-small)", cursor: canFit ? "pointer" : "not-allowed", borderRadius: 4, color: canFit ? "#a855f7" : "#333", display: "flex", alignItems: "center", gap: 6, opacity: canFit ? 1 : 0.5 }}
            onMouseEnter={e => { if (canFit) e.currentTarget.style.background = "#a855f708"; }} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
            ⬒ {r.name}{r.location ? ` (${r.location})` : ""}<span style={{ marginLeft: "auto", fontSize: "var(--ir-small)", color: "#333" }}>{`${rFreeU} ${t("uFree")}`}</span>
          </div>);
        })}
      </> : <div style={{ padding: "4px 8px", fontSize: "var(--ir-small)", color: "#333" }}>{t("noOtherRacks")}</div>}
    </div>
  );
}

/* ═══════ BULK CONNECT MODAL ═══════ */
function BulkConnectModal({ devs, conns, allConns, onBulk, onClose, t, lang }) {
  const [srcDev, setSrcDev] = useState("");
  const [tgtDev, setTgtDev] = useState("");
  const [srcType, setSrcType] = useState("");
  const [tgtType, setTgtType] = useState("");
  const [srcFrom, setSrcFrom] = useState(1);
  const [tgtFrom, setTgtFrom] = useState(1);
  const [count, setCount] = useState(0);
  const sd = devs.find(d => d.id === srcDev), td = devs.find(d => d.id === tgtDev);
  const srcTypes = sd ? [...new Set(sd.ports.map(p => p.type))] : [];
  const tgtTypes = td ? [...new Set(td.ports.map(p => p.type))] : [];
  const srcPorts = sd ? sd.ports.filter(p => p.type === srcType) : [];
  const tgtPorts = td ? td.ports.filter(p => p.type === tgtType) : [];
  const connSet = new Set([...allConns.map(c=>c.fp), ...allConns.map(c=>c.tp)]);
  const freeSrc = srcPorts.filter(p => !connSet.has(p.id) && (!p.status || p.status === "free" || p.status === "reserved"));
  const freeTgt = tgtPorts.filter(p => !connSet.has(p.id) && (!p.status || p.status === "free" || p.status === "reserved"));
  const maxCount = Math.min(freeSrc.length - (srcFrom-1), freeTgt.length - (tgtFrom-1));
  useEffect(() => { if (srcType && srcTypes.length && !srcTypes.includes(srcType)) setSrcType(srcTypes[0]||""); }, [srcDev]);
  useEffect(() => { if (tgtType && tgtTypes.length && !tgtTypes.includes(tgtType)) setTgtType(tgtTypes[0]||""); }, [tgtDev]);
  useEffect(() => { setCount(Math.max(0, Math.min(count, maxCount))); }, [srcFrom, tgtFrom, srcType, tgtType, srcDev, tgtDev]);
  useEffect(() => { if (maxCount > 0 && count === 0) setCount(maxCount); }, [maxCount]);
  const preview = [];
  for (let i = 0; i < count; i++) { const sp = freeSrc[srcFrom-1+i], tp = freeTgt[tgtFrom-1+i]; if (sp && tp) preview.push({ sp, tp }); }
  const ss = { background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "5px 8px", borderRadius: 4, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", width: "100%", boxSizing: "border-box" };
  return (
    <div className="ir-modal" onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, borderRadius: 12, padding: 20, width: 420, maxHeight: "85vh", overflowY: "auto" }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#10b981", marginBottom: 14 }}>⚡ BULK CONNECT (1:1)</div><p className="rc8-bulk-hint">{RC8_CORE_WORDS[lang].bulkHint}</p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
          <div>
            <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("srcDevice")}</label>
            <select value={srcDev} onChange={e => { setSrcDev(e.target.value); setSrcType(""); setSrcFrom(1); }} style={ss}>
              <option value="">{t("select")}</option>
              {devs.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
            {srcTypes.length > 0 && <><label style={{ fontSize: "var(--ir-small)", color: "#555", marginTop: 4, display: "block" }}>{t("portType")}</label>
              <select value={srcType} onChange={e => { setSrcType(e.target.value); setSrcFrom(1); }} style={ss}>
                <option value="">{t("select")}</option>
                {srcTypes.map(t => <option key={t} value={t}>{(PT[t]||PT.rj45).label} ({sd.ports.filter(p=>p.type===t).length})</option>)}
              </select></>}
            {freeSrc.length > 0 && <><label style={{ fontSize: "var(--ir-small)", color: "#555", marginTop: 4, display: "block" }}>START AT #{freeSrc.length} free</label>
              <input type="number" min={1} max={freeSrc.length} value={srcFrom} onChange={e => setSrcFrom(Math.max(1, +e.target.value))} style={ss} /></>}
          </div>
          <div>
            <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("tgtDevice")}</label>
            <select value={tgtDev} onChange={e => { setTgtDev(e.target.value); setTgtType(""); setTgtFrom(1); }} style={ss}>
              <option value="">{t("select")}</option>
              {devs.filter(d => d.id !== srcDev).map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
            {tgtTypes.length > 0 && <><label style={{ fontSize: "var(--ir-small)", color: "#555", marginTop: 4, display: "block" }}>{t("portType")}</label>
              <select value={tgtType} onChange={e => { setTgtType(e.target.value); setTgtFrom(1); }} style={ss}>
                <option value="">{t("select")}</option>
                {tgtTypes.map(t => <option key={t} value={t}>{(PT[t]||PT.rj45).label} ({td.ports.filter(p=>p.type===t).length})</option>)}
              </select></>}
            {freeTgt.length > 0 && <><label style={{ fontSize: "var(--ir-small)", color: "#555", marginTop: 4, display: "block" }}>START AT #{freeTgt.length} free</label>
              <input type="number" min={1} max={freeTgt.length} value={tgtFrom} onChange={e => setTgtFrom(Math.max(1, +e.target.value))} style={ss} /></>}
          </div>
        </div>
        {maxCount > 0 && <div style={{ marginBottom: 12 }}>
          <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>COUNT ({maxCount} max)</label>
          <input type="number" min={1} max={maxCount} value={count} onChange={e => setCount(Math.max(1, Math.min(maxCount, +e.target.value)))} style={ss} />
        </div>}
        {preview.length > 0 && <div style={{ maxHeight: 160, overflowY: "auto", marginBottom: 12, background: "#08080d", borderRadius: 6, padding: 6 }}>
          <div style={{ fontSize: "var(--ir-small)", color: "#333", marginBottom: 4 }}>PREVIEW ({preview.length} connections)</div>
          {preview.map((p, i) => (
            <div key={i} style={{ fontSize: "var(--ir-small)", color: "#666", padding: "2px 4px", display: "flex", gap: 4 }}>
              <span style={{ color: "#10b981" }}>#{p.sp.gn}{p.sp.label ? ` (${p.sp.label})` : ""}</span>
              <span style={{ color: "#333" }}>→</span>
              <span style={{ color: "#3b82f6" }}>#{p.tp.gn}{p.tp.label ? ` (${p.tp.label})` : ""}</span>
            </div>))}
        </div>}
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => { if (preview.length > 0) onBulk(sd, td, preview); }} disabled={preview.length === 0}
            style={{ flex: 1, padding: "8px", background: preview.length > 0 ? "#10b98115" : "#111", border: `1px solid ${preview.length > 0 ? "#10b981" : "#222"}`, color: preview.length > 0 ? "#10b981" : "#333", borderRadius: 6, cursor: preview.length > 0 ? "pointer" : "default", fontSize: "var(--ir-small)", fontWeight: 700, fontFamily: "inherit" }}>⚡ Connect {preview.length}</button>
          <button onClick={onClose} style={{ flex: 1, padding: "8px", background: "#ffffff06", border: "1px solid #222", color: "#555", borderRadius: 6, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{t("cancel")}</button>
        </div>
      </div>
    </div>
  );
}

/* ═══════ EDIT MODALS ═══════ */
function EditModal({ dev, onSave, onClose, t }) {
  const [name, setName] = useState(dev.name);
  const [icon, setIcon] = useState(dev.icon);
  const [poeBudget, setPoeBudget] = useState(dev.poeBudget || 0);
  const [u, setU] = useState(dev.u);
  const [showIcons, setShowIcons] = useState(false);
  const [notes, setNotes] = useState(dev.notes || { sn: "", ip: "", model: "", firmware: "", text: "" });
  const [showNotes, setShowNotes] = useState(!!(dev.notes && Object.values(dev.notes).some(v => v)));
  const [showPorts, setShowPorts] = useState(false);
  const [portPrefix, setPortPrefix] = useState(dev.portPrefix || "");
  // Build port groups from existing ports
  const buildGroups = () => { const gm = {}; dev.ports.forEach(p => { const t = p.type === "rj45_poe" ? "rj45_poe" : p.type; (gm[t] = gm[t] || []).push(p); }); return Object.entries(gm).map(([t, ps]) => ({ t, n: ps.length, ids: ps.map(p => p.id) })); };
  const [portGroups, setPortGroups] = useState(buildGroups);
  const totalNewPorts = portGroups.reduce((s, g) => s + g.n, 0);
  const ns = { width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "5px 8px", borderRadius: 4, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 6 };
  return (
    <div className="ir-modal" onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, borderRadius: 12, padding: 20, width: 360, maxHeight: "85vh", overflowY: "auto" }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#10b981", marginBottom: 14 }}>✎ EDIT DEVICE</div>
        <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("name")}</label>
        <input value={name} onChange={e => setName(e.target.value)} autoFocus style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "7px 9px", borderRadius: 5, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 10 }} />
        <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("sizeU")}</label>
        <input type="number" min={1} max={12} value={u} onChange={e => setU(Math.max(1, +e.target.value))} style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "6px 9px", borderRadius: 5, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 10 }} />
        {dev.ports.some(p => p.poe || p.type === "rj45_poe") && <div style={{ marginBottom: 10 }}>
          <label style={{ fontSize: "var(--ir-small)", color: "#555", letterSpacing: 0.5 }}>⚡ POE BUDGET (WATTS)</label>
          <input type="number" min={0} max={9999} value={poeBudget} onChange={e => setPoeBudget(Math.max(0, +e.target.value))} placeholder="370" style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#f59e0b", padding: "6px 9px", borderRadius: 5, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", boxSizing: "border-box" }} />
        </div>}
        <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("icon")}</label>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
          <div onClick={() => setShowIcons(!showIcons)} style={{ width: 36, height: 36, background: "#08080d", border: `1px solid ${"#1a1a2e"}`, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, cursor: "pointer" }}>{icon}</div>
          {showIcons && <div style={{ display: "flex", flexWrap: "wrap", gap: 4, flex: 1 }}>
            {ICONS.map(ic => <div key={ic} onClick={() => { setIcon(ic); setShowIcons(false); }} style={{ width: 28, height: 28, background: ic === icon ? "#10b98122" : "#08080d", border: `1px solid ${ic === icon ? "#10b981" : "#1a1a2e"}`, borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, cursor: "pointer" }}>{ic}</div>)}
          </div>}
        </div>
        <div onClick={() => setShowNotes(!showNotes)} style={{ fontSize: "var(--ir-small)", color: "#555", cursor: "pointer", marginBottom: 8, display: "flex", alignItems: "center", gap: 4 }}>
          <span style={{ fontSize: "var(--ir-small)" }}>{showNotes ? "▼" : "▶"}</span> 📋 Equipment Details {Object.values(notes).some(v => v) && <span style={{ color: "#10b981", fontSize: "var(--ir-small)" }}>●</span>}
        </div>
        {showNotes && <div style={{ padding: "8px", background: "#08080d", borderRadius: 6, border: `1px solid ${"#1a1a2e"}`, marginBottom: 10 }}>
          <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("serialNumber")}</label>
          <input value={notes.sn} onChange={e => setNotes(p => ({ ...p, sn: e.target.value }))} placeholder="FOC2345X1YZ" style={ns} />
          <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("ipAddress")}</label>
          <input value={notes.ip} onChange={e => setNotes(p => ({ ...p, ip: e.target.value }))} placeholder="192.168.1.1" style={ns} />
          <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("model")}</label>
          <input value={notes.model} onChange={e => setNotes(p => ({ ...p, model: e.target.value }))} placeholder="Cisco C9300-48P" style={ns} />
          <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("firmware")}</label>
          <input value={notes.firmware} onChange={e => setNotes(p => ({ ...p, firmware: e.target.value }))} placeholder="IOS-XE 17.9.4" style={ns} />
          <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("notes")}</label>
          <textarea value={notes.text} onChange={e => setNotes(p => ({ ...p, text: e.target.value }))} placeholder={t("freeNotes")} rows={2} style={{ ...ns, resize: "vertical" }} />
        </div>}
        <div onClick={() => setShowPorts(!showPorts)} style={{ fontSize: "var(--ir-small)", color: "#555", cursor: "pointer", marginBottom: 8, display: "flex", alignItems: "center", gap: 4 }}>
          <span style={{ fontSize: "var(--ir-small)" }}>{showPorts ? "▼" : "▶"}</span> 🔌 Port Configuration <span style={{ fontSize: "var(--ir-small)", color: "#10b981" }}>({totalNewPorts}P)</span>
        </div>
        {showPorts && <div style={{ padding: "8px", background: "#08080d", borderRadius: 6, border: `1px solid ${"#1a1a2e"}`, marginBottom: 10 }}>
          <div style={{ display: "flex", gap: 4, alignItems: "center", marginBottom: 6 }}>
            <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("prefix")}</label>
            <input value={portPrefix} onChange={e => setPortPrefix(e.target.value)} placeholder="z.B. A, Gi0/, Eth" style={{ width: 70, background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "3px 4px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit" }} />
            <span style={{ fontSize: "var(--ir-small)", color: "#333" }}>→ {portPrefix}1, {portPrefix}2...</span>
          </div>
          {portGroups.map((g, gi) => (
            <div key={gi} style={{ display: "flex", gap: 4, alignItems: "center", marginBottom: 4 }}>
              <select value={g.t} onChange={e => setPortGroups(prev => prev.map((x, i) => i === gi ? { ...x, t: e.target.value } : x))} style={{ flex: 1, background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "3px 4px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit" }}>
                {Object.entries(PT).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
              <input type="number" min={1} max={96} value={g.n} onChange={e => setPortGroups(prev => prev.map((x, i) => i === gi ? { ...x, n: Math.max(1, +e.target.value) } : x))} style={{ width: 42, background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "3px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit", textAlign: "center" }} />
              <span style={{ fontSize: "var(--ir-small)", color: "#333" }}>ports</span>
              {portGroups.length > 1 && <button onClick={() => setPortGroups(prev => prev.filter((_, i) => i !== gi))} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: "var(--ir-small)", padding: "0 2px" }}>×</button>}
            </div>
          ))}
          <button onClick={() => setPortGroups(prev => [...prev, { t: "rj45", n: 4 }])} style={{ padding: "3px 6px", background: "none", border: `1px dashed ${"#1a1a2e"}`, color: "#555", borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit", width: "100%", marginTop: 2 }}>{"+ "+t("portGroups")}</button>
          {totalNewPorts !== dev.ports.length && <div style={{ fontSize: "var(--ir-small)", color: "#f59e0b", marginTop: 4 }}>⚠️ Port count changed: {dev.ports.length} → {totalNewPorts}. Existing connections on removed ports will be deleted.</div>}
        </div>}
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => { const cleanNotes = Object.values(notes).some(v => v) ? notes : undefined; onSave({ name: name.trim() || dev.name, icon, u, notes: cleanNotes, portGroups, portPrefix: portPrefix || undefined, poeBudget: poeBudget || undefined }); }} style={{ flex: 1, padding: "8px", background: "#10b98115", border: "1px solid #10b981", color: "#10b981", borderRadius: 6, cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: 700, fontFamily: "inherit" }}>{t("saveBtn")}</button>
          <button onClick={onClose} style={{ flex: 1, padding: "8px", background: "#ffffff06", border: "1px solid #222", color: "#555", borderRadius: 6, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{t("cancel")}</button>
        </div>
      </div>
    </div>
  );
}

function RackEditModal({ rack, onSave, onClose, onDelete, t, locations=[] }) {
  const [name, setName] = useState(rack.name);
  const [loc, setLoc] = useState(rack.location || "");
  const [size, setSize] = useState(rack.size);
  const usedU = rack.devs.reduce((s, d) => s + d.u, 0);
  return (
    <div className="ir-modal" onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, borderRadius: 12, padding: 20, width: 340 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#10b981", marginBottom: 14 }}>✎ EDIT RACK</div>
        <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("rackName")}</label>
        <input value={name} onChange={e => setName(e.target.value)} autoFocus style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "7px 9px", borderRadius: 5, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 10 }} />
        <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("location")}</label>
        <input list="rc8-rack-locations" value={loc} onChange={e => setLoc(e.target.value)} placeholder={t("location")} style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "7px 9px", borderRadius: 5, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 4 }} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: 3, marginBottom: 10 }}>
          {[...new Set([...locations.flatMap(l=>[l.site,l.building,l.room]),...LOC_SUGGEST].filter(Boolean))].filter(l => !loc || l.toLowerCase().includes(loc.toLowerCase())).slice(0, 8).map(l => (
            <button key={l} onClick={() => setLoc(l)} style={{ padding: "2px 7px", background: loc === l ? "#10b98118" : "#08080d", border: `1px solid ${loc === l ? "#10b981" : "#1a1a2e"}`, color: loc === l ? "#10b981" : "#555", borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{l}</button>
          ))}
        </div>
        <label style={{ fontSize: "var(--ir-small)", color: "#555" }}>{t("sizeU")}</label>
        <datalist id="rc8-rack-locations">{[...new Set(locations.flatMap(l=>[l.site,l.building,l.room,[l.site,l.building,l.room].filter(Boolean).join(" / ")]).filter(Boolean))].map(l=><option key={l} value={l}/>)}</datalist><select value={size} onChange={e => { const n = +e.target.value; if (n < usedU) return; setSize(n); }} style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "6px 9px", borderRadius: 5, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 14 }}>
          {RSZ.map(s => <option key={s} value={s} disabled={s < usedU}>{s}U{s < usedU ? ` (need ${usedU}U)` : ""}</option>)}
        </select>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => onSave({ name: name.trim() || rack.name, location: loc.trim(), size })} style={{ flex: 1, padding: "8px", background: "#10b98115", border: "1px solid #10b981", color: "#10b981", borderRadius: 6, cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: 700, fontFamily: "inherit" }}>{t("saveBtn")}</button>
          <button onClick={onClose} style={{ flex: 1, padding: "8px", background: "#ffffff06", border: "1px solid #222", color: "#555", borderRadius: 6, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{t("cancel")}</button>
        </div>
        {onDelete && <button onClick={() => { if (confirm(t("confirmDeleteRack", {name: rack.name}))) onDelete(rack.id); }} style={{ width: "100%", marginTop: 10, padding: "7px", background: "#ef444408", border: "1px solid #ef444433", color: "#ef444488", borderRadius: 6, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{`🗑 ${t("deleteRack")}`}</button>}
      </div>
    </div>
  );
}

/* ═══════ RACK VISUAL (for Reports) ═══════ */
function RackVisual({ rack, allConns, cm, lang }) {
  const S = { bg: "#f8f9fb", bdr: "#e5e7eb" };
  const usedU = rack.devs.reduce((s, d) => s + d.u, 0);
  return (
    <div style={{ background: "#1a1c2e", borderRadius: 8, padding: 8, border: `1px solid ${S.bdr}`, maxWidth: 500, margin: "0 auto 16px" }}>
      <div style={{ padding: "4px 8px", borderBottom: `1px solid ${"#2a2c3e"}`, display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
        <span style={{ fontSize: "var(--ir-small)", fontWeight: 700, color: "#8a8ca0", letterSpacing: 1 }}>{rack.name.toUpperCase()}</span>
        <span style={{ fontSize: "var(--ir-small)", color: "#555" }}>{usedU}/{rack.size}U</span>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {rack.devs.map(d => {
          const h = Math.max(d.u * 18, 20);
          const dc = allConns.filter(c => c.fd === d.id || c.td === d.id);
          const connPorts = new Set([...dc.map(c => c.fd === d.id ? c.fp : c.tp)]);
          const gr = {}; d.ports.forEach(p => { (gr[p.type] = gr[p.type] || []).push(p); });
          return (
            <div key={d.id} style={{ minHeight: h, background: `${d.color}18`, borderLeft: `3px solid ${d.color}`, borderRadius: 3, padding: "3px 6px", display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontSize: "var(--ir-small)", width: 14, textAlign: "center" }}>{d.icon}</span>
              <span style={{ fontSize: "var(--ir-small)", fontWeight: 700, color: d.color, minWidth: 80, fontFamily: "monospace" }}>{d.name}</span>
              <div style={{ display: "flex", gap: 3, flexWrap: "wrap", flex: 1 }}>
                {Object.entries(gr).map(([t, ports]) => (
                  <div key={t} style={{ display: "flex", gap: 1, alignItems: "center" }}>
                    <span style={{ fontSize: "var(--ir-small)", color: (PT[t]||PT.rj45).color, marginRight: 1 }}>{(PT[t]||PT.rj45).label.substring(0,3)}</span>
                    {ports.map(p => {
                      const isConn = connPorts.has(p.id);
                      const c = isConn ? dc.find(c => c.fp === p.id || c.tp === p.id) : null;
                      const col = c ? cm[c.id] || "#555" : "transparent";
                      return <div key={p.id} style={{ width: 4, height: 4, borderRadius: 1, background: isConn ? col : "#2a2c3e", border: `0.5px solid ${isConn ? col : "#333"}` }} title={`#${p.gn}${p.label ? ` ${p.label}` : ""}${isConn ? " ●" : ""}`} />;
                    })}
                  </div>
                ))}
              </div>
              <span style={{ fontSize: "var(--ir-small)", color: "#555" }}>{d.u}U</span>
            </div>
          );
        })}
        {rack.size - usedU > 0 && <div style={{ height: Math.min((rack.size - usedU) * 8, 32), borderRadius: 3, border: `1px dashed ${"#2a2c3e"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "var(--ir-small)", color: "#333" }}>{`${rack.size - usedU}U ${lang==="de"?"frei":lang==="es"?"libre":"free"}`}</div>}
      </div>
    </div>
  );
}

function RackVisualPNG({ rack, allConns, cm, lang, scale = 2, start = true, onReady }) {
  const [src, setSrc] = useState(null);
  const [err, setErr] = useState(null);
  const wrapRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    if (!start) return;
    const run = async () => {
      setErr(null);
      setSrc(null);
      let h2c = window.html2canvas;
      if (!h2c) {
        try { h2c = (await import("html2canvas")).default; } catch {}
      }
      if (!wrapRef.current) { setErr("No export node"); onReady && onReady(false); return; }
      if (!h2c) { setErr("html2canvas missing"); onReady && onReady(false); return; }

      // Espera 1-2 frames para asegurar layout
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

      try {
        const canvas = await h2c(wrapRef.current, {
          scale,
          backgroundColor: "#ffffff",
          useCORS: true,
          allowTaint: true,
          logging: false
        });
        if (!cancelled) setSrc(canvas.toDataURL("image/png"));
        onReady && onReady(true);
      } catch (e) {
        console.error(e);
        setErr(String(e && e.message ? e.message : e));
        onReady && onReady(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, [start, rack.id, rack.size, (rack.devs||[]).length, allConns.length, scale, lang]);

  return (
    <div style={{ maxWidth: 500, margin: "0 auto 16px" }}>
      {!src && <div ref={wrapRef}><RackVisual rack={rack} allConns={allConns} cm={cm} lang={lang} /></div>}
      {src && <img src={src} alt="Rack preview" style={{ width: "100%", display: "block", borderRadius: 8, border: "1px solid #e5e7eb" }} />}
    </div>
  );
}

/* ═══════ RACK DETAIL SNAPSHOT (for Project Report PNG) ═══════ */
function RackDetailSnapshot({ rack, allConns, cm, lang, T, ptColors, rackFace = "front" }) {
  const devs = rack.devs || [];
  const usedU = devs.reduce((s, d) => s + d.u, 0);
  const freeU = Math.max(0, (rack.size || 0) - usedU);
  const displayDevs = rackFace === "rear" ? [...devs].reverse() : devs;

  const rearLabel = lang === "de" ? "Rückansicht" : lang === "es" ? "Vista trasera" : "Rear view";
  const noDevices = lang === "de" ? "Keine Geräte" : lang === "es" ? "Sin dispositivos" : "No devices";
  const uFree = lang === "de" ? "U frei" : lang === "es" ? "U libre" : "U free";
  const no = () => {};

  return (
    <div className="rc-export" style={{ background: (T.bg2 || "#fff"), border: `1px solid ${(T.bdr || "#e5e7eb")}`, borderRadius: 10, padding: 12, color: (T.txt || "#111") }}>
      <style>{`
        .rc-export button{display:none!important}
        .rc-export [draggable="true"]{display:none!important}
        .rc-export input[type="checkbox"]{display:none!important}
      `}</style>

      {rackFace === "rear" && (
        <div style={{ textAlign: "center", padding: "4px 0", fontSize: "var(--ir-small)", color: "#a855f7", background: "#a855f708", borderRadius: 4, letterSpacing: 1, fontWeight: 700 }}>
          {`▥ ${rearLabel}`}
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {(() => {
          let uPos = 1;
          return displayDevs.map((d, i) => {
            const startU = uPos; uPos += d.u;
            return (
              <div key={d.id} style={{ display: "flex", gap: 0 }}>
                <div style={{ width: 28, minWidth: 28, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", gap: 0, flexShrink: 0 }}>
                  {Array.from({ length: d.u }, (_, ui) => (
                    <div key={ui} style={{ fontSize: "var(--ir-small)", color: (T.vdim || T.dim || "#6b7280"), height: Math.max(38, 48 / d.u), display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "monospace", lineHeight: 1 }}>
                      {startU + ui}
                    </div>
                  ))}
                </div>
                <div style={{ flex: 1 }}>
                  <DevRow
                    dev={d}
                    allConns={allConns}
                    sp={null}
                    onPort={no}
                    onCtx={no}
                    onDel={no}
                    onEdit={no}
                    onMove={no}
                    onDevCtx={no}
                    cm={cm}
                    isFirst={i === 0}
                    isLast={i === displayDevs.length - 1}
                    dim={false}
                    rackLookup={{}}
                    flashPorts={null}
                    onDblClick={no}
                    isSelected={false}
                    onSelect={no}
                    collapsed={false}
                    onToggleCollapse={no}
                    ptColors={ptColors}
                    onDrop={no}
                    onDragStart={no}
                    onDragEnter={no}
                    onDragLeaveRow={no}
                    isDragSource={false}
                    isDragOver={false}
                  />
                </div>
              </div>
            );
          });
        })()}

        {devs.length === 0 && (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 120, color: (T.vdim || T.dim || "#6b7280"), fontSize: 12 }}>
            {noDevices}
          </div>
        )}

        {freeU > 0 && devs.length > 0 && (
          <div style={{ display: "flex", gap: 0 }}>
            <div style={{ width: 28, minWidth: 28, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "var(--ir-small)", color: (T.bdr || "#9ca3af"), fontFamily: "monospace" }}>
              {usedU + 1}
            </div>
            <div style={{ flex: 1, height: Math.min(freeU * 12, 48), border: `1px dashed ${(T.bdr || "#e5e7eb")}`, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "var(--ir-small)", color: (T.bdr || "#9ca3af"), marginTop: 4 }}>
              {`${freeU} ${uFree}`}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function RackDetailPNG({ rack, allConns, cm, lang, T, ptColors, rackFace = "front", scale = 2.5, start = true, onReady }) {
  const [src, setSrc] = useState(null);
  const [err, setErr] = useState(null);
  const wrapRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    if (!start) return;
    const run = async () => {
      setErr(null);
      setSrc(null);
      let h2c = window.html2canvas;
      if (!h2c) {
        try { h2c = (await import("html2canvas")).default; } catch {}
      }
      if (!wrapRef.current) { setErr("No export node"); onReady && onReady(false); return; }
      if (!h2c) { setErr("html2canvas missing"); onReady && onReady(false); return; }

      // Espera 1-2 frames para asegurar layout
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

      try {
        const canvas = await h2c(wrapRef.current, {
          scale,
          backgroundColor: "#ffffff",
          useCORS: true,
          allowTaint: true,
          logging: false
        });
        if (!cancelled) setSrc(canvas.toDataURL("image/png"));
        onReady && onReady(true);
      } catch (e) {
        console.error(e);
        setErr(String(e && e.message ? e.message : e));
        onReady && onReady(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, [start, rack.id, rack.size, (rack.devs||[]).length, allConns.length, lang, rackFace, scale]);

  return (
    <div style={{ maxWidth: 780, margin: "0 auto 16px" }}>
      {!src && (
        <div style={{ fontSize: "var(--ir-small)", color: err ? "#ef4444" : "#9ca3af", textAlign: "center", padding: "10px 0" }}>
          {err ? (lang==="de"?"PNG Fehler: ":lang==="es"?"Error PNG: ":"PNG error: ") + err : (start ? (lang==="de"?"PNG wird erzeugt…":lang==="es"?"Generando PNG…":"Generating PNG…") : (lang==="de"?"Wartet…":lang==="es"?"En cola…":"Queued…"))}
        </div>
      )}

      <div ref={wrapRef} style={{ width: 760, margin: "0 auto", display: src ? "none" : "block" }}>
        <RackDetailSnapshot rack={rack} allConns={allConns} cm={cm} lang={lang} T={T} ptColors={ptColors} rackFace={rackFace} />
      </div>

      {src && <img src={src} alt="Rack detailed preview" style={{ width: "100%", display: "block", borderRadius: 10, border: "1px solid #e5e7eb" }} />}
    </div>
  );
}


// ─────────────────────────────────────────────────────────────────────────────
// FAST PNG PREVIEW (canvas, no SVG, no html2canvas) — used in Project Report
// ─────────────────────────────────────────────────────────────────────────────
function _hexToRgba(hex, a) {
  try {
    if (!hex || typeof hex !== "string") return `rgba(148,163,184,${a})`;
    let h = hex.trim();
    if (h[0] === "#") h = h.slice(1);
    if (h.length === 3) h = h.split("").map(ch => ch + ch).join("");
    if (h.length !== 6) return `rgba(148,163,184,${a})`;
    const r = parseInt(h.slice(0, 2), 16);
    const g = parseInt(h.slice(2, 4), 16);
    const b = parseInt(h.slice(4, 6), 16);
    return `rgba(${r},${g},${b},${a})`;
  } catch {
    return `rgba(148,163,184,${a})`;
  }
}
function _roundRect(ctx, x, y, w, h, r, fill = true, stroke = false) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

function rackPreviewToPNGDataURL(rack, allConns, cm, rackFace = "front", opts = {}) {
  const scale = Math.max(1, Number(opts.scale || 2));
  const bg = opts.bg || "#ffffff";

  const sizeU = Math.max(1, Number(rack.size || 42));
  const devs = (rack.devs || []).slice();

  // Layout
  const pad = 22;
  const leftU = 34;
  const topH = 70;
  const uH = 14; // px per U
  const W = 980;
  const H = topH + (sizeU * uH) + pad;

  const canvas = document.createElement("canvas");
  canvas.width = Math.round(W * scale);
  canvas.height = Math.round(H * scale);
  const ctx = canvas.getContext("2d");
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  ctx.imageSmoothingEnabled = true;

  // Background
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // Header
  ctx.fillStyle = "#111827";
  ctx.font = "800 28px system-ui, -apple-system, Segoe UI, Roboto, Arial";
  ctx.fillText(rack.name || "Rack", pad, 36);

  ctx.fillStyle = "#6b7280";
  ctx.font = "600 12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
  const subtitle = `${(rack.location ? rack.location + " · " : "")}${sizeU}U · ${devs.length} dev`;
  ctx.fillText(subtitle, pad, 56);

  // Grid bounds
  const gridX = pad + leftU;
  const gridY = topH;
  const gridW = W - pad * 2 - leftU;
  const gridH = sizeU * uH;

  // Outer grid
  ctx.strokeStyle = "#e5e7eb";
  ctx.lineWidth = 1;
  ctx.strokeRect(gridX, gridY, gridW, gridH);

  // U lines + labels
  ctx.font = "600 10px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace";
  for (let u = 1; u <= sizeU; u++) {
    const y = gridY + (u - 1) * uH;
    ctx.strokeStyle = (u % 2 === 0) ? "#f1f5f9" : "#f8fafc";
    ctx.beginPath();
    ctx.moveTo(gridX, y);
    ctx.lineTo(gridX + gridW, y);
    ctx.stroke();

    if (u === 1 || u === sizeU || (u % 5 === 0)) {
      ctx.fillStyle = "#9ca3af";
      ctx.fillText(String(u), pad + 3, y + uH - 3);
    }
  }

  // Connection lookup by port id (for coloring)
  const dc = (allConns || []).filter(c => c.fr === rack.id || c.tr === rack.id);
  const byPort = new Map();
  dc.forEach(c => {
    if (c.fp) byPort.set(c.fp, c);
    if (c.tp) byPort.set(c.tp, c);
  });

  // Devices
  let uPos = 1;
  devs.forEach(d => {
    const u = Math.max(1, Number(d.u || 1));
    const y = gridY + (uPos - 1) * uH + 1;
    const h = (u * uH) - 2;
    uPos += u;

    const color = d.color || "#94a3b8";
    const x = gridX + 1;
    const w = gridW - 2;

    // Fill + border
    ctx.fillStyle = _hexToRgba(color, 0.14);
    _roundRect(ctx, x, y, w, h, 8, true, false);
    ctx.strokeStyle = _hexToRgba(color, 0.35);
    _roundRect(ctx, x, y, w, h, 8, false, true);

    // Left strip
    ctx.fillStyle = color;
    ctx.fillRect(x, y, 5, h);

    // Device label
    ctx.fillStyle = "#111827";
    ctx.font = "800 12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    const label = `${d.icon ? (d.icon + " ") : ""}${d.name || "Device"}`;
    ctx.fillText(label, x + 10, y + 14);

    // Ports (small squares)
    const sq = 8, gap = 2;
    const px = x + 10;
    const py = y + 20;

    const portsAll = (d.ports || []).filter(p => {
      if (!p) return false;
      // If a port declares a face, try to respect the rack view
      if (!p.face) return true;
      if (p.face === "both") return true;
      return p.face === rackFace;
    });

    if (portsAll.length > 0 && h >= 26) {
      const maxRows = Math.max(1, Math.min(3, Math.floor((h - 22) / (sq + gap))));
      const perRow = Math.max(6, Math.floor((w - 20) / (sq + gap)));
      const maxSq = maxRows * perRow;

      for (let i = 0; i < Math.min(maxSq, portsAll.length); i++) {
        const p = portsAll[i];
        const row = Math.floor(i / perRow);
        const col = i % perRow;
        const rx = px + col * (sq + gap);
        const ry = py + row * (sq + gap);

        const c = byPort.get(p.id);
        const colr = c ? ((cm && cm[c.id]) || c.color || "#10b981") : (p.portColor || "#cbd5e1");

        ctx.fillStyle = colr;
        ctx.fillRect(rx, ry, sq, sq);
        ctx.strokeStyle = "#94a3b8";
        ctx.lineWidth = 0.5;
        ctx.strokeRect(rx + 0.25, ry + 0.25, sq - 0.5, sq - 0.5);
      }

      // "+N" indicator if too many ports
      if (portsAll.length > maxSq) {
        ctx.fillStyle = "#6b7280";
        ctx.font = "700 10px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace";
        ctx.fillText("+" + (portsAll.length - maxSq), x + w - 42, y + 14);
      }
    }

    // Right meta (U + ports)
    ctx.fillStyle = "#6b7280";
    ctx.font = "800 11px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace";
    const meta = `${u}U · ${(d.ports||[]).length}p`;
    ctx.fillText(meta, x + w - ctx.measureText(meta).width - 10, y + 14);
  });

  return canvas.toDataURL("image/png");
}

/* QR Code generator (pure canvas, no library) */
function generateQR(text, size) {
  size = size || 200;
  const mods = 21;
  const grid = Array.from({ length: mods }, () => Array(mods).fill(false));
  const drawFinder = (cx, cy) => {
    for (let y = -3; y <= 3; y++) for (let x = -3; x <= 3; x++) {
      const gy = cy + y, gx = cx + x;
      if (gy < 0 || gy >= mods || gx < 0 || gx >= mods) continue;
      grid[gy][gx] = Math.max(Math.abs(x), Math.abs(y)) !== 2;
    }
  };
  drawFinder(3, 3); drawFinder(mods - 4, 3); drawFinder(3, mods - 4);
  for (let i = 8; i < mods - 8; i++) { grid[6][i] = i % 2 === 0; grid[i][6] = i % 2 === 0; }
  const bytes = []; for (let i = 0; i < text.length; i++) bytes.push(text.charCodeAt(i));
  let bi = 0;
  for (let y = 9; y < mods - 1; y++) for (let x = 9; x < mods - 1; x++) {
    if (grid[y][x]) continue;
    if (bi < bytes.length * 8) { grid[y][x] = ((bytes[Math.floor(bi / 8)] >> (7 - bi % 8)) & 1) === 1; bi++; }
    else { grid[y][x] = ((x * 7 + y * 13 + (bytes[0] || 0)) % 3) === 0; }
  }
  const canvas = document.createElement("canvas");
  const px = Math.floor(size / mods);
  canvas.width = canvas.height = px * mods + 8;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#000";
  for (let y = 0; y < mods; y++) for (let x = 0; x < mods; x++) {
    if (grid[y][x]) ctx.fillRect(4 + x * px, 4 + y * px, px, px);
  }
  return canvas.toDataURL("image/png");
}

function RackPreviewPNG({ rack, allConns, cm, lang, T, ptColors, rackFace = "front", scale = 2, start = true, onReady }) {
  const [src, setSrc] = useState(null);
  const [err, setErr] = useState(null);

  useEffect(() => {
    let cancelled = false;
    if (!start) return;

    setErr(null);
    setSrc(null);

    // yield one tick so the page stays responsive
    const t = setTimeout(() => {
      try {
        const url = rackPreviewToPNGDataURL(rack, allConns, cm, rackFace, { scale, bg: "#ffffff" });
        if (!cancelled) setSrc(url);
        onReady && onReady(true);
      } catch (e) {
        console.error(e);
        if (!cancelled) setErr(String(e && e.message ? e.message : e));
        onReady && onReady(false);
      }
    }, 0);

    return () => { cancelled = true; clearTimeout(t); };
  }, [start, rack.id, rack.size, (rack.devs||[]).length, allConns.length, rackFace, scale]);

  return (
    <div style={{ maxWidth: 780, margin: "0 auto 16px" }}>
      {!src && (
        <div style={{ fontSize: "var(--ir-small)", color: err ? "#ef4444" : "#9ca3af", textAlign: "center", padding: "10px 0" }}>
          {err ? (lang==="de"?"PNG Fehler: ":lang==="es"?"Error PNG: ":"PNG error: ") + err : (start ? (lang==="de"?"PNG wird erzeugt…":lang==="es"?"Generando PNG…":"Generating PNG…") : (lang==="de"?"Wartet…":lang==="es"?"En cola…":"Queued…"))}
        </div>
      )}

      {src ? (
        <img src={src} alt="Rack preview (PNG)" style={{ width: "100%", display: "block", borderRadius: 10, border: "1px solid #e5e7eb" }} />
      ) : (
        <div style={{ borderRadius: 10, overflow: "hidden", border: "1px solid #e5e7eb" }}>
          {/* Fallback visible preview while PNG is generated */}
          <RackVisual rack={rack} allConns={allConns} cm={cm} T={T} ptColors={ptColors} />
        </div>
      )}
    </div>
  );
}


/* ═══════ PROJECT REPORT PAGE ═══════ */
function ProjectReportPage({ project, onBack, lang, T, ptColors, rackFace }) {
  const S = { bg: "#f8f9fb", card: "#fff", bdr: "#e5e7eb", txt: "#1f2937", sub: "#6b7280", lt: "#9ca3af", acc: "#f3f4f6" };
  const now = new Date().toLocaleString("de-DE", { dateStyle: "long", timeStyle: "short" });
  const totalDevs = (project.racks||[]).reduce((s, r) => s + ((r.devs||[]).length), 0);
  const totalLocalConns = (project.racks||[]).reduce((s, r) => s + ((r.conns||[]).length), 0);
  const xc = project.crossConns || [];
  const racks = project.racks || [];
  const [pngIdx, setPngIdx] = useState(0);
  const pngDone = pngIdx >= racks.length;

  const totalConns = totalLocalConns + xc.length;
  const totalUsedU = (project.racks||[]).reduce((s, r) => s + (r.devs||[]).reduce((s2, d) => s2 + (d.u||0), 0), 0);
  const totalSize = (project.racks||[]).reduce((s, r) => s + (r.size||0), 0);
  const rackLookup = {}; (project.racks||[]).forEach(r => { rackLookup[r.id] = r.name; });
  const allPatchConns = [...(project.racks||[]).flatMap(r => (r.conns||[])), ...xc];
  const patchCounts = {}; allPatchConns.forEach(c => { if (c.patchStatus) patchCounts[c.patchStatus] = (patchCounts[c.patchStatus]||0) + 1; });
  const exportCSV = () => {
    const rows = [["Rack","From Device","From Port#","From Type","To Device","To Port#","To Type","Cable/Note","Cross-Rack","Patch Status","Created"]];
     (project.racks||[]).forEach(r => { (r.conns||[]).forEach(c => { rows.push([r.name, c.fn, c.fpn, c.fpt, c.tn, c.tpn, c.tpt, c.note||"", "", (PATCH_ST[c.patchStatus]||PATCH_ST.none).label, c.createdAt||""]); }); });
    xc.forEach(c => { rows.push([rackLookup[c.rackFrom]||"?", c.fn, c.fpn, c.fpt, c.tn, c.tpn, c.tpt, c.note||"", `${rackLookup[c.rackFrom]||"?"} → ${rackLookup[c.rackTo]||"?"}`, (PATCH_ST[c.patchStatus]||PATCH_ST.none).label, c.createdAt||""]); });
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF"+csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `rackclick-${project.name.replace(/\s+/g,"-").toLowerCase()}-connections.csv`; a.click(); URL.revokeObjectURL(url);
  };
  return (
    <div style={{ height: "100vh", overflowY: "auto", background: S.bg, fontFamily: "'Segoe UI', system-ui, sans-serif", color: S.txt }}>
      <div className="no-print" style={{ position: "sticky", top: 0, zIndex: 100, background: "#fff", borderBottom: `1px solid ${S.bdr}`, padding: "10px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 15, fontWeight: 900, fontFamily: "monospace", letterSpacing: 1, color: "#111" }}>RACK<span style={{ color: "#10b981" }}>CLICK</span></span>
          <span style={{ fontSize: "var(--ir-small)", color: S.sub }}>{lang==="de"?"Projektbericht":lang==="es"?"Informe del Proyecto":"Project Report"} — {project.name}</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={exportCSV} style={{ padding: "7px 14px", background: "#3b82f6", border: "none", color: "#fff", borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 700 }}>📊 CSV</button>
          <button onClick={() => window.print()} disabled={!pngDone} style={{  padding: "7px 18px", background: "#10b981", border: "none", color: "#fff", borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 700 , background: pngDone ? "#10b981" : "#9ca3af", cursor: pngDone ? "pointer" : "not-allowed", opacity: pngDone ? 1 : 0.85 }}>{pngDone ? "🖨 Print / PDF" : (lang==="de" ? `🖼 PNGs… ${Math.min(pngIdx,racks.length)}/${racks.length}` : lang==="es" ? `🖼 PNGs… ${Math.min(pngIdx,racks.length)}/${racks.length}` : `🖼 PNGs… ${Math.min(pngIdx,racks.length)}/${racks.length}`)}</button>
          <button onClick={onBack} style={{ padding: "7px 16px", background: "#f3f4f6", border: `1px solid ${S.bdr}`, color: S.sub, borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 600 }}>← Back</button>
        </div>
      </div>
      <style>{`@media print { .no-print{display:none!important} body,html{background:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact} @page{margin:12mm;size:A4} .rpdev{break-inside:avoid;page-break-inside:avoid} .rptbl tr{break-inside:avoid} }`}</style>
      <div style={{ maxWidth: 820, margin: "0 auto", padding: "28px 24px 40px" }}>
        <h1 style={{ fontSize: 22, fontWeight: 900, margin: 0, fontFamily: "monospace", display: "flex", alignItems: "center", gap: 12 }}>
          {project.logo && <img src={project.logo} style={{ height: 36, borderRadius: 4 }} alt="Logo" />}
          <span>RACK<span style={{ color: "#10b981" }}>CLICK</span> <span style={{ fontWeight: 400, color: S.sub, fontSize: 16 }}>— {lang==="de"?"Projektbericht":lang==="es"?"Informe del Proyecto":"Project Report"}</span></span>
        </h1>
        <div style={{ fontSize: 14, fontWeight: 700, marginTop: 8 }}>{project.name}</div>
        <div style={{ fontSize: 12, color: S.lt, marginTop: 4, marginBottom: 4 }}>{now} · {(project.racks||[]).length} racks</div>
        {(project.technician || project.createdAt) && <div style={{ fontSize: "var(--ir-small)", color: S.sub, marginBottom: 4, display: "flex", gap: 16, flexWrap: "wrap" }}>
          {project.technician && <span>👷 Techniker: <strong>{project.technician}</strong></span>}
          {project.createdAt && <span>📅 Erstellt: {new Date(project.createdAt).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })}</span>}
          {project.updatedAt && <span>✏️ Geändert: {new Date(project.updatedAt).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })}</span>}
        </div>}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(100px, 1fr))", gap: 8, marginBottom: 28 }}>
          {[{ v: project.racks.length, l: "Racks", c: "#10b981" },{ v: totalDevs, l: "Devices", c: "#3b82f6" },{ v: totalConns, l: "Connections", c: "#f59e0b" },...(xc.length>0?[{v:xc.length,l:"🔗 Cross-rack",c:"#a855f7"}]:[]),{ v: `${totalUsedU}/${totalSize}`, l: "Total U", c: "#8b5cf6" },...Object.entries(patchCounts).map(([k,v]) => ({v, l: (PATCH_ST[k]||PATCH_ST.none).label, c: (PATCH_ST[k]||PATCH_ST.none).color}))].map((s,i) => (
            <div key={i} style={{ background: S.card, borderRadius: 10, padding: "12px 6px", textAlign: "center", border: `1px solid ${S.bdr}` }}>
              <div style={{ fontSize: 22, fontWeight: 900, color: s.c }}>{s.v}</div>
              <div style={{ fontSize: "var(--ir-small)", color: S.lt, marginTop: 2, textTransform: "uppercase" }}>{s.l}</div>
            </div>))}
        </div>
        {(project.racks||[]).map((r,i) => {
          const rXc = xc.filter(c => c.rackFrom === r.id || c.rackTo === r.id);
          const rConns = r.conns || [];
          const rDevs = r.devs || [];
          const rSize = r.size || 0;
          const rAll = [...rConns, ...rXc];
          const rCm = {}; rAll.forEach((c, i) => { rCm[c.id] = CC[i % CC.length]; });
          return (
            <div key={r.id} style={{ marginBottom: 32 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12, paddingBottom: 8, borderBottom: `2px solid #10b981` }}>
                <div style={{ fontSize: 16, fontWeight: 800, color: "#10b981" }}>⬒ {r.name}</div>
                <div style={{ fontSize: "var(--ir-small)", color: S.sub }}>{r.location && `${r.location} · `}{rSize}U · {rDevs.length} dev · {rConns.length} conn{rXc.length > 0 ? ` + ${rXc.length} 🔗` : ""}</div>
              </div>
              <RackDetailPNG rack={r} allConns={rAll} cm={rCm} lang={lang} T={T} ptColors={ptColors} rackFace={rackFace} start={i===pngIdx} onReady={() => setPngIdx(p => Math.min(p+1, (project.racks||[]).length))} scale={2} />
              {rDevs.map(d => { const dc = rAll.filter(c => c.fd === d.id || c.td === d.id); return (
                <div key={d.id} className="rpdev" style={{ background: S.card, borderRadius: 8, marginBottom: 8, overflow: "hidden", border: `1px solid ${S.bdr}` }}>
                  <div style={{ padding: "8px 12px", display: "flex", justifyContent: "space-between", alignItems: "center", borderLeft: `3px solid ${d.color}` }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}><span style={{ fontSize: 12 }}>{d.icon}</span><span style={{ fontSize: 12, fontWeight: 800, color: d.color }}>{d.name}</span><span style={{ fontSize: "var(--ir-small)", color: S.sub }}>{d.preset} · {d.ports.length}P · {d.u}U</span></div>
                    <span style={{ fontSize: "var(--ir-small)", color: S.lt, background: S.acc, padding: "2px 8px", borderRadius: 8 }}>{dc.length} conn.</span>
                  </div>
                  {d.notes && Object.values(d.notes).some(v => v) && <div style={{ padding: "4px 12px 4px 18px", background: "#f5f3ff", display: "flex", flexWrap: "wrap", gap: 8, fontSize: "var(--ir-small)", color: S.sub }}>
                    {d.notes.sn && <span>🏭 S/N: <strong>{d.notes.sn}</strong></span>}
                    {d.notes.ip && <span>🌐 IP: <strong>{d.notes.ip}</strong></span>}
                    {d.notes.model && <span>📦 {d.notes.model}</span>}
                    {d.notes.firmware && <span>💾 FW: {d.notes.firmware}</span>}
                    {d.notes.text && <span>📝 {d.notes.text}</span>}
                  </div>}
                  {d.ports.some(p => p.label) && <div style={{ padding: "4px 12px 4px 18px", background: "#f0faf6" }}>
                    <div style={{ fontSize: "var(--ir-small)", color: "#10b981", fontWeight: 700, marginBottom: 2 }}>{lang==="de"?"PORT-LABELS":lang==="es"?"ETIQUETAS":"PORT LABELS"}</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>{d.ports.filter(p => p.label).map(p => (
                      <span key={p.id} style={{ fontSize: "var(--ir-small)", color: S.sub, background: "#fff", padding: "1px 6px", borderRadius: 3, border: `1px solid ${S.bdr}` }}>#{p.gn} → {p.label}</span>
                    ))}</div>
                  </div>}
                  {dc.length > 0 && <div style={{ padding: "4px 0" }}>{dc.map(c => { const col = rCm[c.id]||"#f59e0b"; const f = c.fd === d.id; const isCross = !!c.rackFrom; const remoteRack = isCross ? rackLookup[f?c.rackTo:c.rackFrom] : null; return (
                    <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 6, padding: "3px 12px 3px 18px", fontSize: "var(--ir-small)", flexWrap: "wrap" }}>
                      <div style={{ width: 8, height: 8, borderRadius: 2, background: col, flexShrink: 0 }} />
                      {isCross && <span style={{ fontSize: "var(--ir-small)", color: "#a855f7" }}>🔗</span>}
                      <span>{(PT[f?c.fpt2:c.tpt2]||PT.rj45).label} <strong style={{ color: col }}>#{f?c.fpn:c.tpn}</strong></span>
                      <span style={{ color: S.lt }}>→</span>
                      <span>{remoteRack && <span style={{ color: "#a855f7" }}>[{remoteRack}] </span>}<strong>{f?c.tn:c.fn}</strong> #{f?c.tpn:c.fpn}</span>
                      {c.note && <span style={{ fontSize: "var(--ir-small)", color: S.sub, fontStyle: "italic" }}>📎 {c.note}</span>}
                      {c.patchStatus && <span style={{ fontSize: "var(--ir-small)", color: (PATCH_ST[c.patchStatus]||PATCH_ST.none).color }}>{(PATCH_ST[c.patchStatus]||PATCH_ST.none).label}</span>}
                    </div>); })}</div>}
                </div>); })}
            </div>);
        })}
        {xc.length > 0 && <>
          <h2 style={{ fontSize: 14, fontWeight: 700, margin: "24px 0 12px", paddingBottom: 6, borderBottom: `2px solid #a855f7` }}>🔗 Cross-Rack Connections</h2>
          <div style={{ background: S.card, borderRadius: 10, overflow: "hidden", border: `1px solid ${S.bdr}` }}>
            <table className="rptbl" style={{ width: "100%", borderCollapse: "collapse", fontSize: "var(--ir-small)" }}>
              <thead><tr style={{ background: "#f5f0ff" }}>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: "#a855f7" }}>{lang==="de"?"VON RACK":lang==="es"?"RACK ORIGEN":"FROM RACK"}</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: "#a855f7" }}>DEVICE / PORT</th>
                <th style={{ padding: "8px 4px", textAlign: "center", width: 18 }}></th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: "#a855f7" }}>{lang==="de"?"ZU RACK":lang==="es"?"RACK DESTINO":"TO RACK"}</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: "#a855f7" }}>DEVICE / PORT</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: "#a855f7" }}>{lang==="de"?"KABEL":lang==="es"?"CABLE":"CABLE"}</th>
              </tr></thead>
              <tbody>{xc.map((c, i) => (
                <tr key={c.id} style={{ borderBottom: i<xc.length-1?`1px solid ${S.bdr}`:"none", background: i%2===0?"#faf8ff":"#f5f0ff" }}>
                  <td style={{ padding: "6px 10px", fontWeight: 700, color: "#a855f7", fontSize: "var(--ir-small)" }}>{rackLookup[c.rackFrom]}</td>
                  <td style={{ padding: "6px 10px" }}><strong>{c.fn}</strong> <span style={{ color: S.sub, fontSize: "var(--ir-small)" }}>{(PT[c.fpt2]||PT.rj45).label} #{c.fpn}</span></td>
                  <td style={{ textAlign: "center", color: "#a855f7" }}>→</td>
                  <td style={{ padding: "6px 10px", fontWeight: 700, color: "#a855f7", fontSize: "var(--ir-small)" }}>{rackLookup[c.rackTo]}</td>
                  <td style={{ padding: "6px 10px" }}><strong>{c.tn}</strong> <span style={{ color: S.sub, fontSize: "var(--ir-small)" }}>{(PT[c.tpt2]||PT.rj45).label} #{c.tpn}</span></td>
                  <td style={{ padding: "6px 10px", color: S.sub, fontSize: "var(--ir-small)" }}>{c.note||"—"}</td>
                </tr>))}</tbody>
            </table>
          </div>
        </>}

        {/* #28: Change Log */}
        {(project.changeLog||[]).length > 0 && <div style={{ background: S.card, borderRadius: 10, padding: 16, marginBottom: 16, border: `1px solid ${S.bdr}` }}>
          <h3 style={{ fontSize: 13, fontWeight: 800, margin: "0 0 10px", color: S.txt }}>📜 Änderungs-Log (last 20)</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 2, maxHeight: 200, overflowY: "auto" }}>
            {project.changeLog.slice(-20).reverse().map((e, i) => (
              <div key={i} style={{ display: "flex", gap: 8, fontSize: "var(--ir-small)", color: S.sub, padding: "2px 0", borderBottom: `1px solid ${S.acc}` }}>
                <span style={{ color: S.lt, minWidth: 110, fontSize: "var(--ir-small)" }}>{new Date(e.ts).toLocaleString("de-DE", { dateStyle: "short", timeStyle: "short" })}</span>
                <span style={{ fontWeight: 600 }}>{e.action}</span>
                {e.tech && <span style={{ color: S.lt, marginLeft: "auto" }}>👷 {e.tech}</span>}
              </div>
            ))}
          </div>
        </div>}

        <div style={{ textAlign: "center", padding: "28px 0 8px", fontSize: "var(--ir-small)", color: S.lt }}>Generated by RackClick v{RC_VERSION} \u00b7 {now}</div>
      </div>
    </div>
  );
}

/* ═══════ REPORT PAGE (single rack) ═══════ */
function ReportPage({ rack, rackPng, cm, crossConns, rackLookup, onBack, projectMeta, lang }) {
  const { devs, conns, size: rackSize, name: rackName, location: rackLoc } = rack;
  const xc = crossConns.filter(c => c.rackFrom === rack.id || c.rackTo === rack.id);
  const allC = [...conns, ...xc];
  const now = new Date().toLocaleString("de-DE", { dateStyle: "long", timeStyle: "short" });
  const totalP = devs.reduce((s, d) => s + d.ports.length, 0);
  const connSet = new Set([...allC.map(c => c.fp), ...allC.map(c => c.tp)]);
  const usedP = devs.reduce((n,d)=>n+d.ports.filter(p=>connSet.has(p.id)).length,0); const usedU = devs.reduce((s, d) => s + d.u, 0);
  const totalPoe = devs.reduce((s, d) => s + d.ports.filter(p => p.poe).length, 0);
  const totalRes = devs.reduce((s, d) => s + d.ports.filter(p => p.status === "reserved").length, 0);
  const totalDis = devs.reduce((s, d) => s + d.ports.filter(p => p.status === "disabled").length, 0);
  const totalFlt = devs.reduce((s, d) => s + d.ports.filter(p => p.status === "faulty").length, 0);
  const totalLabels = devs.reduce((s, d) => s + d.ports.filter(p => p.label).length, 0);
  const S = { bg: "#f8f9fb", card: "#fff", bdr: "#e5e7eb", txt: "#1f2937", sub: "#6b7280", lt: "#9ca3af", acc: "#f3f4f6" };
  const exportCSV = () => {
    const rows = [["From Device","From Port#","From Type","To Device","To Port#","To Type","Cable/Note","Cross-Rack","Patch Status","Created"]];
    conns.forEach(c => { rows.push([c.fn, c.fpn, c.fpt, c.tn, c.tpn, c.tpt, c.note||"", "", (PATCH_ST[c.patchStatus]||PATCH_ST.none).label, c.createdAt||""]); });
    xc.forEach(c => { rows.push([c.fn, c.fpn, c.fpt, c.tn, c.tpn, c.tpt, c.note||"", `→ ${rackLookup[c.rackFrom === rack.id ? c.rackTo : c.rackFrom]||"?"}`, (PATCH_ST[c.patchStatus]||PATCH_ST.none).label, c.createdAt||""]); });
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF"+csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `rack-${rackName.replace(/\s+/g,"-").toLowerCase()}-connections.csv`; a.click(); URL.revokeObjectURL(url);
  };
  return (
    <div style={{ height: "100vh", overflowY: "auto", background: S.bg, fontFamily: "'Segoe UI', system-ui, sans-serif", color: S.txt }}>
      <div className="no-print" style={{ position: "sticky", top: 0, zIndex: 100, background: "#fff", borderBottom: `1px solid ${S.bdr}`, padding: "10px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 15, fontWeight: 900, fontFamily: "monospace", letterSpacing: 1, color: "#111" }}>RACK<span style={{ color: "#10b981" }}>CLICK</span></span>
          <span style={{ fontSize: "var(--ir-small)", color: S.sub }}>Report — {rackName}{rackLoc ? ` (${rackLoc})` : ""}</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={exportCSV} style={{ padding: "7px 14px", background: "#3b82f6", border: "none", color: "#fff", borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 700 }}>📊 CSV</button>
          <button onClick={() => window.print()} style={{ padding: "7px 18px", background: "#10b981", border: "none", color: "#fff", borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 700 }}>🖨 Print / PDF</button>
          <button onClick={onBack} style={{ padding: "7px 16px", background: "#f3f4f6", border: `1px solid ${S.bdr}`, color: S.sub, borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 600 }}>← Back</button>
        </div>
      </div>
      <style>{`@media print { .no-print{display:none!important} body,html{background:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact} @page{margin:12mm;size:A4} .rpdev{break-inside:avoid;page-break-inside:avoid} .rptbl tr{break-inside:avoid} }`}</style>
      <div style={{ maxWidth: 820, margin: "0 auto", padding: "28px 24px 40px" }}>
        <h1 style={{ fontSize: 22, fontWeight: 900, margin: 0, fontFamily: "monospace", display: "flex", alignItems: "center", gap: 12 }}>
          {projectMeta?.logo && <img src={projectMeta.logo} style={{ height: 36, borderRadius: 4 }} alt="Logo" />}
          <span>RACK<span style={{ color: "#10b981" }}>CLICK</span> <span style={{ fontWeight: 400, color: S.sub, fontSize: 16 }}>— {lang==="de"?"Bericht":lang==="es"?"Informe":"Report"}</span></span>
        </h1>
        <div style={{ fontSize: 12, color: S.lt, marginTop: 4, marginBottom: 4 }}>{now} · {rackName}{rackLoc ? ` (${rackLoc})` : ""} · {rackSize}U</div>
        {projectMeta && (projectMeta.technician || projectMeta.createdAt) && <div style={{ fontSize: "var(--ir-small)", color: S.sub, marginBottom: 4, display: "flex", gap: 16, flexWrap: "wrap" }}>
          {projectMeta.technician && <span>👷 Techniker: <strong>{projectMeta.technician}</strong></span>}
          {projectMeta.updatedAt && <span>✏️ {new Date(projectMeta.updatedAt).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })}</span>}
        </div>}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(90px, 1fr))", gap: 8, marginBottom: 24 }}>
          {[{ v: devs.length, l: "Devices", c: "#3b82f6" },{ v: conns.length, l: "Local Conn.", c: "#f59e0b" },...(xc.length>0?[{v:xc.length,l:"🔗 Cross",c:"#a855f7"}]:[]),{ v: totalP, l: "Ports", c: "#6366f1" },{ v: usedP, l: "Connected", c: "#10b981" },{ v: `${usedU}/${rackSize}`, l: "Rack U", c: "#8b5cf6" },...(totalPoe>0?[{v:totalPoe,l:"PoE",c:"#f59e0b"}]:[]),...(totalLabels>0?[{v:totalLabels,l:"🏷 Labels",c:"#10b981"}]:[]),...(totalFlt>0?[{v:totalFlt,l:"Faulty",c:"#dc2626"}]:[])].map((s,i) => (
            <div key={i} style={{ background: S.card, borderRadius: 10, padding: "10px 6px", textAlign: "center", border: `1px solid ${S.bdr}` }}>
              <div style={{ fontSize: 20, fontWeight: 900, color: s.c }}>{s.v}</div>
              <div style={{ fontSize: "var(--ir-small)", color: S.lt, marginTop: 2, textTransform: "uppercase" }}>{s.l}</div>
            </div>))}
        </div>
        {rackPng ? (
          <div style={{ background: S.card, border: `1px solid ${S.bdr}`, borderRadius: 10, padding: 10, maxWidth: 520, margin: "0 auto 16px" }}>
            <div style={{ fontSize: "var(--ir-small)", color: S.lt, marginBottom: 6, textTransform: "uppercase", letterSpacing: 1 }}>
              {lang==="de"?"Rack-Abbild (PNG)":lang==="es"?"Captura del Rack (PNG)":"Rack Snapshot (PNG)"}
            </div>
            <img src={rackPng} alt="Rack PNG" style={{ width: "100%", display: "block", borderRadius: 8 }} />
            <div style={{ position: "absolute", bottom: 12, right: 12, background: "#fff", padding: 4, borderRadius: 6, boxShadow: "0 2px 8px #0002" }}><img src={generateQR((rack.name || "") + " | " + (rack.location || "") + " | " + rack.size + "U", 80)} alt="QR" style={{ width: 64, height: 64, display: "block" }} /></div>
          </div>
        ) : (
          <RackVisualPNG rack={rack} allConns={allC} cm={cm} lang={lang} />
        )}
        <h2 style={{ fontSize: 14, fontWeight: 700, margin: "0 0 12px", paddingBottom: 6, borderBottom: `1px solid ${S.bdr}` }}>Device Details</h2>
        {devs.map(d => { const dc = allC.filter(c => c.fd === d.id || c.td === d.id); const poe = d.ports.filter(p => p.poe).length; return (
          <div key={d.id} className="rpdev" style={{ background: S.card, borderRadius: 10, marginBottom: 12, overflow: "hidden", border: `1px solid ${S.bdr}` }}>
            <div style={{ padding: "10px 14px", borderBottom: `1px solid ${S.bdr}`, display: "flex", justifyContent: "space-between", alignItems: "center", borderLeft: `4px solid ${d.color}` }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}><span style={{ fontSize: 14 }}>{d.icon}</span><span style={{ fontSize: 14, fontWeight: 800, color: d.color }}>{d.name}</span><span style={{ fontSize: "var(--ir-small)", color: S.sub }}>{d.preset} · {d.ports.length}P · {d.u}U</span>
                {poe > 0 && <span style={{ fontSize: "var(--ir-small)", color: "#f59e0b" }}>⚡{poe}</span>}
              </div>
              <span style={{ fontSize: "var(--ir-small)", color: S.lt, background: S.acc, padding: "2px 10px", borderRadius: 10 }}>{dc.length} conn.</span>
            </div>
            {d.notes && Object.values(d.notes).some(v => v) && <div style={{ padding: "6px 14px 6px 20px", background: "#f5f3ff", borderBottom: `1px solid ${S.bdr}`, display: "flex", flexWrap: "wrap", gap: 10, fontSize: "var(--ir-small)", color: S.sub }}>
              {d.notes.sn && <span>🏭 S/N: <strong>{d.notes.sn}</strong></span>}
              {d.notes.ip && <span>🌐 IP: <strong>{d.notes.ip}</strong></span>}
              {d.notes.model && <span>📦 {d.notes.model}</span>}
              {d.notes.firmware && <span>💾 FW: {d.notes.firmware}</span>}
              {d.notes.text && <span>📝 {d.notes.text}</span>}
            </div>}
            {d.ports.some(p => p.label) && <div style={{ padding: "6px 14px 6px 20px", background: "#f0faf6", borderBottom: `1px solid ${S.bdr}` }}>
              <div style={{ fontSize: "var(--ir-small)", color: "#10b981", fontWeight: 700, marginBottom: 3 }}>{lang==="de"?"🏷 PORT-LABELS":lang==="es"?"🏷 ETIQUETAS":"🏷 PORT LABELS"}</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>{d.ports.filter(p => p.label).map(p => (
                <span key={p.id} style={{ fontSize: "var(--ir-small)", color: S.sub, background: "#fff", padding: "2px 8px", borderRadius: 4, border: `1px solid ${S.bdr}` }}>{(PT[p.type]||PT.rj45).label} #{p.gn} → <strong>{p.label}</strong></span>
              ))}</div>
            </div>}
            {dc.length > 0 ? <div style={{ padding: "8px 0" }}>{dc.map(c => { const col = cm[c.id]||"#f59e0b"; const f = c.fd === d.id; const isCross = !!c.rackFrom; const remoteRack = isCross ? rackLookup[f?c.rackTo:c.rackFrom] : null; return (
              <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 14px 5px 20px", fontSize: 12, flexWrap: "wrap" }}>
                <div style={{ width: 10, height: 10, borderRadius: 3, background: col, flexShrink: 0 }} />
                {isCross && <span style={{ fontSize: "var(--ir-small)", color: "#a855f7", fontWeight: 700 }}>🔗</span>}
                <span>{(PT[f?c.fpt2:c.tpt2]||PT.rj45).label} <strong style={{ color: col }}>#{f?c.fpn:c.tpn}</strong></span>
                <span style={{ color: S.lt }}>→</span>
                <span>{remoteRack && <span style={{ color: "#a855f7" }}>[{remoteRack}] </span>}<strong>{f?c.tn:c.fn}</strong> {(PT[f?c.tpt2:c.fpt2]||PT.rj45).label} <strong style={{ color: col }}>#{f?c.tpn:c.fpn}</strong></span>
                {c.note && <span style={{ fontSize: "var(--ir-small)", color: S.sub, fontStyle: "italic" }}>📎 {c.note}</span>}
                {c.patchStatus && <span style={{ fontSize: "var(--ir-small)", color: (PATCH_ST[c.patchStatus]||PATCH_ST.none).color }}>{(PATCH_ST[c.patchStatus]||PATCH_ST.none).label}</span>}
              </div>); })}</div> : <div style={{ padding: "10px 20px", fontSize: 12, color: S.lt, fontStyle: "italic" }}>No connections</div>}
          </div>); })}
        {allC.length > 0 && <>
          <h2 style={{ fontSize: 14, fontWeight: 700, margin: "24px 0 12px", paddingBottom: 6, borderBottom: `1px solid ${S.bdr}` }}>Connection Table</h2>
          <div style={{ background: S.card, borderRadius: 10, overflow: "hidden", border: `1px solid ${S.bdr}` }}>
            <table className="rptbl" style={{ width: "100%", borderCollapse: "collapse", fontSize: "var(--ir-small)" }}>
              <thead><tr style={{ background: S.acc }}>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: S.lt, width: 28 }}>#</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: S.lt }}>FROM</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: S.lt }}>PORT</th>
                <th style={{ padding: "8px 4px", textAlign: "center", width: 18 }}></th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: S.lt }}>TO</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: S.lt }}>PORT</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: "var(--ir-small)", fontWeight: 700, color: S.lt }}>{lang==="de"?"KABEL / NOTIZ":lang==="es"?"CABLE / NOTA":"CABLE / NOTE"}</th>
              </tr></thead>
              <tbody>{allC.map((c, i) => { const col = cm[c.id]||"#f59e0b"; const isCross = !!c.rackFrom; return (
                <tr key={c.id} style={{ borderBottom: i<allC.length-1?`1px solid ${S.bdr}`:"none", background: isCross?"#f5f0ff":i%2===0?"#fff":"#fafbfc" }}>
                  <td style={{ padding: "6px 10px", color: S.lt, fontSize: "var(--ir-small)" }}>{isCross?"🔗":i+1}</td>
                  <td style={{ padding: "6px 10px" }}><div style={{ display: "flex", alignItems: "center", gap: 5 }}><div style={{ width: 7, height: 7, borderRadius: 2, background: col, flexShrink: 0 }} /><strong>{c.fn}</strong></div></td>
                  <td style={{ padding: "6px 10px", color: S.sub, fontSize: "var(--ir-small)" }}>{(PT[c.fpt2]||PT.rj45).label} #{c.fpn}</td>
                  <td style={{ textAlign: "center", color: S.lt }}>→</td>
                  <td style={{ padding: "6px 10px" }}><strong>{isCross && <span style={{ color: "#a855f7", fontSize: "var(--ir-small)" }}>[{rackLookup[c.rackTo===rack.id?c.rackFrom:c.rackTo]}] </span>}{c.tn}</strong></td>
                  <td style={{ padding: "6px 10px", color: S.sub, fontSize: "var(--ir-small)" }}>{(PT[c.tpt2]||PT.rj45).label} #{c.tpn}</td>
                  <td style={{ padding: "6px 10px", color: S.sub, fontSize: "var(--ir-small)" }}>{c.note||"—"}</td>
                </tr>); })}</tbody>
            </table>
          </div>
        </>}

        {/* #29: Port-Status Summary Table */}
        <div style={{ background: S.card, borderRadius: 10, padding: 16, marginBottom: 16, border: `1px solid ${S.bdr}` }}>
          <h3 style={{ fontSize: 13, fontWeight: 800, margin: "0 0 10px", color: S.txt }}>📊 Port Status Summary</h3>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "var(--ir-small)" }}>
            <thead><tr style={{ borderBottom: `2px solid ${S.bdr}` }}>
              <th style={{ padding: "6px 8px", textAlign: "left", fontSize: "var(--ir-small)", color: S.lt }}>DEVICE</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: "var(--ir-small)", color: S.lt }}>TOTAL</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: "var(--ir-small)", color: "#10b981" }}>CONN</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: "var(--ir-small)", color: "#333" }}>FREE</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: "var(--ir-small)", color: "#f59e0b" }}>RESV</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: "var(--ir-small)", color: "#ef4444" }}>DIS</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: "var(--ir-small)", color: "#dc2626" }}>FLT</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: "var(--ir-small)", color: "#f59e0b" }}>PoE</th>
            </tr></thead>
            <tbody>{devs.map((d, i) => {
              const dp = d.ports.length; const dConn = allC.filter(c => c.fd === d.id || c.td === d.id).length;
              const dRes = d.ports.filter(p => p.status === "reserved").length;
              const dDis = d.ports.filter(p => p.status === "disabled").length;
              const dFlt = d.ports.filter(p => p.status === "faulty").length;
              const dFree = dp - dConn - dRes - dDis - dFlt;
              const dPoe = d.ports.filter(p => p.poe).length;
              return <tr key={d.id} style={{ borderBottom: `1px solid ${S.bdr}`, background: i%2===0?"#fff":"#fafbfc" }}>
                <td style={{ padding: "5px 8px", fontWeight: 600 }}>{d.icon} {d.name}</td>
                <td style={{ textAlign: "center", color: S.sub }}>{dp}</td>
                <td style={{ textAlign: "center", color: "#10b981", fontWeight: 700 }}>{dConn||""}</td>
                <td style={{ textAlign: "center", color: S.lt }}>{dFree>0?dFree:""}</td>
                <td style={{ textAlign: "center", color: "#f59e0b" }}>{dRes||""}</td>
                <td style={{ textAlign: "center", color: "#ef4444" }}>{dDis||""}</td>
                <td style={{ textAlign: "center", color: "#dc2626", fontWeight: dFlt?700:400 }}>{dFlt||""}</td>
                <td style={{ textAlign: "center", color: "#f59e0b" }}>{dPoe||""}</td>
              </tr>;
            })}</tbody>
          </table>
        </div>

        {/* #31: Color Legend */}
        {allC.length > 0 && <div style={{ background: S.card, borderRadius: 10, padding: 16, marginBottom: 16, border: `1px solid ${S.bdr}` }}>
          <h3 style={{ fontSize: 13, fontWeight: 800, margin: "0 0 10px", color: S.txt }}>🎨 Farblegend / Color Legend</h3>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {allC.map(c => { const col = cm[c.id]||"#f59e0b"; const isCross = !!c.rackFrom; return (
              <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: "var(--ir-small)", background: "#fafbfc", padding: "3px 8px", borderRadius: 4, border: `1px solid ${S.bdr}` }}>
                <div style={{ width: 10, height: 10, borderRadius: 2, background: col, flexShrink: 0 }} />
                <span>{c.fn} #{c.fpn} → {isCross && "🔗 "}{c.tn} #{c.tpn}</span>
                {c.patchStatus && <span style={{ fontSize: "var(--ir-small)", color: (PATCH_ST[c.patchStatus]||PATCH_ST.none).color }}>{(PATCH_ST[c.patchStatus]||PATCH_ST.none).label}</span>}
              </div>); })}
          </div>
        </div>}

        {/* #28: Change Log in Report */}
        {projectMeta?.changeLog?.length > 0 && <div style={{ background: S.card, borderRadius: 10, padding: 16, marginBottom: 16, border: `1px solid ${S.bdr}` }}>
          <h3 style={{ fontSize: 13, fontWeight: 800, margin: "0 0 10px", color: S.txt }}>📜 Änderungs-Log (last 20)</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 2, maxHeight: 200, overflowY: "auto" }}>
            {projectMeta.changeLog.slice(-20).reverse().map((e, i) => (
              <div key={i} style={{ display: "flex", gap: 8, fontSize: "var(--ir-small)", color: S.sub, padding: "2px 0", borderBottom: `1px solid ${S.acc}` }}>
                <span style={{ color: S.lt, minWidth: 110, fontSize: "var(--ir-small)" }}>{new Date(e.ts).toLocaleString("de-DE", { dateStyle: "short", timeStyle: "short" })}</span>
                <span style={{ fontWeight: 600 }}>{e.action}</span>
                {e.tech && <span style={{ color: S.lt, marginLeft: "auto" }}>👷 {e.tech}</span>}
              </div>
            ))}
          </div>
        </div>}

        <div style={{ textAlign: "center", padding: "28px 0 8px", fontSize: "var(--ir-small)", color: S.lt }}>Generated by RackClick v{RC_VERSION} \u00b7 {now}</div>
      </div>
    </div>
  );
}

/* ═══════ MAIN APP ═══════ */
function rc8AllLinks(project){return [...project.racks.flatMap(r=>r.conns),...(project.crossConns||[])]}
function rc8Endpoint(project,did,pid){for(const rack of project.racks){const dev=rack.devs.find(d=>d.id===did),port=dev?.ports.find(p=>p.id===pid);if(port)return {rack,dev,port}}return null}
function rc8ReconnectProject(project,intent,destination){
 const links=rc8AllLinks(project),old=links.find(c=>c.id===intent.connectionId),a=rc8Endpoint(project,intent.did,intent.pid),b=rc8Endpoint(project,destination.did,destination.pid);
 if(!old||!a||!b||a.port.id===b.port.id||!((old.fd===intent.did&&old.fp===intent.pid)||(old.td===intent.did&&old.tp===intent.pid)))throw Error('Missing endpoint');
 if(irClientOf(a.rack)!==irClientOf(b.rack)||[a.port,b.port].some(p=>['disabled','faulty'].includes(p.status))||!irPowerPairAllowed(a.port,b.port))throw Error('Invalid pair');
 if(links.some(c=>c.id!==old.id&&((c.fp===a.port.id&&c.fd===a.dev.id)||(c.tp===a.port.id&&c.td===a.dev.id)))||links.some(c=>(c.fp===b.port.id&&c.fd===b.dev.id)||(c.tp===b.port.id&&c.td===b.dev.id)))throw Error('Occupied');
 const {rackFrom,rackTo,...saved}=old;const conn={...saved,fd:a.dev.id,fp:a.port.id,td:b.dev.id,tp:b.port.id,fn:a.dev.name,tn:b.dev.name,fpn:a.port.gn,tpn:b.port.gn,fpt:PT[a.port.type]?.label||a.port.type,tpt:PT[b.port.type]?.label||b.port.type,fpt2:a.port.type,tpt2:b.port.type};
 const cross=a.rack.id!==b.rack.id;if(cross){conn.rackFrom=a.rack.id;conn.rackTo=b.rack.id}
 const next={...project,racks:project.racks.map(r=>({...r,conns:[...r.conns.filter(c=>c.id!==old.id),...(!cross&&r.id===a.rack.id?[conn]:[])]})),crossConns:[...(project.crossConns||[]).filter(c=>c.id!==old.id),...(cross?[conn]:[])]};irAssertTopology(next);
 return {project:next,reserved:[a.port,b.port].some(p=>p.status==='reserved')};
}

const RC8_CORE_WORDS={"en":{"reconnect":"Reconnect: choose a free destination port. The current cable remains until the new connection is saved.","reconnectBlocked":"This cable cannot be reconnected here. Check occupancy, state and client.","batchPoe":"PoE for RJ45 ports in this range","poeOn":"PoE on","poeOff":"PoE off","roleConflict":"This role change contradicts an existing power connection. No changes saved.","emptyRange":"No eligible RJ45 ports in this range.","reconnected":"Cable reconnected; attributes preserved.","cancel":"Cancel","bulkHint":"Start positions refer to the ordered list of free ports, not the printed port number."},"de":{"reconnect":"Neu verbinden: freien Zielport wählen. Das bisherige Kabel bleibt bis zum Speichern bestehen.","reconnectBlocked":"Dieses Kabel kann hier nicht neu verbunden werden. Belegung, Status und Kunde prüfen.","batchPoe":"PoE für RJ45-Ports in diesem Bereich","poeOn":"PoE ein","poeOff":"PoE aus","roleConflict":"Diese Rollenänderung widerspricht einer bestehenden Stromverbindung. Keine Änderung gespeichert.","emptyRange":"Keine geeigneten RJ45-Ports in diesem Bereich.","reconnected":"Kabel neu verbunden; Eigenschaften erhalten.","cancel":"Abbrechen","bulkHint":"Startpositionen beziehen sich auf die geordnete Liste freier Ports, nicht auf die aufgedruckte Portnummer."},"es":{"reconnect":"Reconectar: elige un puerto de destino libre. El cable actual se conserva hasta guardar la nueva conexión.","reconnectBlocked":"No se puede reconectar este cable aquí. Revisa ocupación, estado y cliente.","batchPoe":"PoE de puertos RJ45 en este rango","poeOn":"PoE encendido","poeOff":"PoE apagado","roleConflict":"El cambio de rol contradice una conexión de alimentación existente. No se guardó ningún cambio.","emptyRange":"No hay puertos RJ45 elegibles en este rango.","reconnected":"Cable reconectado; atributos conservados.","cancel":"Cancelar","bulkHint":"Las posiciones de inicio corresponden a la lista ordenada de puertos libres, no al número impreso del puerto."}};
function RackClick() {
 const [rc8Reconnect,setRc8Reconnect]=useState(null);
 const [irManage,setIrManage]=useState(false);
 const [irFaceDevice,setIrFaceDevice]=useState(null);
 const [nextCableColor,setNextCableColor]=useState(null);
 const [irInspect,setIrInspect]=useState(null);
 const [irWire,setIrWire]=useState(null);
 const [legacyView,setLegacyView]=useState(false);
 const [systemhaus,setSystemhaus]=useState(()=>{try{return localStorage.getItem('rackclick_ui_systemhaus')||'RackClick · IT-Systemhaus'}catch{return 'RackClick · IT-Systemhaus'}});
 const irWords=IR_WORDS[(function(){try{return localStorage.getItem(LANG_KEY)||'en'}catch{return 'en'}})()]||IR_WORDS.en;

  /* ─── THEME ─── */
  const [themeId, setThemeId] = useState(() => { try { const old=localStorage.getItem(THEME_KEY)||"dark";return old==="silver"?"light":old==="semidark"?"dark":old; } catch { return "dark"; } });
  const IR_LIGHT=['light','silver'].includes(themeId);
 const IR_PALETTE=IR_LIGHT?{bg:'#f2f5f7',bg2:'#ffffff',bg3:'#edf2f5',bdr:'#c5d0dc',bdr2:'#8998a6',txt:'#1d2d3b',dim:'#42596b',mut:'#526678',vdim:'#526678',inp:'#ffffff',acc:'#08794e'}:{bg:'#101419',bg2:'#191f27',bg3:'#202832',bdr:'#41505e',bdr2:'#748799',txt:'#e6edf3',dim:'#c1ccd6',mut:'#a2afbc',vdim:'#a2afbc',inp:'#151b22',acc:'#43dba5'};
 const T={...(THEMES[themeId]||THEMES.dark),...IR_PALETTE};
 useEffect(()=>{document.documentElement.dataset.rcTheme=IR_LIGHT?'light':'dark'},[themeId]);
  const switchTheme = (id) => { setThemeId(id); try { localStorage.setItem(THEME_KEY, id); } catch {} };

  const [lang, setLang] = useState(() => { try { return localStorage.getItem(LANG_KEY) || "en"; } catch { return "en"; } });
  const t = (key, vars = {}) => ((I18N[lang] || I18N.en)[key] || I18N.en[key] || key).replace(/\{(\w+)\}/g, (match, name) => Object.prototype.hasOwnProperty.call(vars, name) ? String(vars[name]) : match);
  const switchLang=(l)=>{if(project.rackclickDemoLanguage){const next=irTranslateDemo(project,l);if(irClient){const oldClients=irClientList(project),at=oldClients.indexOf(irClient);if(at>=0)setIrClient(irClientList(next)[at]||irClient)}setProject(next)}setLang(l);try{localStorage.setItem(LANG_KEY,l)}catch{}};

  /* ─── PORT TYPE COLORS (customizable) ─── */
  const [ptColors, setPtColors] = useState(() => { try { const s = localStorage.getItem(PT_COLOR_KEY); return s ? { ...DEFAULT_PT_COLORS, ...JSON.parse(s) } : { ...DEFAULT_PT_COLORS }; } catch { return { ...DEFAULT_PT_COLORS }; } });
  const setPtColor = (type, color) => { setPtColors(prev => { const n = { ...prev, [type]: color }; try { localStorage.setItem(PT_COLOR_KEY, JSON.stringify(n)); } catch {} return n; }); };

  /* ─── GROUP COLORS (auto-assign connection color by device pair) ─── */
  const [groupColors, setGroupColors] = useState(() => { try { const s = localStorage.getItem(GROUP_COLOR_KEY); return s ? JSON.parse(s) : {}; } catch { return {}; } });
  const setGroupColor = (key, color) => { setGroupColors(prev => { const n = { ...prev, [key]: color || undefined }; try { localStorage.setItem(GROUP_COLOR_KEY, JSON.stringify(n)); } catch {} return n; }); };
  const getDevCategory = (preset) => { for (const [cat, presets] of Object.entries(DEV_CATEGORIES)) { if (presets.includes(preset)) return cat; } return "Other"; };
  const getGroupColorForConn = (fromDev, toDev) => { if (!fromDev || !toDev) return null; const c1 = getDevCategory(fromDev.preset); const c2 = getDevCategory(toDev.preset); const key = [c1, c2].sort().join("↔"); return nextCableColor || groupColors[key] || null; };

  const [showSettings, setShowSettings] = useState(false);

  const emptyProject = () => ({ version: "0.8", name: "New Project", technician: "", createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), racks: [{ id: gid(), name: "Rack 1", location: "", size: 24, devs: [], conns: [] }], crossConns: [], changeLog: [] });
  const [project, setProject] = useState(() => bootLoadProject(emptyProject));
 const [irClient,setIrClient]=useState(null);
 const irScope=React.useMemo(()=>irClientProject(project,irClient),[project,irClient]);
 const irContextRef=useRef(null);

  const [activeRackId, setActiveRackId] = useState(project.racks[0]?.id);
  const [view, setView] = useState(()=>irClientList(project).length?"clients":"project");
 irContextRef.current={client:irClient,view};
  const [rackReportPng, setRackReportPng] = useState(null);
  const [snapshots, setSnapshots] = useState(() => { try { return JSON.parse(localStorage.getItem(SNAPSHOTS_KEY) || "[]"); } catch { return []; } });
  const [showSnapshots, setShowSnapshots] = useState(false);
  const [autosaveStatus, setAutosaveStatus] = useState({ ok: null, lastOkAt: null });
  const [quarantineEpisodes,setQuarantineEpisodes]=useState(()=>{try{return irQuarantineEntries()}catch{return []}});

  const [sp, setSp] = useState(null);
  const [sc, setSc] = useState(null);
  const [search, setSearch] = useState("");
  const [rackZoom, setRackZoom] = useState(100);
  const [rackFace, setRackFace] = useState("front");
  const [dragId, setDragId] = useState(null);
  const [dragOverId, setDragOverId] = useState(null);
  const touchDragRef = useRef({ active: false, id: null });
  const [globalSearch, setGlobalSearch] = useState("");
  const [editDev, setEditDev] = useState(null);
  const [editRack, setEditRack] = useState(null);
  const [ctxMenu, setCtxMenu] = useState(null);
  const irWattsUndoRef=useRef(false);
  const irConnNoteUndoRef=useRef(null);
  const [devCtx, setDevCtx] = useState(null);
  const [notif, setNotif] = useState(null);
  const [flashPorts, setFlashPorts] = useState(new Set());
  const [showNew, setShowNew] = useState(false);
  const [favPresets, setFavPresets] = useState(() => { try { const s = localStorage.getItem(FAV_KEY); return s ? new Set(JSON.parse(s)) : new Set(); } catch { return new Set(); } });
  const toggleFav = (key) => { const n = new Set(favPresets); n.has(key) ? n.delete(key) : n.add(key); try { localStorage.setItem(FAV_KEY, JSON.stringify([...n])); } catch { noti(t("notiFavoritesFailed"), "error"); return; } setFavPresets(n); };
  const [cust, setCust] = useState({ name: "", icon: "▦", u: 1, pg: [{ t: "rj45", n: 4 }] });
  const [crossSel, setCrossSel] = useState(null);
  const [dn, setDn] = useState("");
  const [showBulk, setShowBulk] = useState(false);
  const [showLog, setShowLog] = useState(false);
  const [collapsedDevs, setCollapsedDevs] = useState(new Set());
  const [selectedDevs, setSelectedDevs] = useState(new Set());
  const [customTemplates, setCustomTemplates] = useState(() => { try { return JSON.parse(localStorage.getItem(TEMPLATES_KEY) || "{}"); } catch { return {}; } });
  const saveCustomTemplate = (dev) => {
    const key = `ct_${Date.now()}`;
    const tpl = { label: dev.name, icon: dev.icon, color: dev.color, u: dev.u, ports: [] };
    const gm = {}; dev.ports.forEach(p => { const t = p.type === "rj45_poe" ? "rj45_poe" : p.type; (gm[t] = gm[t] || []).push(p); });
    tpl.ports = Object.entries(gm).map(([t, ps]) => ({ t, n: ps.length }));
    tpl.rackclickPortLayout=irTemplateLayout(dev);
    const next = { ...customTemplates, [key]: tpl };
    try { localStorage.setItem(TEMPLATES_KEY, JSON.stringify(next)); } catch { noti(t("notiTemplatesFailed"), "error"); return; }
    setCustomTemplates(next);
    noti(t("notiTemplateSaved", {name: dev.name}), "success");
  };
  const deleteCustomTemplate = (key) => {
    const next = { ...customTemplates }; delete next[key];
    try { localStorage.setItem(TEMPLATES_KEY, JSON.stringify(next)); } catch { noti(t("notiTemplatesFailed"), "error"); return; }
    setCustomTemplates(next);
    noti(t("notiTemplateRemoved"), "info");
  };
  const [dirty, setDirty] = useState(false);
  const irProjectRef=useRef(project);irProjectRef.current=project;
  const lastSavedRef = useRef(JSON.stringify(project));
  const notifTimer = useRef(null);

  /* ─── UNDO ─── */
  const [undoStack, setUndoStack] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const pushUndo = useCallback((label) => {
    setUndoStack(prev => {
      const snap = { label, project: JSON.parse(JSON.stringify(project)), activeRackId, irClient, irView:view };
      const next = [snap, ...prev].slice(0, MAX_UNDO);
      return next;
    });
    setRedoStack([]);
    // Auto-log change
    setProject(prev => {
      const log = prev.changeLog || [];
      const entry = { ts: new Date().toISOString(), action: label, client:irClient, tech: irScope.technician || "" };
      return { ...prev, changeLog: [...log, entry].slice(-100) };
    });
  }, [project, activeRackId, irClient, view]);
  const undo = useCallback(() => {
    if (undoStack.length === 0) return;
    const [top, ...rest] = undoStack;
    setRedoStack(prev => [{ label: "redo", project: JSON.parse(JSON.stringify(project)), activeRackId, irClient, irView:view }, ...prev].slice(0, MAX_UNDO));
    setRc8Reconnect(null);setProject(top.project);
    setActiveRackId(top.activeRackId);setIrClient(top.irClient??null);setView(top.irView||"project");setSp(null);setSc(null);setCtxMenu(null);setCrossSel(null);setSelectedDevs(new Set());
    setUndoStack(rest);
    noti(t("notiUndoLabel", {label: top.label}), "info");
  }, [undoStack, project, activeRackId, irClient, view]);
  const redo = useCallback(() => {
    if (redoStack.length === 0) return;
    const [top, ...rest] = redoStack;
    setUndoStack(prev => [{ label: "undo", project: JSON.parse(JSON.stringify(project)), activeRackId, irClient, irView:view }, ...prev].slice(0, MAX_UNDO));
    setRc8Reconnect(null);setProject(top.project);
    setActiveRackId(top.activeRackId);setIrClient(top.irClient??null);setView(top.irView||"project");setSp(null);setSc(null);setCtxMenu(null);setCrossSel(null);setSelectedDevs(new Set());
    setRedoStack(rest);
    noti(`↪ ${t("notiRedo")}`, "info");
  }, [redoStack, project, activeRackId, irClient, view]);

  useEffect(() => {
    const h = e => {
      if(document.querySelector("dialog[open]"))return;
      if ((e.ctrlKey || e.metaKey) && e.key === "z" && !e.shiftKey) { e.preventDefault(); undo(); }
      if ((e.ctrlKey || e.metaKey) && (e.key === "y" || (e.key === "z" && e.shiftKey))) { e.preventDefault(); redo(); }
      if ((e.ctrlKey || e.metaKey) && e.key === "s") { e.preventDefault(); saveJSON(); }
      if (e.key === "Escape") { setRc8Reconnect(null);setSc(null); setShowBulk(false); setSp(null); setCrossSel(null); setCtxMenu(null); setDevCtx(null); setEditDev(null); setEditRack(null); setShowLog(false); setShowSettings(false); }
      if ((e.ctrlKey || e.metaKey) && e.key === "f" && view === "project") { e.preventDefault(); document.querySelector("[data-globalsearch]")?.focus(); }
      if (e.key === "Delete" && selectedDevs.size > 0 && view === "rack" && !editDev && !e.target?.closest?.("input, textarea, select, [contenteditable], [role=\"textbox\"]")) { e.preventDefault(); bulkDeleteSelected(); }
    };
    window.addEventListener("keydown", h); return () => window.removeEventListener("keydown", h);
  }, [undo, redo, selectedDevs, view, editDev]);

  const noti = (msg, type = "success") => { clearTimeout(notifTimer.current); setNotif({ msg, type }); notifTimer.current = setTimeout(() => setNotif(null), 2500); };
  useEffect(() => {
    if (!BOOT_REPORT) return;
    const r = BOOT_REPORT; BOOT_REPORT = null;
    if (r.type === "repaired") noti(r.quarantineSaved?t("notiBootRepaired"):IR_RECOVERY_WORDS[lang].notSaved,r.quarantineSaved?"info":"error");
    else if (r.type === "backup") noti(r.quarantineSaved?t("notiBootBackup") + " (" + r.backupKey + ")":IR_RECOVERY_WORDS[lang].notSaved,r.quarantineSaved?"info":"error");
    else if (r.type === "ambiguous") noti(t("notiBackupAmbiguous"), "error");
    else if (r.type === "safeMode") noti(r.quarantineSaved?t("notiBootSafeMode"):IR_RECOVERY_WORDS[lang].notSaved,"error");
    else if(r.type==="unreadable")noti(IR_RECOVERY_WORDS[lang].unreadable,"error");
  }, []);
  const downloadQuarantine = (autosaveOnly,key=QUARANTINE_KEY) => {
    try {
      const s=localStorage.getItem(key);if(s===null)throw Error('Episode unavailable');
      let content=s,suffix='quarantine';
      if(autosaveOnly){const q=JSON.parse(s);if(typeof q.keys?.autosave!=='string')throw Error('Autosave unavailable');content=q.keys.autosave;suffix='quarantine-autosave'}
      rcDownload(content,'rackclick-'+suffix+'-'+key.replace(/[^a-zA-Z0-9_-]/g,'-')+'-'+rcTimestamp()+'.json');
    }catch{noti(IR_RECOVERY_WORDS[lang].readFailed,'error')}
  };
  const deleteQuarantine = (key=QUARANTINE_KEY) => {
    if(!confirm(t('quarantineDeleteConfirm')))return;
    try{
      localStorage.removeItem(key);
      if(localStorage.getItem(key)!==null)throw Error('Deletion not confirmed');
      setQuarantineEpisodes(irQuarantineEntries());
      noti(t('notiQuarantineDeleted'),'info');
    }catch{noti(IR_RECOVERY_WORDS[lang].deleteFailed,'error')}
  };
  const rack = irScope.racks.find(r => r.id === activeRackId);
  const devs = rack?.devs || [];
  const conns = rack?.conns || [];
  const setDevs = fn => setProject(prev => ({ ...prev, racks: prev.racks.map(r => r.id === activeRackId ? { ...r, devs: typeof fn === "function" ? fn(r.devs) : fn } : r) }));
  const setConns = fn => setProject(prev => ({ ...prev, racks: prev.racks.map(r => r.id === activeRackId ? { ...r, conns: typeof fn === "function" ? fn(r.conns) : fn } : r) }));
  const setCrossConns = fn => setProject(prev => ({ ...prev, crossConns: typeof fn === "function" ? fn(prev.crossConns || []) : fn }));
  const crossForRack = (project.crossConns || []).filter(c => c.rackFrom === activeRackId || c.rackTo === activeRackId);
  const allConns = [...conns, ...crossForRack];
  /* v0.8.4 [7]: label rápido por doble clic (solución mínima con prompt) */
  const quickLabel = useCallback((e, did, pid) => {
    const dev = devs.find(d => d.id === did); const port = dev?.ports.find(p => p.id === pid); if (!port) return;
    const occupied=rc8AllLinks(project).filter(c=>(c.fd===did&&c.fp===pid)||(c.td===did&&c.tp===pid));
    if(occupied.length){if(occupied.length!==1||['disabled','faulty'].includes(port.status)){noti(RC8_CORE_WORDS[lang].reconnectBlocked,'error');return;}setRc8Reconnect({did,pid,connectionId:occupied[0].id});setSp(null);setCrossSel(null);setSc(null);return;}
    const nl = prompt(t("promptQuickLabel") + " \u2014 " + dev.name + " #" + port.gn, port.label || "");
    if (nl === null) return;
    pushUndo("Quick label");
    setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, label: nl.trim() || undefined } : p) } : d));
  }, [devs, t, project, lang]);

  useEffect(()=>{
   const valid=x=>{const p=project.racks.flatMap(r=>r.devs).find(d=>d.id===x.did)?.ports.find(p=>p.id===x.pid);return p&&!['disabled','faulty'].includes(p.status)};
   if(sp&&!valid(sp))setSp(null);if(crossSel&&!valid(crossSel))setCrossSel(null);
   if(rc8Reconnect&&(!valid(rc8Reconnect)||view!=='rack'||!rc8AllLinks(project).some(c=>c.id===rc8Reconnect.connectionId)))setRc8Reconnect(null);
  },[project,sp,crossSel,rc8Reconnect,view]);
  const cm = {}; allConns.forEach((c, i) => { cm[c.id] = c.color || CC[i % CC.length]; });
  const usedU = devs.reduce((s, d) => s + d.u, 0);
  const freeU = rack ? rack.size - usedU : 0;
  const otherRacks = irScope.racks.filter(r => r.id !== activeRackId);
  const rackLookup = {}; (project.racks||[]).forEach(r => { rackLookup[r.id] = r.name; });

  useEffect(() => {
    if(BOOT_AUTOSAVE_BLOCKED){setAutosaveStatus(s=>({...s,ok:null}));return;}
    if (BOOT_SUPPRESS_FIRST_AUTOSAVE) { BOOT_SUPPRESS_FIRST_AUTOSAVE = false; return; }
    /* Autosave honesto (v0.8.3):
       [1] Escritura crítica de SAVE_KEY. Si FALLA: estado ok:false (banner)
           y NO se intenta la rotación de backups en este ciclo (regla aprobada:
           con el almacenamiento lleno, cero escrituras adicionales).
       [2] Rotación de backups SOLO tras éxito de SAVE_KEY, en try propio:
           su fallo no activa el banner (el autosave principal funcionó). */
    let json;
    try { json = JSON.stringify({ ...project, updatedAt: new Date().toISOString() }); }
    catch { setAutosaveStatus(s => ({ ok: false, lastOkAt: s.lastOkAt })); return; }
    try {
      localStorage.setItem(SAVE_KEY, json);
    } catch {
      setAutosaveStatus(s => ({ ok: false, lastOkAt: s.lastOkAt }));
      return;
    }
    setAutosaveStatus({ ok: true, lastOkAt: Date.now() });
    try {
      // Rotate backup every 2 minutes
      const meta = JSON.parse(localStorage.getItem(BACKUP_META) || '{"slot":0,"lastBackup":0}');
      const now = Date.now();
      if (now - meta.lastBackup > 120000) {
        const slot = (meta.slot + 1) % BACKUP_KEYS.length;
        localStorage.setItem(BACKUP_KEYS[slot], json);
        localStorage.setItem(BACKUP_META, JSON.stringify({ slot, lastBackup: now }));
      }
    } catch { console.warn("RackClick: backup rotation failed"); }
  }, [project]);
  useEffect(() => { const current = JSON.stringify(project); setDirty(current !== lastSavedRef.current); }, [project]);
  useEffect(() => { const handler = e => { if (dirty) { e.preventDefault(); e.returnValue = ""; } }; window.addEventListener("beforeunload", handler); return () => window.removeEventListener("beforeunload", handler); }, [dirty]);
  useEffect(() => { document.title = `${dirty ? "● " : ""}RackClick v${RC_VERSION} — ${project.name}`; }, [dirty, project.name]);

  /* ─── Rack CRUD ─── */
  const addRack = (name, location, size) => {
    pushUndo("Add rack");
    const id = gid(); setProject(prev => ({ ...prev, racks: [...prev.racks, ...irLocateNew(prev,irClient,[{ id, name, location, size: +size, devs: [], conns: [] }])] })); noti(t("notiRackCreated") + `: "${name}"`, "success"); return id;
  };
  const deleteRack = (id) => {
    pushUndo("Delete rack");
    setProject(prev => ({ ...prev, racks: prev.racks.filter(r => r.id !== id), crossConns: (prev.crossConns||[]).filter(c => c.rackFrom !== id && c.rackTo !== id) }));
    if (activeRackId === id) { const remaining = irScope.racks.filter(r => r.id !== id); if (remaining.length) setActiveRackId(remaining[0].id); }
    setEditRack(null); setEditDev(null); setDevCtx(null); setSp(null); setSc(null); setView("project"); noti(t("notiRackDel"),"info");
  };
  const openRack = (id) => { setActiveRackId(id); setView("rack"); setSp(null); setSc(null); setSearch(""); setDevCtx(null); setSelectedDevs(new Set()); };
  const saveRackEdit = (changes) => {
    const edited=project.racks.find(r=>r.id===(editRack?.id||activeRackId));
    if(!edited||Number(changes.size)<edited.devs.reduce((n,d)=>n+Number(d.u),0)){noti(CW[lang].capacity,'error');return}
    pushUndo("Edit rack");
    setProject(prev => ({ ...prev, racks: prev.racks.map(r => r.id === (editRack?.id || activeRackId) ? { ...r, ...changes } : r) })); setEditRack(null); noti(t("notiRackUpd"),"success");
  };

  /* ─── Move device to rack ─── */
  const moveDevToRack = (devId, targetRackId) => {
    if(!irScope.racks.some(r=>r.id===targetRackId))return;
    const srcRack = project.racks.find(r => r.devs.some(d => d.id === devId));
    if (!srcRack) return;
    const dev = srcRack.devs.find(d => d.id === devId);
    const targetRack=project.racks.find(r=>r.id===targetRackId);
    if(!targetRack||targetRack.id===srcRack.id)return;
    if(targetRack.devs.reduce((n,d)=>n+Number(d.u),0)+Number(dev.u)>Number(targetRack.size)){noti(CW[lang].capacity,'error');return}
    const localConns = srcRack.conns.filter(c => c.fd === devId || c.td === devId);
    const crossConnsForDev = (project.crossConns||[]).filter(c => c.fd === devId || c.td === devId);
    const totalAffected = localConns.length + crossConnsForDev.length;
    const targetName = project.racks.find(r => r.id === targetRackId)?.name || "target rack";
    if (totalAffected > 0 && !confirm(t("confirmMoveDevice", {name: dev?.name, rack: targetName, local: localConns.length, cross: crossConnsForDev.length}))) return;
    pushUndo("Move device");
    setProject(prev => irMoveDevice(prev,devId,targetRackId));
    setDevCtx(null); noti(`📦 ${t("notiMoved")} ${rackLookup[targetRackId]||"rack"}`, "success");
  };

  /* ─── Save/Load ─── */
  // Snapshot helpers (FIX v0.8.3: estaban definidos DENTRO de saveJSON por
  // error preexistente desde el original — inaccesibles desde el botón 📸 y
  // Settings → "saveSnapshot is not defined". Movidos a scope de componente
  // sin cambiar su lógica.)
  const saveSnapshot = (name) => {
    const snap = { id: Date.now().toString(36), name, date: new Date().toISOString(), data: JSON.stringify(project) };
    const updated = [snap, ...snapshots].slice(0, 20);
    try { localStorage.setItem(SNAPSHOTS_KEY, JSON.stringify(updated)); } catch { noti(t("notiSnapshotsFailed"), "error"); return; }
    setSnapshots(updated);
    noti(t("notiSnapshotSaved"), "success");
  };
  const restoreSnapshot = (snap) => {
    if(irClientList(project).length&&!confirm(CW[lang].snapshotAll))return;
    try { const p = JSON.parse(snap.data); irAssertTopology(p); setProject(p);setIrClient(null);setView(irClientList(p).length?"clients":"project"); noti(t("notiSnapshotRestored"), "success"); } catch { noti(t("notiInvalidJson"), "error"); }
  };
  const deleteSnapshot = (id) => {
    const updated = snapshots.filter(s => s.id !== id);
    try { localStorage.setItem(SNAPSHOTS_KEY, JSON.stringify(updated)); } catch { noti(t("notiSnapshotsFailed"), "error"); return; }
    setSnapshots(updated);
  };
  const irExportAll=()=>{irDownloadData(project,'RackClick-backup-all');lastSavedRef.current=JSON.stringify(project);setDirty(false)};
 const saveJSON=()=>{
  if(view==='clients'){irExportAll();return}
  if(irBoundary(project,irClient).length){noti(CW[lang].boundary,'error');return}
  if(!irScope.racks.length){noti(CW[lang].empty,'info');return}
  const p={...irScope,updatedAt:new Date().toISOString()};if(!p.createdAt)p.createdAt=p.updatedAt;
  irDownloadData(p,'rackclick-'+p.name);if(!irClientList(project).length){lastSavedRef.current=JSON.stringify(project);setDirty(false)}noti(t('notiSaved'),'success');
 };
  const irImport=(mode)=>{
 const inp=document.createElement('input');inp.type='file';inp.accept='.json';inp.multiple=mode==='append';
 const context=irContextRef.current,base=project;
 inp.onchange=async e=>{const files=[...e.target.files];if(!files.length)return;try{
  const data=await Promise.all(files.map(async f=>irImportedProject(JSON.parse(await f.text()),f.name)));
  if(irProjectRef.current!==base||irContextRef.current.client!==context.client||irContextRef.current.view!==context.view)throw Error('Context changed');
  let next=base;
  if(mode==='all'||(mode==='replace'&&!irClientList(base).length&&irClientList(data[0]).length)){
   if(!confirm(CW[lang].replaceAll))return;next=data[0];
  }else if(mode==='replace'){
   if(irClientList(data[0]).length>1)throw Error('Use full backup import');
   if(irBoundary(base,irClient).length){noti(CW[lang].boundary,'error');return}
   if(irClientList(base).length&&!confirm(CW[lang].replaceClient))return;
   next=irReplaceClient(base,irClient,data[0]);
  }else for(const d of data)next=irAppendClient(next,irClient,d);
  irAssertTopology(next);pushUndo(mode==='append'?'Import racks':'Load project');setProject(next);setSp(null);setCrossSel(null);setSelectedDevs(new Set());
  if(mode==='all'||(mode==='replace'&&!irClientList(base).length&&irClientList(data[0]).length)){setIrClient(null);setActiveRackId(null);setView(irClientList(next).length?'clients':'project')}
  else{setActiveRackId(irClientProject(next,irClient).racks[0]?.id);setView('project')}
  noti(t('notiLoaded'),'success');
 }catch{noti(t('notiInvalidJson'),'error')}};inp.click();
 };
 const loadJSON=()=>irImport(view==='clients'?'all':'replace');
 const importRackJSON=()=>irImport('append');
 const mergeProject=()=>irImport('append');
  const exportRack = () => {
    if (!rack) return;
    const crossCount=(project.crossConns||[]).filter(c=>c.rackFrom===rack.id||c.rackTo===rack.id).length;
    if(crossCount){const message=lang==='de'
      ? 'Dieses Rack hat '+crossCount+' rackübergreifende Verbindung(en). Der Rack-Export enthält nur Geräte und lokale Verbindungen. Für eine vollständige Sicherung Projekt-JSON speichern. OK: Rack allein exportieren; Abbrechen: nichts exportieren.'
      : lang==='es'?'Este rack tiene '+crossCount+' conexión(es) con otros racks. El archivo del rack solo incluye dispositivos y conexiones locales. Guarda el JSON del proyecto para conservarlas. Aceptar: exportar solo el rack; Cancelar: no exportar.'
      : 'This rack has '+crossCount+' cross-rack connection(s). Rack export contains devices and local connections only. Save project JSON for a complete backup. OK: export rack only; Cancel: do not export.';
      if(!confirm(message))return;}
    const data = { version: "0.8-rack", note: rack.name, rackSize: rack.size, devs: rack.devs, conns: rack.conns, exportedFrom: irScope.name, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `rack-${rack.name.replace(/\s+/g, "-").toLowerCase()}-${new Date().toISOString().slice(0,10)}.json`; a.click(); URL.revokeObjectURL(url); noti(t("notiExportedRack", {name: rack.name}), "success");
  };
  const importCSV = () => {
    if(!rack)return;const inp=document.createElement('input');inp.type='file';inp.accept='.csv,.txt';
    inp.onchange=async e=>{const f=e.target.files[0];if(!f)return;try{
      const text=await f.text();if(irProjectRef.current!==project)throw Error('Project changed during import');const links=irCSVConnections(text,rack,project);
      if(!allowNewPairs(links.map(c=>[[c.fd,c.fp],[c.td,c.tp]])))return;
      pushUndo('Import CSV');setConns(prev=>[...prev,...links]);noti(t('notiCsvCounts',{added:links.length,skipped:0}),'success');
    }catch{noti(t('notiFailedCsv'),'error')}};inp.click();
  };
  /* #41 Rack Label / ID Tag */
  const printRackLabel = () => {
    if (!rack) return;
    // v0.8.4: pseudo-barcode eliminado (imprim\u00eda como bloque oscuro sin
    // significado). Sustituido por cuadro de ID legible. QR real: fase posterior a F5, en el frontend nuevo.
    const w = window.open("", "_blank");
    w.document.write(`<!DOCTYPE html><html><head><title>RackClick v${htmlEsc(RC_VERSION)} · Label</title><style>
      body{font-family:monospace;padding:20px}
      .label{border:2px solid #111;border-radius:8px;padding:16px;width:300px;page-break-inside:avoid}
      .title{font-size:18px;font-weight:900;letter-spacing:1px;margin-bottom:4px}
      .loc{font-size:11px;color:#666;margin-bottom:8px}
      .info{font-size:10px;color:#333;margin-bottom:6px;display:flex;gap:12px}
      .bar{margin:8px 0;font-size:0;line-height:0;white-space:nowrap}
      .id{font-size:7px;color:#999;margin-top:4px}
      .proj{font-size:9px;color:#555;border-top:1px solid #ddd;padding-top:6px;margin-top:8px}
      @media print{body{padding:0}.label{border:2px solid #000}}
    </style></head><body>
    <div class="label">
      <div class="title">RACK: ${htmlEsc(rack.name)}</div>
      <div class="loc">${htmlEsc(rack.location||"No location")}</div>
      <div class="info"><span>${htmlEsc((rack.devs||[]).length)} Devices</span><span>${htmlEsc(rack.size)}U</span><span>${htmlEsc(rack.conns.length)} Links</span></div>
      <div style="border:1.5px solid #000;border-radius:4px;padding:6px 10px;margin:8px 0;font-size:13px;font-weight:900;letter-spacing:2px;text-align:center;background:#fff;color:#000">${htmlEsc(rack.id.toUpperCase())}</div>
      <div class="proj">RackClick v${htmlEsc(RC_VERSION)} | ${htmlEsc(irScope.name)} | ${htmlEsc(irScope.technician||"—")} | ${htmlEsc(new Date().toLocaleDateString("de-DE"))}</div>
    </div>
    <script>setTimeout(()=>window.print(),300)<\/script>
    </body></html>`);
  };

  
    /* #37A PNG Detail Export — DOM screenshot via html2canvas */
  const _captureRackDetailCanvas = async ({ scale = 3, transparent = false } = {}) => {
    if (!rack) return null;
    const el = document.getElementById("rack-detail-export");
    if (!el) { noti(t("notiRackAreaMissing"), "error"); return null; }

    let h2c = window.html2canvas;
    if (!h2c) {
      try { h2c = (await import("html2canvas")).default; } catch {}
    }
    if (!h2c) { noti(t("notiCanvasMissing"), "error"); return null; }

    // Neutraliza el zoom para exportar a 100% (captura consistente)
    const prevTransform = el.style.transform;
    const prevTransformOrigin = el.style.transformOrigin;
    const prevWidth = el.style.width;

    try {
      el.style.transform = "scale(1)";
      el.style.transformOrigin = "top left";
      el.style.width = "100%";

      // Espera 2 frames para que el layout se estabilice
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

      const canvas = await h2c(el, {
        scale,
        backgroundColor: transparent ? null : T.bg,
        onclone: transparent ? clone => {
          const surface=clone.getElementById('rack-detail-export');
          if(surface)surface.style.setProperty('background-color','transparent','important');
        } : undefined,
        useCORS: true,
        allowTaint: true,
        logging: false
      });

      return canvas;
    } finally {
      // Restaura estilos (siempre)
      el.style.transform = prevTransform;
      el.style.transformOrigin = prevTransformOrigin;
      el.style.width = prevWidth;
    }
  };

  const exportRackDetailPNG = async ({ scale = 3, transparent = false } = {}) => {
    try {
      const canvas = await _captureRackDetailCanvas({ scale, transparent });
      if (!canvas) return;

      const safe = (rack?.name || "rack").replace(/[^a-z0-9\-_]+/gi, "_");
      const filename = `rack-${safe}@${scale}x${transparent ? "-transparent" : ""}.png`;

      const downloadBlob = (blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      };

      canvas.toBlob((blob) => {
        if (blob) { downloadBlob(blob); noti(t("notiPngSaved"), "success"); }
        else {
          const a = document.createElement("a");
          a.href = canvas.toDataURL("image/png");
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          a.remove();
          noti(t("notiPngSaved"), "success");
        }
      }, "image/png", 1);

      // Completion is reported only by the download callback.
    } catch (e) {
      console.error(e);
      noti(t("notiPngFailed", {detail: e?.message || e}), "error");
    }
  };

  // Para reports: genera dataURL PNG (sin descargar)
  const captureRackDetailPNGDataURL = async ({ scale = 2, transparent = false } = {}) => {
    try {
      const canvas = await _captureRackDetailCanvas({ scale, transparent });
      if (!canvas) return null;
      return canvas.toDataURL("image/png");
    } catch (e) {
      console.error(e);
      return null;
    }
  };




  /* #38 PDF Export — opens print-optimized report */
  const exportPDF = () => {
    if(!legacyView){setRackReportPng(null);setView("report");return;}
    if (!rack) return;
    const allC = [...(rack.conns||[]), ...(project.crossConns||[]).filter(c => c.rackFrom === rack.id || c.rackTo === rack.id)];
    const portLabel = (did, pid) => project.racks.flatMap(r => r.devs).find(d => d.id === did)?.ports.find(p => p.id === pid)?.label || "";
    const rackLk = {}; project.racks.forEach(r => rackLk[r.id] = r.name);
    const usedU = rack.devs.reduce((s,d) => s+d.u, 0);
    const connRows = allC.map(c => {
      const xr = c.rackFrom ? `${rackLk[c.rackFrom]||"?"} → ${rackLk[c.rackTo]||"?"}` : "";
      return `<tr><td>${htmlEsc(c.fn||"")}</td><td>${htmlEsc(c.fpt||"")} #${htmlEsc(c.fpn||"")} ${htmlEsc(portLabel(c.fd, c.fp))}</td><td>→</td><td>${htmlEsc(c.tn||"")}</td><td>${htmlEsc(c.tpt||"")} #${htmlEsc(c.tpn||"")} ${htmlEsc(portLabel(c.td, c.tp))}</td><td>${htmlEsc(c.note||"")}</td><td style="color:#a855f7">${htmlEsc(xr)}</td></tr>`;
    }).join("");
    const devRows = rack.devs.map(d => {
      const used = allC.filter(c => c.fd === d.id || c.td === d.id).length;
      return `<tr><td>${htmlEsc(d.icon)} ${htmlEsc(d.name)}</td><td>${htmlEsc(d.preset)}</td><td>${htmlEsc(d.u)}U</td><td>${htmlEsc(d.ports.length)}</td><td>${htmlEsc(used)}</td></tr>`;
    }).join("");
    const w = window.open("", "_blank");
    w.document.write(`<!DOCTYPE html><html><head><title>RackClick Report — ${htmlEsc(rack.name)}</title>
    <style>body{font-family:'Segoe UI',sans-serif;padding:24px;color:#222;font-size:11px}
    h1{font-family:monospace;font-size:18px;margin-bottom:2px} h2{font-size:13px;margin:16px 0 6px;border-bottom:1px solid #ddd;padding-bottom:3px}
    .meta{color:#666;font-size:10px;margin-bottom:16px}
    .stats{display:flex;gap:16px;margin-bottom:12px} .stat{text-align:center;padding:8px 16px;border:1px solid #ddd;border-radius:6px}
    .stat b{display:block;font-size:18px;color:#10b981}
    table{width:100%;border-collapse:collapse;margin-bottom:16px;font-size:10px} th,td{border:1px solid #ddd;padding:4px 8px;text-align:left}
    th{background:#f5f5f5;font-weight:700} tr:nth-child(even){background:#fafafa}
    @media print{body{padding:12px}}</style></head><body>
    <h1>RACK<span style="color:#10b981">CLICK</span> — ${htmlEsc(rack.name)}</h1>
    <div class="meta">${htmlEsc(rack.location||"")} · ${htmlEsc(irScope.name)} · ${htmlEsc(irScope.technician||"")} · ${htmlEsc(new Date().toLocaleDateString("de-DE"))}</div>
    <div class="stats"><div class="stat"><b>${htmlEsc((rack.devs||[]).length)}</b>Devices</div><div class="stat"><b>${htmlEsc(usedU)}/${htmlEsc(rack.size)}</b>U Used</div><div class="stat"><b>${htmlEsc(allC.length)}</b>Connections</div></div>
    <h2>Devices</h2>
    <table><tr><th>Device</th><th>Preset</th><th>Size</th><th>Ports</th><th>Connected</th></tr>${devRows}</table>
    <h2>Connections</h2>
    <table><tr><th>From</th><th>Port</th><th></th><th>To</th><th>Port</th><th>Cable/Note</th><th>Cross-Rack</th></tr>${connRows}</table>
    <div style="margin-top:20px;font-size:8px;color:#aaa">Generated by RackClick v${htmlEsc(RC_VERSION)} \u00b7 ${htmlEsc(new Date().toISOString())}</div>
    <script>setTimeout(()=>window.print(),400)<\/script></body></html>`);
    noti(t("notiExportPdf"), "info");
  };

  /* #39 Excel Export — multi-sheet .xls (HTML table format) */
  const exportExcel = () => {
    if (!rack) return;
    const allC = [...(rack.conns||[]), ...(project.crossConns||[]).filter(c => c.rackFrom === rack.id || c.rackTo === rack.id)];
    const portLabel = (did, pid) => project.racks.flatMap(r => r.devs).find(d => d.id === did)?.ports.find(p => p.id === pid)?.label || "";
    const rackLk = {}; project.racks.forEach(r => rackLk[r.id] = r.name);
    let html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets>`;
    html += `<x:ExcelWorksheet><x:Name>Devices</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>`;
    html += `<x:ExcelWorksheet><x:Name>Connections</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>`;
    html += `<x:ExcelWorksheet><x:Name>Summary</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>`;
    html += `</x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body>`;
    // Sheet 1: Devices
    html += `<table x:str border="1"><tr><th>Name</th><th>Preset</th><th>Size (U)</th><th>Ports</th><th>Connected</th><th>Icon</th><th>Color</th></tr>`;
    rack.devs.forEach(d => { const used = allC.filter(c => c.fd === d.id || c.td === d.id).length; html += `<tr><td>${htmlEsc(d.name)}</td><td>${htmlEsc(d.preset)}</td><td>${htmlEsc(d.u)}</td><td>${htmlEsc(d.ports.length)}</td><td>${htmlEsc(used)}</td><td>${htmlEsc(d.icon)}</td><td>${htmlEsc(d.color)}</td></tr>`; });
    html += `</table>`;
    // Sheet 2: Connections
    html += `<table x:str border="1"><tr><th>From Device</th><th>From Port#</th><th>From Type</th><th>From Label</th><th>To Device</th><th>To Port#</th><th>To Type</th><th>To Label</th><th>Cable/Note</th><th>Cross-Rack</th><th>Color</th><th>Created</th></tr>`;
    allC.forEach(c => { const xr = c.rackFrom ? `${rackLk[c.rackFrom]||"?"} → ${rackLk[c.rackTo]||"?"}` : ""; html += `<tr><td>${htmlEsc(c.fn||"")}</td><td>${htmlEsc(c.fpn||"")}</td><td>${htmlEsc(c.fpt||"")}</td><td>${htmlEsc(portLabel(c.fd, c.fp))}</td><td>${htmlEsc(c.tn||"")}</td><td>${htmlEsc(c.tpn||"")}</td><td>${htmlEsc(c.tpt||"")}</td><td>${htmlEsc(portLabel(c.td, c.tp))}</td><td>${htmlEsc(c.note||"")}</td><td>${htmlEsc(xr)}</td><td>${htmlEsc(c.color||"")}</td><td>${htmlEsc(c.createdAt||"")}</td></tr>`; });
    html += `</table>`;
    // Sheet 3: Summary
    const usedU = rack.devs.reduce((s,d) => s+d.u, 0);
    html += `<table x:str border="1"><tr><th>Property</th><th>Value</th></tr>`;
    html += `<tr><td>Rack Name</td><td>${htmlEsc(rack.name)}</td></tr><tr><td>Location</td><td>${htmlEsc(rack.location||"")}</td></tr>`;
    html += `<tr><td>Size</td><td>${htmlEsc(rack.size)}U</td></tr><tr><td>Used</td><td>${htmlEsc(usedU)}U</td></tr><tr><td>Free</td><td>${htmlEsc(rack.size-usedU)}U</td></tr>`;
    html += `<tr><td>Devices</td><td>${htmlEsc((rack.devs||[]).length)}</td></tr><tr><td>Connections</td><td>${htmlEsc(allC.length)}</td></tr>`;
    html += `<tr><td>Project</td><td>${htmlEsc(irScope.name)}</td></tr><tr><td>Technician</td><td>${htmlEsc(irScope.technician||"")}</td></tr>`;
    html += `<tr><td>Exported</td><td>${htmlEsc(new Date().toISOString())}</td></tr></table>`;
    html += `</body></html>`;
    const blob = new Blob([html], { type: "application/vnd.ms-excel;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `rack-${rack.name.replace(/\s+/g,"-").toLowerCase()}.xls`; a.click(); URL.revokeObjectURL(url);
    noti(t("notiExportXls"), "success");
  };

  const duplicateRack = (rackId) => {
    const src = project.racks.find(r => r.id === rackId); if (!src) return;
    const withConns = src.conns.length > 0 ? confirm(t("confirmDuplicateRack", {name: src.name, count: src.conns.length})) : false;
    pushUndo("Duplicate rack");
    const newId = gid(); const idMap = {};
    const newDevs = src.devs.map(d => { const nid = gid(); idMap[d.id] = nid; return { ...d, id: nid, ports: d.ports.map((p, pi) => ({ ...p, id: `${nid}-p${pi+1}` })) }; });
    const portMap = {}; src.devs.forEach(d => d.ports.forEach((p, pi) => { portMap[p.id] = `${idMap[d.id]}-p${pi+1}`; }));
    const newConns = withConns ? src.conns.map(c => ({ ...c, id: gid(), fd: idMap[c.fd]||c.fd, td: idMap[c.td]||c.td, fp: portMap[c.fp]||c.fp, tp: portMap[c.tp]||c.tp })) : [];
    setProject(prev => ({ ...prev, racks: [...prev.racks, { ...src, id: newId, name: src.name + " (Copy)", location: src.location, size: src.size, devs: newDevs, conns: newConns }] }));
    noti(t("notiDuplicatedRack", {name: src.name, count: newConns.length}), "success");
  };

  /* ─── Device CRUD ─── */
  const irRoomFor=(height,excludeId)=>!!rack&&Number.isInteger(Number(height))&&Number(height)>0&&devs.reduce((n,d)=>n+(d.id===excludeId?0:Number(d.u)),0)+Number(height)<=Number(rack.size);
  const addP = k => {
    const p = PRESETS[k] || customTemplates[k]; if (!p) return;
    if(!irRoomFor(p.u)){noti(CW[lang].capacity,'error');return}
    pushUndo("Add device");
    const id = gid();
    setDevs(prev => [...prev, { id, name: dn.trim() || p.label, icon: p.icon, color: p.color, u: p.u, ports: irTemplatePorts(p,id,lang), preset: p.label }]);
    setDn(""); setShowNew(false); noti(t("notiAddedPreset", {name: p.label}), "success");
  };
  const addCustom = () => {
    if(!irRoomFor(cust.u)){noti(CW[lang].capacity,'error');return}
    pushUndo("Add custom device");
    const id = gid();
    setDevs(prev => [...prev, { id, name: cust.name.trim() || "Custom", icon: cust.icon, color: "#6b7280", u: cust.u, ports: mkP(cust.pg, id), preset: "Custom" }]);
    setCust({ name: "", icon: "▦", u: 1, pg: [{ t: "rj45", n: 4 }] }); setDn(""); setShowNew(false); noti(t("notiCustomDev"), "success");
  };
  const delD = id => { const dev = devs.find(d => d.id === id); const cc = allConns.filter(c => c.fd === id || c.td === id).length; if (!confirm(t("confirmDeleteDevice", {name: dev?.name, count: cc}))) return; pushUndo("Delete device"); setDevs(p => p.filter(d => d.id !== id)); setConns(p => p.filter(c => c.fd !== id && c.td !== id)); setCrossConns(p => p.filter(c => c.fd !== id && c.td !== id)); setSp(null); noti(t("notiRemoved"),"info"); };
  const moveD = (id, dir) => {
    const i=devs.findIndex(d=>d.id===id),ni=i+dir;
    if(i<0||ni<0||ni>=devs.length)return;
    pushUndo("Reorder devices");
    setDevs(prev=>{const a=[...prev],from=a.findIndex(d=>d.id===id),to=from+dir;if(from<0||to<0||to>=a.length)return prev;[a[from],a[to]]=[a[to],a[from]];return a});
  };
  const dragReorder = (fromId, toId) => { if (fromId === toId) { setDragId(null); setDragOverId(null); return; } pushUndo("Reorder devices"); setDevs(prev => { const a = [...prev]; const fi = a.findIndex(d => d.id === fromId); const ti = a.findIndex(d => d.id === toId); if (fi < 0 || ti < 0) return prev; const [item] = a.splice(fi, 1); a.splice(ti, 0, item); return a; }); setDragId(null); setDragOverId(null); };

  /* Touch drag for tablets */
  const onTouchDragStart = useCallback((devId, e) => {
    e.preventDefault(); e.stopPropagation();
    touchDragRef.current = { active: true, id: devId };
    setDragId(devId);
  }, []);
  const onTouchDragMove = useCallback((e) => {
    if (!touchDragRef.current.active) return;
    e.preventDefault();
    const touch = e.touches ? e.touches[0] : e;
    const els = document.elementsFromPoint(touch.clientX, touch.clientY);
    const hit = els.find(el => el.dataset && el.dataset.devid && el.dataset.devid !== touchDragRef.current.id);
    setDragOverId(hit ? hit.dataset.devid : null);
  }, []);
  const onTouchDragEnd = useCallback(() => {
    const td = touchDragRef.current;
    if (!td.active) return;
    touchDragRef.current = { active: false, id: null };
    setDragOverId(prev => { if (prev && td.id !== prev) { dragReorder(td.id, prev); } else { setDragId(null); } return null; });
  }, [dragReorder]);

  const toggleSelectDev = (id, ctrlKey) => {
    setSelectedDevs(prev => {
      const next = new Set(ctrlKey ? prev : []);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const bulkDeleteSelected = () => {
    if (selectedDevs.size === 0) return;
    const totalConns = allConns.filter(c => selectedDevs.has(c.fd) || selectedDevs.has(c.td)).length;
    if (!confirm(t("confirmDeleteDevices", {count: selectedDevs.size, connections: totalConns}))) return;
    pushUndo("Bulk delete");
    setDevs(p => p.filter(d => !selectedDevs.has(d.id)));
    setConns(p => p.filter(c => !selectedDevs.has(c.fd) && !selectedDevs.has(c.td)));
    setCrossConns(p => p.filter(c => !selectedDevs.has(c.fd) && !selectedDevs.has(c.td)));
    setSp(null); setSelectedDevs(new Set()); noti(`🗑 ${selectedDevs.size} ` + t("notiDevicesRemoved"), "info");
  };

  const saveEdit = (changes) => {
    const dev = devs.find(d => d.id === editDev?.id);
    if (!dev) return;
    if(!irRoomFor(changes.u,dev.id)){noti(CW[lang].capacity,'error');return}
    const { portGroups: pg, ...rest } = changes;
    let ports;
    try { ports = reconcilePorts(dev, pg, project.racks.flatMap(r => r.devs.flatMap(d => d.ports))); }
    catch { noti(t("notiPortEditInvalid"), "error"); return; }
    const kept = new Set(ports.map(p => p.id));
    const removed = dev.ports.filter(p => !kept.has(p.id));
    const ids = new Set(removed.map(p => p.id));
    const touches = c => (c.fd === dev.id && ids.has(c.fp)) || (c.td === dev.id && ids.has(c.tp));
    const affected = [...conns, ...(project.crossConns || [])].filter(touches);
    if (removed.length && !confirm(t("confirmRemovePorts", {
      ports: removed.map(p => `${p.id} (${p.type} #${p.gn})`).join(", "), count: affected.length
    }))) return;
    pushUndo("Edit device");
    setProject(prev => ({ ...prev,
      racks: prev.racks.map(r => r.id !== activeRackId ? r : { ...r,
        devs: r.devs.map(d => d.id === dev.id ? { ...d, ...rest, ports } : d),
        conns: r.conns.filter(c => !touches(c)).map(c=>irRenameLink(c,dev.id,rest.name||dev.name)) }),
      crossConns: (prev.crossConns || []).filter(c => !touches(c)).map(c=>irRenameLink(c,dev.id,rest.name||dev.name))
    }));
    setEditDev(null); noti(t("notiUpdated"), "success");
  };

  /* ─── Port context actions (status, poe, label) ─── */
  const onPortCtx = useCallback((e, did, pid) => {
    const port = devs.find(d => d.id === did)?.ports.find(p => p.id === pid); if (!port) return;
    irWattsUndoRef.current=false;setCtxMenu({ x: e.clientX, y: e.clientY, did, pid, port });
  }, [devs]);

  const onCtxAction = useCallback((action, value) => {
    if (!ctxMenu) return;
    const { did, pid } = ctxMenu;
    if(action==="wattsBegin"||action==="wattsEnd"){irWattsUndoRef.current=false;return}
    if (action === "label") {
      pushUndo("Set label");
      setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, label: value || undefined } : p) } : d));
      if (value) noti(`🏷 ${value}`, "success"); else noti(t("notiLabelRemoved"), "info");
    } else if (action === "status") {
      pushUndo("Set status");
      setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, status: value === "free" ? undefined : value } : p) } : d));
    } else if (action === "poe") {
      pushUndo("Toggle PoE");
      setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, poe: value, type: value ? "rj45_poe" : "rj45" } : p) } : d));
      noti(t(value ? "notiPoeOn" : "notiPoeOff"), "info");
    } else if (action === "watts") {
      const old=devs.find(d=>d.id===did)?.ports.find(p=>p.id===pid)?.watts;
      if(value!==undefined&&(!Number.isFinite(value)||value<0||value>90)){noti(CW[lang].wattsRange,'error');return}
      if(old===value)return;
      if(!irWattsUndoRef.current){pushUndo("Edit watts");irWattsUndoRef.current=true}
      setDevs(prev=>prev.map(d=>d.id!==did?d:{...d,ports:d.ports.map(p=>p.id===pid?{...p,watts:value}:p)}));
    } else if (action === "portColor") {
      pushUndo("Set port color");
      setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, portColor: value || undefined } : p) } : d));
      if (value) noti(t("notiColorSet"), "success"); else noti(t("notiColorCleared"), "info");
    }
    if (action !== "watts") setCtxMenu(null);
  }, [ctxMenu, pushUndo, devs]);

  const batchPortStatus = useCallback((devId, from, to, status) => {
    pushUndo(`Batch status ${status}`);
    setDevs(prev => prev.map(d => {
      if (d.id !== devId) return d;
      return { ...d, ports: d.ports.map(p => {
        if (p.gn >= from && p.gn <= to) return { ...p, status: status === "free" ? undefined : status };
        return p;
      }) };
    }));
    noti(t("notiPortRange", {from, to, status: PS[status].label}), "success");
  }, [pushUndo]);

  const batchPortPoe=(devId,from,to,value)=>{const dev=devs.find(d=>d.id===devId);const eligible=dev?.ports.filter(p=>p.gn>=from&&p.gn<=to&&['rj45','rj45_poe'].includes(p.type))||[];if(!eligible.length){noti(RC8_CORE_WORDS[lang].emptyRange,'info');return;}pushUndo('Batch PoE');const ids=new Set(eligible.map(p=>p.id));setDevs(ds=>ds.map(d=>d.id!==devId?d:{...d,ports:d.ports.map(p=>ids.has(p.id)?{...p,poe:value,type:value?'rj45_poe':'rj45'}:p)}));setSp(null);setCrossSel(null);};
  const batchPortColor = useCallback((devId, from, to, color) => {
    pushUndo("Batch port color");
    setDevs(prev => prev.map(d => {
      if (d.id !== devId) return d;
      return { ...d, ports: d.ports.map(p => {
        if (p.gn >= from && p.gn <= to) return { ...p, portColor: color || undefined };
        return p;
      }) };
    }));
    if (color) noti(t("notiPortColors", {from, to}), "success"); else noti(t("notiPortColorsCleared", {from, to}), "info");
  }, [pushUndo]);

  const allowNewPairs = pairs => {
    const lookup=(did,pid)=>project.racks.flatMap(r=>r.devs).find(d=>d.id===did)?.ports.find(p=>p.id===pid);
    if(pairs.some(([a,b])=>!irPowerPairAllowed(lookup(...a),lookup(...b)))){noti(IR_WORDS[lang].badPower,'error');return false}
    const seen = new Set();
    const links = [...project.racks.flatMap(r => r.conns), ...(project.crossConns || [])];
    for (const [did, pid] of pairs.flat()) {
      const d = project.racks.flatMap(r => r.devs).find(d => d.id === did);
      const p = d?.ports.find(p => p.id === pid);
      const key = JSON.stringify([did, pid]);
      if (!p || seen.has(key) || ["disabled", "faulty"].includes(p.status)
          || links.some(c => (c.fd === did && c.fp === pid) || (c.td === did && c.tp === pid))) {
        noti(t("notiPortBlocked"), "error"); return false;
      }
      seen.add(key);
    }
    const reserved = pairs.flat().some(([did, pid]) => project.racks.some(r =>
      r.devs.some(d => d.id === did && d.ports.some(p => p.id === pid && p.status === "reserved"))));
    return !reserved || confirm(t("confirmReserved"));
  };

  const startCrossConnect = useCallback((targetRackId) => {
    if (!ctxMenu) return;
    const { did, pid } = ctxMenu;
    const dev = devs.find(d => d.id === did); const port = dev?.ports.find(p => p.id === pid); if (!dev || !port) return;
    const pt = PT[port.type] || PT.rj45;
    setCrossSel({ fromRackId: activeRackId, did, pid, devName: dev.name, portGn: port.gn, portType: pt.label });
    setCtxMenu(null); openRack(targetRackId);
  }, [ctxMenu, devs, activeRackId]);

  /* ─── Port click handler ─── */
  const onPort = useCallback((did, pid) => {
    if(rc8Reconnect){
      if(rc8Reconnect.did===did&&rc8Reconnect.pid===pid){setRc8Reconnect(null);return;}
      try{const result=rc8ReconnectProject(project,rc8Reconnect,{did,pid});
        if(result.reserved&&!confirm(t('confirmReserved')))return;
        pushUndo('Reconnect cable');setProject(result.project);setRc8Reconnect(null);setSc(null);setSp(null);setCrossSel(null);noti(RC8_CORE_WORDS[lang].reconnected,'success');
      }catch{noti(RC8_CORE_WORDS[lang].reconnectBlocked,'error');}return;
    }
    const dev = devs.find(d => d.id === did); if (!dev) return;
    const port = dev.ports.find(p => p.id === pid); if (!port) return;
    const pt = PT[port.type] || PT.rj45;
    /* v0.8.4 [6]: puertos disabled/faulty no admiten conexiones NUEVAS.
       Si ya tienen conexión, el clic sigue permitido (ver/desconectar). */
    if ((port.status === "disabled" || port.status === "faulty")
        && !allConns.some(c => (c.fd === did && c.fp === pid) || (c.td === did && c.tp === pid))) {
      noti(t("notiPortBlocked"), "error");
      return;
    }
    if (crossSel) {
      const cp = allConns.find(c => c.fp === pid || c.tp === pid);
      if (cp) { setSc(cp); setCrossSel(null); return; }
      const fromRack = project.racks.find(r => r.id === crossSel.fromRackId);
      const fromDev = fromRack?.devs.find(d => d.id === crossSel.did);
      const fromPort = fromDev?.ports.find(p => p.id === crossSel.pid);
      if (!fromPort || crossSel.fromRackId === activeRackId) { noti(t("notiPortBlocked"), "error"); return; }
      if (!allowNewPairs([[[crossSel.did, crossSel.pid], [did, pid]]])) return;
      pushUndo("Cross-rack connect");
      const id = gid();
      const fromPt = PT[fromPort?.type] || PT.rj45;
      const conn = { id, rackFrom: crossSel.fromRackId, rackTo: activeRackId, fd: crossSel.did, fp: crossSel.pid, td: did, tp: pid, fn: fromDev?.name||"?", tn: dev.name, fpn: fromPort?.gn||0, tpn: port.gn, fpt: fromPt.label, tpt: pt.label, fpt2: fromPort?.type||"rj45", tpt2: port.type, createdAt: new Date().toISOString(), ...(getGroupColorForConn(fromDev, dev) ? { color: getGroupColorForConn(fromDev, dev) } : {}) };
      setCrossConns(prev => [...prev, conn]);
      setCrossSel(null); noti(t("notiCrossRack"), "success");
      return;
    }
    const existing = allConns.find(c => (c.fd === did && c.fp === pid) || (c.td === did && c.tp === pid));
    if (existing) { setSc(existing); return; }
    if (!sp) { setSp({ did, pid, devName: dev.name, portGn: port.gn, portType: pt.label }); return; }
    if (sp.pid === pid) { setSp(null); return; }
    if (!allowNewPairs([[[sp.did, sp.pid], [did, pid]]])) return;
    pushUndo("Connect");
    const sDev = devs.find(d => d.id === sp.did); const sPort = sDev?.ports.find(p => p.id === sp.pid); const sPt = PT[sPort?.type] || PT.rj45;
    const id = gid();
    const gc = getGroupColorForConn(sDev, dev);
    setConns(prev => [...prev, { id, fd: sp.did, fp: sp.pid, td: did, tp: pid, fn: sDev?.name||"?", tn: dev.name, fpn: sPort?.gn||0, tpn: port.gn, fpt: sPt.label, tpt: pt.label, fpt2: sPort?.type||"rj45", tpt2: port.type, createdAt: new Date().toISOString(), ...(gc ? { color: gc } : {}) }]);
    setFlashPorts(new Set([sp.pid, pid])); setTimeout(() => setFlashPorts(new Set()), 800);
    setSp(null); noti(t("connected"), "success");
  }, [sp, devs, conns, allConns, crossSel, activeRackId, project, pushUndo, groupColors, nextCableColor, rc8Reconnect, lang]);

  /* ─── Connection actions ─── */
  const delCn = id => { pushUndo("Disconnect"); const isLocal = conns.some(c => c.id === id); if (isLocal) setConns(p => p.filter(c => c.id !== id)); else setCrossConns(p => p.filter(c => c.id !== id)); setSc(null); noti(t("disconnected"),"info"); };
  const updateConnNote = (id, note) => {
    const before=[...conns,...(project.crossConns||[])].find(c=>c.id===id);
    if(!before||before.note===note)return;
    if(irConnNoteUndoRef.current!==id){pushUndo("Edit cable note");irConnNoteUndoRef.current=id}
    const isLocal = conns.some(c => c.id === id);
    if (isLocal) setConns(prev => prev.map(c => c.id === id ? { ...c, note } : c));
    else setCrossConns(prev => prev.map(c => c.id === id ? { ...c, note } : c));
  };
  const updateConnField = (id, field, value) => {
    const before=[...conns,...(project.crossConns||[])].find(c=>c.id===id);
    if(!before||before[field]===value)return;
    pushUndo("Edit cable "+field);
    const isLocal = conns.some(c => c.id === id);
    if (isLocal) setConns(prev => prev.map(c => c.id === id ? { ...c, [field]: value || undefined } : c));
    else setCrossConns(prev => prev.map(c => c.id === id ? { ...c, [field]: value || undefined } : c));
  };

  /* ─── Bulk connect ─── */
  const doBulkConnect = (srcDev, tgtDev, pairs) => {
    if (!pairs.length || !allowNewPairs(pairs.map(({ sp, tp }) => [[srcDev.id, sp.id], [tgtDev.id, tp.id]]))) return;
    pushUndo(`Bulk connect ${pairs.length}`);
    const srcPt = PT[pairs[0].sp.type] || PT.rj45;
    const tgtPt = PT[pairs[0].tp.type] || PT.rj45;
    const gc = getGroupColorForConn(srcDev, tgtDev);
    const newConns = pairs.map(({ sp: s, tp: t }) => ({
      id: gid(), fd: srcDev.id, fp: s.id, td: tgtDev.id, tp: t.id,
      fn: srcDev.name, tn: tgtDev.name, fpn: s.gn, tpn: t.gn,
      fpt: srcPt.label, tpt: tgtPt.label, fpt2: s.type, tpt2: t.type, createdAt: new Date().toISOString(), ...(gc ? { color: gc } : {})
    }));
    setConns(prev => [...prev, ...newConns]);
    setShowBulk(false);
    const fp = new Set(); pairs.forEach(({ sp: s, tp: t }) => { fp.add(s.id); fp.add(t.id); }); setFlashPorts(fp); setTimeout(() => setFlashPorts(new Set()), 800);
    noti(t("notiBulkConnections", {count: pairs.length}), "success");
  };

  const onDevCtx = useCallback((e, dev) => { e.preventDefault(); setDevCtx({ x: e.clientX, y: e.clientY, dev }); }, []);

  /* ─── Demo ─── */
  const newProject=()=>{if(irBoundary(project,irClient).length){noti(CW[lang].boundary,'error');return}if(!confirm(CW[lang].replaceClient))return;pushUndo('New project');setProject(irReplaceClient(project,irClient,emptyProject()));setActiveRackId(null);setView('project')};
 const loadDemo=()=>{if(irBoundary(project,irClient).length){noti(CW[lang].boundary,'error');return}if(irClientList(project).length&&!confirm(CW[lang].replaceClient))return;const data=irDemo(lang),demo=irClientProject(data,IR_DEMO_CLIENTS[1]);pushUndo('Load demo');const next=irReplaceClient(project,irClient,demo);setProject(next);setActiveRackId(irClientProject(next,irClient).racks[0]?.id);setView('project');noti(t('notiDemo'),'success')};

  /* ─── Search/Filter ─── */
  const sq = search.trim().toLowerCase();
  const filtDevs = sq ? devs.filter(d => d.name.toLowerCase().includes(sq) || d.preset.toLowerCase().includes(sq) || d.ports.some(p => p.label?.toLowerCase().includes(sq))) : devs;
  const displayDevs = rackFace === "rear" ? [...filtDevs].reverse() : filtDevs;
  const filtConns = sq ? allConns.filter(c => c.fn.toLowerCase().includes(sq) || c.tn.toLowerCase().includes(sq) || c.note?.toLowerCase().includes(sq)) : allConns;


 const irClear=()=>{setSp(null);setCrossSel(null);setSc(null);setCtxMenu(null);setDevCtx(null);setSelectedDevs(new Set());setEditDev(null);setEditRack(null);setSearch('');setGlobalSearch('');setIrInspect(null);setIrWire(null)};
 const irGoClient=client=>{irClear();setIrClient(client);setActiveRackId(irClientProject(project,client).racks[0]?.id);setView('project')};
 const irGoHome=()=>{irClear();setView('clients')};
 const irSetMeta=(key,value)=>{setProject(p=>!irClient?{...p,[key]:value}:{...p,rackclickClientMeta:[...(p.rackclickClientMeta||[]).filter(m=>m.client!==irClient),{...((p.rackclickClientMeta||[]).find(m=>m.client===irClient)||{}),client:irClient,[key]:value}]})};
 const irRenameCurrent=()=>{const name=prompt(CW[lang].renameClient,irClient||project.name);if(!name?.trim())return;const next=name.trim().slice(0,100);try{const p=irClient?irRenameClient(project,irClient,next):{...project,name:next};pushUndo('Rename client');setProject(p);if(irClient)setIrClient(next)}catch{noti(CW[lang].clientExists,'error')}};
 const irLoadTen=()=>{if(!confirm(CW[lang].demoConfirm))return;pushUndo('Demo 10');setProject(irDemo(lang));setIrClient(null);irClear();setView('clients')};
  /* ═══════ ROUTING ═══════ */
  if(view === "clientLabels") return <IRClientLabels project={irScope} lang={lang} onBack={()=>setView("project")}/>;
  if (view === "projectReport"&&!legacyView) return <IRClientReport project={irScope} lang={lang} onBack={()=>setView("project")} onClassic={()=>setView("classicReport")}/>;
  if (view === "classicReport"||view === "projectReport") return <ProjectReportPage project={irScope} onBack={() => setView("project")} lang={lang} T={T} ptColors={ptColors} rackFace={rackFace} />;
  if (view === "report" && rack && !legacyView) return <IRClientReport showClientBrand={false} project={{...irScope,name:irScope.name+" · "+rack.name,racks:[rack]}} lang={lang} onBack={()=>{setView("rack");setRackReportPng(null)}} onClassic={()=>setView("classicRackReport")}/>;
  if ((view === "report" || view === "classicRackReport") && rack) return <ReportPage rack={rack} rackPng={rackReportPng} cm={cm} crossConns={irScope.crossConns||[]} rackLookup={rackLookup} onBack={() => { setView("rack"); setRackReportPng(null); }} lang={lang} projectMeta={{ technician: irScope.technician, createdAt: project.createdAt, updatedAt: project.updatedAt, logo: irScope.logo, changeLog: irScope.changeLog }} />;

  /* ═══════ PROJECT VIEW ═══════ */
  if (view === "project" || view === "clients" || !rack) return (
    <div className="rc-app ir-app" style={{ minHeight: "100vh", background: T.bg, color: T.txt, fontFamily: "monospace", padding: 0 }}><IRClientNavigation client={irClient} onClient={irGoClient} onHome={irGoHome} project={project} rack={rack} view={view} onRack={openRack} onSettings={()=>{setView('clients');setShowSettings(true)}} lang={lang} systemhaus={project.rackclickSystemhaus||systemhaus} onManage={()=>setIrManage(true)} onRename={()=>{const name=prompt((IR_WORDS[lang]||IR_WORDS.en).systemhaus,project.rackclickSystemhaus||systemhaus);if(name?.trim()){pushUndo('Systemhaus');setProject(p=>({...p,rackclickSystemhaus:name.trim().slice(0,80)}))}}}/>{irManage&&<IRInfrastructure project={project} lang={lang} onClose={()=>setIrManage(false)} onApply={draft=>{pushUndo('Infrastructure');setProject(draft);setView('clients')}}/>}{irFaceDevice&&<IRFaceEditor device={irFaceDevice} lang={lang} onClose={()=>setIrFaceDevice(null)} onApply={(values,roles)=>{const edited={...irFaceDevice,ports:irFaceDevice.ports.map(p=>({...p,rackclickPowerRole:roles[p.id]}))};const lookup=(did,pid)=> (did===edited.id?edited:project.racks.flatMap(r=>r.devs).find(d=>d.id===did))?.ports.find(p=>p.id===pid);if(rc8AllLinks(project).some(c=>(c.fd===edited.id||c.td===edited.id)&&!irPowerPairAllowed(lookup(c.fd,c.fp),lookup(c.td,c.tp)))){noti(RC8_CORE_WORDS[lang].roleConflict,'error');return;}pushUndo('Port faces');setProject(p=>({...p,racks:p.racks.map(r=>({...r,devs:r.devs.map(d=>d.id!==irFaceDevice.id?d:{...d,ports:d.ports.map(port=>{const {rackclickFace,rackclickPowerRole,...base}=port;const rest={...base,...(roles[port.id]&&roles[port.id]!=='unspecified'?{rackclickPowerRole:roles[port.id]}:{})};return values[port.id]==='auto'?rest:{...rest,rackclickFace:values[port.id]}})})}))}))}}/>}{BOOT_RECOVERY_REASON&&<div className="ir-recovery-block" role="alert" style={{background:'#7f1d1d',color:'#fff',padding:'12px 20px',fontSize: 13,fontWeight:700}}>
    {IR_RECOVERY_WORDS[lang][BOOT_RECOVERY_REASON]} <button onClick={saveJSON}>{IR_RECOVERY_WORDS[lang].exportMemory}</button>
    {BOOT_RECOVERY_REASON==='quarantineFailed'&&<button onClick={irDownloadCurrentRescue}>{IR_RECOVERY_WORDS[lang].exportRaw}</button>}
    <button onClick={()=>location.reload()}>{IR_RECOVERY_WORDS[lang].reload}</button>
  </div>}<div className="ir-breadcrumb">{project.rackclickSystemhaus||systemhaus} <span>›</span> <button className="ir-crumb-home" onClick={irGoHome}>{CW[lang].infrastructure}</button> {view!=='clients'&&<><span>›</span><button className="ir-crumb-client" onClick={()=>irGoClient(irClient)}>{irScope.name}</button></>} {view==='rack'&&rack?.rackclickLocation&&<><span>›</span>{['client','site','building','room'].map(k=>rack.rackclickLocation[k]).filter(Boolean).join(' / ')}</>} {view==='rack'&&<><span>›</span>{rack?.location}<span>›</span>{rack?.name}</>}<small>v{RC_VERSION}</small></div>
      <style>{`
        .rc-app input, .rc-app select { background: ${T.inp} !important; border-color: ${T.bdr} !important; color: ${T.txt} !important; }
        .rc-app input::placeholder { color: ${T.vdim} !important; }
      `}</style>
      {editRack && <RackEditModal locations={irLocations(irScope)} rack={editRack} onSave={saveRackEdit} onClose={() => setEditRack(null)} t={t} onDelete={irScope.racks.length > 1 ? deleteRack : null} />}

      {/* #28: Change Log Modal */}
      {showLog && <div onClick={() => setShowLog(false)} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
        <div onClick={e => e.stopPropagation()} style={{ background: T.bg2, border: `1px solid ${T.bdr}`, borderRadius: 12, padding: 24, minWidth: 400, maxWidth: 520, maxHeight: "70vh", display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <span style={{ fontSize: 14, fontWeight: 800 }}>📜 Änderungs-Log</span>
            <div style={{ display: "flex", gap: 6 }}>
              <button onClick={() => { if (confirm(t("confirmClearLog"))) { setProject(prev => ({ ...prev, changeLog: irClientList(prev).length?(prev.changeLog||[]).filter(e=>(e.client??null)!==irClient):[] })); setShowLog(false); noti(t("notiLogCleared"), "info"); } }} style={{ padding: "3px 8px", background: "#ef444408", border: "1px solid #ef444422", color: "#ef4444", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>Clear</button>
              <button onClick={() => setShowLog(false)} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: 14 }}>×</button>
            </div>
          </div>
          <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 1 }}>
            {(irScope.changeLog||[]).slice().reverse().map((e, i) => (
              <div key={i} style={{ display: "flex", gap: 8, fontSize: "var(--ir-small)", color: T.dim, padding: "3px 0", borderBottom: `1px solid ${T.bg3}` }}>
                <span style={{ color: T.mut, minWidth: 100, fontSize: "var(--ir-small)", fontFamily: "monospace" }}>{new Date(e.ts).toLocaleString("de-DE", { dateStyle: "short", timeStyle: "short" })}</span>
                <span style={{ fontWeight: 600, color: T.txt }}>{e.action}</span>
                {e.tech && <span style={{ color: T.mut, marginLeft: "auto", fontSize: "var(--ir-small)" }}>👷 {e.tech}</span>}
              </div>
            ))}
            {(irScope.changeLog||[]).length === 0 && <div style={{ fontSize: "var(--ir-small)", color: T.vdim, textAlign: "center", padding: 20 }}>No log entries yet</div>}
          </div>
        </div>
      </div>}

      {/* ═══ SETTINGS MODAL ═══ */}
      {showSettings && <div onClick={() => setShowSettings(false)} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
        <div onClick={e => e.stopPropagation()} style={{ background: T.bg2, border: `1px solid ${T.bdr}`, borderRadius: 12, padding: 24, width: 480, maxHeight: "80vh", overflowY: "auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <span style={{ fontSize: 14, fontWeight: 800, color: T.txt }}>{(IR_WORDS[lang]||IR_WORDS.en).settings}</span>
            <button onClick={() => setShowSettings(false)} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: 16 }}>×</button>
          </div>

          <div className="ir-settings-extra"><label>{(IR_WORDS[lang]||IR_WORDS.en).systemhaus}<input value={project.rackclickSystemhaus||systemhaus} maxLength={80} onBlur={e=>delete e.currentTarget.dataset.irUndo} onChange={e=>{if(!e.currentTarget.dataset.irUndo){pushUndo('Systemhaus');e.currentTarget.dataset.irUndo='1'}setProject(p=>({...p,rackclickSystemhaus:e.target.value}))}}/></label><label><input type="checkbox" checked={legacyView} onChange={e=>setLegacyView(e.target.checked)}/>{(IR_WORDS[lang]||IR_WORDS.en).fallback}</label></div>
          {/* Language */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: "var(--ir-small)", color: T.dim, fontWeight: 700, letterSpacing: 0.5, marginBottom: 6 }}>🌐 {t("language")}</div>
            <div style={{ display: "flex", gap: 4 }}>
              {[["en","🇬🇧 English"],["de","🇩🇪 Deutsch"],["es","🇪🇸 Español"]].map(([id,label]) => (
                <button key={id} onClick={() => switchLang(id)} style={{ flex: 1, padding: "8px 4px", background: lang === id ? T.acc+"22" : T.bg3, border: `2px solid ${lang === id ? T.acc : T.bdr}`, color: lang === id ? T.acc : T.dim, borderRadius: 6, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit", fontWeight: lang === id ? 700 : 400 }}>{label}</button>
              ))}
            </div>
          </div>

          {/* Theme */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: "var(--ir-small)", color: T.dim, fontWeight: 700, letterSpacing: 0.5, marginBottom: 6 }}>{`🎨 ${t("theme")}`}</div>
            <div style={{ display: "flex", gap: 4 }}>
              {[THEMES.dark,THEMES.light].map(t => (
                <button key={t.id} onClick={() => switchTheme(t.id)} style={{ flex: 1, padding: "8px 4px", background: themeId === t.id ? T.acc+"22" : T.bg3, border: `2px solid ${themeId === t.id ? T.acc : T.bdr}`, color: themeId === t.id ? T.acc : T.dim, borderRadius: 6, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit", fontWeight: themeId === t.id ? 700 : 400 }}>{(IR_WORDS[lang]||IR_WORDS.en)[{dark:"themeDark",semidark:"themeSemidark",silver:"themeSilver",light:"themeLight"}[t.id]]}</button>
              ))}
            </div>
          </div>

          {/* Port Type Colors */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: "var(--ir-small)", color: T.dim, fontWeight: 700, letterSpacing: 0.5, marginBottom: 6 }}>{`🔌 ${t("portColors")}`}</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
              {Object.entries(PT).map(([key, pt]) => (
                <div key={key} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 8px", background: T.bg3, borderRadius: 4, border: `1px solid ${T.bdr}` }}>
                  <input type="color" value={ptColors[key] || pt.color} onChange={e => setPtColor(key, e.target.value)} style={{ width: 20, height: 20, border: "none", cursor: "pointer", padding: 0, background: "none" }} />
                  <span style={{ fontSize: "var(--ir-small)", color: T.txt, flex: 1 }}>{pt.label}</span>
                  {ptColors[key] !== DEFAULT_PT_COLORS[key] && <button onClick={() => setPtColor(key, DEFAULT_PT_COLORS[key])} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: "var(--ir-small)" }}>↺</button>}
                </div>
              ))}
            </div>
            <button onClick={() => { setPtColors({...DEFAULT_PT_COLORS}); try { localStorage.removeItem(PT_COLOR_KEY); } catch {} }} style={{ marginTop: 4, padding: "3px 8px", background: "none", border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{`↺ ${t("resetAll")}`}</button>
          </div>

          {/* Group Connection Colors */}
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: "var(--ir-small)", color: T.dim, fontWeight: 700, letterSpacing: 0.5, marginBottom: 4 }}>{`🔗 ${t("groupColors")}`}</div>
            <div style={{ fontSize: "var(--ir-small)", color: T.mut, marginBottom: 6 }}>{t("groupHint")}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
              {(() => { const cats = Object.keys(DEV_CATEGORIES); const pairs = []; for (let i = 0; i < cats.length; i++) for (let j = i; j < cats.length; j++) pairs.push([cats[i], cats[j]].sort().join("↔")); return pairs; })().map(pair => (
                <div key={pair} style={{ display: "flex", alignItems: "center", gap: 6, padding: "3px 8px", background: T.bg3, borderRadius: 4, border: `1px solid ${T.bdr}` }}>
                  <span style={{ fontSize: "var(--ir-small)", color: T.txt, flex: 1, fontWeight: 600 }}>{pair}</span>
                  <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
                    {["#ffffff","#d1d5db","#fbbf24","#3b82f6","#10b981","#ef4444","#a855f7","#f97316","#06b6d4","#000000"].map(c => (
                      <div key={c} onClick={() => setGroupColor(pair, groupColors[pair] === c ? null : c)}
                        style={{ width: 14, height: 14, borderRadius: 3, background: c, border: `2px solid ${groupColors[pair] === c ? T.acc : c === "#ffffff" ? "#ccc" : c}`, cursor: "pointer", boxShadow: groupColors[pair] === c ? `0 0 4px ${T.acc}` : "none" }} />
                    ))}
                    {groupColors[pair] && <button onClick={() => setGroupColor(pair, null)} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: "var(--ir-small)", padding: "0 2px" }}>×</button>}
                  </div>
                </div>
              ))}
            </div>
          </div>


          <section className="ir-settings-collections">
            <h3>{(IR_WORDS[lang]||IR_WORDS.en).manageTemplates} ({Object.keys(customTemplates).length})</h3>
            {Object.keys(customTemplates).length === 0 && <p>{(IR_WORDS[lang]||IR_WORDS.en).noTemplates}</p>}
            {Object.entries(customTemplates).map(([key,tpl])=><div key={key}><span>{tpl.label||tpl.name||key}</span><button aria-label={(IR_WORDS[lang]||IR_WORDS.en).removeTemplate+' '+(tpl.label||tpl.name||key)} onClick={()=>deleteCustomTemplate(key)}>{(IR_WORDS[lang]||IR_WORDS.en).remove}</button></div>)}
            <h3>{(IR_WORDS[lang]||IR_WORDS.en).manageFavorites} ({favPresets.size})</h3>
            {favPresets.size === 0 && <p>{(IR_WORDS[lang]||IR_WORDS.en).noFavorites}</p>}
            {[...favPresets].filter(key=>PRESETS[key]).map(key=><div key={key}><span>{PRESETS[key].label||key}</span><button aria-label={(IR_WORDS[lang]||IR_WORDS.en).removeFavorite+' '+(PRESETS[key].label||key)} onClick={()=>toggleFav(key)}>{(IR_WORDS[lang]||IR_WORDS.en).remove}</button></div>)}
          </section>
          {/* Snapshots */}
          <div style={{ marginBottom: 12 }}>
            <div onClick={() => setShowSnapshots(!showSnapshots)} style={{ fontSize: "var(--ir-small)", color: T.dim, fontWeight: 700, letterSpacing: 0.5, marginBottom: 4, cursor: "pointer" }}>{"📸 " + t("snapshots") + " (" + snapshots.length + ") " + (showSnapshots ? "▼" : "▶")}</div>
            {showSnapshots && <div style={{ maxHeight: 180, overflowY: "auto", display: "flex", flexDirection: "column", gap: 4 }}>
              {snapshots.length === 0 && <div style={{ fontSize: "var(--ir-small)", color: T.dim, padding: 8 }}>{t("noSnapshots")}</div>}
              {snapshots.map(snap => <div key={snap.id} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 6px", background: T.bg3, borderRadius: 4, fontSize: "var(--ir-small)" }}>
                <span style={{ flex: 1, color: T.txt, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={snap.name}>{snap.name}</span>
                <span style={{ color: T.dim, fontSize: "var(--ir-small)", flexShrink: 0 }}>{new Date(snap.date).toLocaleDateString()}</span>
                <button onClick={e => { e.stopPropagation(); if (confirm(t("restoreSnapshot") + ": " + snap.name + "?")) restoreSnapshot(snap); }} style={{ background: "#10b98112", border: "1px solid #10b98133", color: "#10b981", borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", padding: "2px 5px", fontFamily: "inherit" }}>{t("restoreSnapshot")}</button>
                <button onClick={e => { e.stopPropagation(); deleteSnapshot(snap.id); }} style={{ background: "#ef444412", border: "1px solid #ef444433", color: "#ef4444", borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", padding: "2px 5px", fontFamily: "inherit" }}>{t("deleteSnapshot")}</button>
              </div>)}
            </div>}
          </div>

          {/* Distinct raw recovery episodes, no automatic deletion. */}
          {quarantineEpisodes.length>0 && <div className="ir-recovery-episodes" style={{marginBottom:12,border:'1px solid #ef4444',padding:10,borderRadius:8}}>
            <strong>{t('quarantine')} · {IR_RECOVERY_WORDS[lang].quarantineCount}: {quarantineEpisodes.length}</strong>
            {quarantineEpisodes.map((episode,index)=><div key={episode.key} style={{padding:8,borderBottom:'1px solid #ef444466'}}>
              <div>{index+1}. {episode.createdAt||episode.key} · {episode.reason||'raw data'}</div>
              <button onClick={()=>downloadQuarantine(false,episode.key)}>{t('quarantineDownload')}</button>
              {episode.hasAutosave&&<button onClick={()=>downloadQuarantine(true,episode.key)}>{t('quarantineDownloadAutosave')}</button>}
              <button onClick={()=>deleteQuarantine(episode.key)}>{t('quarantineDelete')}</button>
            </div>)}
          </div>}
        </div>
      </div>}

            {autosaveStatus.ok === false && <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 3000, background: "#7f1d1d", borderTop: "2px solid #ef4444", padding: "10px 16px", display: "flex", alignItems: "center", justifyContent: "center", gap: 12, flexWrap: "wrap" }}>
        <span style={{ color: "#fecaca", fontSize: "var(--ir-small)", fontWeight: 700 }}>{"\u26A0\uFE0F " + t("autosaveBannerTitle") + " \u2014 " + t("autosaveBannerText")}</span>
        <button onClick={irExportAll} style={{ padding: "6px 12px", background: "#ef4444", border: "none", color: "#fff", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: 900, fontFamily: "inherit" }}>{"\uD83D\uDCBE " + t("autosaveExportNow")}</button>
      </div>}
      {notif && <div style={{ position: "fixed", top: 12, left: "50%", transform: "translateX(-50%)", zIndex: 2000, padding: "6px 18px", borderRadius: 8, fontSize: "var(--ir-small)", fontWeight: 700, background: notif.type === "error" ? "#ef4444" : notif.type === "info" ? "#3b82f6" : "#10b981", color: "#fff", boxShadow: "0 4px 12px #000a" }}>{notif.msg}</div>}
      {view==='clients'?<IRClientsHome project={project} lang={lang} onClient={irGoClient} onDemo={irLoadTen} onExport={irExportAll} onLoad={()=>irImport('all')} onManage={()=>setIrManage(true)} onLanguage={switchLang} status={autosaveStatus}/>:<>
      <div className="ir-project-toolbar" style={{ padding: "14px 20px 8px", display: "flex", alignItems: "center", gap: 12, borderBottom: `1px solid ${T.bg3}`, flexWrap: "wrap" }}>
        <span style={{ fontSize: 17, fontWeight: 900, letterSpacing: 1, color: T.txt }}>RACK<span style={{ color: T.acc }}>CLICK</span></span>
        <span style={{ fontSize: "var(--ir-small)", color: T.vdim }}>v0.9.0-rc9</span>
        <span title={t("autosaveLabel")} style={{ fontSize: "var(--ir-small)", color: autosaveStatus.ok === false ? "#ef4444" : T.vdim, fontWeight: autosaveStatus.ok === false ? 900 : 400 }}>
          {autosaveStatus.ok === true && ("\uD83D\uDCBE \u2713 " + new Date(autosaveStatus.lastOkAt).toLocaleTimeString("de-DE"))}
          {autosaveStatus.ok === false && ("\uD83D\uDCBE \u2717 " + t("autosaveFailing"))}
        </span>
        <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
          {[THEMES.dark,THEMES.light].map(t => (
            <button key={t.id} onClick={() => switchTheme(t.id)} style={{ padding: "2px 5px", background: themeId === t.id ? T.acc+"22" : "transparent", border: `1px solid ${themeId === t.id ? T.acc : T.bdr}`, color: themeId === t.id ? T.acc : T.mut, borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{(IR_WORDS[lang]||IR_WORDS.en)[{dark:"themeDark",semidark:"themeSemidark",silver:"themeSilver",light:"themeLight"}[t.id]]}</button>
          ))}
          <button onClick={() => setShowSettings(true)} style={{ padding: "2px 6px", background: T.bg2, border: `1px solid ${T.bdr}`, color: T.dim, borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit", marginLeft: 4 }}>⚙️</button>
        </div>
        <div style={{ marginLeft: "auto", display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
          <button onClick={saveJSON} style={{ padding: "4px 10px", background: dirty ? "#10b98125" : "#10b98108", border: `1px solid ${dirty ? "#10b981" : "#10b98133"}`, color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit", position: "relative" }}>{dirty && <span style={{ position: "absolute", top: -2, right: -2, width: 6, height: 6, borderRadius: "50%", background: "#ef4444" }} />}{`💾 ${(irClient?CW[lang].saveClient:t("save"))}${dirty ? " *" : ""}`}</button>
          <button onClick={() => { const name = prompt(CW[lang].saveSnapshot, project.name + " " + new Date().toLocaleDateString()); if (name) saveSnapshot(name); }} style={{ padding: "4px 10px", background: "#f59e0b08", border: "1px solid #f59e0b33", color: "#f59e0b", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{"📸 " + t("snapshot")}</button>
          <button onClick={loadJSON} style={{ padding: "4px 10px", background: "#3b82f608", border: "1px solid #3b82f633", color: "#3b82f6", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{`📂 ${t("load")}`}</button>
          <button onClick={mergeProject} title={CW[lang].clientOnly} style={{ padding: "4px 10px", background: "#a855f708", border: "1px solid #a855f733", color: "#a855f7", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{`🔀 ${t("merge")}`}</button>
          <button onClick={importRackJSON} style={{ padding: "4px 10px", background: "#a855f708", border: "1px solid #a855f733", color: "#a855f7", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{`📥 ${t("import")}`}</button>
          {!legacyView&&<><button className="ir-client-export" onClick={()=>irReportCSV(irScope,lang)}>{(RC8_REPORT_WORDS[lang]||RC8_REPORT_WORDS.en).csv}</button><button className="ir-client-export" onClick={()=>setView("clientLabels")}>{(RC8_REPORT_WORDS[lang]||RC8_REPORT_WORDS.en).labels}</button></>}
          {irScope.racks.length > 0 && <button onClick={() => setView("projectReport")} style={{ padding: "4px 14px", background: "#f59e0b12", border: "1px solid #f59e0b44", color: "#f59e0b", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: 700, fontFamily: "inherit" }}>{`📊 ${t("report")}`}</button>}
          <button onClick={loadDemo} style={{ padding: "4px 10px", background: T.bg3, border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{t("demo")}</button>
          <button onClick={newProject} title={CW[lang].clientOnly} style={{ padding: "4px 10px", background: "#ef444408", border: "1px solid #ef444422", color: "#ef4444", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{`🗑 ${t("newProj")}`}</button>
        </div>
      </div>
      {irBoundary(project,irClient).length>0&&<div className="ir-warning">{CW[lang].boundary}<button onClick={irExportAll}>{CW[lang].backupAll}</button></div>}
      <div style={{ padding: "16px 20px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 8 }}>
          <input aria-label={CW[lang].renameClient} value={irScope.name} readOnly onClick={irRenameCurrent} style={{ background: "none", border: "none", color: T.txt, fontSize: 20, fontWeight: 900, fontFamily: "monospace", outline: "none", padding: 0, maxWidth: 400 }} />
          <div style={{ display: "flex", gap: 12, alignItems: "center", marginTop: 2 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <span style={{ fontSize: "var(--ir-small)", color: T.vdim }}>👷</span>
              <input value={irScope.technician || ""} onChange={e => irSetMeta("technician",e.target.value)} placeholder={CW[lang].technician} style={{ background: "none", border: "none", borderBottom: `1px solid ${T.bdr}`, color: T.dim, fontSize: "var(--ir-small)", fontFamily: "monospace", outline: "none", padding: "1px 4px", width: 140 }} />
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              {irSafeReportLogo(irScope.logo) ? <img className="ir-client-logo" src={irSafeReportLogo(irScope.logo)} alt={(RC8_REPORT_WORDS[lang]||RC8_REPORT_WORDS.en).logo} /> : null}
              <button onClick={() => { const inp = document.createElement("input"); inp.type = "file"; inp.accept = "image/*"; inp.onchange = e => { const f = e.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = ev => { irSetMeta("logo",ev.target.result); noti(t("notiLogoSet"), "success"); }; r.readAsDataURL(f); }; inp.click(); }} style={{ padding: "2px 6px", background: "none", border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{irScope.logo ? "🖼" : "🖼 Logo"}</button>
              {irScope.logo && <button onClick={() => { irSetMeta("logo",undefined); noti(t("notiLogoRemoved"), "info"); }} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: "var(--ir-small)" }}>×</button>}
            </div>
            {project.updatedAt && <span style={{ fontSize: "var(--ir-small)", color: T.vdim }}>📅 {new Date(project.updatedAt).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })}</span>}
            {(irScope.changeLog||[]).length > 0 && <button onClick={() => setShowLog(true)} style={{ padding: "2px 6px", background: "none", border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>📜 Log ({(irScope.changeLog||[]).length})</button>}
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            {[{ v: irScope.racks.length, l: "Racks", c: "#10b981" },{ v: (irScope.racks||[]).reduce((s, r) => s + ((r.devs||[]).length), 0), l: CW[lang].devices, c: "#3b82f6" },{ v: irScope.racks.reduce((s, r) => s + (r.conns||[]).length, 0) + (irScope.crossConns||[]).length, l: CW[lang].connections, c: "#f59e0b" },...((irScope.crossConns||[]).length > 0 ? [{ v: (irScope.crossConns||[]).length, l: "🔗 Cross-rack", c: "#a855f7" }] : [])].map((s, i) => (
              <div key={i} style={{ background: T.bg2, borderRadius: 8, padding: "8px 14px", textAlign: "center", border: `1px solid ${T.bdr}` }}>
                <div style={{ fontSize: 18, fontWeight: 900, color: s.c }}>{s.v}</div>
                <div style={{ fontSize: "var(--ir-small)", color: T.vdim, textTransform: "uppercase" }}>{s.l}</div>
              </div>))}
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 12, marginBottom: 16 }}>
          {/* Global search */}
          <div style={{ gridColumn: "1 / -1", marginBottom: 4 }}>
            <input data-globalsearch="1" placeholder={t("globalSearch")} value={globalSearch} onChange={e => setGlobalSearch(e.target.value)} style={{ width: "100%", background: T.bg2, border: `1px solid ${T.bdr}`, color: T.txt, padding: "8px 12px", borderRadius: 6, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", boxSizing: "border-box" }} />
            {globalSearch.trim() && (() => {
              const gsq = globalSearch.trim().toLowerCase();
              const results = [];
              irScope.racks.forEach(r => {
                r.devs.forEach(d => {
                  const match = d.name.toLowerCase().includes(gsq) || d.preset.toLowerCase().includes(gsq) || (d.notes && Object.values(d.notes).some(v => v && String(v).toLowerCase().includes(gsq)));
                  const matchingPorts = d.ports.filter(p => p.label && p.label.toLowerCase().includes(gsq));
                  if (match || matchingPorts.length > 0) results.push({ rack: r, dev: d, ports: matchingPorts, type: "dev" });
                });
                (r.conns||[]).forEach(c => { if (c.fn.toLowerCase().includes(gsq) || c.tn.toLowerCase().includes(gsq) || (c.note && c.note.toLowerCase().includes(gsq))) results.push({ rack: r, conn: c, type: "conn" }); });
              });
              (irScope.crossConns||[]).forEach(c => { if (c.fn.toLowerCase().includes(gsq) || c.tn.toLowerCase().includes(gsq) || (c.note && c.note.toLowerCase().includes(gsq))) results.push({ rack: irScope.racks.find(r => r.id === c.rackFrom), conn: c, type: "xconn" }); });
              return results.length > 0 ? (
                <div style={{ marginTop: 6, maxHeight: 200, overflowY: "auto", border: `1px solid ${T.bdr}`, borderRadius: 6, background: T.bg2 }}>
                  <div style={{ fontSize: "var(--ir-small)", color: T.mut, padding: "4px 10px" }}>{results.length} {(IR_WORDS[lang]||IR_WORDS.en).searchHits}</div>
                  {results.slice(0, 30).map((r, i) => (
                    <div key={i} onClick={() => { setActiveRackId(r.rack?.id); setView("rack"); setSearch(r.type === "dev" ? r.dev?.name?.substring(0,8) : ""); setGlobalSearch(""); }}
                      style={{ padding: "4px 10px", fontSize: "var(--ir-small)", cursor: "pointer", borderTop: `1px solid ${T.bg3}`, display: "flex", alignItems: "center", gap: 6, color: T.dim }}
                      onMouseEnter={e => e.currentTarget.style.background = "#10b98108"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                      <span style={{ fontSize: "var(--ir-small)", color: "#10b981", minWidth: 60 }}>⬒ {r.rack?.name}</span>
                      {r.type === "dev" && <><span style={{ color: r.dev.color, fontWeight: 700 }}>{r.dev.icon} {r.dev.name}</span><span style={{ color: T.mut }}>{r.dev.preset}</span>{r.ports.length > 0 && <span style={{ color: "#10b981" }}>🏷 {r.ports.map(p => p.label).join(", ")}</span>}</>}
                      {r.type === "conn" && <><span style={{ color: "#f59e0b" }}>{r.conn.fn} → {r.conn.tn}</span>{r.conn.note && <span style={{ color: T.mut, fontStyle: "italic" }}>📎 {r.conn.note}</span>}</>}
                      {r.type === "xconn" && <><span style={{ color: "#a855f7" }}>🔗 {r.conn.fn} → {r.conn.tn}</span></>}
                    </div>
                  ))}
                </div>
              ) : <div style={{ padding: "6px 10px", fontSize: "var(--ir-small)", color: T.vdim }}>{(IR_WORDS[lang]||IR_WORDS.en).noSearch} "{globalSearch}"</div>;
            })()}
          </div>
          {(irScope.racks||[]).map((r,i) => {
            const rUsedU = r.devs.reduce((s, d) => s + d.u, 0);
            return (
              <div key={r.id} onClick={() => openRack(r.id)} style={{ background: T.bg2, border: `1px solid ${T.bdr}`, borderRadius: 10, padding: 16, cursor: "pointer", transition: "border-color 0.15s", position: "relative" }}
                onMouseEnter={e => e.currentTarget.style.borderColor = "#10b98144"} onMouseLeave={e => e.currentTarget.style.borderColor = "#1a1a2e"}>
                <button onClick={e => { e.stopPropagation(); duplicateRack(r.id); }} style={{ position: "absolute", top: 8, right: 30, background: "none", border: "none", color: T.vdim, cursor: "pointer", fontSize: "var(--ir-small)", padding: "2px 6px" }} title="Duplicate">📋</button>
                <button onClick={e => { e.stopPropagation(); setEditRack(r); }} style={{ position: "absolute", top: 8, right: 8, background: "none", border: "none", color: T.vdim, cursor: "pointer", fontSize: 12, padding: "2px 6px" }} title="Edit">✎</button>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <div style={{ width: 24, height: 24, background: "#10b98115", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, color: "#10b981" }}>⬒</div>
                  <div><div style={{ fontSize: 12, fontWeight: 800, color: "#10b981" }}>{r.name}</div>{r.location && <div style={{ fontSize: "var(--ir-small)", color: T.mut }}>{r.location}</div>}</div>
                </div>
                <div style={{ display: "flex", gap: 12, fontSize: "var(--ir-small)", color: T.mut }}>
                  <span><span style={{ color: "#3b82f6", fontWeight: 700 }}>{(r.devs||[]).length}</span> {CW[lang].devices}</span>
                  <span><span style={{ color: "#f59e0b", fontWeight: 700 }}>{(r.conns||[]).length}</span> {CW[lang].connections}</span>
                  <span><span style={{ color: "#8b5cf6", fontWeight: 700 }}>{rUsedU}/{r.size}</span>U</span>
                </div>
                <div style={{ marginTop: 6, height: 3, background: T.bdr, borderRadius: 2, overflow: "hidden" }}>
                  <div style={{ height: "100%", width: `${r.size > 0 ? (rUsedU/r.size)*100 : 0}%`, background: rUsedU/r.size > 0.8 ? "#ef4444" : "#10b981", borderRadius: 2 }} />
                </div>
              </div>
            );
          })}
          <div onClick={() => {
            const name = prompt(t("promptRackName") + ":", `Rack ${irScope.racks.length + 1}`);
            if (name) addRack(name, "", 24);
          }} style={{ background: T.inp, border: `1px dashed ${T.bdr}`, borderRadius: 10, padding: 16, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", minHeight: 100, color: T.vdim, fontSize: 12, transition: "border-color 0.15s" }}
            onMouseEnter={e => e.currentTarget.style.borderColor = "#10b98144"} onMouseLeave={e => e.currentTarget.style.borderColor = "#1a1a2e"}>
            {t("addRack")}
          </div>
        </div>
      </div>
      </>}
    </div>
  );

  /* ═══════ RACK VIEW ═══════ */
  return (
    <div className="rc-app ir-app" style={{ minHeight: "100vh", background: T.bg, color: T.txt, fontFamily: "monospace", display: "flex", flexDirection: "column" }}><IRClientNavigation client={irClient} onClient={irGoClient} onHome={irGoHome} project={project} rack={rack} view={view} onRack={openRack} onSettings={()=>{setView('clients');setShowSettings(true)}} lang={lang} systemhaus={project.rackclickSystemhaus||systemhaus} onManage={()=>setIrManage(true)} onRename={()=>{const name=prompt((IR_WORDS[lang]||IR_WORDS.en).systemhaus,project.rackclickSystemhaus||systemhaus);if(name?.trim()){pushUndo('Systemhaus');setProject(p=>({...p,rackclickSystemhaus:name.trim().slice(0,80)}))}}}/>{irManage&&<IRInfrastructure project={project} lang={lang} onClose={()=>setIrManage(false)} onApply={draft=>{pushUndo('Infrastructure');setProject(draft);setView('clients')}}/>}{irFaceDevice&&<IRFaceEditor device={irFaceDevice} lang={lang} onClose={()=>setIrFaceDevice(null)} onApply={(values,roles)=>{const edited={...irFaceDevice,ports:irFaceDevice.ports.map(p=>({...p,rackclickPowerRole:roles[p.id]}))};const lookup=(did,pid)=> (did===edited.id?edited:project.racks.flatMap(r=>r.devs).find(d=>d.id===did))?.ports.find(p=>p.id===pid);if(rc8AllLinks(project).some(c=>(c.fd===edited.id||c.td===edited.id)&&!irPowerPairAllowed(lookup(c.fd,c.fp),lookup(c.td,c.tp)))){noti(RC8_CORE_WORDS[lang].roleConflict,'error');return;}pushUndo('Port faces');setProject(p=>({...p,racks:p.racks.map(r=>({...r,devs:r.devs.map(d=>d.id!==irFaceDevice.id?d:{...d,ports:d.ports.map(port=>{const {rackclickFace,rackclickPowerRole,...base}=port;const rest={...base,...(roles[port.id]&&roles[port.id]!=='unspecified'?{rackclickPowerRole:roles[port.id]}:{})};return values[port.id]==='auto'?rest:{...rest,rackclickFace:values[port.id]}})})}))}))}}/>}{BOOT_RECOVERY_REASON&&<div className="ir-recovery-block" role="alert" style={{background:'#7f1d1d',color:'#fff',padding:'12px 20px',fontSize: 13,fontWeight:700}}>
    {IR_RECOVERY_WORDS[lang][BOOT_RECOVERY_REASON]} <button onClick={saveJSON}>{IR_RECOVERY_WORDS[lang].exportMemory}</button>
    {BOOT_RECOVERY_REASON==='quarantineFailed'&&<button onClick={irDownloadCurrentRescue}>{IR_RECOVERY_WORDS[lang].exportRaw}</button>}
    <button onClick={()=>location.reload()}>{IR_RECOVERY_WORDS[lang].reload}</button>
  </div>}<div className="ir-breadcrumb">{project.rackclickSystemhaus||systemhaus} <span>›</span> <button className="ir-crumb-home" onClick={irGoHome}>{CW[lang].infrastructure}</button> {view!=='clients'&&<><span>›</span><button className="ir-crumb-client" onClick={()=>irGoClient(irClient)}>{irScope.name}</button></>} {view==='rack'&&rack?.rackclickLocation&&<><span>›</span>{['client','site','building','room'].map(k=>rack.rackclickLocation[k]).filter(Boolean).join(' / ')}</>} {view==='rack'&&<><span>›</span>{rack?.location}<span>›</span>{rack?.name}</>}<small>v{RC_VERSION}</small></div>
      <style>{`
        .rc-app input, .rc-app select { background: ${T.inp} !important; border-color: ${T.bdr} !important; color: ${T.txt} !important; }
        .rc-app input::placeholder { color: ${T.vdim} !important; }
      `}</style>
      {editDev && <EditModal dev={editDev} onSave={saveEdit} onClose={() => setEditDev(null)} t={t} />}
      {editRack && <RackEditModal locations={irLocations(irScope)} rack={rack} onSave={saveRackEdit} onClose={() => setEditRack(null)} t={t} onDelete={irScope.racks.length > 1 ? deleteRack : null} />}
      {ctxMenu && <PortCtxMenu pos={{ x: ctxMenu.x, y: ctxMenu.y }} port={(devs.find(d => d.id === ctxMenu.did)?.ports.find(pp => pp.id === ctxMenu.pid)) || ctxMenu.port} onAction={onCtxAction} onClose={() => setCtxMenu(null)} otherRacks={otherRacks} onCrossConnect={startCrossConnect} t={t} />}
      {devCtx && <DevCtxMenu pos={{ x: devCtx.x, y: devCtx.y }} dev={devCtx.dev} otherRacks={otherRacks} onMoveToRack={moveDevToRack} onBatchStatus={batchPortStatus} onBatchPoe={batchPortPoe} lang={lang} onBatchColor={batchPortColor} onSaveTemplate={saveCustomTemplate} onClose={() => setDevCtx(null)} t={t} />}
      {showBulk && <BulkConnectModal devs={devs} conns={conns} allConns={allConns} lang={lang} onBulk={doBulkConnect} onClose={() => setShowBulk(false)} t={t} />}
      {notif && <div style={{ position: "fixed", top: 12, left: "50%", transform: "translateX(-50%)", zIndex: 2000, padding: "6px 18px", borderRadius: 8, fontSize: "var(--ir-small)", fontWeight: 700, background: notif.type === "error" ? "#ef4444" : notif.type === "info" ? "#3b82f6" : "#10b981", color: "#fff", boxShadow: "0 4px 12px #000a" }}>{notif.msg}</div>}

      {/* Connection detail modal */}
      {sc && (() => { const col = cm[sc.id]||"#f59e0b"; const isCross = !!sc.rackFrom; const ps = PATCH_ST[sc.patchStatus] || PATCH_ST.none; return (
        <div onClick={() => setSc(null)} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
          <div onClick={e => e.stopPropagation()} style={{ background: T.bg2, border: `1px solid ${col}44`, borderRadius: 12, padding: 24, minWidth: 340, maxWidth: 400 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
              <div style={{ width: 12, height: 12, borderRadius: 3, background: col }} />
              <span style={{ fontSize: 13, fontWeight: 800, color: col }}>Connection</span>
              {isCross && <span style={{ fontSize: "var(--ir-small)", color: "#a855f7" }}>🔗 cross-rack</span>}
              {sc.patchStatus && <span style={{ fontSize: "var(--ir-small)", color: ps.color, background: ps.color+"15", padding: "1px 6px", borderRadius: 3, marginLeft: "auto" }}>{ps.label}</span>}
            </div>
            <div style={{ background: T.bg3, borderRadius: 8, padding: 14, marginBottom: 12 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: col }} />
                {isCross && <span style={{ fontSize: "var(--ir-small)", color: "#a855f7", background: "#a855f710", padding: "1px 5px", borderRadius: 3 }}>{rackLookup[sc.rackFrom]}</span>}
                <span style={{ fontSize: 12, fontWeight: 700 }}>{sc.fn}</span>
                <span style={{ fontSize: "var(--ir-small)", color: T.mut }}>{(PT[sc.fpt2]||PT.rj45).label} #{sc.fpn}</span>
              </div>
              <div style={{ borderLeft: `2px solid ${col}33`, height: 10, marginLeft: 3 }} />
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: col }} />
                {isCross && <span style={{ fontSize: "var(--ir-small)", color: "#a855f7", background: "#a855f710", padding: "1px 5px", borderRadius: 3 }}>{rackLookup[sc.rackTo]}</span>}
                <span style={{ fontSize: 12, fontWeight: 700 }}>{sc.tn}</span>
                <span style={{ fontSize: "var(--ir-small)", color: T.mut }}>{(PT[sc.tpt2]||PT.rj45).label} #{sc.tpn}</span>
              </div>
            </div>
            <div style={{ marginBottom: 10 }}>
              <label style={{ fontSize: "var(--ir-small)", color: T.mut, letterSpacing: 0.5 }}>{t("cableNote")}</label>
              <input value={sc.note || ""} onChange={e => { const v = e.target.value; updateConnNote(sc.id, v); setSc(prev => ({ ...prev, note: v })); }} onBlur={()=>{irConnNoteUndoRef.current=null}} placeholder="z.B. Cat6a 15m blau, LWL OS2, Trunk..." style={{ width: "100%", background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "6px 9px", borderRadius: 5, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginTop: 3 }} />
            </div>
            <div style={{ display: "flex", gap: 10, marginBottom: 10 }}>
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: "var(--ir-small)", color: T.mut, letterSpacing: 0.5 }}>PATCH STATUS</label>
                <div style={{ display: "flex", gap: 3, marginTop: 3, flexWrap: "wrap" }}>
                  {Object.entries(PATCH_ST).map(([k, v]) => (
                    <button key={k} onClick={() => { updateConnField(sc.id, "patchStatus", k === "none" ? undefined : k); setSc(prev => ({ ...prev, patchStatus: k === "none" ? undefined : k })); }}
                      style={{ padding: "3px 6px", background: (sc.patchStatus||"none") === k ? v.color+"22" : "transparent", border: `1px solid ${(sc.patchStatus||"none") === k ? v.color : "#1a1a2e"}`, color: v.color, borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{v.label}</button>
                  ))}
                </div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 10, marginBottom: 12, alignItems: "flex-end" }}>
              <div>
                <label style={{ fontSize: "var(--ir-small)", color: T.mut, letterSpacing: 0.5 }}>{t("color")}</label>
                <div style={{ display: "flex", gap: 2, marginTop: 3, flexWrap: "wrap", maxWidth: 160 }}>
                  {["",...CC.slice(0,16)].map((c, i) => (
                    <div key={i} onClick={() => { updateConnField(sc.id, "color", c||undefined); setSc(prev => ({ ...prev, color: c||undefined })); }}
                      style={{ width: 14, height: 14, borderRadius: 3, background: c||"#1a1a2e", border: `1.5px solid ${(sc.color||"") === c ? "#fff" : "transparent"}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "var(--ir-small)", color: T.mut }}>
                      {!c && "A"}
                    </div>
                  ))}
                </div>
              </div>
              {sc.createdAt && <div style={{ fontSize: "var(--ir-small)", color: T.vdim, marginLeft: "auto" }}>📅 {new Date(sc.createdAt).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })}</div>}
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => delCn(sc.id)} style={{ flex: 1, padding: "8px 0", background: "#ef444412", border: "1px solid #ef4444", color: "#ef4444", borderRadius: 6, cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: 700, fontFamily: "inherit" }}>Disconnect</button>
              <button onClick={() => setSc(null)} style={{ flex: 1, padding: "8px 0", background: "#ffffff06", border: "1px solid #222", color: T.mut, borderRadius: 6, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>Close</button>
            </div>
          </div>
        </div>); })()}

      {autosaveStatus.ok === false && <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 3000, background: "#7f1d1d", borderTop: "2px solid #ef4444", padding: "10px 16px", display: "flex", alignItems: "center", justifyContent: "center", gap: 12, flexWrap: "wrap" }}>
        <span style={{ color: "#fecaca", fontSize: "var(--ir-small)", fontWeight: 700 }}>{"\u26A0\uFE0F " + t("autosaveBannerTitle") + " \u2014 " + t("autosaveBannerText")}</span>
        <button onClick={irExportAll} style={{ padding: "6px 12px", background: "#ef4444", border: "none", color: "#fff", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: 900, fontFamily: "inherit" }}>{"\uD83D\uDCBE " + t("autosaveExportNow")}</button>
      </div>}

      {/* Header */}
      <div className="ir-toolbar" style={{ padding: "8px 16px", display: "flex", alignItems: "center", gap: 8, borderBottom: `1px solid ${T.bg3}`, flexWrap: "wrap" }}>
        <span onClick={() => setView("project")} style={{ fontSize: 14, fontWeight: 900, letterSpacing: 1, cursor: "pointer" }}>RACK<span style={{ color: T.acc }}>CLICK</span></span>
        <span title={t("autosaveLabel")} style={{ fontSize: "var(--ir-small)", color: autosaveStatus.ok === false ? "#ef4444" : T.vdim, fontWeight: autosaveStatus.ok === false ? 900 : 400 }}>
          {autosaveStatus.ok === true && ("\uD83D\uDCBE \u2713 " + new Date(autosaveStatus.lastOkAt).toLocaleTimeString("de-DE"))}
          {autosaveStatus.ok === false && ("\uD83D\uDCBE \u2717 " + t("autosaveFailing"))}
        </span>
        <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
          <button onClick={saveJSON} style={{ padding: "4px 10px", background: dirty ? T.acc+"25" : T.acc+"08", border: `1px solid ${dirty ? T.acc : T.acc+"33"}`, color: T.acc, borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit", position: "relative" }}>{dirty && <span style={{ position: "absolute", top: -2, right: -2, width: 6, height: 6, borderRadius: "50%", background: "#ef4444" }} />}{`💾 ${(irClient?CW[lang].saveClient:t("save"))}${dirty ? " *" : ""}`}</button>
          <button onClick={() => setEditRack(rack)} style={{ padding: "4px 8px", background: "none", border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>✎</button>
          {allConns.length > 0 && <button onClick={async () => { if(!legacyView){setRackReportPng(null);setView("report");return} const img = await captureRackDetailPNGDataURL({ scale: 3, transparent: false }); if (img) setRackReportPng(img); setView("report"); }} style={{ padding: "4px 14px", background: "#f59e0b12", border: "1px solid #f59e0b44", color: "#f59e0b", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: 700, fontFamily: "inherit" }}>{`📊 ${t("report")}`}</button>}
          <button onClick={exportRack} title="Export rack JSON" style={{ padding: "4px 10px", background: "#a855f708", border: "1px solid #a855f733", color: "#a855f7", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>📤 Export</button>
          <button onClick={importCSV} title="Import connections from CSV" style={{ padding: "4px 10px", background: "#3b82f608", border: "1px solid #3b82f633", color: "#3b82f6", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>📥 CSV</button>
          <button onClick={printRackLabel} title="Print rack label/tag" style={{ padding: "4px 10px", background: "#06b6d408", border: "1px solid #06b6d433", color: "#06b6d4", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>🏷️ Label</button>
          <button onClick={async () => { const warning=lang==='de'?'Dekorativer QR-Platzhalter: Er enthält keinen verlässlich scanbaren Rack-Link. Trotzdem als Grafik herunterladen?':lang==='es'?'QR decorativo: no contiene un enlace del rack que pueda escanearse de forma fiable. ¿Descargar la imagen de todos modos?':'Decorative QR placeholder: it does not contain a reliably scannable rack link. Download the image anyway?';if(!confirm(warning))return; const qr = await irDecorativeQR((rack.name || "") + " | " + (rack.location || "") + " | " + rack.size + "U",lang); const a = document.createElement("a"); a.href = qr; a.download = "decorative-qr-not-scannable-" + (rack.name || "rack").replace(/\s+/g, "-") + ".png"; a.click(); }} title="QR Code" style={{ padding: "4px 10px", background: "#a855f708", border: "1px solid #a855f722", color: "#a855f7", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{"📱 QR"}</button>
          <button onClick={() => exportRackDetailPNG({ scale: 3, transparent: false })} title="Export rack as PNG (3x)" style={{ padding: "4px 10px", background: "#10b98108", border: "1px solid #10b98122", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>🧾 PNG</button>
          <button onClick={() => exportRackDetailPNG({ scale: 4, transparent: false })} title="Export rack as PNG HD (4x)" style={{ padding: "4px 10px", background: "#10b98108", border: "1px solid #10b98122", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>🧾 PNG HD</button>
          <button onClick={() => exportRackDetailPNG({ scale: 4, transparent: true })} title="Export rack as PNG transparent (4x)" style={{ padding: "4px 10px", background: "#10b98108", border: "1px solid #10b98122", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>🧾 PNG (transp)</button>
          <button onClick={exportPDF} title="Export rack report as PDF" style={{ padding: "4px 10px", background: "#ef444408", border: "1px solid #ef444422", color: "#ef4444", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>📄 PDF</button>
          <button onClick={exportExcel} title="Export rack data as Excel" style={{ padding: "4px 10px", background: "#22c55e08", border: "1px solid #22c55e22", color: "#22c55e", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>📊 XLS</button>
          <div style={{ display: "flex", alignItems: "center", gap: 2, background: T.bg2, borderRadius: 4, border: `1px solid ${T.bdr}`, padding: "0 2px" }}>
            <button onClick={() => setRackZoom(z => Math.max(50, z - 10))} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: "var(--ir-small)", padding: "2px 4px" }}>−</button>
            <span style={{ fontSize: "var(--ir-small)", color: T.mut, minWidth: 26, textAlign: "center" }}>{rackZoom}%</span>
            <button onClick={() => setRackZoom(z => Math.min(150, z + 10))} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: "var(--ir-small)", padding: "2px 4px" }}>+</button>
            {rackZoom !== 100 && <button onClick={() => setRackZoom(100)} style={{ background: "none", border: "none", color: T.vdim, cursor: "pointer", fontSize: "var(--ir-small)", padding: "2px 3px" }}>↺</button>}
          </div>
          <button onClick={() => setRackFace(f => f === "front" ? "rear" : "front")} style={{ padding: "3px 8px", background: rackFace === "rear" ? "#a855f715" : T.bg2, border: `1px solid ${rackFace === "rear" ? "#a855f7" : T.bdr}`, color: rackFace === "rear" ? "#a855f7" : T.mut, borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{rackFace === "front" ? `▤ ${t("front")}` : `▥ ${t("rear")}`}</button>
        </div>
        <div style={{ marginLeft: "auto", display: "flex", gap: 4, alignItems: "center" }}>
          <button onClick={undo} disabled={undoStack.length === 0} title={`Undo${undoStack.length > 0 ? ` (${undoStack[0]?.label})` : ""} · Ctrl+Z`} style={{ padding: "3px 8px", background: undoStack.length ? "#3b82f608" : "transparent", border: `1px solid ${undoStack.length ? "#3b82f633" : "#111"}`, color: undoStack.length ? "#3b82f6" : "#222", borderRadius: 4, cursor: undoStack.length ? "pointer" : "default", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>↩{undoStack.length > 0 ? ` ${undoStack.length}` : ""}</button>
          <button onClick={redo} disabled={redoStack.length === 0} title="Redo · Ctrl+Y" style={{ padding: "3px 8px", background: redoStack.length ? "#f59e0b08" : "transparent", border: `1px solid ${redoStack.length ? "#f59e0b33" : "#111"}`, color: redoStack.length ? "#f59e0b" : "#222", borderRadius: 4, cursor: redoStack.length ? "pointer" : "default", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>↪</button>
        </div>
      </div>

      {/* Rack tabs */}
      {irScope.racks.length > 1 && <div style={{ display: "flex", padding: "0 16px", gap: 2, borderBottom: `1px solid ${T.bg3}`, overflow: "auto" }}>
        <button onClick={() => setView("project")} style={{ padding: "6px 12px", background: "none", border: "none", color: T.vdim, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>← Project</button>
        {irScope.racks.map(r => (
          <button key={r.id} onClick={() => { openRack(r.id); if (crossSel) noti(t("notiPickDestination", {name: r.name}), "info"); }}
            style={{ padding: "6px 12px", background: r.id === activeRackId ? "#10b98112" : "transparent", border: "none", borderBottom: r.id === activeRackId ? "2px solid #10b981" : "2px solid transparent", color: r.id === activeRackId ? "#10b981" : "#444", cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: r.id === activeRackId ? 700 : 400, fontFamily: "inherit", whiteSpace: "nowrap" }}>
            {r.name}{r.location ? ` (${r.location})` : ""}
          </button>))}
      </div>}

      {/* Cross-connect banner */}
      {crossSel && <div className="ir-connect-hint" style={{ padding: "5px 16px", background: "#a855f712", borderBottom: "1px solid #a855f733", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: "var(--ir-small)", color: "#a855f7" }}>🔗 {crossSel.devName}:{crossSel.portType}#{crossSel.portGn} ({rackLookup[crossSel.fromRackId]}) → pick destination port</span>
        <button onClick={() => setCrossSel(null)} style={{ padding: "2px 10px", background: "none", border: "1px solid #a855f722", color: "#a855f7", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{t("cancel")}</button>
      </div>}

      {/* Selection banner */}
      {sp && !crossSel && <div className="ir-connect-hint" style={{ padding: "5px 16px", background: "#10b98112", borderBottom: "1px solid #10b98133", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: "var(--ir-small)", color: "#10b981" }}>⚡ {devs.find(d => d.id === sp.did)?.name}:{sp.portType}#{sp.portGn} → pick destination</span>
        <button onClick={() => setSp(null)} style={{ padding: "2px 10px", background: "none", border: "1px solid #10b98122", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{t("cancel")}</button>
      </div>}

      {selectedDevs.size > 0 && <div style={{ padding: "5px 16px", background: "#3b82f612", borderBottom: "1px solid #3b82f633", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: "var(--ir-small)", color: "#3b82f6" }}>☑ {selectedDevs.size} selected</span>
        <div style={{ display: "flex", gap: 4 }}>
          <button onClick={() => { const all = new Set(devs.map(d => d.id)); setSelectedDevs(all); }} style={{ padding: "2px 8px", background: "none", border: "1px solid #3b82f622", color: "#3b82f6", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>All</button>
          <button onClick={bulkDeleteSelected} style={{ padding: "2px 8px", background: "#ef444412", border: "1px solid #ef444433", color: "#ef4444", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>🗑 Delete</button>
          <button onClick={() => setSelectedDevs(new Set())} style={{ padding: "2px 8px", background: "none", border: "1px solid #22222a", color: T.mut, borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>Clear</button>
        </div>
      </div>}

      {rc8Reconnect&&<div className="ir-connect-hint" role="status">{RC8_CORE_WORDS[lang].reconnect}<button onClick={()=>setRc8Reconnect(null)}>{RC8_CORE_WORDS[lang].cancel}</button></div>}
      <div className="ir-layout">
        {/* Sidebar */}
        <div className="ir-right"><IntegratedInspector rack={rack} allConns={allConns} inspected={irInspect} nextColor={nextCableColor} onNextColor={setNextCableColor} onContext={onPortCtx} lang={lang}/>
          <div style={{ padding: "8px 10px 4px" }}>
            <input placeholder={t("rackSearch")} value={search} onChange={e => setSearch(e.target.value)} style={{ width: "100%", background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "6px 9px", borderRadius: 5, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none", boxSizing: "border-box" }} />
          </div>
          <div style={{ padding: "6px 10px", display: "flex", justifyContent: "space-around", borderBottom: `1px solid ${T.bg3}` }}>
            <div style={{ textAlign: "center" }}><div style={{ fontSize: 16, fontWeight: 900, color: T.acc }}>{ devs.length}</div><div style={{ fontSize: "var(--ir-small)", color: T.vdim }}>{t("devices")}</div></div>
            <div style={{ textAlign: "center" }}><div style={{ fontSize: 16, fontWeight: 900, color: "#3b82f6" }}>{freeU}</div><div style={{ fontSize: "var(--ir-small)", color: T.vdim }}>{t("freeU")}</div></div>
            <div style={{ textAlign: "center" }}><div style={{ fontSize: 16, fontWeight: 900, color: "#f59e0b" }}>{allConns.length}</div><div style={{ fontSize: "var(--ir-small)", color: T.vdim }}>{t("links")}</div></div>
            {crossForRack.length > 0 && <div style={{ textAlign: "center" }}><div style={{ fontSize: 16, fontWeight: 900, color: "#a855f7" }}>{crossForRack.length}</div><div style={{ fontSize: "var(--ir-small)", color: "#a855f7" }}>🔗</div></div>}
          </div>

          {/* Device port usage */}
          {devs.length > 0 && <div style={{ padding: "4px 10px 6px", borderBottom: `1px solid ${T.bg3}` }}>
            <div style={{ fontSize: "var(--ir-small)", color: T.vdim, letterSpacing: 0.5, marginBottom: 3 }}>{t("portUsage")}</div>
            {devs.map(d => { const used = allConns.filter(c => c.fd === d.id || c.td === d.id).length; const total = d.ports.length; const pct = total > 0 ? Math.round(used / total * 100) : 0; return (
              <div key={d.id} style={{ display: "flex", alignItems: "center", gap: 6, padding: "2px 0", fontSize: "var(--ir-small)" }}>
                <span style={{ color: d.color, fontWeight: 700, minWidth: 70, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "monospace" }}>{d.name}</span>
                <div style={{ flex: 1, height: 4, background: T.bdr, borderRadius: 2, overflow: "hidden" }}>
                  <div style={{ width: `${pct}%`, height: "100%", background: pct > 80 ? "#f59e0b" : "#10b981", borderRadius: 2, transition: "width 0.2s" }} />
                </div>
                <span style={{ color: T.mut, minWidth: 32, textAlign: "right", fontFamily: "monospace" }}>{used}/{total}</span>
              </div>); })}
          </div>}

          {/* New device */}
          <div className="rc8-device-catalogue" style={{ padding: "8px 10px", borderBottom: `1px solid ${T.bg3}` }}>
            {!showNew ? (
              <div style={{ display: "flex", gap: 4 }}>
                <button onClick={() => setShowNew(true)} style={{ flex: 1, padding: "5px", background: "#10b98108", border: "1px solid #10b98122", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: 700, fontFamily: "inherit" }}>{t("addDevice")}</button>
                {devs.length >= 2 && <button onClick={() => setShowBulk(true)} title="Bulk connect 1:1" style={{ padding: "5px 8px", background: "#f59e0b08", border: "1px solid #f59e0b22", color: "#f59e0b", borderRadius: 4, cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: 700, fontFamily: "inherit" }}>⚡ BULK</button>}
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <input className="rc8-device-name" value={dn} onChange={e => setDn(e.target.value)} placeholder={(RC8_CATALOGUE[lang]||RC8_CATALOGUE.en).nameOptional} style={{ background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "5px 8px", borderRadius: 4, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none" }} autoFocus />
                {favPresets.size > 0 && <div>
                  <div style={{ fontSize: "var(--ir-small)", color: "#f59e0b", letterSpacing: 0.5, marginBottom: 2 }}>{`★ ${t("favorites")}`}</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>
                    {[...favPresets].filter(k => PRESETS[k]).map(k => { const p = PRESETS[k]; return (
                      <button key={k} onClick={() => addP(k)} disabled={freeU < p.u} style={{ padding: "3px 6px", background: freeU >= p.u ? "#f59e0b08" : "#1a1a2e08", border: `1px solid ${freeU >= p.u ? "#f59e0b33" : "#111"}`, color: freeU >= p.u ? "#f59e0b" : "#333", borderRadius: 3, cursor: freeU >= p.u ? "pointer" : "default", fontSize: "var(--ir-small)", fontFamily: "inherit", display: "flex", alignItems: "center", gap: 3 }}>
                        <span>{p.icon}</span> {p.label}
                      </button>); })}
                  </div>
                </div>}
                {Object.keys(customTemplates).length > 0 && <div>
                  <div style={{ fontSize: "var(--ir-small)", color: "#10b981", letterSpacing: 0.5, marginBottom: 2, marginTop: 3 }}>{`📌 ${t("myTemplates")}`}</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>
                    {Object.entries(customTemplates).map(([k, t]) => (
                      <div key={k} style={{ display: "flex", alignItems: "center", gap: 0 }}>
                        <button onClick={() => addP(k)} disabled={freeU < t.u} style={{ padding: "3px 6px", background: freeU >= t.u ? "#10b98115" : "#1a1a2e08", border: `1px solid ${freeU >= t.u ? "#10b98133" : "#111"}`, color: freeU >= t.u ? "#10b981" : "#333", borderRadius: "3px 0 0 3px", cursor: freeU >= t.u ? "pointer" : "default", fontSize: "var(--ir-small)", fontFamily: "inherit", display: "flex", alignItems: "center", gap: 3 }}>
                          <span>{t.icon}</span> {t.label}
                        </button>
                        <button onClick={() => deleteCustomTemplate(k)} title="Remove template" style={{ padding: "3px 4px", background: "#ef444408", border: "1px solid #ef444422", borderLeft: "none", color: "#ef4444", borderRadius: "0 3px 3px 0", cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>×</button>
                      </div>
                    ))}
                  </div>
                </div>}
<p className="rc8-catalogue-note">{(RC8_CATALOGUE[lang]||RC8_CATALOGUE.en).generic}</p>                {CATS.map(cat => (
                  <div key={cat.label}>
                    <div style={{ fontSize: "var(--ir-small)", color: T.vdim, letterSpacing: 0.5, marginBottom: 2, marginTop: 3 }}>{((RC8_CATALOGUE[lang]||RC8_CATALOGUE.en).categories[cat.label]||cat.label).toUpperCase()}</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>
                      {cat.keys.map(k => { const p = PRESETS[k]; return (
                        <button key={k} onClick={() => addP(k)} disabled={freeU < p.u} style={{ padding: "3px 6px", background: freeU >= p.u ? "#10b98108" : "#1a1a2e08", border: `1px solid ${freeU >= p.u ? "#10b98122" : "#111"}`, color: freeU >= p.u ? "#e0e0e0" : "#333", borderRadius: 3, cursor: freeU >= p.u ? "pointer" : "default", fontSize: "var(--ir-small)", fontFamily: "inherit", display: "flex", alignItems: "center", gap: 3 }}>
                          <span>{p.icon}</span> {p.label}
                          <span role="button" tabIndex={0} aria-label={t("favorites")+' '+p.label} aria-pressed={favPresets.has(k)} className="rc8-favorite" onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();toggleFav(k)}}} onClick={e=>{e.stopPropagation();toggleFav(k)}}><IRIcon name="star" size={20}/></span>
                        </button>); })}
                    </div>
                  </div>
                ))}
                <details style={{ marginTop: 4 }}>
                  <summary style={{ fontSize: "var(--ir-small)", color: T.mut, cursor: "pointer" }}>{`✏️ ${t("customDevice")}`}</summary>
                  <div style={{ display: "flex", flexDirection: "column", gap: 3, marginTop: 4 }}>
                    <input value={cust.name} onChange={e => setCust(prev => ({ ...prev, name: e.target.value }))} placeholder="Name" style={{ background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "4px 6px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit", outline: "none" }} />
                    <div style={{ display: "flex", gap: 3, alignItems: "center" }}>
                      <select value={cust.u} onChange={e => setCust(prev => ({ ...prev, u: +e.target.value }))} style={{ background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "3px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit" }}>
                        {[1,2,3,4,5,6,8].map(n => <option key={n} value={n}>{n}U</option>)}
                      </select>
                      <select value={cust.icon} onChange={e => setCust(prev => ({ ...prev, icon: e.target.value }))} style={{ background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "3px", borderRadius: 3, fontSize: "var(--ir-small)" }}>
                        {ICONS.map(ic => <option key={ic} value={ic}>{ic}</option>)}
                      </select>
                    </div>
                    {cust.pg.map((g, gi) => (
                      <div key={gi} style={{ display: "flex", gap: 3 }}>
                        <select value={g.t} onChange={e => setCust(prev => ({ ...prev, pg: prev.pg.map((x, i) => i === gi ? { ...x, t: e.target.value } : x) }))} style={{ background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "3px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit", flex: 1 }}>
                          {Object.entries(PT).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                        </select>
                        <input type="number" min={1} max={96} value={g.n} onChange={e => setCust(prev => ({ ...prev, pg: prev.pg.map((x, i) => i === gi ? { ...x, n: Math.max(1, +e.target.value) } : x) }))} style={{ width: 40, background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "3px", borderRadius: 3, fontSize: "var(--ir-small)", fontFamily: "inherit", textAlign: "center" }} />
                        <select aria-label={(IR_WORDS[lang]||IR_WORDS.en).portFace+' '+(gi+1)} value={g.face||'auto'} onChange={e=>setCust(prev=>({...prev,pg:prev.pg.map((x,i)=>i===gi?{...x,face:e.target.value}:x)}))}>{['auto','front','rear'].map(f=><option key={f} value={f}>{(IR_WORDS[lang]||IR_WORDS.en)[f==='auto'?'autoFace':f]}</option>)}</select>{cust.pg.length > 1 && <button onClick={() => setCust(prev => ({ ...prev, pg: prev.pg.filter((_, i) => i !== gi) }))} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: "var(--ir-small)" }}>×</button>}
                      </div>
                    ))}
                    <button onClick={() => setCust(prev => ({ ...prev, pg: [...prev.pg, { t: "rj45", n: 4 }] }))} style={{ padding: "2px", background: "none", border: `1px dashed ${T.bdr}`, color: T.vdim, borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{"+ "+t("portGroups")}</button>
                    <button onClick={addCustom} style={{ padding: "4px", background: "#10b98112", border: "1px solid #10b98133", color: "#10b981", borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontWeight: 700, fontFamily: "inherit" }}>{(RC8_CATALOGUE[lang]||RC8_CATALOGUE.en).create}</button>
                  </div>
                </details>
                <button onClick={() => setShowNew(false)} style={{ padding: "4px", background: "none", border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 3, cursor: "pointer", fontSize: "var(--ir-small)", fontFamily: "inherit" }}>{t("cancel")}</button>
              </div>
            )}
          </div>

          {/* Connections list */}
          {filtConns.length > 0 && <div style={{ padding: "0 10px 10px" }}>
            <div style={{ fontSize: "var(--ir-small)", fontWeight: 700, color: T.vdim, marginBottom: 5, letterSpacing: 0.5 }}>{t("connections")} ({filtConns.length}{sq ? `/${allConns.length}` : ""})</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              {filtConns.map(c => { const col = cm[c.id]; const isCross = !!c.rackFrom; return (
                <div key={c.id} className="ir-connection-card" onMouseEnterCapture={()=>setIrWire(c.id)} onClick={() => {setIrWire(c.id);setSc(c)}} style={{ padding: "4px 7px", background: isCross ? "#a855f708" : `${col}08`, borderRadius: 4, fontSize: "var(--ir-small)", cursor: "pointer", border: `1px solid ${isCross ? "#a855f715" : col+"15"}`, display: "flex", flexDirection: "column", gap: 1, transition: "border-color 0.1s" }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = (isCross ? "#a855f7" : col)+"55"} onMouseLeave={e => e.currentTarget.style.borderColor = (isCross ? "#a855f7" : col)+"15"}>
                  <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                    {isCross && <span style={{ fontSize: "var(--ir-small)" }}>🔗</span>}
                    <div style={{ width: 7, height: 7, borderRadius: 2, background: col, flexShrink: 0 }} />
                    <span style={{ color: "#666" }}><span style={{ color: col, fontWeight: 700 }}>{c.fn}</span><span style={{ color: T.vdim }}>:{c.fpn}</span><span style={{ color: T.vdim, margin: "0 3px" }}>→</span><span style={{ color: col, fontWeight: 700 }}>{c.tn}</span><span style={{ color: T.vdim }}>:{c.tpn}</span></span>
                  </div>
                  {c.note && <div style={{ fontSize: "var(--ir-small)", color: T.mut, paddingLeft: 12, fontStyle: "italic" }}>📎 {c.note}</div>}
                  {c.patchStatus && <div style={{ fontSize: "var(--ir-small)", color: (PATCH_ST[c.patchStatus]||PATCH_ST.none).color, paddingLeft: 12 }}>{(PATCH_ST[c.patchStatus]||PATCH_ST.none).label}</div>}
                </div>); })}
            </div>
          </div>}

          <div style={{ marginTop: "auto", padding: 10, borderTop: `1px solid ${T.bg3}` }}>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, fontSize: "var(--ir-small)", color: T.mut }}>
              <span>{t("hintLClick")}</span><span>{t("hintRClick")}</span><span>{t("hintDblClick")}</span><span>🔗: {t("hintCrossRack")}</span><span>⚡: {t("hintBulk")}</span><span>{t("hintUndo")}</span><span>{t("hintSave")}</span><span>{t("hintEsc")}</span><span>{t("hintDel")}</span>
            </div>
          </div>
        </div>

        {/* Main rack area */}
        <div className="ir-main">
          {!legacyView&&<IntegratedPhysicalRack id="rack-detail-export" rack={rack} project={project} allConns={allConns} colors={cm} selection={sp} onPort={(did,pid)=>{setIrInspect({did,pid});const c=allConns.find(c=>c.fp===pid||c.tp===pid);if(c)setIrWire(c.id);onPort(did,pid)}} onContext={(e,did,pid)=>{setIrInspect({did,pid});onPortCtx(e,did,pid)}} onLabel={quickLabel} onEdit={setEditDev} onDelete={delD} onDeviceContext={onDevCtx} face={rackFace} zoom={rackZoom} lang={lang} onMove={moveD} onSelect={toggleSelectDev} selectedDevs={selectedDevs} collapsedDevs={collapsedDevs} onCollapse={id=>setCollapsedDevs(prev=>{const n=new Set(prev);n.has(id)?n.delete(id):n.add(id);return n})} onDrop={dragReorder} onDragStart={setDragId} onDragEnter={setDragOverId} onDragEnd={()=>{setDragId(null);setDragOverId(null)}} onTouchDragStart={onTouchDragStart} onTouchDragMove={onTouchDragMove} onTouchDragEnd={onTouchDragEnd} search={search} flashPorts={flashPorts} wireFocus={irWire} onWireFocus={setIrWire} ptColors={ptColors} onFaces={setIrFaceDevice} onFace={setRackFace}/>}
          <div id={legacyView?'rack-detail-export':undefined} onTouchMove={onTouchDragMove} onTouchEnd={onTouchDragEnd} style={{ display: legacyView ? "flex" : "none", flexDirection: "column", gap: 4, transform: `scale(${rackZoom/100})`, transformOrigin: "top left", width: `${10000/rackZoom}%` }}>
          {rackFace === "rear" && <div style={{ textAlign: "center", padding: "4px 0", fontSize: "var(--ir-small)", color: "#a855f7", background: "#a855f708", borderRadius: 4, letterSpacing: 1, fontWeight: 700 }}>{`▥ ${t("rearView")}`}</div>}
          {(() => { let uPos = 1; return displayDevs.map((d, i) => {
            const startU = uPos; uPos += d.u;
            return (
              <div key={d.id} style={{ display: "flex", gap: 0 }}>
                <div style={{ width: 28, minWidth: 28, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", gap: 0, flexShrink: 0 }}>
                  {Array.from({ length: d.u }, (_, ui) => (
                    <div key={ui} style={{ fontSize: "var(--ir-small)", color: T.vdim, height: Math.max(38, 48 / d.u), display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "monospace", lineHeight: 1 }}>{startU + ui}</div>
                  ))}
                </div>
                <div style={{ flex: 1 }}>
                  <DevRow dev={d} allConns={allConns} sp={sp} onPort={onPort} onCtx={onPortCtx} onDel={delD} onEdit={dev => setEditDev(dev)} onMove={moveD} onDevCtx={onDevCtx} cm={cm}
                    isFirst={i === 0} isLast={i === displayDevs.length - 1} dim={sq && !filtDevs.includes(d)} rackLookup={rackLookup} flashPorts={flashPorts} onDblClick={quickLabel}
                    isSelected={selectedDevs.has(d.id)} onSelect={toggleSelectDev} collapsed={collapsedDevs.has(d.id)} onToggleCollapse={() => setCollapsedDevs(prev => { const n = new Set(prev); n.has(d.id) ? n.delete(d.id) : n.add(d.id); return n; })} ptColors={ptColors}
                    onDrop={dragReorder} onDragStart={id => setDragId(id)} onDragEnter={id => setDragOverId(id)} onDragLeaveRow={() => { setDragId(null); setDragOverId(null); }}
                    isDragSource={dragId === d.id} isDragOver={dragOverId === d.id && dragId !== d.id} onTouchDragStart={onTouchDragStart} />
                </div>
              </div>);
          }); })()}
          {devs.length === 0 && <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 200, color: T.vdim, fontSize: 12 }}>{t("noDevices")}</div>}
          {/* Empty U indicator */}
          {freeU > 0 && devs.length > 0 && <div style={{ display: "flex", gap: 0 }}>
            <div style={{ width: 28, minWidth: 28, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "var(--ir-small)", color: T.bdr, fontFamily: "monospace" }}>{usedU + 1}</div>
            <div style={{ flex: 1, height: Math.min(freeU * 12, 48), border: `1px dashed ${T.bdr}`, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "var(--ir-small)", color: T.bdr, marginTop: 4 }}>{`${freeU} ${t("uFree")}`}</div>
          </div>}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════ ERROR BOUNDARY (v0.8.1) — Red de seguridad de último recurso ═══════
   Reglas de este bloque (aprobadas en Paso 2):
   - SOLO LECTURA de localStorage (getItem). Cero setItem/removeItem/clear.
   - No parsea los datos del usuario: los trata como strings opacos.
   - Autocontenido: sin hooks, sin i18n de la app, textos estáticos DE+EN.
   - Limitación documentada: solo captura errores de RENDER. No cubre
     event handlers, código async, fallos de CDN ni errores de Babel. */
const RC_VERSION = "0.9.0-rc9";
const RESCUE_KEYS = [
  SAVE_KEY, ...BACKUP_KEYS, BACKUP_META, SNAPSHOTS_KEY, TEMPLATES_KEY,
  THEME_KEY, LANG_KEY, PT_COLOR_KEY, GROUP_COLOR_KEY,
  FAV_KEY, QUARANTINE_KEY
];

function rcReadRaw(key) {
  try { return localStorage.getItem(key); } catch { return null; }
}

function rcDownload(text, filename) {
  try {
    const blob = new Blob([text], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  } catch (e) { alert("Download fehlgeschlagen / Download failed: " + e.message); }
}

function rcTimestamp() {
  return new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
}

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null, info: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    this.setState({ info });
  }
  downloadFullRescue = () => {
    const bundle = {
      _meta: {
        type: "rackclick-rescue-bundle",
        appVersion: RC_VERSION,
        createdAt: new Date().toISOString(),
        error: this.state.error ? String(this.state.error.message || this.state.error) : "unknown",
        note: "Los valores son strings CRUDOS de localStorage, sin parsear. / Values are RAW localStorage strings, unparsed."
      },
      keys: {}
    };
    RESCUE_KEYS.forEach(k => { bundle.keys[k] = rcReadRaw(k); });
    try { for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k?.startsWith(IR_QUARANTINE_PREFIX))bundle.keys[k]=rcReadRaw(k)} } catch {}
    rcDownload(JSON.stringify(bundle, null, 2), `rackclick-RESCATE-${rcTimestamp()}.json`);
  };
  downloadAutosaveOnly = () => {
    const raw = rcReadRaw(SAVE_KEY);
    if (raw === null) return;
    // Contenido crudo de SAVE_KEY tal cual — cargable directamente con Load
    rcDownload(raw, `rackclick-autosave-${rcTimestamp()}.json`);
  };
  retry = () => { this.setState({ error: null, info: null }); };
  render() {
    if (!this.state.error) return this.props.children;
    const hasAutosave = rcReadRaw(SAVE_KEY) !== null;
    const errMsg = String(this.state.error && (this.state.error.message || this.state.error));
    const stack = this.state.info && this.state.info.componentStack
      ? this.state.info.componentStack.split("\n").slice(0, 8).join("\n") : "";
    const btn = { padding: "10px 16px", borderRadius: 8, border: "1px solid #2a2a3e", cursor: "pointer",
      fontFamily: "inherit", fontSize: 13, fontWeight: 700, background: "#12121c", color: "#e0e0e0" };
    return (
      <div style={{ minHeight: "100vh", background: "#08080d", color: "#e0e0e0",
        fontFamily: "'JetBrains Mono','Fira Code',monospace", display: "flex",
        alignItems: "center", justifyContent: "center", padding: 20 }}>
        <div style={{ maxWidth: 640, width: "100%", background: "#0d0d15", border: "1px solid #2a2a3e",
          borderRadius: 12, padding: 28 }}>
          <div style={{ fontSize: 20, fontWeight: 900, marginBottom: 6 }}>
            {"\u26A0\uFE0F RackClick hat einen unerwarteten Fehler festgestellt"}
          </div>
          <div style={{ fontSize: 12, color: "#888", marginBottom: 14 }}>
            {"RackClick encountered an unexpected error"}
          </div>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#10b981", marginBottom: 16 }}>
            {"\u2714 Deine Daten sind NICHT verloren. / Your data is NOT lost."}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 18 }}>
            <button onClick={this.downloadFullRescue}
              style={{ ...btn, background: "#10b981", color: "#08080d", border: "1px solid #10b981" }}>
              {"\uD83D\uDCE5 Komplette Rettung herunterladen / Download full rescue"}
            </button>
            <button onClick={this.downloadAutosaveOnly} disabled={!hasAutosave}
              title={hasAutosave ? "" : "Kein Autosave vorhanden / No autosave found"}
              style={{ ...btn, opacity: hasAutosave ? 1 : 0.4, cursor: hasAutosave ? "pointer" : "not-allowed" }}>
              {hasAutosave
                ? "\uD83D\uDCE5 Nur Autosave herunterladen (direkt ladbar) / Download autosave only (loadable)"
                : "\uD83D\uDCE5 Kein Autosave vorhanden / No autosave found"}
            </button>
            <button onClick={this.retry} style={btn}>
              {"\uD83D\uDD04 Erneut versuchen / Retry"}
            </button>
          </div>
          <div style={{ fontSize: "var(--ir-small)", color: "#aaa", lineHeight: 1.6, marginBottom: 14 }}>
            {"Wenn der Fehler wiederholt auftritt: Rettung herunterladen, die vorherige RackClick-Version \u00f6ffnen und das letzte gespeicherte JSON laden. / If the error repeats: download the rescue, open the previous RackClick version and load your last saved JSON."}
          </div>
          <details style={{ fontSize: "var(--ir-small)", color: "#666" }}>
            <summary style={{ cursor: "pointer", marginBottom: 6 }}>{"Technische Details / Technical details"}</summary>
            <div style={{ whiteSpace: "pre-wrap", background: "#08080d", border: "1px solid #1a1a2e",
              borderRadius: 6, padding: 10, marginTop: 6 }}>
              {`Version: v${RC_VERSION}\nZeit/Time: ${new Date().toISOString()}\nFehler/Error: ${errMsg}\n${stack}`}
            </div>
          </details>
        </div>
      </div>
    );
  }
}

ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(ErrorBoundary, null, React.createElement(RackClick)));

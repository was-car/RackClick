// Report/export corrections applied to the generated JSX. The adopted v0.8.6
// source stays byte-identical and its hash gate remains active.
const replaceOnce=(source,anchor,replacement)=>{
  const parts=source.split(anchor);
  if(parts.length!==2)throw Error('Export integration anchor mismatch: '+anchor.slice(0,96)+' ['+(parts.length-1)+']');
  return parts.join(replacement);
};

export function exportPatches(input){
  let source=input;
  const reportCSV=`const IR_EXPORT_HEADERS={rack:'Rack',from:'From Device',fromPort:'From Port#',fromType:'From Type',to:'To Device',toPort:'To Port#',toType:'To Type',note:'Cable/Note',cross:'Cross-Rack',patch:'Patch Status',created:'Created'};
const IR_EXPORT_PATCH={
 en:{none:'—',planned:'Planned',progress:'In Progress',done:'Done',tested:'Tested'},
 de:{none:'—',planned:'Geplant',progress:'In Bearbeitung',done:'Abgeschlossen',tested:'Getestet'},
 es:{none:'—',planned:'Planificado',progress:'En curso',done:'Terminado',tested:'Probado'}
};
function irReportCSV(project,lang){
 // Column names remain stable so a downloaded CSV can be imported again.
 const w=IR_EXPORT_HEADERS,patch=IR_EXPORT_PATCH[lang]||IR_EXPORT_PATCH.en;
 const racks=project.racks||[],byId=new Map(racks.map(r=>[r.id,r.name]));
 const rows=[[w.rack,w.from,w.fromPort,w.fromType,w.to,w.toPort,w.toType,w.note,w.cross,w.patch,w.created]];
 const add=(c,rack,cross)=>rows.push([rack,c.fn,c.fpn,c.fpt,c.tn,c.tpn,c.tpt,c.note||'',cross,patch[c.patchStatus]||patch.none,c.createdAt||'']);
 for(const rack of racks)for(const c of rack.conns||[])add(c,rack.name,'');
 for(const c of project.crossConns||[]){
  if(!byId.has(c.rackFrom)&&!byId.has(c.rackTo))continue;
  const from=byId.get(c.rackFrom)||c.rackFrom,to=byId.get(c.rackTo)||c.rackTo;
  add(c,from,from+' → '+to);
 }
 // Prefix spreadsheet formula metacharacters without altering application data.
 const cell=v=>{const value=String(v??'');return '"'+(/^[\\s]*[=+@-]/.test(value)?"'"+value:value).replace(/"/g,'""')+'"'};
 const csv='\\uFEFF'+rows.map(row=>row.map(cell).join(',')).join('\\r\\n');
 const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
 const link=document.createElement('a');link.href=url;
 link.download='rackclick-'+String(project.name||'report').replace(/[^a-z0-9_-]+/gi,'-')+'-connections.csv';
 document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);
}
function irDecorativeQR(text,lang){
 const raw=generateQR(text);
 return new Promise((resolve,reject)=>{
  const image=new Image();image.onload=()=>{
   const canvas=document.createElement('canvas');canvas.width=Math.max(320,image.width+32);canvas.height=image.height+66;
   const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);
   ctx.drawImage(image,(canvas.width-image.width)/2,12);
   ctx.fillStyle='#111';ctx.font='bold 14px sans-serif';ctx.textAlign='center';
   ctx.fillText(lang==='de'?'DEKORATIV · NICHT SCANNBAR':lang==='es'?'DECORATIVO · NO ESCANEABLE':'DECORATIVE · NOT SCANNABLE',canvas.width/2,canvas.height-20);
   resolve(canvas.toDataURL('image/png'));
  };image.onerror=reject;image.src=raw;
 });
}
`;
  source=replaceOnce(source,'function IRClientReport({project,lang,onBack,onClassic})',reportCSV+'function IRClientReport({project,lang,onBack,onClassic})');
  source=replaceOnce(source,'<button onClick={()=>window.print()}>{w.print}</button><button onClick={onClassic}>{w.classic}</button>',
    '<button onClick={()=>window.print()}>{w.print}</button><button onClick={()=>irReportCSV(project,lang)} aria-label="Export CSV">CSV</button><button onClick={onClassic}>{w.classic}</button>');

  source=replaceOnce(source,'    const data = { version: "0.8-rack", note: rack.name,',
`    const crossCount=(project.crossConns||[]).filter(c=>c.rackFrom===rack.id||c.rackTo===rack.id).length;
    if(crossCount){const message=lang==='de'
      ? 'Dieses Rack hat '+crossCount+' rackübergreifende Verbindung(en). Der Rack-Export enthält nur Geräte und lokale Verbindungen. Für eine vollständige Sicherung Projekt-JSON speichern. OK: Rack allein exportieren; Abbrechen: nichts exportieren.'
      : lang==='es'?'Este rack tiene '+crossCount+' conexión(es) con otros racks. El archivo del rack solo incluye dispositivos y conexiones locales. Guarda el JSON del proyecto para conservarlas. Aceptar: exportar solo el rack; Cancelar: no exportar.'
      : 'This rack has '+crossCount+' cross-rack connection(s). Rack export contains devices and local connections only. Save project JSON for a complete backup. OK: export rack only; Cancel: do not export.';
      if(!confirm(message))return;}
    const data = { version: "0.8-rack", note: rack.name,`);

  source=replaceOnce(source,'        backgroundColor: transparent ? null : T.bg,\n        useCORS: true,',
`        backgroundColor: transparent ? null : T.bg,
        onclone: transparent ? clone => {
          const surface=clone.getElementById('rack-detail-export');
          if(surface)surface.style.setProperty('background-color','transparent','important');
        } : undefined,
        useCORS: true,`);
  source=replaceOnce(source,'      noti(t("notiPngSaved"), "success");\n    } catch (e) {',
    '      // Completion is reported only by the download callback.\n    } catch (e) {');
  source=replaceOnce(source,'        if (blob) downloadBlob(blob);\n        else {',
    '        if (blob) { downloadBlob(blob); noti(t("notiPngSaved"), "success"); }\n        else {');
  source=replaceOnce(source,'          a.click();\n          a.remove();\n        }\n      }, "image/png", 1);',
    '          a.click();\n          a.remove();\n          noti(t("notiPngSaved"), "success");\n        }\n      }, "image/png", 1);');

  const qrHead='<button onClick={() => { const qr = generateQR((rack.name || "") + " | " + (rack.location || "") + " | " + rack.size + "U");';
  source=replaceOnce(source,qrHead,
`<button onClick={async () => { const warning=lang==='de'?'Dekorativer QR-Platzhalter: Er enthält keinen verlässlich scanbaren Rack-Link. Trotzdem als Grafik herunterladen?':lang==='es'?'QR decorativo: no contiene un enlace del rack que pueda escanearse de forma fiable. ¿Descargar la imagen de todos modos?':'Decorative QR placeholder: it does not contain a reliably scannable rack link. Download the image anyway?';if(!confirm(warning))return; const qr = await irDecorativeQR((rack.name || "") + " | " + (rack.location || "") + " | " + rack.size + "U",lang);`);
  source=replaceOnce(source,'a.download = "qr-" + (rack.name || "rack").replace(/\\s+/g, "-") + ".png";',
    'a.download = "decorative-qr-not-scannable-" + (rack.name || "rack").replace(/\\s+/g, "-") + ".png";');
  return source;
}

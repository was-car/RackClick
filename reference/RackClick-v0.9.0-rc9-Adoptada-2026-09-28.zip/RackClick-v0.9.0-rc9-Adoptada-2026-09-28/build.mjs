import {rc8CorePatches} from './rc8-core-patches.mjs';
import {rc8UxPatches} from './rc8-ux-patches.mjs';
import {rc8ReportPatches} from './rc8-report-patches.mjs';
import {powerPatches} from './power-patches.mjs';
import {exportPatches} from './export-patches.mjs';
import {uxPatches,checkIntegratedAccessibleLabels} from './ux-patches.mjs';
import{transform}from'esbuild';import{clientPatches}from'./client-patches.mjs';import{integrityPatches}from'./integrity-patches.mjs';import{readFile,writeFile,mkdir,readdir,rm}from'node:fs/promises';import vm from'node:vm';import{createHash}from'node:crypto';
const hash=b=>createHash('sha256').update(b).digest('hex');
// Failed builds must not leave an old candidate that looks like a fresh success.
await mkdir('dist',{recursive:true});for(const file of await readdir('dist'))if(/^RackClick-v0\.9\.0-rc\d+-Offline\.html$/.test(file))await rm('dist/'+file);
const rollback=await readFile('rollback/rackclick-v0.8.6.html');if(hash(rollback)!=='12deafdd6e3d5f7f1169f5b5e8390f43e3b0a12ae4e0653524af5da19f025404')throw Error('Rollback hash mismatch');
const src=await readFile('src/rack-click-v0.8.6.jsx');if(hash(src)!=='ddac495636a22b5a9b1da9086456b684795ed93b885a0946737de3f5f304cb12')throw Error('Adopted source hash mismatch');
const coreWords=vm.runInNewContext(src.toString().slice(0,src.toString().indexOf('/* ═══════ VALIDATION'))+';I18N',{React:{}});
function checkWords(dict){const keys=Object.keys(dict.en).sort().join('|');for(const l of ['de','es']){if(Object.keys(dict[l]).sort().join('|')!==keys)throw Error('i18n key mismatch '+l);for(const k of Object.keys(dict.en)){const ph=s=>(s.match(/\{\w+\}/g)||[]).sort().join('|');if(ph(dict.en[k])!==ph(dict[l][k]))throw Error('i18n placeholder '+l+'/'+k)}}}
checkWords(coreWords);
const version=(await readFile('VERSION','utf8')).trim();if(!/^0\.9\.0-rc\d+$/.test(version))throw Error('Invalid candidate version');let source=src.toString().replaceAll('0.8.6',version);const patches=[];
function patch(a,b){const parts=source.split(a);if(parts.length!==2)throw Error('Non-unique integration point: '+a.slice(0,90)+' ['+(parts.length-1)+']');source=parts.join(b);patches.push(a.slice(0,90))}
const integrated=await readFile('src/integrated-ui.jsxinc','utf8');patch('/* ═══════ CONSTANTS ═══════ */',integrated+'\n/* ═══════ CONSTANTS ═══════ */');
checkIntegratedAccessibleLabels(integrated);
patch('function RackClick() {',`function RackClick() {
 const [irManage,setIrManage]=useState(false);
 const [irFaceDevice,setIrFaceDevice]=useState(null);
 const [nextCableColor,setNextCableColor]=useState(null);
 const [irInspect,setIrInspect]=useState(null);
 const [irWire,setIrWire]=useState(null);
 const [legacyView,setLegacyView]=useState(false);
 const [systemhaus,setSystemhaus]=useState(()=>{try{return localStorage.getItem('rackclick_ui_systemhaus')||'RackClick · IT-Systemhaus'}catch{return 'RackClick · IT-Systemhaus'}});
 const irWords=IR_WORDS[(function(){try{return localStorage.getItem(LANG_KEY)||'en'}catch{return 'en'}})()]||IR_WORDS.en;
`);
patch('  const T = THEMES[themeId] || THEMES.dark;',`  const IR_LIGHT=['light','silver'].includes(themeId);
 const IR_PALETTE=IR_LIGHT?{bg:'#f2f5f7',bg2:'#ffffff',bg3:'#edf2f5',bdr:'#c5d0dc',bdr2:'#8998a6',txt:'#1d2d3b',dim:'#42596b',mut:'#526678',vdim:'#526678',inp:'#ffffff',acc:'#08794e'}:{bg:'#101419',bg2:'#191f27',bg3:'#202832',bdr:'#41505e',bdr2:'#748799',txt:'#e6edf3',dim:'#c1ccd6',mut:'#a2afbc',vdim:'#a2afbc',inp:'#151b22',acc:'#43dba5'};
 const T={...(THEMES[themeId]||THEMES.dark),...IR_PALETTE};
 useEffect(()=>{document.documentElement.dataset.rcTheme=IR_LIGHT?'light':'dark'},[themeId]);`);
// Exact state/order fix required by compiling JSX rather than Babel's legacy hoisting.
const a=source.indexOf('  /* v0.8.4 [7]: label rápido por doble clic'),b=source.indexOf('  const rack = project.racks.find(r => r.id === activeRackId);',a),c=source.indexOf('  const cm = {}; allConns.forEach',b);if(a<0||b<0||c<0)throw Error('Callback relocation anchor missing');const label=source.slice(a,b);source=source.slice(0,a)+source.slice(b,c)+label+source.slice(c);
patch('return groupColors[key] || null;', 'return nextCableColor || groupColors[key] || null;');patch('project, pushUndo, groupColors]);','project, pushUndo, groupColors, nextCableColor]);');
// New navigation and complete project toolbar remain attached to the stable state.
const nav=`<IRClientNavigation client={irClient} onClient={irGoClient} onHome={irGoHome} project={project} rack={rack} view={view} onRack={openRack} onSettings={()=>{setView('clients');setShowSettings(true)}} lang={lang} systemhaus={project.rackclickSystemhaus||systemhaus} onManage={()=>setIrManage(true)} onRename={()=>{const name=prompt((IR_WORDS[lang]||IR_WORDS.en).systemhaus,project.rackclickSystemhaus||systemhaus);if(name?.trim()){pushUndo('Systemhaus');setProject(p=>({...p,rackclickSystemhaus:name.trim().slice(0,80)}))}}}/>{irManage&&<IRInfrastructure project={project} lang={lang} onClose={()=>setIrManage(false)} onApply={draft=>{pushUndo('Infrastructure');setProject(draft);setView('clients')}}/>}{irFaceDevice&&<IRFaceEditor device={irFaceDevice} lang={lang} onClose={()=>setIrFaceDevice(null)} onApply={(values,roles)=>{pushUndo('Port faces');setProject(p=>({...p,racks:p.racks.map(r=>({...r,devs:r.devs.map(d=>d.id!==irFaceDevice.id?d:{...d,ports:d.ports.map(port=>{const {rackclickFace,rackclickPowerRole,...base}=port;const rest={...base,...(roles[port.id]&&roles[port.id]!=='unspecified'?{rackclickPowerRole:roles[port.id]}:{})};return values[port.id]==='auto'?rest:{...rest,rackclickFace:values[port.id]}})})}))}))}}/>}<div className="ir-breadcrumb">{project.rackclickSystemhaus||systemhaus} <span>›</span> <button className="ir-crumb-home" onClick={irGoHome}>{CW[lang].infrastructure}</button> {view!=='clients'&&<><span>›</span><button className="ir-crumb-client" onClick={()=>irGoClient(irClient)}>{irScope.name}</button></>} {view==='rack'&&rack?.rackclickLocation&&<><span>›</span>{['client','site','building','room'].map(k=>rack.rackclickLocation[k]).filter(Boolean).join(' / ')}</>} {view==='rack'&&<><span>›</span>{rack?.location}<span>›</span>{rack?.name}</>}<small>v{RC_VERSION}</small></div>`;
for(const root of ['<div className="rc-app" style={{ minHeight: "100vh", background: T.bg, color: T.txt, fontFamily: "monospace", padding: 0 }}>','<div className="rc-app" style={{ minHeight: "100vh", background: T.bg, color: T.txt, fontFamily: "monospace", display: "flex", flexDirection: "column" }}>'])patch(root,root.replace('className="rc-app"','className="rc-app ir-app"')+nav);
patch('          {/* Language */}',`          <div className="ir-settings-extra"><label>{(IR_WORDS[lang]||IR_WORDS.en).systemhaus}<input value={project.rackclickSystemhaus||systemhaus} maxLength={80} onBlur={e=>delete e.currentTarget.dataset.irUndo} onChange={e=>{if(!e.currentTarget.dataset.irUndo){pushUndo('Systemhaus');e.currentTarget.dataset.irUndo='1'}setProject(p=>({...p,rackclickSystemhaus:e.target.value}))}}/></label><label><input type="checkbox" checked={legacyView} onChange={e=>setLegacyView(e.target.checked)}/>{(IR_WORDS[lang]||IR_WORDS.en).fallback}</label></div>\n          {/* Language */}`);
patch('      <div style={{ padding: "14px 20px 8px", display: "flex", alignItems: "center", gap: 12, borderBottom: `1px solid ${T.bg3}`, flexWrap: "wrap" }}>','      <div className="ir-project-toolbar" style={{ padding: "14px 20px 8px", display: "flex", alignItems: "center", gap: 12, borderBottom: `1px solid ${T.bg3}`, flexWrap: "wrap" }}>');
patch('      {/* Header */}\n      <div style={{ padding: "8px 16px", display: "flex", alignItems: "center", gap: 8, borderBottom: `1px solid ${T.bg3}`, flexWrap: "wrap" }}>','      {/* Header */}\n      <div className="ir-toolbar" style={{ padding: "8px 16px", display: "flex", alignItems: "center", gap: 8, borderBottom: `1px solid ${T.bg3}`, flexWrap: "wrap" }}>');
patch('      <div style={{ display: "flex", height: `calc(100vh - ${project.racks.length > 1 ? 82 : 50}px${crossSel ? " - 30px" : ""}${sp && !crossSel ? " - 30px" : ""}${selectedDevs.size > 0 ? " - 30px" : ""})`, overflow: "hidden" }}>','      <div className="ir-layout">');
patch('        <div style={{ width: 268, minWidth: 268, borderRight: `1px solid ${T.bg3}`, display: "flex", flexDirection: "column", overflowY: "auto", background: T.bg2 }}>','        <div className="ir-right"><IntegratedInspector rack={rack} allConns={allConns} inspected={irInspect} nextColor={nextCableColor} onNextColor={setNextCableColor} onContext={onPortCtx} lang={lang}/>');
patch('        <div style={{ flex: 1, overflowY: "auto", padding: 16 }}>\n          <div id="rack-detail-export" onTouchMove={onTouchDragMove} onTouchEnd={onTouchDragEnd} style={{ display: "flex",',`        <div className="ir-main">
          {!legacyView&&<IntegratedPhysicalRack id="rack-detail-export" rack={rack} allConns={allConns} colors={cm} selection={sp} onPort={(did,pid)=>{setIrInspect({did,pid});const c=allConns.find(c=>c.fp===pid||c.tp===pid);if(c)setIrWire(c.id);onPort(did,pid)}} onContext={(e,did,pid)=>{setIrInspect({did,pid});onPortCtx(e,did,pid)}} onLabel={quickLabel} onEdit={setEditDev} onDelete={delD} onDeviceContext={onDevCtx} face={rackFace} zoom={rackZoom} lang={lang} onMove={moveD} onSelect={toggleSelectDev} selectedDevs={selectedDevs} collapsedDevs={collapsedDevs} onCollapse={id=>setCollapsedDevs(prev=>{const n=new Set(prev);n.has(id)?n.delete(id):n.add(id);return n})} onDrop={dragReorder} onDragStart={setDragId} onDragEnter={setDragOverId} onDragEnd={()=>{setDragId(null);setDragOverId(null)}} onTouchDragStart={onTouchDragStart} onTouchDragMove={onTouchDragMove} onTouchDragEnd={onTouchDragEnd} search={search} flashPorts={flashPorts} wireFocus={irWire} onWireFocus={setIrWire} ptColors={ptColors} onFaces={setIrFaceDevice} onFace={setRackFace}/>}
          <div id={legacyView?'rack-detail-export':undefined} onTouchMove={onTouchDragMove} onTouchEnd={onTouchDragEnd} style={{ display: legacyView ? "flex" : "none",`);
patch('<div key={c.id} onClick={() => setSc(c)} style={{ padding: "4px 7px",','<div key={c.id} className="ir-connection-card" onMouseEnterCapture={()=>setIrWire(c.id)} onClick={() => {setIrWire(c.id);setSc(c)}} style={{ padding: "4px 7px",');
source=await integrityPatches(source);
source=source.replace('    const h = e => {\n      if ((e.ctrlKey', '    const h = e => {\n      if(document.querySelector("dialog[open]"))return;\n      if ((e.ctrlKey');
patch('  if (!d || typeof d !== "object") return "Not a valid object";', '  if (!d || typeof d !== "object") return "Not a valid object";\n  try{irAssertPresentation(d)}catch{return "Invalid presentation metadata"}');
// Menus retain original handlers with visible theme tokens and viewport clamping.
source=source.replaceAll('<div ref={ref} style={{ position: "fixed", left: pos.x, top: pos.y, zIndex: 1200,', '<div className="ir-context" ref={ref} style={{ position: "fixed", left: Math.max(8,Math.min(pos.x,window.innerWidth-310)), top: Math.max(8,Math.min(pos.y,window.innerHeight-440)), zIndex: 1200,');
source=source.replaceAll('<div onClick={onClose} style={{ position: "fixed", inset: 0,', '<div className="ir-modal" onClick={onClose} style={{ position: "fixed", inset: 0,');
source=source.replace('RackClick — ${project.name}', 'RackClick v${RC_VERSION} — ${project.name}');
source=source.replace('<title>Rack Label</title>','<title>RackClick v${htmlEsc(RC_VERSION)} · Label</title>');
source=source.replace('<div class="proj">${htmlEsc(project.name)}','<div class="proj">RackClick v${htmlEsc(RC_VERSION)} | ${htmlEsc(project.name)}');
source=source.replace('if (e.key === "Escape") { setSp(null);', 'if (e.key === "Escape") { setSc(null); setShowBulk(false); setSp(null);');
// Connection mode must never shift the ports between first click and double click.
source=source.replace('{crossSel && <div style={{ padding: "5px 16px",','{crossSel && <div className="ir-connect-hint" style={{ padding: "5px 16px",');
source=source.replace('{sp && !crossSel && <div style={{ padding: "5px 16px",','{sp && !crossSel && <div className="ir-connect-hint" style={{ padding: "5px 16px",');
// Improve typography in existing forms without changing event handlers or data.
source=source.replace(/fontSize:\s*(\d+)(?=\s*[,}])/g,(_,n)=>'fontSize: '+(Number(n)<12?'"var(--ir-small)"':n));
source=source.replaceAll('>v0.8</span>','>v'+version+'</span>');
source=await clientPatches(source);
source=await powerPatches(source);
source=exportPatches(source);
source=uxPatches(source);
source=rc8CorePatches(source);
source=rc8UxPatches(source);
source=rc8ReportPatches(source);
const transformed=await transform(source,{loader:'jsx',target:'es2020',jsxFactory:'irElement',jsxFragment:'React.Fragment',minify:false,legalComments:'inline'});
let scripts='';for(const[name,digest]of[['react.production.min.js','4b4969fa4ef3594324da2c6d78ce8766fbbc2fd121fff395aedf997db0a99a06'],['react-dom.production.min.js','21758ed084cd0e37e735722ee4f3957ea960628a29dfa6c3ce1a1d47a2d6e4f7'],['html2canvas.min.js','e87e550794322e574a1fda0c1549a3c70dae5a93d9113417a429016838eab8cb']]){const bytes=await readFile('vendor/'+name);if(hash(bytes)!==digest)throw Error('Vendor hash mismatch '+name);scripts+=`<script data-vendor="${name}">${bytes.toString().replace(/<\/script/gi,'<\\/script')}</script>`}
let css='';for(const font of JSON.parse(await readFile('assets/fonts/manifest.json','utf8'))){const bytes=await readFile(font.file);if(hash(bytes)!==font.sha256)throw Error('Font hash mismatch');css+=`@font-face{font-family:'${font.family}';font-style:normal;font-weight:${font.weight};font-display:block;src:url(data:font/woff2;base64,${bytes.toString('base64')}) format('woff2');unicode-range:${font.range}}`}
const appCSS=await readFile('src/integrated.css','utf8');if(/@import|url\(\s*['\"]?https?:/i.test(appCSS))throw Error('Remote CSS forbidden');css+=appCSS;
const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="dark light"><title>RackClick v${version} · Integrada</title><style>${css}</style></head><body><div id="root"></div>${scripts}<script data-app="rackclick-v${version}">${transformed.code.replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
// Check new UI dictionary keys independently of the legacy dictionary.
const ctx={};const words=integrated.slice(integrated.indexOf('const IR_WORDS=')+'const IR_WORDS='.length,integrated.indexOf('\nfunction IRIcon'));const parsed=Function('return ('+words.trim().replace(/;$/,'')+')')();checkWords(parsed);const keys=Object.keys(parsed.en).sort().join('|');for(const l of ['de','es'])if(Object.keys(parsed[l]).sort().join('|')!==keys)throw Error('Integrated i18n mismatch');
if(!html.includes(`const RC_VERSION = "${version}"`))throw Error('Version identity check failed');
await mkdir('dist',{recursive:true});await mkdir('evidence',{recursive:true});await writeFile(`dist/RackClick-v${version}-Offline.html`,html);await writeFile('evidence/integrated-source.jsx',source);await writeFile('evidence/build.json',JSON.stringify({version,baseSHA256:hash(src),htmlSHA256:hash(html),bytes:Buffer.byteLength(html),patches,i18nKeys:Object.keys(parsed.en).length,coreI18nKeys:Object.keys(coreWords.en).length,rollbackSHA256:hash(rollback),networkRuntime:false},null,2));console.log('Build OK',version,Buffer.byteLength(html),hash(html));

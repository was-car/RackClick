# RackClick v0.9.0-rc9 · Dos ajustes visuales

ADOPTADA por confirmación expresa de Wascar. Fecha: 28.09.2026.

1. Exporta el respaldo completo desde RC8.
2. Abre `RackClick-v0.9.0-rc9-Offline.html` en una carpeta/perfil de pruebas separado. Carga una copia o usa los diez clientes sintéticos. No necesitas instalar nada.
3. Dentro de un cliente, abre **Etiquetas de todos los racks**: deben tener el mismo aspecto de la etiqueta individual (borde, nombre, ubicación, datos, ID enmarcado y pie).
4. En un switch PoE, comprueba el indicador activo amarillo y el inactivo sin relleno. Encender/apagar conserva su funcionamiento.
5. Comprueba la vista previa de impresión de las etiquetas. Puedes narrarme tus observaciones; no necesitas escribirlas en el manual.

Los cambios dirigidos fueron aceptados por Wascar el 28.09.2026. La revisión lingüística profunda que decidiste no hacer queda identificada como no realizada.

SHA-256 HTML: `63a60c4b52360211e1ae90b2e38541dc76bf372007219868e7c203af9223ea96`.

Retorno inmediato: `rollback/RackClick-v0.9.0-rc8-Offline.html`, intacto. También se conserva la base adoptada v0.8.6. Usa una copia del JSON y perfiles separados al volver atrás.

No cambia esquema, almacenamiento, lógica de conexiones, reportes ni marca RackClick. No contiene servidor ni base de datos. No se publica automáticamente.

## Documentación y pruebas

- `docs/SESION-QA-WASCAR-2026-09-28.md`: tu recorrido 58–69, separado por caso.
- `docs/NOVEDADES-RC9-DE.md`: actualización del manual en alemán.
- `evidence/rc9/`: pruebas dirigidas, capturas e impresión PDF.
- `evidence/RC8-RC9.diff`: cambios de código y versión.
- Los documentos RC8 y anteriores se conservan como antecedentes fechados; no son actas de pruebas nuevas de RC9.

Compilar: `npm ci` y `npm run build` con Node.js. Abrir el HTML no necesita Node ni Python. Pruebas dirigidas: `python tests/test_rc9_visual.py` con Playwright/Chromium instalado; build reproducible y negativo: `node tests/test_build_negative.mjs`.

// Focused UI corrections applied to the generated source. The adopted v0.8.6 source stays byte-identical.
export function uxPatches(source) {
  function once(before, after, label) {
    const parts = source.split(before);
    if (parts.length !== 2) throw Error(`UX patch anchor ${label}: ${parts.length - 1} matches`);
    source = parts.join(after);
  }

  once('{results.length} Treffer', '{results.length} {(IR_WORDS[lang]||IR_WORDS.en).searchHits}', 'global search count');
  once('Keine Treffer für "{globalSearch}"', '{(IR_WORDS[lang]||IR_WORDS.en).noSearch} "{globalSearch}"', 'global search empty');
  const themeLabel="{t.label}</button>";
  if (source.split(themeLabel).length-1!==2) throw Error("UX patch anchor theme labels");
  source=source.replaceAll(themeLabel,'{(IR_WORDS[lang]||IR_WORDS.en)[{dark:"themeDark",semidark:"themeSemidark",silver:"themeSilver",light:"themeLight"}[t.id]]}</button>');
  once('⚙️ Settings</span>', '{(IR_WORDS[lang]||IR_WORDS.en).settings}</span>', 'settings heading');

  once('    setView("project"); noti(t("notiRackDel"),"info");',
       '    setEditRack(null); setEditDev(null); setDevCtx(null); setSp(null); setSc(null); setView("project"); noti(t("notiRackDel"),"info");', 'rack deletion closes stale editor');

  // The batch handler already acts on every matching group port number; the label must report that same cardinality.
  once('{def.label} ({batchRange.to - batchRange.from + 1})',
       '{def.label} ({dev.ports.filter(p=>p.gn>=batchRange.from&&p.gn<=batchRange.to).length})', 'batch status count');
  once('              {batchColorRange.to - batchColorRange.from + 1}\n            </div>',
       '              {dev.ports.filter(p=>p.gn>=batchColorRange.from&&p.gn<=batchColorRange.to).length}\n            </div>', 'batch color count');
  once('(${batchColorRange.to - batchColorRange.from + 1})`}',
       '(${dev.ports.filter(p=>p.gn>=batchColorRange.from&&p.gn<=batchColorRange.to).length})`}', 'batch color clear count');

  const settings = `
          <section className="ir-settings-collections">
            <h3>{(IR_WORDS[lang]||IR_WORDS.en).manageTemplates} ({Object.keys(customTemplates).length})</h3>
            {Object.keys(customTemplates).length === 0 && <p>{(IR_WORDS[lang]||IR_WORDS.en).noTemplates}</p>}
            {Object.entries(customTemplates).map(([key,tpl])=><div key={key}><span>{tpl.label||tpl.name||key}</span><button aria-label={(IR_WORDS[lang]||IR_WORDS.en).removeTemplate+' '+(tpl.label||tpl.name||key)} onClick={()=>deleteCustomTemplate(key)}>{(IR_WORDS[lang]||IR_WORDS.en).remove}</button></div>)}
            <h3>{(IR_WORDS[lang]||IR_WORDS.en).manageFavorites} ({favPresets.size})</h3>
            {favPresets.size === 0 && <p>{(IR_WORDS[lang]||IR_WORDS.en).noFavorites}</p>}
            {[...favPresets].filter(key=>PRESETS[key]).map(key=><div key={key}><span>{PRESETS[key].label||key}</span><button aria-label={(IR_WORDS[lang]||IR_WORDS.en).removeFavorite+' '+(PRESETS[key].label||key)} onClick={()=>toggleFav(key)}>{(IR_WORDS[lang]||IR_WORDS.en).remove}</button></div>)}
          </section>
`;
  once('          {/* Snapshots */}', settings+'          {/* Snapshots */}', 'Settings collections');
  return source;
}

// Narrow invariant for attributes in the new physical interface. Dictionary and placeholders are checked by build.mjs.
export function checkIntegratedAccessibleLabels(integrated) {
  const raw = [...integrated.matchAll(/\b(?:aria-label|title)="([^"]+)"/g)].map(match=>match[0]);
  if (raw.length) throw Error(`Untranslated new-UI accessibility attribute: ${raw.join(', ')}`);
  const jsx=integrated.slice(integrated.indexOf("function IRIcon"));
  if (/Keine Treffer für|\bMove up\b|\bDelete device\b/.test(jsx)) throw Error('Untranslated new-UI fixed text');
}

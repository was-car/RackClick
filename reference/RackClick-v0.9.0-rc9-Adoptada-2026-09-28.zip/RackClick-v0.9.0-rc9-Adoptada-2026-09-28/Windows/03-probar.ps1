$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
python -X utf8 tests/run_qa.py
if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed. See evidence.' }

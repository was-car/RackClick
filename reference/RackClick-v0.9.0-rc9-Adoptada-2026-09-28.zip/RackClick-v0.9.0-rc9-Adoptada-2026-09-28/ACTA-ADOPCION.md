# Adopción oficial · RackClick v0.9.0-rc9 offline

Fecha: 28.09.2026 (Europe/Berlin). Wascar aprueba expresamente RC9 para uso y adopta el offline tras su revisión de etiquetas en lote, PoE amarillo y el recorrido de QA anterior.

Archivo: RackClick-v0.9.0-rc9-Offline.html.
SHA-256: 63a60c4b52360211e1ae90b2e38541dc76bf372007219868e7c203af9223ea96.

Estado: ADOPTADA. No se renombra internamente a v0.9.0 ni se recompila para la adopción. El binario probado es el publicado para descarga. Rollback inmediato: RC8 (20ba6bf676fa932967bf14862858ea34ef69c7074a1185fb83e8d6a1687c8cad). Base legacy adoptada v0.8.6 conservada.

La adopción es decisión del propietario. Se conservan los límites de evidencia: pruebas RC9 dirigidas Chromium/Linux, revisión independiente histórica y QA manual del usuario; no se inventa una revisión independiente completa nueva de RC9 ni un análisis antivirus todavía inexistente. La revisión lingüística profunda del usuario no fue realizada por decisión expresa. Esto no bloquea la adopción que acaba de confirmar.

Siguiente etapa: servicio para Systemhaus, API, persistencia, usuarios/grupos/permisos y retorno controlado del trabajo de campo. Planificada; no implementada por la web ni por la demo.

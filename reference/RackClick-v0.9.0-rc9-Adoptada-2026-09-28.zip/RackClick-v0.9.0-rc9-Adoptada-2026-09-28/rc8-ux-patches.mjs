// RC8 presentation changes. Applied after existing integration patches; adopted source unchanged.
export function rc8UxPatches(source){
 const once=(a,b,name)=>{const n=source.split(a).length-1;if(n!==1)throw Error('RC8 UX '+name+': '+n+' anchors');source=source.replace(a,b)};
 const many=(a,b,count,name)=>{const n=source.split(a).length-1;if(n!==count)throw Error('RC8 UX '+name+': '+n+' anchors');source=source.replaceAll(a,b)};
 once('function IRIcon({name,size=18}){const paths={',`function IRIcon({name,size=18}){const paths={search:'M10 3a7 7 0 100 14 7 7 0 100-14M15 15l6 6',star:'M12 2l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z',`, 'SVG icons');
 // Localized catalogue strings; keys and categories are checked before compilation.
 const catalogue={
 en:{nameOptional:'Device name (optional)',create:'Create',portGroup:'+ Port Group',generic:'Generic editable templates; verify the actual device. AP uses a 1U documentation slot.',categories:{'Patch Panels':'Patch Panels',Switches:'Switches',Servers:'Servers',Storage:'Storage',Network:'Network',Power:'Power',Spacers:'Spacers'}},
 de:{nameOptional:'Gerätename (optional)',create:'Erstellen',portGroup:'+ Portgruppe',generic:'Generische editierbare Vorlagen; reales Gerät prüfen. AP belegt einen 1U-Dokumentationsplatz.',categories:{'Patch Panels':'Patchpanel',Switches:'Switches',Servers:'Server',Storage:'Speicher',Network:'Netzwerk',Power:'Stromversorgung',Spacers:'Zubehör'}},
 es:{nameOptional:'Nombre del equipo (opcional)',create:'Crear',portGroup:'+ Grupo de puertos',generic:'Plantillas genéricas editables; verifica el equipo real. AP ocupa un espacio documental de 1U.',categories:{'Patch Panels':'Paneles de parcheo',Switches:'Switches',Servers:'Servidores',Storage:'Almacenamiento',Network:'Red',Power:'Alimentación',Spacers:'Accesorios'}}
 };
 for(const lang of ['de','es']){if(Object.keys(catalogue[lang]).sort().join('|')!==Object.keys(catalogue.en).sort().join('|')||Object.keys(catalogue[lang].categories).sort().join('|')!==Object.keys(catalogue.en.categories).sort().join('|'))throw Error('RC8 catalogue i18n keys '+lang)}
 once('function IRIcon(', 'const RC8_CATALOGUE='+JSON.stringify(catalogue)+';\nfunction IRIcon(', 'catalogue dictionary');
 once('>+ NEW DEVICE</button>', '>{t("addDevice")}</button>', 'new device translation');
 once('placeholder="Device name (optional)"','placeholder={(RC8_CATALOGUE[lang]||RC8_CATALOGUE.en).nameOptional}', 'device name translation');
 many('>+ Port Group</button>', '>{"+ "+t("portGroups")}</button>',2,'port group translation');
 once('>Create</button>', '>{(RC8_CATALOGUE[lang]||RC8_CATALOGUE.en).create}</button>', 'create translation');
 once('{cat.label.toUpperCase()}', '{((RC8_CATALOGUE[lang]||RC8_CATALOGUE.en).categories[cat.label]||cat.label).toUpperCase()}', 'category translation');
 // Remove emoji from input placeholders and draw one coherent SVG search icon.
 once("function irElement(type,props,...children){",`function irElement(type,props,...children){
 if(type==='input'&&typeof props?.placeholder==='string'&&/🔍/.test(props.placeholder)){props={...props,placeholder:props.placeholder.replace(/🔍\\s*/g,''),className:((props.className||'')+' rc8-search')};}
`, 'search inputs');
 many('Object.values(THEMES).map(t => (','[THEMES.dark,THEMES.light].map(t => (',2,'two theme selectors');
 once('return localStorage.getItem(THEME_KEY) || "dark";', 'const old=localStorage.getItem(THEME_KEY)||"dark";return old==="silver"?"light":old==="semidark"?"dark":old;', 'legacy theme normalization');
 // Actions are at the top and remain visible while scrolling through long client/rack lists.
 const foot='<footer><button onClick={onClose}>{w.cancel}</button><button onClick={()=>{onApply(draft);onClose()}}>{w.save}</button></footer>';
 once(foot,'','remove bottom infrastructure actions');
 once('<p>{w.hierarchyHelp}</p>',foot.replace('<footer>','<footer className="rc8-infra-actions">')+'<p>{w.hierarchyHelp}</p>','top infrastructure actions');
 // Keep favorites and custom templates immediately below the optional name.
 const ts=source.indexOf('                {Object.keys(customTemplates).length > 0 && <div>'),te=source.indexOf('                <details style={{ marginTop: 4 }}>',ts);
 if(ts<0||te<0)throw Error('RC8 UX template section');
 const tpl=source.slice(ts,te);source=source.slice(0,ts)+source.slice(te);
 once('                {CATS.map(cat => (',tpl+'                {CATS.map(cat => (','collections order');
 once('                {CATS.map(cat => (', '<p className="rc8-catalogue-note">{(RC8_CATALOGUE[lang]||RC8_CATALOGUE.en).generic}</p>                {CATS.map(cat => (', 'generic catalogue disclosure');
 once('<input value={dn}', '<input className="rc8-device-name" value={dn}', 'device name');
 const starStart='<span onClick={e => { e.stopPropagation(); toggleFav(k); }}',start=source.indexOf(starStart),end=source.indexOf('</span>',start);
 if(start<0||end<0)throw Error('RC8 UX favorite control');
 source=source.slice(0,start)+`<span role="button" tabIndex={0} aria-label={t("favorites")+' '+p.label} aria-pressed={favPresets.has(k)} className="rc8-favorite" onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();toggleFav(k)}}} onClick={e=>{e.stopPropagation();toggleFav(k)}}><IRIcon name="star" size={20}/></span>`+source.slice(end+7);
 // Theme-aware panel: semantic class restricts overrides to catalogue controls.
 once('{/* New device */}\n          <div style=', '{/* New device */}\n          <div className="rc8-device-catalogue" style=', 'catalogue class');
 // Responsive width at normal zoom; deliberate zoom retains horizontal scrolling and readable ports.
 once('style={{minWidth:840*zoom/100}}','style={{minWidth:Math.min(640,840*zoom/100),width:zoom>100?(zoom+\'%\'):\'100%\'}}','rack width');
 // Rack location suggestions preserve free text and are scoped to the active client.
 once('function RackEditModal({ rack, onSave, onClose, onDelete, t }) {','function RackEditModal({ rack, onSave, onClose, onDelete, t, locations=[] }) {','location prop');
 many('<RackEditModal rack=', '<RackEditModal locations={irLocations(irScope)} rack=',2,'location callsites');
 once('<input value={loc}', '<input list="rc8-rack-locations" value={loc}', 'location datalist');
 once('{LOC_SUGGEST.filter(l => !loc || l.toLowerCase().includes(loc.toLowerCase())).slice(0, 8).map(l => (','{[...new Set([...locations.flatMap(l=>[l.site,l.building,l.room]),...LOC_SUGGEST].filter(Boolean))].filter(l => !loc || l.toLowerCase().includes(loc.toLowerCase())).slice(0, 8).map(l => (','location quick suggestions');
 once('<select value={size}', '<datalist id="rc8-rack-locations">{[...new Set(locations.flatMap(l=>[l.site,l.building,l.room,[l.site,l.building,l.room].filter(Boolean).join(" / ")]).filter(Boolean))].map(l=><option key={l} value={l}/>)}</datalist><select value={size}', 'rack datalist options');
 // Generic editable inventory, never represented as vendor-specific hardware.
 once('const CATS = [',`Object.assign(PRESETS,{
 sw8:{label:'Switch 8P',icon:'⇋',color:'#e76f51',u:1,ports:[{t:'rj45',n:8},{t:'sfp',n:2}]},
 sw16:{label:'Switch 16P',icon:'⇋',color:'#e76f51',u:1,ports:[{t:'rj45',n:16},{t:'sfp',n:2}]},
 sw8p:{label:'Switch 8P PoE',icon:'⇋',color:'#e76f51',u:1,ports:[{t:'rj45_poe',n:8},{t:'sfp',n:2}]},
 rtr8:{label:'Router 8P',icon:'◎',color:'#b5838d',u:1,ports:[{t:'rj45',n:8},{t:'sfp',n:2},{t:'console',n:1}]},
 fw4:{label:'Firewall 4P',icon:'⛨',color:'#d97706',u:1,ports:[{t:'rj45',n:4},{t:'console',n:1}]},
 nas1u:{label:'NAS 1U',icon:'▤',color:'#7c3aed',u:1,ports:[{t:'rj45',n:2},{t:'usb_a',n:2}]},
 srv1u4:{label:'Server 1U 4LAN',icon:'▦',color:'#457b9d',u:1,ports:[{t:'rj45',n:4},{t:'mgmt',n:1},{t:'usb_a',n:2}]},
 ap:{label:'Access Point (AP)',icon:'◎',color:'#06b6d4',u:1,ports:[{t:'rj45',n:1}]}
});
const CATS = [`, 'generic catalogue');
 once('keys: ["sw24","sw24p","sw48","sw48p","swsfp"]','keys: ["sw8","sw8p","sw16","sw24","sw24p","sw48","sw48p","swsfp"]','switch presets');
 once('keys: ["srv1u","srv2u","srv4u"]','keys: ["srv1u","srv1u4","srv2u","srv4u"]','server presets');
 once('keys: ["nas2u","nas4u","san"]','keys: ["nas1u","nas2u","nas4u","san"]','storage presets');
 once('keys: ["rtr","fw","mc"]','keys: ["rtr","rtr8","fw","fw4","ap","mc"]','network presets');
 // Custom-device port groups carry the existing face metadata through mkP.
 once('if (d.t === "rj45_poe") port.poe = true; p.push(port);','if (d.t === "rj45_poe") port.poe = true; if(d.face==="front"||d.face==="rear")port.rackclickFace=d.face; p.push(port);','custom face serialization');
 once('{cust.pg.length > 1 && <button',`<select aria-label={(IR_WORDS[lang]||IR_WORDS.en).portFace+' '+(gi+1)} value={g.face||'auto'} onChange={e=>setCust(prev=>({...prev,pg:prev.pg.map((x,i)=>i===gi?{...x,face:e.target.value}:x)}))}>{['auto','front','rear'].map(f=><option key={f} value={f}>{(IR_WORDS[lang]||IR_WORDS.en)[f==='auto'?'autoFace':f]}</option>)}</select>{cust.pg.length > 1 && <button`, 'custom face input');
 return source;
}

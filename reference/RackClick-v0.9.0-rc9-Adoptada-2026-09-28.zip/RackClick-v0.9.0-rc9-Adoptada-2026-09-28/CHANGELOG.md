# ADOPTADA · v0.9.0-rc9 · 28.09.2026

Confirmación expresa de Wascar. Archivo y hash exactos preservados. Véase ACTA-ADOPCION.md. Los estados de candidata en las entradas anteriores son históricos.

# v0.9.0-rc9 · 28.09.2026 · KANDIDAT / CANDIDATA

- Etiquetas en lote alineadas al diseño individual.
- Indicador PoE activo amarillo; estado inactivo conserva contorno.
- Registro de QA narrado 58–69. Marca RackClick conservada.
- Sin cambios de datos o lógica. No adoptada. Rollback inmediato RC8.

# v0.9.0-rc8 · candidata de revisión

Cambios a partir de RC7: acciones infraestructura accesibles; catálogo claro/favoritos y8presets genéricos; dos temas; tooltips; PoE sin desplazamiento y suma corregida; PoE por rango; selección invalidada limpiada; reconexión atómica; validación de cambio de rol eléctrico; logo/técnico/reportes modernos/CSV/etiquetas. Se mantiene fuente adoptada v0.8.6 intacta; ensamblado de presentación y correcciones explícitas. No se integra v0.8.7 ni servidor.

Registros y pruebas en docs/ACTA-RC8.md y evidence/rc8/. Adopción pendiente del usuario.

---

# v0.9.0-rc7 — 2026-09-26 — CANDIDATA PARA QA DE WASCAR

Remediación de los hallazgos AUD-001…AUD-022 de la auditoría funcional rc6. Chromium 14/14 suites, Firefox 12/14 en primera ejecución y ambas suites afectadas pasan por separado; se documenta la observación intermitente P2 sobre el clic de Guardar. PDF automatizado solo en Chromium. Estado por hallazgo y criterio en `docs/CONTROL-CORRECCIONES-RC7.md`; únicamente las correcciones con reproducción en rc6, prueba positiva en rc7 y revisión independiente podrán declararse verificadas. El diseño visual rc6 aprobado por Wascar se conserva. Base adoptada y rollback: v0.8.6. RC7 no está adoptada ni publicada; la revisión manual en Windows sigue pendiente.

# v0.9.0-rc6 — 2026-09-26 — CANDIDATA

Informe de rack unificado con el informe de cliente aprobado; diez nombres ficticios estables; plantillas conservan caras/roles/colores con IDs nuevos; manual técnico ilustrado y matriz HTML/CSV. Revisión independiente detectó portColor omitido, corregido y probado. Prioridad futura Windows; Linux aplazado. QA del usuario y adopción pendientes.

# v0.9.0-rc5 — 2026-09-26 — CANDIDATA
Vista Frontal/Trasera explícita; rol opcional de alimentación y configuración manual; PDU1U/UPS y PSU en presets nuevos; demos eléctricas; bloqueo de nuevas parejas incompatibles; trazado ascendente corregido; documentación HTML ampliada y pack QA. Diseño del informe aprobado por Wascar y preservado. Ninguna adopción funcional declarada. Datos importados intactos, sin cableado automático.

# v0.9.0-rc4 — 2026-09-26 — CANDIDATA
Directorio de clientes y proyecto acotado; datos/ubicaciones de otros clientes preservados; metadatos de técnico/logo propios; carga, fusión, guardado y reporte según contexto; respaldo y snapshots globales explícitos; diez demos localizadas con 68 racks; informe visual de cliente e impresión; manual offline ES/DE/EN. Dos defectos de aislamiento detectados en revisión independiente y corregidos antes de entrega: ubicación importada y limpieza de historial. Undo mantiene cliente y vista. Sin adopción ni publicación.

# v0.9.0-rc3 – 2026-09-26 – KANDIDATA
Systemhaus dentro del proyecto; jerarquía cliente/sede/edificio/sala; asignación y gestión atómica; caras editables sin nuevos endpoints; vista trasera ilustrativa; notas en inspector; validación de metadata también en boot; undo Settings corregido tras revisión independiente.
No adoptada. No publicada. Base/rollback adoptado: v0.8.6. v0.8.7 excluida.

## Historial anterior
# Änderungs-/Entwicklungslog

## 0.9.0-rc2 — 2026-09-26 — CANDIDATA, no adoptada

Integración funcional de v0.8.6 con la dirección visual Demo Integrada 01: shell oscuro/claro, rack vectorial, conexiones visibles e inspector. Los controles de proyecto, rack, equipos, puertos, import/export y supervivencia siguen enlazados al núcleo. Se añade preferencia UI para Systemhaus y prioridad de color de próxima conexión.

Correcciones: multiselección; primer clic sin desplazamiento del rack; doble clic; Escape en conexión/bulk; menú por teclado y contraste; versión real en título/etiqueta; remapeo merge/import; movimiento sin mutación/orientación errónea; CSV sin elección ambigua; nombres de extremos al renombrar; conteo local en reporte. Regresiones y revisión independiente incluidas.

No se adopta v0.8.7. No hay PostgreSQL, servidor ni multiusuario en este artefacto. No está publicada. La matriz de paridad y puertas de QA completas permanecen abiertas.

## 0.8.6 — 2026-09-24 — ADOPTADA por Wascar

Base y rollback inmediato de esta candidata. Fuente y HTML intactos, hashes completos en evidence/build.json y SHA256SUMS.txt. La aceptación histórica no implica adopción de rc2.

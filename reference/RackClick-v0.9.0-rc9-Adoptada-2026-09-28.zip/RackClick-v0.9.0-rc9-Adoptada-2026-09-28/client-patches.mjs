import{readFile}from'node:fs/promises';
export async function clientPatches(source){
 const once=(a,b)=>{const parts=source.split(a);if(parts.length!==2)throw Error('Client integration anchor '+a.slice(0,80)+' '+(parts.length-1));source=parts.join(b)};
 const block=(a,b,text)=>{const x=source.indexOf(a),y=source.indexOf(b,x);if(x<0||y<0)throw Error('Client block '+a);source=source.slice(0,x)+text+source.slice(y)};
 const words=JSON.parse(await readFile('assets/clients-i18n.json','utf8'));for(const lang of ['de','es'])if(Object.keys(words[lang]).sort().join('|')!==Object.keys(words.en).sort().join('|'))throw Error('Client i18n parity');
 once('/* ═══════ CONSTANTS ═══════ */','const CW='+JSON.stringify(words)+';\n'+await readFile('src/clients.jsxinc','utf8')+'\n/* ═══════ CONSTANTS ═══════ */');
 once('  const [project, setProject] = useState(() => bootLoadProject(emptyProject));',`  const [project, setProject] = useState(() => bootLoadProject(emptyProject));
 const [irClient,setIrClient]=useState(null);
 const irScope=React.useMemo(()=>irClientProject(project,irClient),[project,irClient]);
 const irContextRef=useRef(null);
`);
 once('  const [view, setView] = useState("project");','  const [view, setView] = useState(()=>irClientList(project).length?"clients":"project");\n irContextRef.current={client:irClient,view};');
 once('const otherRacks = project.racks.filter(r => r.id !== activeRackId);','const otherRacks = irScope.racks.filter(r => r.id !== activeRackId);');
 once('const rack = project.racks.find(r => r.id === activeRackId);','const rack = irScope.racks.find(r => r.id === activeRackId);');
 // Global undo retains the selected client alongside the full portfolio.
 source=source.replaceAll('project: JSON.parse(JSON.stringify(project)), activeRackId','project: JSON.parse(JSON.stringify(project)), activeRackId, irClient, irView:view');
 source=source.replaceAll('setActiveRackId(top.activeRackId);','setActiveRackId(top.activeRackId);setIrClient(top.irClient??null);setView(top.irView||"project");setSp(null);setSc(null);setCtxMenu(null);setCrossSel(null);setSelectedDevs(new Set());');
 source=source.replaceAll('[project, activeRackId]);','[project, activeRackId, irClient, view]);').replaceAll('[undoStack, project, activeRackId]);','[undoStack, project, activeRackId, irClient, view]);').replaceAll('[redoStack, project, activeRackId]);','[redoStack, project, activeRackId, irClient, view]);');
 source=source.replace('action: label, tech: prev.technician || ""','action: label, client:irClient, tech: irScope.technician || ""');
 source=source.replace('racks: [...prev.racks, { id, name, location, size: +size, devs: [], conns: [] }]','racks: [...prev.racks, ...irLocateNew(prev,irClient,[{ id, name, location, size: +size, devs: [], conns: [] }])]');
 once('  const moveDevToRack = (devId, targetRackId) => {','  const moveDevToRack = (devId, targetRackId) => {\n    if(!irScope.racks.some(r=>r.id===targetRackId))return;');
 source=source.replace('racks: [...prev.racks, { id: newId, name: src.name + " (Copy)",', 'racks: [...prev.racks, { ...src, id: newId, name: src.name + " (Copy)",');
 source=source.replace('const remaining = project.racks.filter(r => r.id !== id);','const remaining = irScope.racks.filter(r => r.id !== id);');
 source=source.replace('setProject(prev => ({ ...prev, changeLog: [] }))','setProject(prev => ({ ...prev, changeLog: irClientList(prev).length?(prev.changeLog||[]).filter(e=>(e.client??null)!==irClient):[] }))');
 // Protect global snapshots from confusion with single-client exports.
 source=source.replace('  const restoreSnapshot = (snap) => {','  const restoreSnapshot = (snap) => {\n    if(irClientList(project).length&&!confirm(CW[lang].snapshotAll))return;');
 source=source.replace('const p = JSON.parse(snap.data); setProject(p);','const p = JSON.parse(snap.data); irAssertTopology(p); setProject(p);setIrClient(null);setView(irClientList(p).length?"clients":"project");');
 once('data: JSON.stringify(project) }','data: JSON.stringify(project) }'); // snapshot remains deliberately portfolio-wide
 block('  const saveJSON = () => {','  const loadJSON = () => {',`  const irExportAll=()=>{irDownloadData(project,'RackClick-backup-all');lastSavedRef.current=JSON.stringify(project);setDirty(false)};
 const saveJSON=()=>{
  if(view==='clients'){irExportAll();return}
  if(irBoundary(project,irClient).length){noti(CW[lang].boundary,'error');return}
  if(!irScope.racks.length){noti(CW[lang].empty,'info');return}
  const p={...irScope,updatedAt:new Date().toISOString()};if(!p.createdAt)p.createdAt=p.updatedAt;
  irDownloadData(p,'rackclick-'+p.name);if(!irClientList(project).length){lastSavedRef.current=JSON.stringify(project);setDirty(false)}noti(t('notiSaved'),'success');
 };
`);
 block('  const loadJSON = () => {','  const exportRack = () => {',`  const irImport=(mode)=>{
 const inp=document.createElement('input');inp.type='file';inp.accept='.json';inp.multiple=mode==='append';
 const context=irContextRef.current,base=project;
 inp.onchange=async e=>{const files=[...e.target.files];if(!files.length)return;try{
  const data=await Promise.all(files.map(async f=>irImportedProject(JSON.parse(await f.text()),f.name)));
  if(irProjectRef.current!==base||irContextRef.current.client!==context.client||irContextRef.current.view!==context.view)throw Error('Context changed');
  let next=base;
  if(mode==='all'||(mode==='replace'&&!irClientList(base).length&&irClientList(data[0]).length)){
   if(!confirm(CW[lang].replaceAll))return;next=data[0];
  }else if(mode==='replace'){
   if(irClientList(data[0]).length>1)throw Error('Use full backup import');
   if(irBoundary(base,irClient).length){noti(CW[lang].boundary,'error');return}
   if(irClientList(base).length&&!confirm(CW[lang].replaceClient))return;
   next=irReplaceClient(base,irClient,data[0]);
  }else for(const d of data)next=irAppendClient(next,irClient,d);
  irAssertTopology(next);pushUndo(mode==='append'?'Import racks':'Load project');setProject(next);setSp(null);setCrossSel(null);setSelectedDevs(new Set());
  if(mode==='all'||(mode==='replace'&&!irClientList(base).length&&irClientList(data[0]).length)){setIrClient(null);setActiveRackId(null);setView(irClientList(next).length?'clients':'project')}
  else{setActiveRackId(irClientProject(next,irClient).racks[0]?.id);setView('project')}
  noti(t('notiLoaded'),'success');
 }catch{noti(t('notiInvalidJson'),'error')}};inp.click();
 };
 const loadJSON=()=>irImport(view==='clients'?'all':'replace');
 const importRackJSON=()=>irImport('append');
 const mergeProject=()=>irImport('append');
`);
 // All portfolio mutations live before routing; every visible client action gets its scope.
 const idx=source.indexOf('  /* ═══════ ROUTING ═══════ */');if(idx<0)throw Error('routing');
 const actions=`
 const irClear=()=>{setSp(null);setCrossSel(null);setSc(null);setCtxMenu(null);setDevCtx(null);setSelectedDevs(new Set());setEditDev(null);setEditRack(null);setSearch('');setGlobalSearch('');setIrInspect(null);setIrWire(null)};
 const irGoClient=client=>{irClear();setIrClient(client);setActiveRackId(irClientProject(project,client).racks[0]?.id);setView('project')};
 const irGoHome=()=>{irClear();setView('clients')};
 const irSetMeta=(key,value)=>{setProject(p=>!irClient?{...p,[key]:value}:{...p,rackclickClientMeta:[...(p.rackclickClientMeta||[]).filter(m=>m.client!==irClient),{...((p.rackclickClientMeta||[]).find(m=>m.client===irClient)||{}),client:irClient,[key]:value}]})};
 const irRenameCurrent=()=>{const name=prompt(CW[lang].renameClient,irClient||project.name);if(!name?.trim())return;const next=name.trim().slice(0,100);try{const p=irClient?irRenameClient(project,irClient,next):{...project,name:next};pushUndo('Rename client');setProject(p);if(irClient)setIrClient(next)}catch{noti(CW[lang].clientExists,'error')}};
 const irLoadTen=()=>{if(!confirm(CW[lang].demoConfirm))return;pushUndo('Demo 10');setProject(irDemo(lang));setIrClient(null);irClear();setView('clients')};
`;
 source=source.slice(0,idx)+actions+source.slice(idx);
 block('  const newProject = () => {','  /* ─── Search/Filter ─── */',`  const newProject=()=>{if(irBoundary(project,irClient).length){noti(CW[lang].boundary,'error');return}if(!confirm(CW[lang].replaceClient))return;pushUndo('New project');setProject(irReplaceClient(project,irClient,emptyProject()));setActiveRackId(null);setView('project')};
 const loadDemo=()=>{if(irBoundary(project,irClient).length){noti(CW[lang].boundary,'error');return}if(irClientList(project).length&&!confirm(CW[lang].replaceClient))return;const data=irDemo(lang),demo=irClientProject(data,IR_DEMO_CLIENTS[1]);pushUndo('Load demo');const next=irReplaceClient(project,irClient,demo);setProject(next);setActiveRackId(irClientProject(next,irClient).racks[0]?.id);setView('project');noti(t('notiDemo'),'success')};

`);
 // Scope textual and inventory references in the rendered legacy controls, not their full-state setters.
 source=source.replaceAll('htmlEsc(project.name)','htmlEsc(irScope.name)').replaceAll('htmlEsc(project.technician','htmlEsc(irScope.technician').replaceAll('exportedFrom: project.name','exportedFrom: irScope.name');
 const render=source.indexOf('  /* ═══════ ROUTING ═══════ */');
 let tail=source.slice(render).replaceAll('project.racks','irScope.racks').replaceAll('project.crossConns','irScope.crossConns').replaceAll('project.technician','irScope.technician').replaceAll('project.logo','irScope.logo').replaceAll('project.changeLog','irScope.changeLog');
 tail=tail.replace('value={project.name} onChange={e => setProject(prev => ({ ...prev, name: e.target.value }))}', 'aria-label={CW[lang].renameClient} value={irScope.name} readOnly onClick={irRenameCurrent}');
 tail=tail.replace('setProject(prev => ({ ...prev, technician: e.target.value }))','irSetMeta("technician",e.target.value)').replace('placeholder="Techniker..."','placeholder={CW[lang].technician}');
 tail=tail.replaceAll('setProject(prev => ({ ...prev, logo: ev.target.result }))','irSetMeta("logo",ev.target.result)').replaceAll('setProject(prev => ({ ...prev, logo: undefined }))','irSetMeta("logo",undefined)');
 tail=tail.replace('if (view === "projectReport") return <ProjectReportPage project={project}', 'if (view === "projectReport"&&!legacyView) return <IRClientReport project={irScope} lang={lang} onBack={()=>setView("project")} onClassic={()=>setView("classicReport")}/>;\n  if (view === "classicReport"||view === "projectReport") return <ProjectReportPage project={irScope}');
 tail=tail.replace('onClick={async () => { const img = await captureRackDetailPNGDataURL', 'onClick={async () => { if(!legacyView){setRackReportPng(null);setView("report");return} const img = await captureRackDetailPNGDataURL');
 tail=tail.replace('if (view === "report" && rack) return <ReportPage', 'if (view === "report" && rack && !legacyView) return <IRClientReport project={{...irScope,name:irScope.name+" · "+rack.name,racks:[rack]}} lang={lang} onBack={()=>{setView("rack");setRackReportPng(null)}} onClassic={()=>setView("classicRackReport")}/>;\n  if ((view === "report" || view === "classicRackReport") && rack) return <ReportPage');
 tail=tail.replace('if (view === "project" || !rack)', 'if (view === "project" || view === "clients" || !rack)');
 // Existing visual shell surrounds a dedicated client directory; no global rack grid in that screen.
 tail=tail.replace('      <div className="ir-project-toolbar"', '      {view===\'clients\'?<IRClientsHome project={project} lang={lang} onClient={irGoClient} onDemo={irLoadTen} onExport={irExportAll} onLoad={()=>irImport(\'all\')} onManage={()=>setIrManage(true)} onLanguage={switchLang} status={autosaveStatus}/>:<>\n      <div className="ir-project-toolbar"');
 const end=tail.indexOf('\n  /* ═══════ RACK VIEW');if(end<0)throw Error('rack marker');const last=tail.lastIndexOf('    </div>',end);tail=tail.slice(0,last)+'      </>}\n'+tail.slice(last);
 // Save button announces its scope; failure banner always offers the complete memory backup.
 tail=tail.replaceAll('onClick={saveJSON} style={{ padding: "6px 12px", background: "#ef4444"','onClick={irExportAll} style={{ padding: "6px 12px", background: "#ef4444"');
 tail=tail.replaceAll('t("save")}${dirty','(irClient?CW[lang].saveClient:t("save"))}${dirty');
 tail=tail.replace('title="Merge another project into this one"','title={CW[lang].clientOnly}').replace('title="Neues Projekt / New Project"','title={CW[lang].clientOnly}');
 tail=tail.replace('l: "Devices"','l: CW[lang].devices').replace('l: "Connections"','l: CW[lang].connections');
 tail=tail.replace('const name = prompt(t("snapshotName"),','const name = prompt(CW[lang].saveSnapshot,');
 // Cross-client corruption remains in the portfolio, visible as warning; no silent data deletion.
 tail=tail.replace('      <div style={{ padding: "16px 20px" }}>','      {irBoundary(project,irClient).length>0&&<div className="ir-warning">{CW[lang].boundary}<button onClick={irExportAll}>{CW[lang].backupAll}</button></div>}\n      <div style={{ padding: "16px 20px" }}>');
 tail=tail.replace('</span> devices</span>','</span> {CW[lang].devices}</span>').replace('</span> conn.</span>','</span> {CW[lang].connections}</span>');
 tail=tail.replace('            + Add Rack','            {t("addRack")}');
 source=source.slice(0,render)+tail;
 once('const switchLang = (l) => { setLang(l); try { localStorage.setItem(LANG_KEY, l); } catch {} };',`const switchLang=(l)=>{if(project.rackclickDemoLanguage){const next=irTranslateDemo(project,l);if(irClient){const oldClients=irClientList(project),at=oldClients.indexOf(irClient);if(at>=0)setIrClient(irClientList(next)[at]||irClient)}setProject(next)}setLang(l);try{localStorage.setItem(LANG_KEY,l)}catch{}};`);
 // The legacy source is immutable; replace only the affected actions in the generated app.
 once('  const moveD = (id, dir) => { setDevs(prev => { const i = prev.findIndex(d => d.id === id); if (i < 0) return prev; const ni = i + dir; if (ni < 0 || ni >= prev.length) return prev; const a = [...prev]; [a[i], a[ni]] = [a[ni], a[i]]; return a; }); };',
 `  const moveD = (id, dir) => {
    const i=devs.findIndex(d=>d.id===id),ni=i+dir;
    if(i<0||ni<0||ni>=devs.length)return;
    pushUndo("Reorder devices");
    setDevs(prev=>{const a=[...prev],from=a.findIndex(d=>d.id===id),to=from+dir;if(from<0||to<0||to>=a.length)return prev;[a[from],a[to]]=[a[to],a[from]];return a});
  };`);
 once('      if (e.key === "Delete" && selectedDevs.size > 0 && view === "rack" && !editDev) { e.preventDefault(); bulkDeleteSelected(); }',
 '      if (e.key === "Delete" && selectedDevs.size > 0 && view === "rack" && !editDev && !e.target?.closest?.("input, textarea, select, [contenteditable], [role=\\\"textbox\\\"]")) { e.preventDefault(); bulkDeleteSelected(); }');
 once('  const addP = k => {\n    pushUndo("Add device");\n    const p = PRESETS[k] || customTemplates[k]; if (!p) return; const id = gid();',
 `  const addP = k => {
    const p = PRESETS[k] || customTemplates[k]; if (!p) return;
    if(!irRoomFor(p.u)){noti(CW[lang].capacity,'error');return}
    pushUndo("Add device");
    const id = gid();`);
 once('  const addCustom = () => {\n    pushUndo("Add custom device");',
 `  const addCustom = () => {
    if(!irRoomFor(cust.u)){noti(CW[lang].capacity,'error');return}
    pushUndo("Add custom device");`);
 once('  const saveEdit = (changes) => {\n    const dev = devs.find(d => d.id === editDev?.id);\n    if (!dev) return;',
 `  const saveEdit = (changes) => {
    const dev = devs.find(d => d.id === editDev?.id);
    if (!dev) return;
    if(!irRoomFor(changes.u,dev.id)){noti(CW[lang].capacity,'error');return}`);
 once('    const dev = srcRack.devs.find(d => d.id === devId);\n    const localConns =',
 `    const dev = srcRack.devs.find(d => d.id === devId);
    const targetRack=project.racks.find(r=>r.id===targetRackId);
    if(!targetRack||targetRack.id===srcRack.id)return;
    if(targetRack.devs.reduce((n,d)=>n+Number(d.u),0)+Number(dev.u)>Number(targetRack.size)){noti(CW[lang].capacity,'error');return}
    const localConns =`);
 once('  const addP = k => {',
 `  const irRoomFor=(height,excludeId)=>!!rack&&Number.isInteger(Number(height))&&Number(height)>0&&devs.reduce((n,d)=>n+(d.id===excludeId?0:Number(d.u)),0)+Number(height)<=Number(rack.size);
  const addP = k => {`);
 once('  const saveRackEdit = (changes) => {\n    pushUndo("Edit rack");',
 `  const saveRackEdit = (changes) => {
    const edited=project.racks.find(r=>r.id===(editRack?.id||activeRackId));
    if(!edited||Number(changes.size)<edited.devs.reduce((n,d)=>n+Number(d.u),0)){noti(CW[lang].capacity,'error');return}
    pushUndo("Edit rack");`);
 once('  const [ctxMenu, setCtxMenu] = useState(null);',
 '  const [ctxMenu, setCtxMenu] = useState(null);\n  const irWattsUndoRef=useRef(false);\n  const irConnNoteUndoRef=useRef(null);');
 once('    setCtxMenu({ x: e.clientX, y: e.clientY, did, pid, port });',
 '    irWattsUndoRef.current=false;setCtxMenu({ x: e.clientX, y: e.clientY, did, pid, port });');
 once('    if (action === "label") {',
 '    if(action==="wattsBegin"||action==="wattsEnd"){irWattsUndoRef.current=false;return}\n    if (action === "label") {');
 once('    } else if (action === "watts") {\n      setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, watts: value || undefined } : p) } : d));',
 `    } else if (action === "watts") {
      const old=devs.find(d=>d.id===did)?.ports.find(p=>p.id===pid)?.watts;
      if(value!==undefined&&(!Number.isFinite(value)||value<0||value>90)){noti(CW[lang].wattsRange,'error');return}
      if(old===value)return;
      if(!irWattsUndoRef.current){pushUndo("Edit watts");irWattsUndoRef.current=true}
      setDevs(prev=>prev.map(d=>d.id!==did?d:{...d,ports:d.ports.map(p=>p.id===pid?{...p,watts:value}:p)}));`);
 once('  }, [ctxMenu, pushUndo]);','  }, [ctxMenu, pushUndo, devs]);');
 once('value={port.watts||""} onChange={e => onAction("watts", +e.target.value)}',
 'value={port.watts??""} onFocus={() => onAction("wattsBegin")} onBlur={() => onAction("wattsEnd")} onChange={e => onAction("watts", e.target.value===""?undefined:Number(e.target.value))}');
 once('  const updateConnNote = (id, note) => {\n    const isLocal = conns.some(c => c.id === id);',
 `  const updateConnNote = (id, note) => {
    const before=[...conns,...(project.crossConns||[])].find(c=>c.id===id);
    if(!before||before.note===note)return;
    if(irConnNoteUndoRef.current!==id){pushUndo("Edit cable note");irConnNoteUndoRef.current=id}
    const isLocal = conns.some(c => c.id === id);`);
 once('  const updateConnField = (id, field, value) => {\n    const isLocal = conns.some(c => c.id === id);',
 `  const updateConnField = (id, field, value) => {
    const before=[...conns,...(project.crossConns||[])].find(c=>c.id===id);
    if(!before||before[field]===value)return;
    pushUndo("Edit cable "+field);
    const isLocal = conns.some(c => c.id === id);`);
 once('onChange={e => { const v = e.target.value; updateConnNote(sc.id, v); setSc(prev => ({ ...prev, note: v })); }} placeholder="z.B. Cat6a 15m blau, LWL OS2, Trunk..."',
 'onChange={e => { const v = e.target.value; updateConnNote(sc.id, v); setSc(prev => ({ ...prev, note: v })); }} onBlur={()=>{irConnNoteUndoRef.current=null}} placeholder="z.B. Cat6a 15m blau, LWL OS2, Trunk..."');
 return source;
}

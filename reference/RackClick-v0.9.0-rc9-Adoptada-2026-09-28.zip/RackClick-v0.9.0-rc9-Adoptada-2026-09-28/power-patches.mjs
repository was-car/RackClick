import{readFile}from'node:fs/promises';
export async function powerPatches(source){
 const once=(a,b)=>{const x=source.split(a);if(x.length!==2)throw Error('Power anchor '+a.slice(0,50));source=x.join(b)};
 once('/* ═══════ CONSTANTS ═══════ */',(await readFile('src/power.jsxinc','utf8'))+'\n/* ═══════ CONSTANTS ═══════ */');
 once('const CATS = [',`// New catalog devices only: existing imported inventory remains untouched.
for(const key of ['sw24','sw24p','sw48','sw48p','swsfp','srv1u','srv2u','srv4u','nas2u','nas4u','san','rtr','fw','mc']) PRESETS[key].ports=[...PRESETS[key].ports,{t:'power',n:/srv|nas|san/.test(key)?2:1}];
PRESETS.pdu.ports=[{t:'power',n:9}];PRESETS.ups.ports=[{t:'power',n:5},{t:'mgmt',n:1},{t:'usb_a',n:1}];
const CATS = [`);
 once('ports: mkP(p.ports, id), preset: p.label','ports: irTemplatePorts(p,id,lang), preset: p.label');
 once('    const next = { ...customTemplates, [key]: tpl };','    tpl.rackclickPortLayout=irTemplateLayout(dev);\n    const next = { ...customTemplates, [key]: tpl };');
 once('    const seen = new Set();\n    const links =',`    const lookup=(did,pid)=>project.racks.flatMap(r=>r.devs).find(d=>d.id===did)?.ports.find(p=>p.id===pid);
    if(pairs.some(([a,b])=>!irPowerPairAllowed(lookup(...a),lookup(...b)))){noti(IR_WORDS[lang].badPower,'error');return false}
    const seen = new Set();
    const links =`);
 once('});return irAssertTopology(p);\n}\nfunction irTranslateDemo','});irPowerDemo(p,lang);return irAssertTopology(p);\n}\nfunction irTranslateDemo');
 return source;
}

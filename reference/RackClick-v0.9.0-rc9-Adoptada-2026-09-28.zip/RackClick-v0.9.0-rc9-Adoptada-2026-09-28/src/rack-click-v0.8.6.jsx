const { useState, useCallback, useRef, useEffect } = React;

/* ═══════ CONSTANTS ═══════ */
/* ─── THEMES ─── */
const THEMES = {
  dark:     { id: "dark",     label: "🌑 Oscuro",      bg: "#08080d", bg2: "#0d0d14", bg3: "#12121a", bdr: "#1a1a2e", bdr2: "#2a2c3e", txt: "#e0e0e0", dim: "#888", mut: "#555", vdim: "#333", inp: "#08080d", acc: "#10b981", portBg: "#0c0c14", portBd: "#1e1e2e", portTx: "#2a2a3a", rackBg: "#1a1c2e", rackHd: "#8a8ca0" },
  semidark: { id: "semidark", label: "🌘 Semi-Oscuro",  bg: "#181d2a", bg2: "#1e2436", bg3: "#252d3e", bdr: "#2d3650", bdr2: "#3a4565", txt: "#e4e6ef", dim: "#9aa0b8", mut: "#667085", vdim: "#4a5268", inp: "#181d2a", acc: "#10b981", portBg: "#1a2030", portBd: "#2d3650", portTx: "#4a5268", rackBg: "#232b3e", rackHd: "#9aa0b8" },
  silver:   { id: "silver",   label: "🌗 Plata",        bg: "#e8eaef", bg2: "#dfe1e8", bg3: "#d0d3dc", bdr: "#b8bcc8", bdr2: "#a0a5b2", txt: "#1a1e2e", dim: "#3d4356", mut: "#4a5164", vdim: "#6b7288", inp: "#f0f1f5", acc: "#047857", portBg: "#d5d8e0", portBd: "#8a90a2", portTx: "#3d4356", rackBg: "#d0d3dc", rackHd: "#2e3248" },
  light:    { id: "light",    label: "☀️ Claro",        bg: "#f6f7fb", bg2: "#ffffff", bg3: "#eef0f5", bdr: "#d0d4e0", bdr2: "#b8bcc8", txt: "#1f2937", dim: "#404a5c", mut: "#4b5563", vdim: "#77809a", inp: "#ffffff", acc: "#047857", portBg: "#eef0f5", portBd: "#a8aec0", portTx: "#3f4756", rackBg: "#e0e3eb", rackHd: "#2e3248" },
};
const THEME_KEY = "rackclick_theme";
const LANG_KEY = "rackclick_lang";
const I18N = {
  en: {
    confirmReserved:"Reserved port — connect?", confirmRemovePorts:"Remove ports {ports} and {count} connections?", notiPortEditInvalid:"Invalid port configuration. Nothing changed.", notiBackupAmbiguous:"Backup order unknown. Export rescue data and choose a copy manually. Autosave paused until a project change.",
    notiSnapshotsFailed:"Could not save the snapshot change. Nothing was changed.", notiTemplatesFailed:"Could not save the template change. Nothing was changed.", notiFavoritesFailed:"Could not save favorites. Nothing was changed.", notiTemplateSaved:"📌 Template \"{name}\" saved", notiUndoLabel:"↩ Undo: {label}", notiFixed:"⚠️ Repaired: {detail}", notiUnknownFile:"Unknown format: {name}", notiImportedFile:"📥 Imported: {name}", notiFailedFile:"Import failed: {name}", notiMergedCounts:"🔀 Merged: {count} racks, {cross} cross-rack connections from \"{name}\"", notiExportedRack:"📤 Exported \"{name}\"", notiCsvCounts:"📥 CSV: {added} connections added, {skipped} skipped", notiRackAreaMissing:"Rack export area not found.", notiCanvasMissing:"html2canvas is not loaded.", notiPngSaved:"PNG exported ✅", notiPngFailed:"PNG export failed: {detail}", notiDuplicatedRack:"📋 Duplicated \"{name}\"; copied connections: {count}", notiAddedPreset:"Added {name}", notiPoeOn:"⚡ PoE ON", notiPoeOff:"PoE OFF", notiPortRange:"⚡ Ports {from}–{to} → {status}", notiPortColors:"🎨 Ports {from}–{to}: color set", notiPortColorsCleared:"🎨 Ports {from}–{to}: color cleared", notiBulkConnections:"⚡ {count} connections created", notiPickDestination:"🔗 Pick destination port in {name}", confirmDeleteRack:"Delete rack \"{name}\" and all its devices?", confirmDuplicateRack:"Duplicate \"{name}\" WITH {count} connections?\n\nOK = with connections\nCancel = devices only", confirmNewProject:"⚠️ Delete everything and start a new project?", confirmClearLog:"Clear all log entries?", confirmMoveDevice:"Move \"{name}\" to \"{rack}\"?\n\nLocal connections to convert: {local}.\nCross-rack connections to update: {cross}.\n\nContinue?", confirmDeleteDevice:"Delete \"{name}\"? Active connections: {count}.\n\nUse Ctrl+Z to undo.", confirmDeleteDevices:"Delete {count} devices? Affected connections: {connections}.\n\nUse Ctrl+Z to undo.",
     devices: "DEVICES", freeU: "FREE U", links: "LINKS", portUsage: "PORT USAGE", addDevice: "+ NEW DEVICE", save: "Save", load: "Load", merge: "Merge", import: "Import", report: "Report", demo: "Demo", newProj: "New", search: "Search...", settings: "Settings", theme: "THEME / PANEL", portColors: "PORT TYPE COLORS", groupColors: "CONNECTION COLORS BY DEVICE GROUP", groupHint: "When connecting these device types, auto-assign this cable color.", resetAll: "Reset all to defaults", language: "LANGUAGE", favorites: "FAVORITES", myTemplates: "MY TEMPLATES", customDevice: "Custom Device", front: "Front", rear: "Rear", rearView: "REAR VIEW", label: "Label", connected: "Connected!", disconnected: "Disconnected", deleted: "deleted", exported: "exported", merged: "Merged", addRack: "+ Add Rack", noDevices: "\u2190 Add devices from sidebar", connections: "CONNECTIONS", globalSearch: "\ud83d\udd0d Global search: devices, ports, labels, connections...", rackSearch: "\ud83d\udd0d Search...", labelDose: "LABEL / DOSE", status: "STATUS", cancel: "Cancel", saveBtn: "Save", connect: "Connect", portType: "PORT TYPE", srcDevice: "SOURCE DEVICE", tgtDevice: "TARGET DEVICE", select: "Select...", count: "COUNT", preview: "PREVIEW", noOtherRacks: "No other racks", allPorts: "All ports", ports: "Ports", moveToRack: "Move to rack", batchStatus: "Batch port status", saveTemplate: "Save as template", name: "NAME", sizeU: "SIZE (U)", icon: "ICON", serialNumber: "SERIAL NUMBER", ipAddress: "IP ADDRESS", model: "MODEL", firmware: "FIRMWARE", notes: "NOTES", portGroups: "PORT GROUPS", rackName: "RACK NAME", location: "LOCATION", deleteRack: "Delete this rack", startAt: "START AT", free: "free", max: "max", connCreated: "connections", uFree: "U free", hintLClick: "L-click: connect", hintRClick: "R-click: status/PoE/label", hintDblClick: "Dbl-click: label", hintCrossRack: "cross-rack", hintBulk: "bulk", hintUndo: "Ctrl+Z: undo", hintSave: "Ctrl+S: save", hintEsc: "Esc: cancel", hintDel: "Del: delete selected", notiSaved: "Saved!", notiRemoved: "Removed", notiUpdated: "Updated", notiLoaded: "Project loaded", notiNewProj: "New project created", notiRackDel: "Rack deleted", notiRackUpd: "Rack updated", notiExportPdf: "PDF report opened \u2014 use Print \u2192 Save as PDF", notiExportXls: "Excel exported (3 sheets: Devices, Connections, Summary)", notiCrossRack: "Cross-rack connected!", notiLogoSet: "Logo set", notiLogoRemoved: "Logo removed", notiLogCleared: "Log cleared", notiLabelRemoved: "Label removed", notiTemplateRemoved: "Template removed", notiInvalidJson: "Invalid JSON file", notiUnknownFmt: "Unknown format", notiCsvEmpty: "CSV is empty", notiCsvCols: "CSV needs 'From Device' and 'To Device' columns", notiFailedMerge: "Failed to merge project", notiOnlyV08: "Only v0.8 projects can be merged", notiFailedCsv: "Failed to parse CSV", notiDemo: "Demo: 2 racks + port labels + cable notes", notiV07Import: "v0.7 imported as rack", notiCustomDev: "Added custom device", notiDevAdded: "added to rack", poeBudget: "PoE BUDGET (W)", color: "COLOR", notesSection: "DEVICE NOTES", freeNotes: "Free notes...", connectToRack: "CONNECT TO RACK", moveToRackHeader: "MOVE TO RACK", prefix: "PREFIX", portLabels: "PORT LABELS", fromRack: "FROM RACK", toRack: "TO RACK", cable: "CABLE", cableNote: "CABLE / NOTE", projectReport: "Project Report", rackReport: "Report", notiRedo: "Redo", notiMoved: "Moved to", saveAsTemplate: "Save as Template", batchPortStatus: "Batch Port Status", qrCode: "QR Code", snapshot: "Snapshot", snapshots: "Snapshots", restoreSnapshot: "Restore", deleteSnapshot: "Delete", noSnapshots: "No snapshots yet", snapshotName: "Snapshot name", notiSnapshotSaved: "Snapshot saved!", notiSnapshotRestored: "Snapshot restored!", portColor: "PORT COLOR", batchPortColor: "Batch Port Color", clearColor: "Clear", notiColorSet: "Color applied!", notiColorCleared: "Color cleared", notiBootRepaired: "Project repaired at startup \u2014 original saved to quarantine", notiBootBackup: "Autosave invalid \u2014 recovered from backup", notiBootSafeMode: "Safe mode: no saved project could be loaded. Data secured in quarantine", quarantine: "QUARANTINE", quarantineInfo: "Data from a failed startup is stored here", quarantineDownload: "Download bundle", quarantineDownloadAutosave: "Download autosave only", quarantineCreatedAt: "Created", quarantineReason: "Reason", quarantineDelete: "Delete quarantine", quarantineDeleteConfirm: "Delete quarantined data permanently?", notiQuarantineDeleted: "Quarantine deleted", autosaveLabel: "Autosave", autosaveFailing: "Autosave FAILING", autosaveBannerTitle: "Automatic saving is failing (storage full)", autosaveBannerText: "Export your project NOW to avoid data loss", autosaveExportNow: "Export JSON now", autosaveLastOk: "last saved", notiRackCreated: "Rack created", promptRackName: "Rack name", notiDevicesRemoved: "devices removed", notiPortBlocked: "Port is disabled/faulty \u2014 no new connections", promptQuickLabel: "Port label / outlet" },
  de: {
    confirmReserved:"Reservierter Port — verbinden?", confirmRemovePorts:"Ports {ports} und {count} Verbindungen entfernen?", notiPortEditInvalid:"Ungültige Portkonfiguration. Keine Änderung.", notiBackupAmbiguous:"Backup-Reihenfolge unklar. Rettungsdaten exportieren und Kopie manuell wählen. Autosave bis zur Projektänderung pausiert.",
    notiSnapshotsFailed:"Die Snapshot-Änderung konnte nicht gespeichert werden. Es wurde nichts geändert.", notiTemplatesFailed:"Die Vorlagenänderung konnte nicht gespeichert werden. Es wurde nichts geändert.", notiFavoritesFailed:"Favoriten konnten nicht gespeichert werden. Es wurde nichts geändert.", notiTemplateSaved:"📌 Vorlage „{name}“ gespeichert", notiUndoLabel:"↩ Rückgängig: {label}", notiFixed:"⚠️ Repariert: {detail}", notiUnknownFile:"Unbekanntes Format: {name}", notiImportedFile:"📥 Importiert: {name}", notiFailedFile:"Import fehlgeschlagen: {name}", notiMergedCounts:"🔀 Zusammengeführt: {count} Racks, {cross} rackübergreifende Verbindungen aus „{name}“", notiExportedRack:"📤 „{name}“ exportiert", notiCsvCounts:"📥 CSV: {added} Verbindungen hinzugefügt, {skipped} übersprungen", notiRackAreaMissing:"Der Rack-Bereich für den Export wurde nicht gefunden.", notiCanvasMissing:"html2canvas ist nicht geladen.", notiPngSaved:"PNG exportiert ✅", notiPngFailed:"PNG-Export fehlgeschlagen: {detail}", notiDuplicatedRack:"📋 „{name}“ dupliziert; kopierte Verbindungen: {count}", notiAddedPreset:"{name} hinzugefügt", notiPoeOn:"⚡ PoE EIN", notiPoeOff:"PoE AUS", notiPortRange:"⚡ Ports {from}–{to} → {status}", notiPortColors:"🎨 Ports {from}–{to}: Farbe gesetzt", notiPortColorsCleared:"🎨 Ports {from}–{to}: Farbe entfernt", notiBulkConnections:"⚡ {count} Verbindungen erstellt", notiPickDestination:"🔗 Zielport in {name} auswählen", confirmDeleteRack:"Rack „{name}“ und alle Geräte darin löschen?", confirmDuplicateRack:"„{name}“ MIT {count} Verbindungen duplizieren?\n\nOK = mit Verbindungen\nAbbrechen = nur Geräte", confirmNewProject:"⚠️ Alles löschen und ein neues Projekt starten?", confirmClearLog:"Alle Protokolleinträge löschen?", confirmMoveDevice:"„{name}“ nach „{rack}“ verschieben?\n\nUmzuwandelnde lokale Verbindungen: {local}.\nZu aktualisierende rackübergreifende Verbindungen: {cross}.\n\nFortfahren?", confirmDeleteDevice:"„{name}“ löschen? Aktive Verbindungen: {count}.\n\nMit Strg+Z rückgängig machen.", confirmDeleteDevices:"{count} Geräte löschen? Betroffene Verbindungen: {connections}.\n\nMit Strg+Z rückgängig machen.",
     devices: "GER\u00c4TE", freeU: "FREI U", links: "VERB.", portUsage: "PORT-AUSLASTUNG", addDevice: "+ NEUES GER\u00c4T", save: "Speichern", load: "Laden", merge: "Zusammenf.", import: "Import", report: "Bericht", demo: "Demo", newProj: "Neu", search: "Suchen...", settings: "Einstellungen", theme: "DESIGN / PANEL", portColors: "PORT-TYP FARBEN", groupColors: "VERBINDUNGSFARBEN NACH GER\u00c4TEGRUPPE", groupHint: "Bei Verbindung dieser Ger\u00e4tetypen wird automatisch diese Kabelfarbe zugewiesen.", resetAll: "Alle auf Standard zur\u00fccksetzen", language: "SPRACHE", favorites: "FAVORITEN", myTemplates: "MEINE VORLAGEN", customDevice: "Eigenes Ger\u00e4t", front: "Vorne", rear: "Hinten", rearView: "R\u00dcCKANSICHT", label: "Etikett", connected: "Verbunden!", disconnected: "Getrennt", deleted: "gel\u00f6scht", exported: "exportiert", merged: "Zusammengef\u00fchrt", addRack: "+ Rack hinzuf\u00fcgen", noDevices: "\u2190 Ger\u00e4te aus Sidebar hinzuf\u00fcgen", connections: "VERBINDUNGEN", globalSearch: "\ud83d\udd0d Suche: Ger\u00e4te, Ports, Labels, Verbindungen...", rackSearch: "\ud83d\udd0d Suchen...", labelDose: "LABEL / DOSE", status: "STATUS", cancel: "Abbrechen", saveBtn: "Speichern", connect: "Verbinden", portType: "PORT-TYP", srcDevice: "QUELLGER\u00c4T", tgtDevice: "ZIELGER\u00c4T", select: "W\u00e4hlen...", count: "ANZAHL", preview: "VORSCHAU", noOtherRacks: "Keine weiteren Racks", allPorts: "Alle Ports", ports: "Ports", moveToRack: "In anderes Rack verschieben", batchStatus: "Port-Status f\u00fcr Bereich", saveTemplate: "Als Vorlage speichern", name: "NAME", sizeU: "GR\u00d6SSE (U)", icon: "ICON", serialNumber: "SERIENNUMMER", ipAddress: "IP-ADRESSE", model: "MODELL", firmware: "FIRMWARE", notes: "NOTIZEN", portGroups: "PORT-GRUPPEN", rackName: "RACK-NAME", location: "STANDORT", deleteRack: "Dieses Rack l\u00f6schen", startAt: "STARTEN AB", free: "frei", max: "max", connCreated: "Verbindungen", uFree: "U frei", hintLClick: "L-Klick: verbinden", hintRClick: "R-Klick: Status/PoE/Label", hintDblClick: "Doppelklick: Label", hintCrossRack: "Cross-Rack", hintBulk: "Bulk", hintUndo: "Strg+Z: r\u00fcckg.", hintSave: "Strg+S: speichern", hintEsc: "Esc: abbrechen", hintDel: "Entf: ausgew. l\u00f6schen", notiSaved: "Gespeichert!", notiRemoved: "Entfernt", notiUpdated: "Aktualisiert", notiLoaded: "Projekt geladen", notiNewProj: "Neues Projekt erstellt", notiRackDel: "Rack gel\u00f6scht", notiRackUpd: "Rack aktualisiert", notiExportPdf: "PDF-Bericht ge\u00f6ffnet \u2014 Drucken \u2192 Als PDF speichern", notiExportXls: "Excel exportiert (3 Bl\u00e4tter: Ger\u00e4te, Verbindungen, Zusammenfassung)", notiCrossRack: "Cross-Rack verbunden!", notiLogoSet: "Logo gesetzt", notiLogoRemoved: "Logo entfernt", notiLogCleared: "Log gel\u00f6scht", notiLabelRemoved: "Label entfernt", notiTemplateRemoved: "Vorlage entfernt", notiInvalidJson: "Ung\u00fcltige JSON-Datei", notiUnknownFmt: "Unbekanntes Format", notiCsvEmpty: "CSV ist leer", notiCsvCols: "CSV braucht 'From Device' und 'To Device' Spalten", notiFailedMerge: "Projekt-Zusammenf\u00fchrung fehlgeschlagen", notiOnlyV08: "Nur v0.8-Projekte k\u00f6nnen zusammengef\u00fchrt werden", notiFailedCsv: "CSV-Parsing fehlgeschlagen", notiDemo: "Demo: 2 Racks + Port-Labels + Kabelnotizen", notiV07Import: "v0.7 als Rack importiert", notiCustomDev: "Eigenes Ger\u00e4t hinzugef\u00fcgt", notiDevAdded: "zum Rack hinzugef\u00fcgt", poeBudget: "PoE-BUDGET (W)", color: "FARBE", notesSection: "GER\u00c4TENOTIZEN", freeNotes: "Freie Notizen...", connectToRack: "MIT RACK VERBINDEN", moveToRackHeader: "IN RACK VERSCHIEBEN", prefix: "PR\u00c4FIX", portLabels: "PORT-LABELS", fromRack: "VON RACK", toRack: "ZU RACK", cable: "KABEL", cableNote: "KABEL / NOTIZ", projectReport: "Projektbericht", rackReport: "Bericht", notiRedo: "Wiederherstellen", notiMoved: "Verschoben nach", saveAsTemplate: "Als Vorlage speichern", batchPortStatus: "Port-Status Batch", qrCode: "QR-Code", snapshot: "Snapshot", snapshots: "Snapshots", restoreSnapshot: "Wiederherstellen", deleteSnapshot: "Löschen", noSnapshots: "Noch keine Snapshots", snapshotName: "Snapshot-Name", notiSnapshotSaved: "Snapshot gespeichert!", notiSnapshotRestored: "Snapshot wiederhergestellt!", portColor: "PORT-FARBE", batchPortColor: "Port-Farbe (Batch)", clearColor: "Entfernen", notiColorSet: "Farbe gesetzt!", notiColorCleared: "Farbe entfernt", notiBootRepaired: "Projekt beim Start repariert \u2014 Original in Quarant\u00e4ne gesichert", notiBootBackup: "Autosave ung\u00fcltig \u2014 aus Backup wiederhergestellt", notiBootSafeMode: "Abgesicherter Modus: kein gespeichertes Projekt ladbar. Daten in Quarant\u00e4ne gesichert", quarantine: "QUARANT\u00c4NE", quarantineInfo: "Hier liegen Daten eines fehlgeschlagenen Starts", quarantineDownload: "Bundle herunterladen", quarantineDownloadAutosave: "Nur Autosave herunterladen", quarantineCreatedAt: "Erstellt", quarantineReason: "Grund", quarantineDelete: "Quarant\u00e4ne l\u00f6schen", quarantineDeleteConfirm: "Quarant\u00e4ne-Daten endg\u00fcltig l\u00f6schen?", notiQuarantineDeleted: "Quarant\u00e4ne gel\u00f6scht", autosaveLabel: "Autosave", autosaveFailing: "Autosave-FEHLER", autosaveBannerTitle: "Automatisches Speichern schl\u00e4gt fehl (Speicher voll)", autosaveBannerText: "Exportiere dein Projekt JETZT, um Datenverlust zu vermeiden", autosaveExportNow: "JSON jetzt exportieren", autosaveLastOk: "zuletzt gespeichert", notiRackCreated: "Rack erstellt", promptRackName: "Rack-Name", notiDevicesRemoved: "Ger\u00e4te entfernt", notiPortBlocked: "Port ist deaktiviert/defekt \u2014 keine neuen Verbindungen", promptQuickLabel: "Port-Label / Dose" },
  es: {
    confirmReserved:"Puerto reservado — ¿conectar?", confirmRemovePorts:"¿Eliminar puertos {ports} y {count} conexiones?", notiPortEditInvalid:"Configuración de puertos inválida. Sin cambios.", notiBackupAmbiguous:"Orden de backups desconocido. Exporta el rescate y elige una copia manualmente. Autoguardado pausado hasta cambiar el proyecto.",
    notiSnapshotsFailed:"No se pudo guardar el cambio de snapshots. No se cambió nada.", notiTemplatesFailed:"No se pudo guardar el cambio de plantillas. No se cambió nada.", notiFavoritesFailed:"No se pudieron guardar los favoritos. No se cambió nada.", notiTemplateSaved:"📌 Plantilla «{name}» guardada", notiUndoLabel:"↩ Deshacer: {label}", notiFixed:"⚠️ Reparado: {detail}", notiUnknownFile:"Formato desconocido: {name}", notiImportedFile:"📥 Importado: {name}", notiFailedFile:"Error al importar: {name}", notiMergedCounts:"🔀 Fusionados: {count} racks, {cross} conexiones entre racks de «{name}»", notiExportedRack:"📤 Exportado «{name}»", notiCsvCounts:"📥 CSV: {added} conexiones añadidas, {skipped} omitidas", notiRackAreaMissing:"No se encontró el área del rack para exportar.", notiCanvasMissing:"html2canvas no está cargado.", notiPngSaved:"PNG exportado ✅", notiPngFailed:"Error al exportar PNG: {detail}", notiDuplicatedRack:"📋 Duplicado «{name}»; conexiones copiadas: {count}", notiAddedPreset:"Añadido {name}", notiPoeOn:"⚡ PoE activado", notiPoeOff:"PoE desactivado", notiPortRange:"⚡ Puertos {from}–{to} → {status}", notiPortColors:"🎨 Puertos {from}–{to}: color establecido", notiPortColorsCleared:"🎨 Puertos {from}–{to}: color eliminado", notiBulkConnections:"⚡ {count} conexiones creadas", notiPickDestination:"🔗 Selecciona el puerto de destino en {name}", confirmDeleteRack:"¿Eliminar el rack «{name}» y todos sus dispositivos?", confirmDuplicateRack:"¿Duplicar «{name}» CON {count} conexiones?\n\nAceptar = con conexiones\nCancelar = solo dispositivos", confirmNewProject:"⚠️ ¿Borrar todo y comenzar un proyecto nuevo?", confirmClearLog:"¿Borrar todas las entradas del registro?", confirmMoveDevice:"¿Mover «{name}» a «{rack}»?\n\nConexiones locales que se convertirán: {local}.\nConexiones entre racks que se actualizarán: {cross}.\n\n¿Continuar?", confirmDeleteDevice:"¿Eliminar «{name}»? Conexiones activas: {count}.\n\nUsa Ctrl+Z para deshacer.", confirmDeleteDevices:"¿Eliminar {count} dispositivos? Conexiones afectadas: {connections}.\n\nUsa Ctrl+Z para deshacer.",
     devices: "EQUIPOS", freeU: "U LIBRE", links: "ENLACES", portUsage: "USO DE PUERTOS", addDevice: "+ NUEVO EQUIPO", save: "Guardar", load: "Cargar", merge: "Fusionar", import: "Importar", report: "Informe", demo: "Demo", newProj: "Nuevo", search: "Buscar...", settings: "Ajustes", theme: "TEMA / PANEL", portColors: "COLORES DE TIPO DE PUERTO", groupColors: "COLORES DE CONEXI\u00d3N POR GRUPO", groupHint: "Al conectar estos tipos de equipos, se asigna autom\u00e1ticamente este color de cable.", resetAll: "Restablecer todo", language: "IDIOMA", favorites: "FAVORITOS", myTemplates: "MIS PLANTILLAS", customDevice: "Equipo personalizado", front: "Frontal", rear: "Trasero", rearView: "VISTA TRASERA", label: "Etiqueta", connected: "\u00a1Conectado!", disconnected: "Desconectado", deleted: "eliminado", exported: "exportado", merged: "Fusionado", addRack: "+ Agregar Rack", noDevices: "\u2190 Agregar equipos desde barra lateral", connections: "CONEXIONES", globalSearch: "\ud83d\udd0d Buscar: equipos, puertos, etiquetas, conexiones...", rackSearch: "\ud83d\udd0d Buscar...", labelDose: "LABEL / DOSE", status: "ESTADO", cancel: "Cancelar", saveBtn: "Guardar", connect: "Conectar", portType: "TIPO DE PUERTO", srcDevice: "EQUIPO ORIGEN", tgtDevice: "EQUIPO DESTINO", select: "Seleccionar...", count: "CANTIDAD", preview: "VISTA PREVIA", noOtherRacks: "No hay otros racks", allPorts: "Todos los puertos", ports: "Puertos", moveToRack: "Mover a otro rack", batchStatus: "Estado de puertos por rango", saveTemplate: "Guardar como plantilla", name: "NOMBRE", sizeU: "TAMA\u00d1O (U)", icon: "ICONO", serialNumber: "N\u00daMERO DE SERIE", ipAddress: "DIRECCI\u00d3N IP", model: "MODELO", firmware: "FIRMWARE", notes: "NOTAS", portGroups: "GRUPOS DE PUERTOS", rackName: "NOMBRE DEL RACK", location: "UBICACI\u00d3N", deleteRack: "Eliminar este rack", startAt: "EMPEZAR EN", free: "libre", max: "m\u00e1x", connCreated: "conexiones", uFree: "U libre", hintLClick: "L-clic: conectar", hintRClick: "R-clic: estado/PoE/label", hintDblClick: "Doble clic: label", hintCrossRack: "cross-rack", hintBulk: "masivo", hintUndo: "Ctrl+Z: deshacer", hintSave: "Ctrl+S: guardar", hintEsc: "Esc: cancelar", hintDel: "Supr: eliminar sel.", notiSaved: "\u00a1Guardado!", notiRemoved: "Eliminado", notiUpdated: "Actualizado", notiLoaded: "Proyecto cargado", notiNewProj: "Nuevo proyecto creado", notiRackDel: "Rack eliminado", notiRackUpd: "Rack actualizado", notiExportPdf: "Informe PDF abierto \u2014 Imprimir \u2192 Guardar como PDF", notiExportXls: "Excel exportado (3 hojas: Equipos, Conexiones, Resumen)", notiCrossRack: "\u00a1Cross-rack conectado!", notiLogoSet: "Logo establecido", notiLogoRemoved: "Logo eliminado", notiLogCleared: "Log borrado", notiLabelRemoved: "Etiqueta eliminada", notiTemplateRemoved: "Plantilla eliminada", notiInvalidJson: "Archivo JSON inv\u00e1lido", notiUnknownFmt: "Formato desconocido", notiCsvEmpty: "CSV est\u00e1 vac\u00edo", notiCsvCols: "CSV necesita columnas 'From Device' y 'To Device'", notiFailedMerge: "Error al fusionar proyecto", notiOnlyV08: "Solo se pueden fusionar proyectos v0.8", notiFailedCsv: "Error al analizar CSV", notiDemo: "Demo: 2 racks + labels de puerto + notas de cable", notiV07Import: "v0.7 importado como rack", notiCustomDev: "Equipo personalizado a\u00f1adido", notiDevAdded: "a\u00f1adido al rack", poeBudget: "PRESUPUESTO PoE (W)", color: "COLOR", notesSection: "NOTAS DEL EQUIPO", freeNotes: "Notas libres...", connectToRack: "CONECTAR A RACK", moveToRackHeader: "MOVER A RACK", prefix: "PREFIJO", portLabels: "ETIQUETAS DE PUERTOS", fromRack: "RACK ORIGEN", toRack: "RACK DESTINO", cable: "CABLE", cableNote: "CABLE / NOTA", projectReport: "Informe del Proyecto", rackReport: "Informe", notiRedo: "Rehacer", notiMoved: "Movido a", saveAsTemplate: "Guardar como Plantilla", batchPortStatus: "Estado de Puertos (Lote)", qrCode: "Código QR", snapshot: "Instantánea", snapshots: "Instantáneas", restoreSnapshot: "Restaurar", deleteSnapshot: "Eliminar", noSnapshots: "Sin instantáneas aún", snapshotName: "Nombre", notiSnapshotSaved: "¡Instantánea guardada!", notiSnapshotRestored: "¡Instantánea restaurada!", portColor: "COLOR DE PUERTO", batchPortColor: "Color de Puertos (Lote)", clearColor: "Quitar", notiColorSet: "¡Color aplicado!", notiColorCleared: "Color eliminado", notiBootRepaired: "Proyecto reparado al arrancar \u2014 original guardado en cuarentena", notiBootBackup: "Autosave inv\u00e1lido \u2014 recuperado desde backup", notiBootSafeMode: "Modo seguro: ning\u00fan proyecto guardado pudo cargarse. Datos asegurados en cuarentena", quarantine: "CUARENTENA", quarantineInfo: "Aqu\u00ed se guardan datos de un arranque fallido", quarantineDownload: "Descargar bundle", quarantineDownloadAutosave: "Descargar solo autosave", quarantineCreatedAt: "Creado", quarantineReason: "Motivo", quarantineDelete: "Eliminar cuarentena", quarantineDeleteConfirm: "\u00bfEliminar definitivamente los datos en cuarentena?", notiQuarantineDeleted: "Cuarentena eliminada", autosaveLabel: "Autoguardado", autosaveFailing: "Autoguardado CON ERROR", autosaveBannerTitle: "El guardado autom\u00e1tico est\u00e1 fallando (almacenamiento lleno)", autosaveBannerText: "Exporta tu proyecto AHORA para evitar p\u00e9rdida de datos", autosaveExportNow: "Exportar JSON ahora", autosaveLastOk: "\u00faltimo guardado", notiRackCreated: "Rack creado", promptRackName: "Nombre del rack", notiDevicesRemoved: "dispositivos eliminados", notiPortBlocked: "Puerto deshabilitado/defectuoso \u2014 sin conexiones nuevas", promptQuickLabel: "Label del puerto / toma" },
};

/* ─── DEFAULT PORT TYPE COLORS (customizable) ─── */
const DEFAULT_PT_COLORS = {
  rj45: "#3b82f6", rj45_poe: "#3b82f6", sfp: "#a855f7", sfp28: "#ef4444",
  qsfp: "#10b981", mgmt: "#f59e0b", console: "#6b7280", power: "#ef4444",
  usb_a: "#9ca3af", usb_c: "#9ca3af",
};
const PT_COLOR_KEY = "rackclick_pt_colors";

/* ─── GROUP COLORS (connection color by device category pair) ─── */
const DEV_CATEGORIES = {
  "Patch Panel": ["pp24","pp48","ppf24"],
  "Switch": ["sw24","sw48","swsfp"],
  "Router": ["rtr"],
  "Firewall": ["fw"],
  "Server": ["srv1u","srv2u","srv4u"],
  "NAS/SAN": ["nas2u","nas4u","san"],
  "Other": [],
};
const GROUP_COLOR_KEY = "rackclick_group_colors";
const CC = [
  "#ef4444","#06b6d4","#f59e0b","#10b981","#f97316","#8b5cf6","#ec4899","#14b8a6",
  "#ea580c","#22d3ee","#f87171","#3b82f6","#fbbf24","#34d399","#fb923c","#a78bfa",
  "#f472b6","#2dd4bf","#c084fc","#67e8f9","#e11d48","#059669","#2563eb","#7c3aed",
  "#0d9488","#dc2626","#ca8a04","#c2410c","#0f766e","#9333ea","#4f46e5","#16a34a",
  "#0284c7","#b91c1c","#64748b","#1e3a5f","#fb7185","#818cf8","#fde047","#a5f3fc",
  "#fdba74","#6366f1","#7dd3fc","#86efac","#d97706","#be123c","#4338ca","#0891b2",
  "#4ade80","#e97451","#b45309","#1d4ed8","#2dd4bf","#d97706","#1e40af","#9f1239",
  "#0f766e","#be185d","#fb923c","#6d28d9",
];

const PT = {
  rj45:    { label: "RJ45",      shape: "sq",   color: "#3b82f6" },
  rj45_poe:{ label: "RJ45 PoE",  shape: "sq",   color: "#3b82f6", poe: true },
  sfp:     { label: "SFP/SFP+",  shape: "rect", color: "#a855f7" },
  sfp28:   { label: "SFP28",     shape: "rect", color: "#ef4444" },
  qsfp:    { label: "QSFP+",     shape: "wide", color: "#10b981" },
  mgmt:    { label: "MGMT",      shape: "circ", color: "#f59e0b" },
  console: { label: "Console",   shape: "circ", color: "#6b7280" },
  power:   { label: "Power",     shape: "sq",   color: "#ef4444" },
  usb_a:   { label: "USB-A",     shape: "sq",   color: "#9ca3af" },
  usb_c:   { label: "USB-C",     shape: "rect", color: "#9ca3af" },
};

const PS = {
  free:     { label: "Free",     color: null,      sym: "" },
  reserved: { label: "Reserved", color: "#f59e0b", sym: "R" },
  disabled: { label: "Disabled", color: "#ef4444", sym: "×" },
  faulty:   { label: "Faulty",   color: "#dc2626", sym: "!" },
};

const ICONS = ["▥","⇋","▦","▤","▩","◎","⛨","⚡","🔋","⇌","◻","⬒","☰","▣","⊞","⊡","▧","⬡"];

const PRESETS = {
  pp24:  { label: "Patch Panel 24P",     icon: "▥", color: "#2a9d8f", u: 1, ports: [{ t: "rj45", n: 24 }] },
  pp48:  { label: "Patch Panel 48P",     icon: "▥", color: "#2a9d8f", u: 2, ports: [{ t: "rj45", n: 48 }] },
  ppf24: { label: "Fiber Patch 24P",     icon: "▥", color: "#10b981", u: 1, ports: [{ t: "sfp", n: 24 }] },
  sw24:  { label: "Switch 24P",          icon: "⇋", color: "#e76f51", u: 1, ports: [{ t: "rj45", n: 24 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 },{ t: "console", n: 1 }] },
  sw24p: { label: "Switch 24P PoE",      icon: "⇋", color: "#e76f51", u: 1, ports: [{ t: "rj45_poe", n: 24 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 },{ t: "console", n: 1 }] },
  sw48:  { label: "Switch 48P",          icon: "⇋", color: "#e76f51", u: 1, ports: [{ t: "rj45", n: 48 },{ t: "sfp", n: 4 },{ t: "mgmt", n: 1 },{ t: "console", n: 1 }] },
  sw48p: { label: "Switch 48P PoE",      icon: "⇋", color: "#e76f51", u: 1, ports: [{ t: "rj45_poe", n: 48 },{ t: "sfp", n: 4 },{ t: "mgmt", n: 1 },{ t: "console", n: 1 }] },
  swsfp: { label: "Switch SFP+ 24P",     icon: "⇋", color: "#dc2626", u: 1, ports: [{ t: "sfp", n: 24 },{ t: "qsfp", n: 2 },{ t: "mgmt", n: 1 }] },
  srv1u: { label: "Server 1U",           icon: "▦", color: "#457b9d", u: 1, ports: [{ t: "rj45", n: 2 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 }] },
  srv2u: { label: "Server 2U",           icon: "▦", color: "#457b9d", u: 2, ports: [{ t: "rj45", n: 4 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 }] },
  srv4u: { label: "Server 4U (GPU)",     icon: "▦", color: "#0369a1", u: 4, ports: [{ t: "rj45", n: 2 },{ t: "sfp28", n: 2 },{ t: "qsfp", n: 2 },{ t: "mgmt", n: 1 }] },
  nas2u: { label: "NAS 2U",             icon: "▤", color: "#7c3aed", u: 2, ports: [{ t: "rj45", n: 2 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 }] },
  nas4u: { label: "NAS 4U",             icon: "▤", color: "#7c3aed", u: 4, ports: [{ t: "rj45", n: 4 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 }] },
  san:   { label: "SAN Storage",         icon: "▩", color: "#8b5cf6", u: 2, ports: [{ t: "sfp", n: 4 },{ t: "mgmt", n: 1 }] },
  rtr:   { label: "Router",             icon: "◎", color: "#b5838d", u: 1, ports: [{ t: "rj45", n: 4 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 },{ t: "console", n: 1 }] },
  fw:    { label: "Firewall",           icon: "⛨", color: "#d97706", u: 1, ports: [{ t: "rj45", n: 8 },{ t: "sfp", n: 2 },{ t: "mgmt", n: 1 }] },
  pdu:   { label: "PDU",                icon: "⚡", color: "#6b7280", u: 1, ports: [{ t: "power", n: 8 }] },
  ups:   { label: "UPS 2U",             icon: "🔋", color: "#eab308", u: 2, ports: [{ t: "power", n: 4 },{ t: "mgmt", n: 1 },{ t: "usb_a", n: 1 }] },
  mc:    { label: "Media Converter",     icon: "⇌", color: "#06b6d4", u: 1, ports: [{ t: "rj45", n: 4 },{ t: "sfp", n: 4 }] },
  bl1u:  { label: "Blank 1U",            icon: "▬", color: "#333333", u: 1, ports: [] },
  bl2u:  { label: "Blank 2U",            icon: "▬", color: "#333333", u: 2, ports: [] },
  sp1u:  { label: "Spacer 1U",           icon: "┄", color: "#1a1a2e", u: 1, ports: [] },
  sp2u:  { label: "Spacer 2U",           icon: "┄", color: "#1a1a2e", u: 2, ports: [] },
  cbl1u: { label: "Cable Mgmt 1U",       icon: "⊞", color: "#444444", u: 1, ports: [] },
  shelf: { label: "Shelf 1U",            icon: "⊟", color: "#555555", u: 1, ports: [] },
};

const CATS = [
  { label: "Patch Panels",  keys: ["pp24","pp48","ppf24"] },
  { label: "Switches",      keys: ["sw24","sw24p","sw48","sw48p","swsfp"] },
  { label: "Servers",       keys: ["srv1u","srv2u","srv4u"] },
  { label: "Storage",       keys: ["nas2u","nas4u","san"] },
  { label: "Network",       keys: ["rtr","fw","mc"] },
  { label: "Power",         keys: ["pdu","ups"] },
  { label: "Spacers",       keys: ["bl1u","bl2u","sp1u","sp2u","cbl1u","shelf"] },
];

const RSZ = [6, 12, 16, 20, 24, 32, 42, 48];
const gid = () => Math.random().toString(36).substr(2, 9);
const FAV_KEY = "rackclick_fav_presets";
const htmlEsc = value => String(value ?? "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
const SAVE_KEY = "rackclick_autosave_v08";
const BACKUP_KEYS = ["rackclick_backup_1", "rackclick_backup_2", "rackclick_backup_3"];
const BACKUP_META = "rackclick_backup_meta";
const TEMPLATES_KEY = "rackclick_custom_templates";
const SNAPSHOTS_KEY = "rackclick_snapshots";
const PATCH_ST = { none: { label: "—", color: "#333" }, planned: { label: "📋 Planned", color: "#3b82f6" }, progress: { label: "🔧 In Progress", color: "#f59e0b" }, done: { label: "✅ Done", color: "#10b981" }, tested: { label: "🧪 Tested", color: "#8b5cf6" } };
const LOC_SUGGEST = ["Keller","UG","EG","OG1","OG2","OG3","OG4","OG5","DG","Serverraum","Technikraum","Gebäude A","Gebäude B","Gebäude C"];
const MAX_UNDO = 30;

/* ═══════ VALIDATION ═══════ */
const validateRack = (r) => {
  if (!r || typeof r !== "object") return "Rack is not an object";
  if (!r.id || typeof r.id !== "string") r.id = gid();
  if (!r.name || typeof r.name !== "string") r.name = "Unnamed Rack";
  if (!r.size || typeof r.size !== "number" || r.size < 1) r.size = 24;
  if (!Array.isArray(r.devs)) r.devs = [];
  if (!Array.isArray(r.conns)) r.conns = [];
  r.devs = r.devs.filter(d => d && typeof d === "object" && d.id && d.name && Array.isArray(d.ports));
  r.devs.forEach(d => { if (!d.u || typeof d.u !== "number") d.u = 1; if (!d.icon) d.icon = "▦"; if (!d.color) d.color = "#6b7280"; if (!d.preset) d.preset = "Custom"; d.ports = d.ports.filter(p => p && p.id && p.type); });
  const allPortIds = new Set(); r.devs.forEach(d => d.ports.forEach(p => allPortIds.add(p.id)));
  const allDevIds = new Set(r.devs.map(d => d.id));
  r.conns = r.conns.filter(c => c && c.id && c.fd && c.td && c.fp && c.tp && allDevIds.has(c.fd) && allDevIds.has(c.td) && allPortIds.has(c.fp) && allPortIds.has(c.tp));
  return null;
};
const validateProject = (d) => {
  if (!d || typeof d !== "object") return "Not a valid object";
  if (d.version !== "0.8") return "Not a v0.8 project";
  if (!Array.isArray(d.racks) || d.racks.length === 0) return "No racks found";
  if (!d.name || typeof d.name !== "string") d.name = "Imported Project";
  const errors = [];
  d.racks.forEach((r, i) => { const e = validateRack(r); if (e) errors.push(`Rack ${i+1}: ${e}`); });
  if (!Array.isArray(d.crossConns)) d.crossConns = [];
  const allDevIds = new Set(); d.racks.forEach(r => r.devs.forEach(dev => allDevIds.add(dev.id)));
  const rackIds = new Set(d.racks.map(r => r.id));
  d.crossConns = d.crossConns.filter(c => c && c.id && c.fd && c.td && allDevIds.has(c.fd) && allDevIds.has(c.td) && rackIds.has(c.rackFrom) && rackIds.has(c.rackTo));
  return errors.length > 0 ? errors.join("; ") : null;
};

/* \u2550\u2550\u2550 BOOT LOADER (v0.8.2) \u2014 Validaci\u00f3n de arranque + modo seguro \u2550\u2550\u2550
   Reglas aprobadas (Paso 3):
   - La cuarentena se escribe ANTES de devolver cualquier proyecto.
   - Strings CRUDOS sin parsear, en una sola clave (bundle).
   - Cero removeItem/clear autom\u00e1ticos: eliminar cuarentena es acci\u00f3n
     expl\u00edcita del usuario en Settings.
   - En modo seguro (o si la escritura de cuarentena fall\u00f3), se suprime el
     PRIMER ciclo del autosave para no sobrescribir el estado anterior. */
const QUARANTINE_KEY = "rackclick_quarantine";
let BOOT_REPORT = null;
let BOOT_SUPPRESS_FIRST_AUTOSAVE = false;

function bootQuarantine(reason, rawMap) {
  try {
    localStorage.setItem(QUARANTINE_KEY, JSON.stringify({ createdAt: new Date().toISOString(), reason, keys: rawMap }));
    return true;
  } catch { return false; }
}

function bootTryParse(raw) {
  if (!raw) return { ok: false };
  let p;
  try { p = JSON.parse(raw); } catch { return { ok: false }; }
  if (!p || typeof p !== "object" || p.version !== "0.8") return { ok: false };
  const before = JSON.stringify(p);
  let err;
  try { err = validateProject(p); } catch { return { ok: false }; }
  if (err) return { ok: false };
  return { ok: true, project: p, repaired: JSON.stringify(p) !== before };
}

function bootLoadProject(emptyFactory) {
  let rawSave = null;
  try { rawSave = localStorage.getItem(SAVE_KEY); } catch {}
  const rawMap = { autosave: rawSave };
  BACKUP_KEYS.forEach(bk => { try { rawMap[bk] = localStorage.getItem(bk); } catch { rawMap[bk] = null; } });

  // Primer uso: no hay nada guardado \u2014 arranque normal, sin informe ni cuarentena
  if (!rawSave && !BACKUP_KEYS.some(bk => rawMap[bk])) return emptyFactory();

  // [1] Autosave
  const rs = bootTryParse(rawSave);
  if (rs.ok && !rs.repaired) return rs.project; // ruta sana: id\u00e9ntica a v0.8.1

  if (rs.ok && rs.repaired) {
    const qOk = bootQuarantine("repaired-at-boot", rawMap);
    if (!qOk) BOOT_SUPPRESS_FIRST_AUTOSAVE = true;
    BOOT_REPORT = { type: "repaired", quarantineSaved: qOk };
    return rs.project;
  }

  // [2] Legacy cursor = last written slot. It orders copies, not proof of commit.
  let meta = null;
  try { meta = JSON.parse(localStorage.getItem(BACKUP_META)); } catch {}
  const validSlot = Number.isInteger(meta?.slot) && meta.slot >= 0 && meta.slot < BACKUP_KEYS.length;
  const candidates = BACKUP_KEYS.filter(bk => bootTryParse(rawMap[bk]).ok);
  if (!validSlot && candidates.length > 1) {
    // No arbitrary choice and no overwrite of existing recovery evidence.
    BOOT_SUPPRESS_FIRST_AUTOSAVE = true;
    BOOT_REPORT = { type: "ambiguous" };
    return emptyFactory();
  }
  const order = validSlot
    ? BACKUP_KEYS.map((_, i) => BACKUP_KEYS[(meta.slot - i + BACKUP_KEYS.length) % BACKUP_KEYS.length])
    : candidates;
  for (const bk of order) {
    const rb = bootTryParse(rawMap[bk]);
    if (rb.ok) {
      const qOk = bootQuarantine("autosave-invalid", rawMap);
      if (!qOk) BOOT_SUPPRESS_FIRST_AUTOSAVE = true;
      BOOT_REPORT = { type: "backup", backupKey: bk, quarantineSaved: qOk };
      return rb.project;
    }
  }

  // [3] Modo seguro
  const qOk = bootQuarantine("all-invalid", rawMap);
  BOOT_SUPPRESS_FIRST_AUTOSAVE = true; // SIEMPRE en modo seguro (regla aprobada T8)
  BOOT_REPORT = { type: "safeMode", quarantineSaved: qOk };
  return emptyFactory();
}

function reconcilePorts(dev, groups, allPorts) {
  if (!Array.isArray(groups)) throw new Error("port groups");
  const old = new Map(dev.ports.map(p => [p.id, p]));
  if (old.size !== dev.ports.length) throw new Error("duplicate port ID");
  const used = new Set(allPorts.map(p => p.id));
  const kept = new Map(), claimed = new Set(), added = [];
  let sequence = 1;
  for (const g of groups) {
    if (!PT[g.t] || !Number.isInteger(g.n) || g.n < 1 || g.n > 96) throw new Error("port group");
    const ids = g.ids || [];
    if (!Array.isArray(ids)) throw new Error("port IDs");
    ids.forEach(id => {
      if (!old.has(id) || claimed.has(id)) throw new Error("port ownership");
      claimed.add(id);
    });
    ids.slice(0, g.n).forEach(id => {
      const p = old.get(id);
      kept.set(id, p.type === g.t ? p : { ...p, type: g.t });
    });
    let gn = Math.max(0, ...ids.map(id => Number(old.get(id).gn) || 0));
    for (let i = ids.length; i < g.n; i++) {
      while (used.has(`${dev.id}-p${sequence}`)) sequence++;
      const id = `${dev.id}-p${sequence++}`; used.add(id);
      added.push({ id, gn: ++gn, type: g.t, ...(g.t === "rj45_poe" ? { poe: true } : {}) });
    }
  }
  return [...dev.ports.filter(p => kept.has(p.id)).map(p => kept.get(p.id)), ...added];
}

const mkP = (defs, did) => {
  const p = []; let seq = 1;
  defs.forEach(d => { for (let i = 0; i < d.n; i++) { const port = { id: `${did}-p${seq}`, gn: i + 1, type: d.t }; if (d.t === "rj45_poe") port.poe = true; p.push(port); seq++; } });
  return p;
};

/* ═══════ PORT ═══════ */
function Port({ port, did, isSel, cc, cl, isCross, onClick, onCtx, flash, onDblClick, prefix }) {
  const pt = PT[port.type] || PT.rj45;
  const has = !!cc; const st = port.status || "free"; const psDef = PS[st] || PS.free; const isPoe = port.poe;
  const pf = prefix || "";
  const touchRef = useRef(null);
  const onTouchStart = (e) => { touchRef.current = setTimeout(() => { const t = e.touches[0]; onCtx({ preventDefault:()=>{}, stopPropagation:()=>{}, clientX: t.clientX, clientY: t.clientY }, did, port.id); touchRef.current = null; }, 500); };
  const onTouchEnd = () => { if (touchRef.current) { clearTimeout(touchRef.current); touchRef.current = null; } };
  let bg, bd;
  if (flash) { bg = "#00ff88"; bd = "#00ff88"; }
  else if (isSel) { bg = "#00ff88"; bd = "#00ff88"; }
  else if (has && isCross) { bg = cc; bd = "#a855f7"; }
  else if (has) { bg = cc; bd = cc; }
  else if (st === "reserved") { bg = "#0c0c14"; bd = "#f59e0b"; }
  else if (st === "disabled") { bg = "#1a0808"; bd = "#ef444488"; }
  else if (st === "faulty") { bg = "#1a0808"; bd = "#dc2626"; }
  else if (port.portColor) { bg = port.portColor + "33"; bd = port.portColor; }
  else { bg = "#0c0c14"; bd = "#1e1e2e"; }
  const w = pf ? Math.max(pt.shape === "wide" ? 26 : pt.shape === "rect" ? 20 : 16, 6 * (pf.length + String(port.gn).length) + 8) : pt.shape === "wide" ? 26 : pt.shape === "rect" ? 20 : 16;
  const br = pt.shape === "circ" ? 8 : 2;
  let title = `${pt.label} ${pf}#${port.gn}`;
  if (port.label) title += ` [${port.label}]`;
  if (cl) title += ` → ${cl}`;
  if (isCross) title += " 🔗";
  if (st !== "free") title += ` (${psDef.label})`;
  if (isPoe) title += " ⚡PoE";
  let display = pf ? `${pf}${port.gn}` : port.gn;
  if (!has && !isSel && st === "disabled") display = "×";
  else if (!has && !isSel && st === "faulty") display = "!";
  const hasLabel = !!port.label;
  return (
    <div role="button" aria-label={title} tabIndex={0}
      onClick={e => { e.stopPropagation(); if (e.detail > 1) return; onClick(did, port.id); }}
      onKeyDown={e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onClick(did, port.id); } }}
      onDoubleClick={e => { e.stopPropagation(); e.preventDefault(); if (onDblClick) onDblClick(e, did, port.id); }}
      /* v0.8.4: los dos clics del doble clic no deben togglear la selección */
      onContextMenu={e => { e.preventDefault(); e.stopPropagation(); onCtx(e, did, port.id); }}
      onTouchStart={onTouchStart} onTouchEnd={onTouchEnd} onTouchMove={onTouchEnd}
      title={title}
      style={{ width: w, height: 15, borderRadius: br, backgroundColor: bg,
        border: `1.5px ${st === "reserved" && !has && !isSel ? "dashed" : "solid"} ${bd}`,
        cursor: "pointer", transition: "all 0.1s",
        boxShadow: flash ? "0 0 12px #00ff88, 0 0 24px #00ff8866" : isSel ? "0 0 8px #00ff88" : has ? `0 0 5px ${cc}44` : st === "faulty" ? "0 0 4px #dc262666" : "none",
        display: "flex", alignItems: "center", justifyContent: "center", fontSize: 7,
        color: isSel || has ? "#000" : st === "disabled" ? "#ef4444" : st === "faulty" ? "#dc2626" : st === "reserved" ? "#f59e0b" : "#2a2a3a",
        fontWeight: 800, fontFamily: "monospace", flexShrink: 0, userSelect: "none", position: "relative" }}>
      {display}
      {isPoe && !isSel && <div style={{ position: "absolute", top: -4, right: -3, fontSize: 5, color: "#f59e0b", lineHeight: 1 }}>⚡</div>}
      {isCross && has && <div style={{ position: "absolute", bottom: -5, left: "50%", transform: "translateX(-50%)", fontSize: 5, lineHeight: 1 }}>🔗</div>}
      {hasLabel && !has && !isSel && <div style={{ position: "absolute", bottom: -6, left: "50%", transform: "translateX(-50%)", fontSize: 5, color: "#10b981", lineHeight: 1, whiteSpace: "nowrap", maxWidth: 24, overflow: "hidden" }}>•</div>}
      {port.portColor && !has && !isSel && <div style={{ position: "absolute", bottom: -1, left: 2, right: 2, height: 2, borderRadius: 1, background: port.portColor }} />}
    </div>
  );
}

/* ═══════ PORT CONTEXT MENU ═══════ */
function PortCtxMenu({ pos, port, onAction, onClose, otherRacks, onCrossConnect, t }) {
  const ref = useRef(null);
  const [labelVal, setLabelVal] = useState(port.label || "");
  useEffect(() => {
    const h = e => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    document.addEventListener("mousedown", h); return () => document.removeEventListener("mousedown", h);
  }, [onClose]);
  const pt = PT[port.type] || PT.rj45; const st = port.status || "free";
  const canPoe = port.type === "rj45" || port.type === "rj45_poe";
  const statuses = ["free", "reserved", "disabled", "faulty"];
  const hasOtherRacks = otherRacks && otherRacks.length > 0;
  return (
    <div ref={ref} style={{ position: "fixed", left: pos.x, top: pos.y, zIndex: 1200, background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, borderRadius: 8, padding: 6, minWidth: 180, boxShadow: "0 8px 24px #000a", maxHeight: "80vh", overflowY: "auto" }}>
      <div style={{ fontSize: 8, color: "#555", padding: "2px 8px", letterSpacing: 0.5 }}>{pt.label} #{port.gn}{port.label ? ` — ${port.label}` : ""}</div>
      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      <div style={{ fontSize: 8, color: "#333", padding: "2px 8px", letterSpacing: 0.5 }}>{t("labelDose")}</div>
      <div style={{ padding: "2px 8px", display: "flex", gap: 4 }}>
        <input value={labelVal} onChange={e => setLabelVal(e.target.value)} placeholder="z.B. Büro 201, Dose A..." onKeyDown={e => { if (e.key === "Enter") { onAction("label", labelVal.trim()); onClose(); } }}
          style={{ flex: 1, background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "3px 6px", borderRadius: 3, fontSize: 9, fontFamily: "inherit", outline: "none" }} />
        <button onClick={() => { onAction("label", labelVal.trim()); onClose(); }}
          style={{ padding: "3px 6px", background: "#10b98115", border: "1px solid #10b98133", color: "#10b981", borderRadius: 3, cursor: "pointer", fontSize: 8, fontFamily: "inherit" }}>✓</button>
      </div>
      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      <div style={{ fontSize: 8, color: "#333", padding: "2px 8px", letterSpacing: 0.5 }}>{t("status")}</div>
      {statuses.map(s => {
        const def = PS[s]; const active = st === s || (s === "free" && !st);
        return (
          <div key={s} onClick={() => { onAction("status", s); onClose(); }}
            style={{ padding: "4px 8px", fontSize: 10, cursor: "pointer", borderRadius: 4, display: "flex", alignItems: "center", gap: 6, background: active ? "#10b98112" : "transparent", color: active ? "#10b981" : "#888" }}
            onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#ffffff08"; }} onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}>
            <div style={{ width: 8, height: 8, borderRadius: 2, background: def.color || "#333", border: s === "free" ? "1px solid #333" : "none", flexShrink: 0 }} />
            {def.label}{active && <span style={{ marginLeft: "auto", fontSize: 8 }}>✓</span>}
          </div>);
      })}
      {canPoe && <>
        <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
        <div onClick={() => { onAction("poe", !port.poe); onClose(); }}
          style={{ padding: "4px 8px", fontSize: 10, cursor: "pointer", borderRadius: 4, display: "flex", alignItems: "center", gap: 6, color: port.poe ? "#f59e0b" : "#888" }}
          onMouseEnter={e => e.currentTarget.style.background = "#ffffff08"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
          ⚡ PoE {port.poe ? "ON" : "OFF"}{port.poe && <span style={{ marginLeft: "auto", fontSize: 8, color: "#f59e0b" }}>✓</span>}
        </div>
        {port.poe && <div style={{ padding: "2px 8px", display: "flex", alignItems: "center", gap: 4 }} onClick={e => e.stopPropagation()}>
          <span style={{ fontSize: 7, color: "#f59e0b" }}>W</span>
          <input type="number" min={0} max={90} value={port.watts||""} onChange={e => onAction("watts", +e.target.value)} placeholder="15.4" style={{ width: 50, background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#f59e0b", padding: "2px 4px", borderRadius: 3, fontSize: 9, fontFamily: "inherit", outline: "none" }} />
        </div>}
      </>}

      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      <div style={{ fontSize: 8, color: "#333", padding: "2px 8px", letterSpacing: 0.5 }}>{`🎨 ${t("portColor")}`}</div>
      <div style={{ padding: "2px 8px", display: "flex", gap: 3, flexWrap: "wrap", alignItems: "center" }}>
        {["#3b82f6","#10b981","#f59e0b","#ef4444","#a855f7","#06b6d4","#ec4899","#f97316","#84cc16","#6366f1","#14b8a6","#e11d48"].map(c => (
          <div key={c} onClick={() => { onAction("portColor", c); onClose(); }}
            style={{ width: 14, height: 14, borderRadius: 3, background: c, cursor: "pointer", border: port.portColor === c ? "2px solid #fff" : "1px solid #333", flexShrink: 0 }} />
        ))}
        {port.portColor && <div onClick={() => { onAction("portColor", null); onClose(); }}
          style={{ padding: "2px 5px", fontSize: 7, color: "#ef4444", cursor: "pointer", border: "1px solid #ef444433", borderRadius: 3, background: "#ef444408" }}>{t("clearColor")}</div>}
      </div>
      {hasOtherRacks && <>
        <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
        <div style={{ fontSize: 8, color: "#333", padding: "2px 8px", letterSpacing: 0.5 }}>{`🔗 ${t("connectToRack")}`}</div>
        {otherRacks.map(r => (
          <div key={r.id} onClick={() => { onCrossConnect(r.id); onClose(); }}
            style={{ padding: "4px 8px", fontSize: 10, cursor: "pointer", borderRadius: 4, color: "#a855f7", display: "flex", alignItems: "center", gap: 6 }}
            onMouseEnter={e => e.currentTarget.style.background = "#a855f708"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
            ⬒ {r.name}{r.location ? ` (${r.location})` : ""}
          </div>))}
      </>}
    </div>
  );
}

/* ═══════ PORT GROUP ═══════ */
function PortGroup({ ports, dev, allConns, sp, onPort, onCtx, cm, type, rackLookup, flashPorts, onDblClick, ptColors }) {
  const pt = PT[type] || PT.rj45;
  const ptCol = (ptColors && ptColors[type]) || pt.color;
  const gc = pid => {
    const c = allConns.find(x => (x.fd === dev.id && x.fp === pid) || (x.td === dev.id && x.tp === pid));
    if (!c) return {};
    const f = c.fd === dev.id; const isCross = !!c.rackFrom;
    let label = `${f ? c.tn : c.fn} ${(PT[f?c.tpt2:c.fpt2]||PT.rj45).label}#${f ? c.tpn : c.fpn}`;
    if (isCross) { const rn = rackLookup?.[f ? c.rackTo : c.rackFrom]; if (rn) label = `[${rn}] ${label}`; }
    return { color: cm[c.id], label, isCross };
  };
  const useTwoRows = ports.length >= 8 && (type === "rj45" || type === "rj45_poe" || type === "sfp" || type === "sfp28");
  const renderPort = p => { const { color, label, isCross } = gc(p.id); return <Port key={p.id} port={p} did={dev.id} isSel={sp?.did === dev.id && sp?.pid === p.id} cc={color} cl={label} isCross={isCross} onClick={onPort} onCtx={onCtx} flash={typeof flashPorts?.has === "function" && flashPorts.has(p.id)} onDblClick={onDblClick} prefix={dev.portPrefix} />; };
  if (useTwoRows) {
    const top = ports.filter((_, i) => i % 2 === 0), bot = ports.filter((_, i) => i % 2 === 1);
    return (<div style={{ display: "flex", alignItems: "flex-start", gap: 4 }}>
      <span style={{ fontSize: 7, color: ptCol, fontWeight: 700, width: 40, flexShrink: 0, fontFamily: "monospace", paddingTop: 4 }}>{pt.label}</span>
      <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>{top.map(renderPort)}</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>{bot.map(renderPort)}</div>
      </div>
    </div>);
  }
  return (<div style={{ display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
    <span style={{ fontSize: 7, color: ptCol, fontWeight: 700, width: 40, flexShrink: 0, fontFamily: "monospace" }}>{pt.label}</span>
    <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>{ports.map(renderPort)}</div>
  </div>);
}

/* ═══════ DEVICE ROW ═══════ */
function DevRow({ dev, allConns, sp, onPort, onCtx, onDel, onEdit, onMove, onDevCtx, cm, isFirst, isLast, dim, rackLookup, flashPorts, onDblClick, isSelected, onSelect, collapsed, onToggleCollapse, ptColors, onDragStart, onDragOver, onDrop, isDragSource, isDragOver, onDragEnter, onDragLeaveRow, onTouchDragStart }) {
  const devTouchRef = useRef(null);
  const onDevTouchStart = (e) => { devTouchRef.current = setTimeout(() => { const t = e.touches[0]; onDevCtx({ preventDefault:()=>{}, clientX: t.clientX, clientY: t.clientY }, dev); devTouchRef.current = null; }, 500); };
  const onDevTouchEnd = () => { if (devTouchRef.current) { clearTimeout(devTouchRef.current); devTouchRef.current = null; } };
  const h = Math.max(dev.u * 38, 48);
  const gr = {}; dev.ports.forEach(p => { (gr[p.type] = gr[p.type] || []).push(p); });
  const poeCount = dev.ports.filter(p => p.poe).length;
  const stCounts = {}; dev.ports.forEach(p => { const s = p.status || "free"; stCounts[s] = (stCounts[s] || 0) + 1; });
  const hasSpecial = poeCount > 0 || stCounts.reserved || stCounts.disabled || stCounts.faulty;
  const crossCount = allConns.filter(c => c.rackFrom && (c.fd === dev.id || c.td === dev.id)).length;
  const labelCount = dev.ports.filter(p => p.label).length;
  const dragBorder = isDragOver ? `2px solid #10b981` : `1px solid ${isSelected ? dev.color+"66" : dev.color+"28"}`;
  return (
    <div data-devid={dev.id} onContextMenu={e => { e.preventDefault(); onDevCtx(e, dev); }}
      onClick={e => { if (e.ctrlKey || e.metaKey) { e.preventDefault(); onSelect(dev.id, true); } }}
      onTouchStart={onDevTouchStart} onTouchEnd={onDevTouchEnd} onTouchMove={onDevTouchEnd}
      onDragOver={e => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; if (onDragEnter) onDragEnter(dev.id); }}
      onDragLeave={e => { if (!e.currentTarget.contains(e.relatedTarget)) { if (onDragLeaveRow) onDragLeaveRow(); } }}
      onDrop={e => { e.preventDefault(); const fromId = e.dataTransfer.getData("text/plain"); onDrop && onDrop(fromId, dev.id); }}
      style={{ minHeight: h, background: isDragOver ? "#10b98112" : isDragSource ? "#10b98108" : isSelected ? `${dev.color}25` : `linear-gradient(135deg, ${dev.color}0d, ${dev.color}05)`, border: dragBorder, borderRadius: 7, padding: "5px 10px 5px 0", display: "flex", flexDirection: "column", gap: 2, position: "relative", opacity: isDragSource ? 0.4 : dim ? 0.25 : 1, transition: isDragSource ? "opacity 0.2s" : "all 0.15s", boxShadow: isDragOver ? "0 0 12px #10b98133" : "none" }}>
      {isDragOver && <div style={{ position: "absolute", top: -2, left: 0, right: 0, height: 3, background: "#10b981", borderRadius: 2, zIndex: 2 }} />}
      <div style={{ position: "absolute", top: 0, left: 0, width: 4, height: "100%", background: dev.color, borderRadius: "7px 0 0 7px" }} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingLeft: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
          {/* Drag handle */}
          <div draggable onDragStart={e => { e.dataTransfer.setData("text/plain", dev.id); e.dataTransfer.effectAllowed = "move"; if (onDragStart) onDragStart(dev.id); }}
            onDragEnd={() => { if (onDragLeaveRow) onDragLeaveRow(); }}
            onTouchStart={e => onTouchDragStart && onTouchDragStart(dev.id, e)}
            style={{ cursor: "grab", padding: "4px 3px 4px 8px", display: "flex", alignItems: "center", justifyContent: "center", color: "#333", fontSize: 10, lineHeight: 1, userSelect: "none", touchAction: "none", flexShrink: 0 }}
            role="button" aria-label="Drag to reorder" title="Drag to reorder">⋮⋮</div>
          <span onClick={e => { e.stopPropagation(); onSelect(dev.id, e.ctrlKey || e.metaKey); }} style={{ fontSize: 9, cursor: "pointer", width: 14, height: 14, borderRadius: 3, border: `1px solid ${isSelected ? "#10b981" : "#1a1a2e"}`, background: isSelected ? "#10b981" : "transparent", display: "flex", alignItems: "center", justifyContent: "center", color: "#000", fontWeight: 900, flexShrink: 0 }}>{isSelected ? "✓" : ""}</span>
          <span style={{ fontSize: 11 }}>{dev.icon}</span>
          <span style={{ fontSize: 11, fontWeight: 800, color: dev.color, fontFamily: "monospace" }}>{dev.name}</span>
          <span style={{ fontSize: 8, color: "#333", fontFamily: "monospace" }}>{dev.preset} · {dev.ports.length}P · {dev.u}U</span>
          {dev.poeBudget > 0 && (() => { const used = dev.ports.reduce((s, p) => s + (p.watts||0), 0); const pct = Math.round(used/dev.poeBudget*100); return (
            <span style={{ fontSize: 7, color: pct > 90 ? "#ef4444" : pct > 70 ? "#f59e0b" : "#10b981", fontFamily: "monospace" }}>⚡{used}W/{dev.poeBudget}W ({pct}%)</span>
          ); })()}
          {hasSpecial && <span style={{ fontSize: 7, color: "#555", fontFamily: "monospace" }}>
            {poeCount > 0 && <span style={{ color: "#f59e0b" }}>⚡{poeCount} </span>}
            {stCounts.reserved > 0 && <span style={{ color: "#f59e0b" }}>R:{stCounts.reserved} </span>}
            {stCounts.disabled > 0 && <span style={{ color: "#ef4444" }}>D:{stCounts.disabled} </span>}
            {stCounts.faulty > 0 && <span style={{ color: "#dc2626" }}>F:{stCounts.faulty}</span>}
          </span>}
          {crossCount > 0 && <span style={{ fontSize: 7, color: "#a855f7" }}>🔗{crossCount}</span>}
          {labelCount > 0 && <span style={{ fontSize: 7, color: "#10b981" }}>🏷{labelCount}</span>}
          {dev.notes && Object.values(dev.notes).some(v => v) && <span style={{ fontSize: 7, color: "#a78bfa" }} title={[dev.notes.sn && `S/N: ${dev.notes.sn}`, dev.notes.ip && `IP: ${dev.notes.ip}`, dev.notes.model, dev.notes.firmware && `FW: ${dev.notes.firmware}`, dev.notes.text].filter(Boolean).join(" | ")}>📋</span>}
        </div>
        <div style={{ display: "flex", gap: 1, alignItems: "center" }}>
          {dev.ports.length > 0 && <button onClick={e => { e.stopPropagation(); onToggleCollapse(); }} role="button" aria-label={collapsed ? "Expand ports" : "Collapse ports"} aria-expanded={!collapsed} title={collapsed ? "Expand" : "Collapse"} style={{ background: "none", border: "none", color: "#333", cursor: "pointer", fontSize: 8, padding: "2px 3px", lineHeight: 1 }}>{collapsed ? "▶" : "▾"}</button>}
          {!isFirst && <button onClick={e => { e.stopPropagation(); onMove(dev.id, -1); }} role="button" aria-label="Move up" title="Move up" style={{ background: "none", border: "none", color: "#333", cursor: "pointer", fontSize: 10, padding: "2px 3px", lineHeight: 1 }}>▲</button>}
          {!isLast && <button onClick={e => { e.stopPropagation(); onMove(dev.id, 1); }} role="button" aria-label="Move down" title="Move down" style={{ background: "none", border: "none", color: "#333", cursor: "pointer", fontSize: 10, padding: "2px 3px", lineHeight: 1 }}>▼</button>}
          <button onClick={e => { e.stopPropagation(); onEdit(dev); }} role="button" aria-label="Edit device" title="Edit" style={{ background: "none", border: "none", color: "#555", cursor: "pointer", fontSize: 11, padding: "2px 4px" }}>✎</button>
          <button onClick={e => { e.stopPropagation(); onDel(dev.id); }} role="button" aria-label="Delete device" title="Delete" style={{ background: "none", border: "none", color: "#282828", cursor: "pointer", fontSize: 14, padding: "0 4px" }}>×</button>
        </div>
      </div>
      {!collapsed && dev.ports.length > 0 && <div style={{ paddingLeft: 8, display: "flex", flexDirection: "column", gap: 2 }}>
        {Object.entries(gr).map(([t, ports]) => <PortGroup key={t} ports={ports} dev={dev} allConns={allConns} sp={sp} onPort={onPort} onCtx={onCtx} cm={cm} type={t} rackLookup={rackLookup} flashPorts={flashPorts} onDblClick={onDblClick} ptColors={ptColors} />)}
      </div>}
    </div>
  );
}

/* ═══════ DEV CONTEXT MENU ═══════ */
function DevCtxMenu({ pos, dev, otherRacks, onMoveToRack, onBatchStatus, onBatchColor, onSaveTemplate, onClose, t }) {
  const ref = useRef(null);
  const [showBatch, setShowBatch] = useState(false);
  const [batchRange, setBatchRange] = useState({ from: 1, to: dev.ports.length, status: "reserved" });
  const [showBatchColor, setShowBatchColor] = useState(false);
  const [batchColorRange, setBatchColorRange] = useState({ from: 1, to: dev.ports.length });
  useEffect(() => { const h = e => { if (ref.current && !ref.current.contains(e.target)) onClose(); }; document.addEventListener("mousedown", h); return () => document.removeEventListener("mousedown", h); }, [onClose]);
  return (
    <div ref={ref} style={{ position: "fixed", left: pos.x, top: pos.y, zIndex: 1200, background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, borderRadius: 8, padding: 6, minWidth: 200, boxShadow: "0 8px 24px #000a", maxHeight: "70vh", overflowY: "auto" }}>
      <div style={{ fontSize: 8, color: "#555", padding: "2px 8px", letterSpacing: 0.5 }}>{dev.icon} {dev.name} · {dev.ports.length}P</div>
      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      <div onClick={() => { onSaveTemplate(dev); onClose(); }} style={{ padding: "4px 8px", fontSize: 10, cursor: "pointer", borderRadius: 4, color: "#10b981", display: "flex", alignItems: "center", gap: 6 }}
        onMouseEnter={e => e.currentTarget.style.background = "#10b98108"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
        {`📌 ${t("saveAsTemplate")}`}
      </div>
      <div onClick={() => setShowBatch(!showBatch)} style={{ padding: "4px 8px", fontSize: 10, cursor: "pointer", borderRadius: 4, color: "#f59e0b", display: "flex", alignItems: "center", gap: 6 }}
        onMouseEnter={e => e.currentTarget.style.background = "#f59e0b08"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
        {`⚡ ${t("batchPortStatus")} ${showBatch ? "▼" : "▶"}`}
      </div>
      {showBatch && <div style={{ padding: "4px 8px", display: "flex", flexDirection: "column", gap: 4 }}>
        <div style={{ display: "flex", gap: 4, alignItems: "center", fontSize: 9 }}>
          <span style={{ color: "#555" }}>{t("ports")}</span>
          <input type="number" min={1} max={dev.ports.length} value={batchRange.from} onChange={e => setBatchRange(p => ({ ...p, from: Math.max(1, +e.target.value) }))} style={{ width: 36, background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "2px 4px", borderRadius: 3, fontSize: 9, fontFamily: "inherit", textAlign: "center" }} />
          <span style={{ color: "#333" }}>—</span>
          <input type="number" min={1} max={dev.ports.length} value={batchRange.to} onChange={e => setBatchRange(p => ({ ...p, to: Math.min(dev.ports.length, +e.target.value) }))} style={{ width: 36, background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "2px 4px", borderRadius: 3, fontSize: 9, fontFamily: "inherit", textAlign: "center" }} />
        </div>
        <div style={{ display: "flex", gap: 3, flexWrap: "wrap" }}>
          {["free","reserved","disabled","faulty"].map(s => {
            const def = PS[s];
            return <button key={s} onClick={() => { onBatchStatus(dev.id, batchRange.from, batchRange.to, s); onClose(); }}
              style={{ padding: "3px 6px", background: s === "free" ? "#10b98112" : `${def.color}18`, border: `1px solid ${def.color || "#10b981"}33`, color: def.color || "#10b981", borderRadius: 3, cursor: "pointer", fontSize: 8, fontFamily: "inherit" }}>
              {def.label} ({batchRange.to - batchRange.from + 1})
            </button>;
          })}
        </div>
        <div style={{ display: "flex", gap: 3 }}>
          <button onClick={() => { setBatchRange({ from: 1, to: dev.ports.length, status: "free" }); }}
            style={{ padding: "2px 5px", background: "none", border: `1px solid ${"#1a1a2e"}`, color: "#333", borderRadius: 3, cursor: "pointer", fontSize: 7, fontFamily: "inherit" }}>{t("allPorts")}</button>
        </div>
      </div>}

      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      <div onClick={() => setShowBatchColor(!showBatchColor)} style={{ padding: "4px 8px", fontSize: 10, cursor: "pointer", borderRadius: 4, color: "#06b6d4", display: "flex", alignItems: "center", gap: 6 }}
        onMouseEnter={e => e.currentTarget.style.background = "#06b6d408"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
        {`🎨 ${t("batchPortColor")} ${showBatchColor ? "▼" : "▶"}`}
      </div>
      {showBatchColor && <div style={{ padding: "4px 8px", display: "flex", flexDirection: "column", gap: 4 }}>
        <div style={{ display: "flex", gap: 4, alignItems: "center", fontSize: 9 }}>
          <span style={{ color: "#555" }}>{t("ports")}</span>
          <input type="number" min={1} max={dev.ports.length} value={batchColorRange.from} onChange={e => setBatchColorRange(p => ({ ...p, from: Math.max(1, +e.target.value) }))} style={{ width: 36, background: "#08080d", border: "1px solid #1a1a2e", color: "#e0e0e0", padding: "2px 4px", borderRadius: 3, fontSize: 9, fontFamily: "inherit", textAlign: "center" }} />
          <span style={{ color: "#333" }}>—</span>
          <input type="number" min={1} max={dev.ports.length} value={batchColorRange.to} onChange={e => setBatchColorRange(p => ({ ...p, to: Math.min(dev.ports.length, +e.target.value) }))} style={{ width: 36, background: "#08080d", border: "1px solid #1a1a2e", color: "#e0e0e0", padding: "2px 4px", borderRadius: 3, fontSize: 9, fontFamily: "inherit", textAlign: "center" }} />
          <button onClick={() => setBatchColorRange({ from: 1, to: dev.ports.length })}
            style={{ padding: "2px 5px", background: "none", border: "1px solid #1a1a2e", color: "#555", borderRadius: 3, cursor: "pointer", fontSize: 7, fontFamily: "inherit" }}>{t("allPorts")}</button>
        </div>
        <div style={{ display: "flex", gap: 3, flexWrap: "wrap", alignItems: "center" }}>
          {["#3b82f6","#10b981","#f59e0b","#ef4444","#a855f7","#06b6d4","#ec4899","#f97316","#84cc16","#6366f1","#14b8a6","#e11d48"].map(c => (
            <div key={c} onClick={() => { onBatchColor(dev.id, batchColorRange.from, batchColorRange.to, c); onClose(); }}
              style={{ width: 16, height: 16, borderRadius: 3, background: c, cursor: "pointer", border: "1px solid #333", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 6, color: "#fff", fontWeight: 900 }}>
              {batchColorRange.to - batchColorRange.from + 1}
            </div>
          ))}
          <div onClick={() => { onBatchColor(dev.id, batchColorRange.from, batchColorRange.to, null); onClose(); }}
            style={{ padding: "3px 6px", fontSize: 8, color: "#ef4444", cursor: "pointer", border: "1px solid #ef444433", borderRadius: 3, background: "#ef444408" }}>{`✕ ${t("clearColor")} (${batchColorRange.to - batchColorRange.from + 1})`}</div>
        </div>
      </div>}
      <div style={{ height: 1, background: "#1a1a2e", margin: "4px 0" }} />
      {otherRacks.length > 0 ? <>
        <div style={{ fontSize: 8, color: "#333", padding: "2px 8px", letterSpacing: 0.5 }}>{`📦 ${t("moveToRackHeader")}`}</div>
        {otherRacks.map(r => { const rFreeU = r.size - r.devs.reduce((s,d) => s+d.u, 0); const canFit = rFreeU >= dev.u;
          return (<div key={r.id} onClick={() => { if (canFit) { onMoveToRack(dev.id, r.id); onClose(); } }}
            style={{ padding: "4px 8px", fontSize: 10, cursor: canFit ? "pointer" : "not-allowed", borderRadius: 4, color: canFit ? "#a855f7" : "#333", display: "flex", alignItems: "center", gap: 6, opacity: canFit ? 1 : 0.5 }}
            onMouseEnter={e => { if (canFit) e.currentTarget.style.background = "#a855f708"; }} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
            ⬒ {r.name}{r.location ? ` (${r.location})` : ""}<span style={{ marginLeft: "auto", fontSize: 7, color: "#333" }}>{`${rFreeU} ${t("uFree")}`}</span>
          </div>);
        })}
      </> : <div style={{ padding: "4px 8px", fontSize: 10, color: "#333" }}>{t("noOtherRacks")}</div>}
    </div>
  );
}

/* ═══════ BULK CONNECT MODAL ═══════ */
function BulkConnectModal({ devs, conns, allConns, onBulk, onClose, t }) {
  const [srcDev, setSrcDev] = useState("");
  const [tgtDev, setTgtDev] = useState("");
  const [srcType, setSrcType] = useState("");
  const [tgtType, setTgtType] = useState("");
  const [srcFrom, setSrcFrom] = useState(1);
  const [tgtFrom, setTgtFrom] = useState(1);
  const [count, setCount] = useState(0);
  const sd = devs.find(d => d.id === srcDev), td = devs.find(d => d.id === tgtDev);
  const srcTypes = sd ? [...new Set(sd.ports.map(p => p.type))] : [];
  const tgtTypes = td ? [...new Set(td.ports.map(p => p.type))] : [];
  const srcPorts = sd ? sd.ports.filter(p => p.type === srcType) : [];
  const tgtPorts = td ? td.ports.filter(p => p.type === tgtType) : [];
  const connSet = new Set([...allConns.map(c=>c.fp), ...allConns.map(c=>c.tp)]);
  const freeSrc = srcPorts.filter(p => !connSet.has(p.id) && (!p.status || p.status === "free" || p.status === "reserved"));
  const freeTgt = tgtPorts.filter(p => !connSet.has(p.id) && (!p.status || p.status === "free" || p.status === "reserved"));
  const maxCount = Math.min(freeSrc.length - (srcFrom-1), freeTgt.length - (tgtFrom-1));
  useEffect(() => { if (srcType && srcTypes.length && !srcTypes.includes(srcType)) setSrcType(srcTypes[0]||""); }, [srcDev]);
  useEffect(() => { if (tgtType && tgtTypes.length && !tgtTypes.includes(tgtType)) setTgtType(tgtTypes[0]||""); }, [tgtDev]);
  useEffect(() => { setCount(Math.max(0, Math.min(count, maxCount))); }, [srcFrom, tgtFrom, srcType, tgtType, srcDev, tgtDev]);
  useEffect(() => { if (maxCount > 0 && count === 0) setCount(maxCount); }, [maxCount]);
  const preview = [];
  for (let i = 0; i < count; i++) { const sp = freeSrc[srcFrom-1+i], tp = freeTgt[tgtFrom-1+i]; if (sp && tp) preview.push({ sp, tp }); }
  const ss = { background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "5px 8px", borderRadius: 4, fontSize: 10, fontFamily: "inherit", outline: "none", width: "100%", boxSizing: "border-box" };
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, borderRadius: 12, padding: 20, width: 420, maxHeight: "85vh", overflowY: "auto" }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#10b981", marginBottom: 14 }}>⚡ BULK CONNECT (1:1)</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
          <div>
            <label style={{ fontSize: 8, color: "#555" }}>{t("srcDevice")}</label>
            <select value={srcDev} onChange={e => { setSrcDev(e.target.value); setSrcType(""); setSrcFrom(1); }} style={ss}>
              <option value="">{t("select")}</option>
              {devs.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
            {srcTypes.length > 0 && <><label style={{ fontSize: 8, color: "#555", marginTop: 4, display: "block" }}>{t("portType")}</label>
              <select value={srcType} onChange={e => { setSrcType(e.target.value); setSrcFrom(1); }} style={ss}>
                <option value="">{t("select")}</option>
                {srcTypes.map(t => <option key={t} value={t}>{(PT[t]||PT.rj45).label} ({sd.ports.filter(p=>p.type===t).length})</option>)}
              </select></>}
            {freeSrc.length > 0 && <><label style={{ fontSize: 8, color: "#555", marginTop: 4, display: "block" }}>START AT #{freeSrc.length} free</label>
              <input type="number" min={1} max={freeSrc.length} value={srcFrom} onChange={e => setSrcFrom(Math.max(1, +e.target.value))} style={ss} /></>}
          </div>
          <div>
            <label style={{ fontSize: 8, color: "#555" }}>{t("tgtDevice")}</label>
            <select value={tgtDev} onChange={e => { setTgtDev(e.target.value); setTgtType(""); setTgtFrom(1); }} style={ss}>
              <option value="">{t("select")}</option>
              {devs.filter(d => d.id !== srcDev).map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
            {tgtTypes.length > 0 && <><label style={{ fontSize: 8, color: "#555", marginTop: 4, display: "block" }}>{t("portType")}</label>
              <select value={tgtType} onChange={e => { setTgtType(e.target.value); setTgtFrom(1); }} style={ss}>
                <option value="">{t("select")}</option>
                {tgtTypes.map(t => <option key={t} value={t}>{(PT[t]||PT.rj45).label} ({td.ports.filter(p=>p.type===t).length})</option>)}
              </select></>}
            {freeTgt.length > 0 && <><label style={{ fontSize: 8, color: "#555", marginTop: 4, display: "block" }}>START AT #{freeTgt.length} free</label>
              <input type="number" min={1} max={freeTgt.length} value={tgtFrom} onChange={e => setTgtFrom(Math.max(1, +e.target.value))} style={ss} /></>}
          </div>
        </div>
        {maxCount > 0 && <div style={{ marginBottom: 12 }}>
          <label style={{ fontSize: 8, color: "#555" }}>COUNT ({maxCount} max)</label>
          <input type="number" min={1} max={maxCount} value={count} onChange={e => setCount(Math.max(1, Math.min(maxCount, +e.target.value)))} style={ss} />
        </div>}
        {preview.length > 0 && <div style={{ maxHeight: 160, overflowY: "auto", marginBottom: 12, background: "#08080d", borderRadius: 6, padding: 6 }}>
          <div style={{ fontSize: 8, color: "#333", marginBottom: 4 }}>PREVIEW ({preview.length} connections)</div>
          {preview.map((p, i) => (
            <div key={i} style={{ fontSize: 9, color: "#666", padding: "2px 4px", display: "flex", gap: 4 }}>
              <span style={{ color: "#10b981" }}>#{p.sp.gn}{p.sp.label ? ` (${p.sp.label})` : ""}</span>
              <span style={{ color: "#333" }}>→</span>
              <span style={{ color: "#3b82f6" }}>#{p.tp.gn}{p.tp.label ? ` (${p.tp.label})` : ""}</span>
            </div>))}
        </div>}
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => { if (preview.length > 0) onBulk(sd, td, preview); }} disabled={preview.length === 0}
            style={{ flex: 1, padding: "8px", background: preview.length > 0 ? "#10b98115" : "#111", border: `1px solid ${preview.length > 0 ? "#10b981" : "#222"}`, color: preview.length > 0 ? "#10b981" : "#333", borderRadius: 6, cursor: preview.length > 0 ? "pointer" : "default", fontSize: 11, fontWeight: 700, fontFamily: "inherit" }}>⚡ Connect {preview.length}</button>
          <button onClick={onClose} style={{ flex: 1, padding: "8px", background: "#ffffff06", border: "1px solid #222", color: "#555", borderRadius: 6, cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>{t("cancel")}</button>
        </div>
      </div>
    </div>
  );
}

/* ═══════ EDIT MODALS ═══════ */
function EditModal({ dev, onSave, onClose, t }) {
  const [name, setName] = useState(dev.name);
  const [icon, setIcon] = useState(dev.icon);
  const [poeBudget, setPoeBudget] = useState(dev.poeBudget || 0);
  const [u, setU] = useState(dev.u);
  const [showIcons, setShowIcons] = useState(false);
  const [notes, setNotes] = useState(dev.notes || { sn: "", ip: "", model: "", firmware: "", text: "" });
  const [showNotes, setShowNotes] = useState(!!(dev.notes && Object.values(dev.notes).some(v => v)));
  const [showPorts, setShowPorts] = useState(false);
  const [portPrefix, setPortPrefix] = useState(dev.portPrefix || "");
  // Build port groups from existing ports
  const buildGroups = () => { const gm = {}; dev.ports.forEach(p => { const t = p.type === "rj45_poe" ? "rj45_poe" : p.type; (gm[t] = gm[t] || []).push(p); }); return Object.entries(gm).map(([t, ps]) => ({ t, n: ps.length, ids: ps.map(p => p.id) })); };
  const [portGroups, setPortGroups] = useState(buildGroups);
  const totalNewPorts = portGroups.reduce((s, g) => s + g.n, 0);
  const ns = { width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "5px 8px", borderRadius: 4, fontSize: 10, fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 6 };
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, borderRadius: 12, padding: 20, width: 360, maxHeight: "85vh", overflowY: "auto" }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#10b981", marginBottom: 14 }}>✎ EDIT DEVICE</div>
        <label style={{ fontSize: 8, color: "#555" }}>{t("name")}</label>
        <input value={name} onChange={e => setName(e.target.value)} autoFocus style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "7px 9px", borderRadius: 5, fontSize: 11, fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 10 }} />
        <label style={{ fontSize: 8, color: "#555" }}>{t("sizeU")}</label>
        <input type="number" min={1} max={12} value={u} onChange={e => setU(Math.max(1, +e.target.value))} style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "6px 9px", borderRadius: 5, fontSize: 11, fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 10 }} />
        {dev.ports.some(p => p.poe || p.type === "rj45_poe") && <div style={{ marginBottom: 10 }}>
          <label style={{ fontSize: 8, color: "#555", letterSpacing: 0.5 }}>⚡ POE BUDGET (WATTS)</label>
          <input type="number" min={0} max={9999} value={poeBudget} onChange={e => setPoeBudget(Math.max(0, +e.target.value))} placeholder="370" style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#f59e0b", padding: "6px 9px", borderRadius: 5, fontSize: 11, fontFamily: "inherit", outline: "none", boxSizing: "border-box" }} />
        </div>}
        <label style={{ fontSize: 8, color: "#555" }}>{t("icon")}</label>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
          <div onClick={() => setShowIcons(!showIcons)} style={{ width: 36, height: 36, background: "#08080d", border: `1px solid ${"#1a1a2e"}`, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, cursor: "pointer" }}>{icon}</div>
          {showIcons && <div style={{ display: "flex", flexWrap: "wrap", gap: 4, flex: 1 }}>
            {ICONS.map(ic => <div key={ic} onClick={() => { setIcon(ic); setShowIcons(false); }} style={{ width: 28, height: 28, background: ic === icon ? "#10b98122" : "#08080d", border: `1px solid ${ic === icon ? "#10b981" : "#1a1a2e"}`, borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, cursor: "pointer" }}>{ic}</div>)}
          </div>}
        </div>
        <div onClick={() => setShowNotes(!showNotes)} style={{ fontSize: 9, color: "#555", cursor: "pointer", marginBottom: 8, display: "flex", alignItems: "center", gap: 4 }}>
          <span style={{ fontSize: 8 }}>{showNotes ? "▼" : "▶"}</span> 📋 Equipment Details {Object.values(notes).some(v => v) && <span style={{ color: "#10b981", fontSize: 7 }}>●</span>}
        </div>
        {showNotes && <div style={{ padding: "8px", background: "#08080d", borderRadius: 6, border: `1px solid ${"#1a1a2e"}`, marginBottom: 10 }}>
          <label style={{ fontSize: 7, color: "#555" }}>{t("serialNumber")}</label>
          <input value={notes.sn} onChange={e => setNotes(p => ({ ...p, sn: e.target.value }))} placeholder="FOC2345X1YZ" style={ns} />
          <label style={{ fontSize: 7, color: "#555" }}>{t("ipAddress")}</label>
          <input value={notes.ip} onChange={e => setNotes(p => ({ ...p, ip: e.target.value }))} placeholder="192.168.1.1" style={ns} />
          <label style={{ fontSize: 7, color: "#555" }}>{t("model")}</label>
          <input value={notes.model} onChange={e => setNotes(p => ({ ...p, model: e.target.value }))} placeholder="Cisco C9300-48P" style={ns} />
          <label style={{ fontSize: 7, color: "#555" }}>{t("firmware")}</label>
          <input value={notes.firmware} onChange={e => setNotes(p => ({ ...p, firmware: e.target.value }))} placeholder="IOS-XE 17.9.4" style={ns} />
          <label style={{ fontSize: 7, color: "#555" }}>{t("notes")}</label>
          <textarea value={notes.text} onChange={e => setNotes(p => ({ ...p, text: e.target.value }))} placeholder={t("freeNotes")} rows={2} style={{ ...ns, resize: "vertical" }} />
        </div>}
        <div onClick={() => setShowPorts(!showPorts)} style={{ fontSize: 9, color: "#555", cursor: "pointer", marginBottom: 8, display: "flex", alignItems: "center", gap: 4 }}>
          <span style={{ fontSize: 8 }}>{showPorts ? "▼" : "▶"}</span> 🔌 Port Configuration <span style={{ fontSize: 8, color: "#10b981" }}>({totalNewPorts}P)</span>
        </div>
        {showPorts && <div style={{ padding: "8px", background: "#08080d", borderRadius: 6, border: `1px solid ${"#1a1a2e"}`, marginBottom: 10 }}>
          <div style={{ display: "flex", gap: 4, alignItems: "center", marginBottom: 6 }}>
            <label style={{ fontSize: 7, color: "#555" }}>{t("prefix")}</label>
            <input value={portPrefix} onChange={e => setPortPrefix(e.target.value)} placeholder="z.B. A, Gi0/, Eth" style={{ width: 70, background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "3px 4px", borderRadius: 3, fontSize: 9, fontFamily: "inherit" }} />
            <span style={{ fontSize: 7, color: "#333" }}>→ {portPrefix}1, {portPrefix}2...</span>
          </div>
          {portGroups.map((g, gi) => (
            <div key={gi} style={{ display: "flex", gap: 4, alignItems: "center", marginBottom: 4 }}>
              <select value={g.t} onChange={e => setPortGroups(prev => prev.map((x, i) => i === gi ? { ...x, t: e.target.value } : x))} style={{ flex: 1, background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "3px 4px", borderRadius: 3, fontSize: 9, fontFamily: "inherit" }}>
                {Object.entries(PT).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
              <input type="number" min={1} max={96} value={g.n} onChange={e => setPortGroups(prev => prev.map((x, i) => i === gi ? { ...x, n: Math.max(1, +e.target.value) } : x))} style={{ width: 42, background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "3px", borderRadius: 3, fontSize: 9, fontFamily: "inherit", textAlign: "center" }} />
              <span style={{ fontSize: 7, color: "#333" }}>ports</span>
              {portGroups.length > 1 && <button onClick={() => setPortGroups(prev => prev.filter((_, i) => i !== gi))} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: 11, padding: "0 2px" }}>×</button>}
            </div>
          ))}
          <button onClick={() => setPortGroups(prev => [...prev, { t: "rj45", n: 4 }])} style={{ padding: "3px 6px", background: "none", border: `1px dashed ${"#1a1a2e"}`, color: "#555", borderRadius: 3, cursor: "pointer", fontSize: 8, fontFamily: "inherit", width: "100%", marginTop: 2 }}>+ Port Group</button>
          {totalNewPorts !== dev.ports.length && <div style={{ fontSize: 7, color: "#f59e0b", marginTop: 4 }}>⚠️ Port count changed: {dev.ports.length} → {totalNewPorts}. Existing connections on removed ports will be deleted.</div>}
        </div>}
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => { const cleanNotes = Object.values(notes).some(v => v) ? notes : undefined; onSave({ name: name.trim() || dev.name, icon, u, notes: cleanNotes, portGroups, portPrefix: portPrefix || undefined, poeBudget: poeBudget || undefined }); }} style={{ flex: 1, padding: "8px", background: "#10b98115", border: "1px solid #10b981", color: "#10b981", borderRadius: 6, cursor: "pointer", fontSize: 11, fontWeight: 700, fontFamily: "inherit" }}>{t("saveBtn")}</button>
          <button onClick={onClose} style={{ flex: 1, padding: "8px", background: "#ffffff06", border: "1px solid #222", color: "#555", borderRadius: 6, cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>{t("cancel")}</button>
        </div>
      </div>
    </div>
  );
}

function RackEditModal({ rack, onSave, onClose, onDelete, t }) {
  const [name, setName] = useState(rack.name);
  const [loc, setLoc] = useState(rack.location || "");
  const [size, setSize] = useState(rack.size);
  const usedU = rack.devs.reduce((s, d) => s + d.u, 0);
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: "#0d0d14", border: `1px solid ${"#1a1a2e"}`, borderRadius: 12, padding: 20, width: 340 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#10b981", marginBottom: 14 }}>✎ EDIT RACK</div>
        <label style={{ fontSize: 8, color: "#555" }}>{t("rackName")}</label>
        <input value={name} onChange={e => setName(e.target.value)} autoFocus style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "7px 9px", borderRadius: 5, fontSize: 11, fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 10 }} />
        <label style={{ fontSize: 8, color: "#555" }}>{t("location")}</label>
        <input value={loc} onChange={e => setLoc(e.target.value)} placeholder={t("location")} style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "7px 9px", borderRadius: 5, fontSize: 11, fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 4 }} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: 3, marginBottom: 10 }}>
          {LOC_SUGGEST.filter(l => !loc || l.toLowerCase().includes(loc.toLowerCase())).slice(0, 8).map(l => (
            <button key={l} onClick={() => setLoc(l)} style={{ padding: "2px 7px", background: loc === l ? "#10b98118" : "#08080d", border: `1px solid ${loc === l ? "#10b981" : "#1a1a2e"}`, color: loc === l ? "#10b981" : "#555", borderRadius: 3, cursor: "pointer", fontSize: 8, fontFamily: "inherit" }}>{l}</button>
          ))}
        </div>
        <label style={{ fontSize: 8, color: "#555" }}>{t("sizeU")}</label>
        <select value={size} onChange={e => { const n = +e.target.value; if (n < usedU) return; setSize(n); }} style={{ width: "100%", background: "#08080d", border: `1px solid ${"#1a1a2e"}`, color: "#e0e0e0", padding: "6px 9px", borderRadius: 5, fontSize: 11, fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginBottom: 14 }}>
          {RSZ.map(s => <option key={s} value={s} disabled={s < usedU}>{s}U{s < usedU ? ` (need ${usedU}U)` : ""}</option>)}
        </select>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => onSave({ name: name.trim() || rack.name, location: loc.trim(), size })} style={{ flex: 1, padding: "8px", background: "#10b98115", border: "1px solid #10b981", color: "#10b981", borderRadius: 6, cursor: "pointer", fontSize: 11, fontWeight: 700, fontFamily: "inherit" }}>{t("saveBtn")}</button>
          <button onClick={onClose} style={{ flex: 1, padding: "8px", background: "#ffffff06", border: "1px solid #222", color: "#555", borderRadius: 6, cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>{t("cancel")}</button>
        </div>
        {onDelete && <button onClick={() => { if (confirm(t("confirmDeleteRack", {name: rack.name}))) onDelete(rack.id); }} style={{ width: "100%", marginTop: 10, padding: "7px", background: "#ef444408", border: "1px solid #ef444433", color: "#ef444488", borderRadius: 6, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>{`🗑 ${t("deleteRack")}`}</button>}
      </div>
    </div>
  );
}

/* ═══════ RACK VISUAL (for Reports) ═══════ */
function RackVisual({ rack, allConns, cm, lang }) {
  const S = { bg: "#f8f9fb", bdr: "#e5e7eb" };
  const usedU = rack.devs.reduce((s, d) => s + d.u, 0);
  return (
    <div style={{ background: "#1a1c2e", borderRadius: 8, padding: 8, border: `1px solid ${S.bdr}`, maxWidth: 500, margin: "0 auto 16px" }}>
      <div style={{ padding: "4px 8px", borderBottom: `1px solid ${"#2a2c3e"}`, display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
        <span style={{ fontSize: 10, fontWeight: 700, color: "#8a8ca0", letterSpacing: 1 }}>{rack.name.toUpperCase()}</span>
        <span style={{ fontSize: 8, color: "#555" }}>{usedU}/{rack.size}U</span>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {rack.devs.map(d => {
          const h = Math.max(d.u * 18, 20);
          const dc = allConns.filter(c => c.fd === d.id || c.td === d.id);
          const connPorts = new Set([...dc.map(c => c.fd === d.id ? c.fp : c.tp)]);
          const gr = {}; d.ports.forEach(p => { (gr[p.type] = gr[p.type] || []).push(p); });
          return (
            <div key={d.id} style={{ minHeight: h, background: `${d.color}18`, borderLeft: `3px solid ${d.color}`, borderRadius: 3, padding: "3px 6px", display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontSize: 8, width: 14, textAlign: "center" }}>{d.icon}</span>
              <span style={{ fontSize: 8, fontWeight: 700, color: d.color, minWidth: 80, fontFamily: "monospace" }}>{d.name}</span>
              <div style={{ display: "flex", gap: 3, flexWrap: "wrap", flex: 1 }}>
                {Object.entries(gr).map(([t, ports]) => (
                  <div key={t} style={{ display: "flex", gap: 1, alignItems: "center" }}>
                    <span style={{ fontSize: 5, color: (PT[t]||PT.rj45).color, marginRight: 1 }}>{(PT[t]||PT.rj45).label.substring(0,3)}</span>
                    {ports.map(p => {
                      const isConn = connPorts.has(p.id);
                      const c = isConn ? dc.find(c => c.fp === p.id || c.tp === p.id) : null;
                      const col = c ? cm[c.id] || "#555" : "transparent";
                      return <div key={p.id} style={{ width: 4, height: 4, borderRadius: 1, background: isConn ? col : "#2a2c3e", border: `0.5px solid ${isConn ? col : "#333"}` }} title={`#${p.gn}${p.label ? ` ${p.label}` : ""}${isConn ? " ●" : ""}`} />;
                    })}
                  </div>
                ))}
              </div>
              <span style={{ fontSize: 7, color: "#555" }}>{d.u}U</span>
            </div>
          );
        })}
        {rack.size - usedU > 0 && <div style={{ height: Math.min((rack.size - usedU) * 8, 32), borderRadius: 3, border: `1px dashed ${"#2a2c3e"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 7, color: "#333" }}>{`${rack.size - usedU}U ${lang==="de"?"frei":lang==="es"?"libre":"free"}`}</div>}
      </div>
    </div>
  );
}

function RackVisualPNG({ rack, allConns, cm, lang, scale = 2, start = true, onReady }) {
  const [src, setSrc] = useState(null);
  const [err, setErr] = useState(null);
  const wrapRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    if (!start) return;
    const run = async () => {
      setErr(null);
      setSrc(null);
      let h2c = window.html2canvas;
      if (!h2c) {
        try { h2c = (await import("html2canvas")).default; } catch {}
      }
      if (!wrapRef.current) { setErr("No export node"); onReady && onReady(false); return; }
      if (!h2c) { setErr("html2canvas missing"); onReady && onReady(false); return; }

      // Espera 1-2 frames para asegurar layout
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

      try {
        const canvas = await h2c(wrapRef.current, {
          scale,
          backgroundColor: "#ffffff",
          useCORS: true,
          allowTaint: true,
          logging: false
        });
        if (!cancelled) setSrc(canvas.toDataURL("image/png"));
        onReady && onReady(true);
      } catch (e) {
        console.error(e);
        setErr(String(e && e.message ? e.message : e));
        onReady && onReady(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, [start, rack.id, rack.size, (rack.devs||[]).length, allConns.length, scale, lang]);

  return (
    <div style={{ maxWidth: 500, margin: "0 auto 16px" }}>
      {!src && <div ref={wrapRef}><RackVisual rack={rack} allConns={allConns} cm={cm} lang={lang} /></div>}
      {src && <img src={src} alt="Rack preview" style={{ width: "100%", display: "block", borderRadius: 8, border: "1px solid #e5e7eb" }} />}
    </div>
  );
}

/* ═══════ RACK DETAIL SNAPSHOT (for Project Report PNG) ═══════ */
function RackDetailSnapshot({ rack, allConns, cm, lang, T, ptColors, rackFace = "front" }) {
  const devs = rack.devs || [];
  const usedU = devs.reduce((s, d) => s + d.u, 0);
  const freeU = Math.max(0, (rack.size || 0) - usedU);
  const displayDevs = rackFace === "rear" ? [...devs].reverse() : devs;

  const rearLabel = lang === "de" ? "Rückansicht" : lang === "es" ? "Vista trasera" : "Rear view";
  const noDevices = lang === "de" ? "Keine Geräte" : lang === "es" ? "Sin dispositivos" : "No devices";
  const uFree = lang === "de" ? "U frei" : lang === "es" ? "U libre" : "U free";
  const no = () => {};

  return (
    <div className="rc-export" style={{ background: (T.bg2 || "#fff"), border: `1px solid ${(T.bdr || "#e5e7eb")}`, borderRadius: 10, padding: 12, color: (T.txt || "#111") }}>
      <style>{`
        .rc-export button{display:none!important}
        .rc-export [draggable="true"]{display:none!important}
        .rc-export input[type="checkbox"]{display:none!important}
      `}</style>

      {rackFace === "rear" && (
        <div style={{ textAlign: "center", padding: "4px 0", fontSize: 8, color: "#a855f7", background: "#a855f708", borderRadius: 4, letterSpacing: 1, fontWeight: 700 }}>
          {`▥ ${rearLabel}`}
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {(() => {
          let uPos = 1;
          return displayDevs.map((d, i) => {
            const startU = uPos; uPos += d.u;
            return (
              <div key={d.id} style={{ display: "flex", gap: 0 }}>
                <div style={{ width: 28, minWidth: 28, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", gap: 0, flexShrink: 0 }}>
                  {Array.from({ length: d.u }, (_, ui) => (
                    <div key={ui} style={{ fontSize: 7, color: (T.vdim || T.dim || "#6b7280"), height: Math.max(38, 48 / d.u), display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "monospace", lineHeight: 1 }}>
                      {startU + ui}
                    </div>
                  ))}
                </div>
                <div style={{ flex: 1 }}>
                  <DevRow
                    dev={d}
                    allConns={allConns}
                    sp={null}
                    onPort={no}
                    onCtx={no}
                    onDel={no}
                    onEdit={no}
                    onMove={no}
                    onDevCtx={no}
                    cm={cm}
                    isFirst={i === 0}
                    isLast={i === displayDevs.length - 1}
                    dim={false}
                    rackLookup={{}}
                    flashPorts={null}
                    onDblClick={no}
                    isSelected={false}
                    onSelect={no}
                    collapsed={false}
                    onToggleCollapse={no}
                    ptColors={ptColors}
                    onDrop={no}
                    onDragStart={no}
                    onDragEnter={no}
                    onDragLeaveRow={no}
                    isDragSource={false}
                    isDragOver={false}
                  />
                </div>
              </div>
            );
          });
        })()}

        {devs.length === 0 && (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 120, color: (T.vdim || T.dim || "#6b7280"), fontSize: 12 }}>
            {noDevices}
          </div>
        )}

        {freeU > 0 && devs.length > 0 && (
          <div style={{ display: "flex", gap: 0 }}>
            <div style={{ width: 28, minWidth: 28, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 7, color: (T.bdr || "#9ca3af"), fontFamily: "monospace" }}>
              {usedU + 1}
            </div>
            <div style={{ flex: 1, height: Math.min(freeU * 12, 48), border: `1px dashed ${(T.bdr || "#e5e7eb")}`, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: (T.bdr || "#9ca3af"), marginTop: 4 }}>
              {`${freeU} ${uFree}`}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function RackDetailPNG({ rack, allConns, cm, lang, T, ptColors, rackFace = "front", scale = 2.5, start = true, onReady }) {
  const [src, setSrc] = useState(null);
  const [err, setErr] = useState(null);
  const wrapRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    if (!start) return;
    const run = async () => {
      setErr(null);
      setSrc(null);
      let h2c = window.html2canvas;
      if (!h2c) {
        try { h2c = (await import("html2canvas")).default; } catch {}
      }
      if (!wrapRef.current) { setErr("No export node"); onReady && onReady(false); return; }
      if (!h2c) { setErr("html2canvas missing"); onReady && onReady(false); return; }

      // Espera 1-2 frames para asegurar layout
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

      try {
        const canvas = await h2c(wrapRef.current, {
          scale,
          backgroundColor: "#ffffff",
          useCORS: true,
          allowTaint: true,
          logging: false
        });
        if (!cancelled) setSrc(canvas.toDataURL("image/png"));
        onReady && onReady(true);
      } catch (e) {
        console.error(e);
        setErr(String(e && e.message ? e.message : e));
        onReady && onReady(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, [start, rack.id, rack.size, (rack.devs||[]).length, allConns.length, lang, rackFace, scale]);

  return (
    <div style={{ maxWidth: 780, margin: "0 auto 16px" }}>
      {!src && (
        <div style={{ fontSize: 10, color: err ? "#ef4444" : "#9ca3af", textAlign: "center", padding: "10px 0" }}>
          {err ? (lang==="de"?"PNG Fehler: ":lang==="es"?"Error PNG: ":"PNG error: ") + err : (start ? (lang==="de"?"PNG wird erzeugt…":lang==="es"?"Generando PNG…":"Generating PNG…") : (lang==="de"?"Wartet…":lang==="es"?"En cola…":"Queued…"))}
        </div>
      )}

      <div ref={wrapRef} style={{ width: 760, margin: "0 auto", display: src ? "none" : "block" }}>
        <RackDetailSnapshot rack={rack} allConns={allConns} cm={cm} lang={lang} T={T} ptColors={ptColors} rackFace={rackFace} />
      </div>

      {src && <img src={src} alt="Rack detailed preview" style={{ width: "100%", display: "block", borderRadius: 10, border: "1px solid #e5e7eb" }} />}
    </div>
  );
}


// ─────────────────────────────────────────────────────────────────────────────
// FAST PNG PREVIEW (canvas, no SVG, no html2canvas) — used in Project Report
// ─────────────────────────────────────────────────────────────────────────────
function _hexToRgba(hex, a) {
  try {
    if (!hex || typeof hex !== "string") return `rgba(148,163,184,${a})`;
    let h = hex.trim();
    if (h[0] === "#") h = h.slice(1);
    if (h.length === 3) h = h.split("").map(ch => ch + ch).join("");
    if (h.length !== 6) return `rgba(148,163,184,${a})`;
    const r = parseInt(h.slice(0, 2), 16);
    const g = parseInt(h.slice(2, 4), 16);
    const b = parseInt(h.slice(4, 6), 16);
    return `rgba(${r},${g},${b},${a})`;
  } catch {
    return `rgba(148,163,184,${a})`;
  }
}
function _roundRect(ctx, x, y, w, h, r, fill = true, stroke = false) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

function rackPreviewToPNGDataURL(rack, allConns, cm, rackFace = "front", opts = {}) {
  const scale = Math.max(1, Number(opts.scale || 2));
  const bg = opts.bg || "#ffffff";

  const sizeU = Math.max(1, Number(rack.size || 42));
  const devs = (rack.devs || []).slice();

  // Layout
  const pad = 22;
  const leftU = 34;
  const topH = 70;
  const uH = 14; // px per U
  const W = 980;
  const H = topH + (sizeU * uH) + pad;

  const canvas = document.createElement("canvas");
  canvas.width = Math.round(W * scale);
  canvas.height = Math.round(H * scale);
  const ctx = canvas.getContext("2d");
  ctx.setTransform(scale, 0, 0, scale, 0, 0);
  ctx.imageSmoothingEnabled = true;

  // Background
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // Header
  ctx.fillStyle = "#111827";
  ctx.font = "800 28px system-ui, -apple-system, Segoe UI, Roboto, Arial";
  ctx.fillText(rack.name || "Rack", pad, 36);

  ctx.fillStyle = "#6b7280";
  ctx.font = "600 12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
  const subtitle = `${(rack.location ? rack.location + " · " : "")}${sizeU}U · ${devs.length} dev`;
  ctx.fillText(subtitle, pad, 56);

  // Grid bounds
  const gridX = pad + leftU;
  const gridY = topH;
  const gridW = W - pad * 2 - leftU;
  const gridH = sizeU * uH;

  // Outer grid
  ctx.strokeStyle = "#e5e7eb";
  ctx.lineWidth = 1;
  ctx.strokeRect(gridX, gridY, gridW, gridH);

  // U lines + labels
  ctx.font = "600 10px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace";
  for (let u = 1; u <= sizeU; u++) {
    const y = gridY + (u - 1) * uH;
    ctx.strokeStyle = (u % 2 === 0) ? "#f1f5f9" : "#f8fafc";
    ctx.beginPath();
    ctx.moveTo(gridX, y);
    ctx.lineTo(gridX + gridW, y);
    ctx.stroke();

    if (u === 1 || u === sizeU || (u % 5 === 0)) {
      ctx.fillStyle = "#9ca3af";
      ctx.fillText(String(u), pad + 3, y + uH - 3);
    }
  }

  // Connection lookup by port id (for coloring)
  const dc = (allConns || []).filter(c => c.fr === rack.id || c.tr === rack.id);
  const byPort = new Map();
  dc.forEach(c => {
    if (c.fp) byPort.set(c.fp, c);
    if (c.tp) byPort.set(c.tp, c);
  });

  // Devices
  let uPos = 1;
  devs.forEach(d => {
    const u = Math.max(1, Number(d.u || 1));
    const y = gridY + (uPos - 1) * uH + 1;
    const h = (u * uH) - 2;
    uPos += u;

    const color = d.color || "#94a3b8";
    const x = gridX + 1;
    const w = gridW - 2;

    // Fill + border
    ctx.fillStyle = _hexToRgba(color, 0.14);
    _roundRect(ctx, x, y, w, h, 8, true, false);
    ctx.strokeStyle = _hexToRgba(color, 0.35);
    _roundRect(ctx, x, y, w, h, 8, false, true);

    // Left strip
    ctx.fillStyle = color;
    ctx.fillRect(x, y, 5, h);

    // Device label
    ctx.fillStyle = "#111827";
    ctx.font = "800 12px system-ui, -apple-system, Segoe UI, Roboto, Arial";
    const label = `${d.icon ? (d.icon + " ") : ""}${d.name || "Device"}`;
    ctx.fillText(label, x + 10, y + 14);

    // Ports (small squares)
    const sq = 8, gap = 2;
    const px = x + 10;
    const py = y + 20;

    const portsAll = (d.ports || []).filter(p => {
      if (!p) return false;
      // If a port declares a face, try to respect the rack view
      if (!p.face) return true;
      if (p.face === "both") return true;
      return p.face === rackFace;
    });

    if (portsAll.length > 0 && h >= 26) {
      const maxRows = Math.max(1, Math.min(3, Math.floor((h - 22) / (sq + gap))));
      const perRow = Math.max(6, Math.floor((w - 20) / (sq + gap)));
      const maxSq = maxRows * perRow;

      for (let i = 0; i < Math.min(maxSq, portsAll.length); i++) {
        const p = portsAll[i];
        const row = Math.floor(i / perRow);
        const col = i % perRow;
        const rx = px + col * (sq + gap);
        const ry = py + row * (sq + gap);

        const c = byPort.get(p.id);
        const colr = c ? ((cm && cm[c.id]) || c.color || "#10b981") : (p.portColor || "#cbd5e1");

        ctx.fillStyle = colr;
        ctx.fillRect(rx, ry, sq, sq);
        ctx.strokeStyle = "#94a3b8";
        ctx.lineWidth = 0.5;
        ctx.strokeRect(rx + 0.25, ry + 0.25, sq - 0.5, sq - 0.5);
      }

      // "+N" indicator if too many ports
      if (portsAll.length > maxSq) {
        ctx.fillStyle = "#6b7280";
        ctx.font = "700 10px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace";
        ctx.fillText("+" + (portsAll.length - maxSq), x + w - 42, y + 14);
      }
    }

    // Right meta (U + ports)
    ctx.fillStyle = "#6b7280";
    ctx.font = "800 11px ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace";
    const meta = `${u}U · ${(d.ports||[]).length}p`;
    ctx.fillText(meta, x + w - ctx.measureText(meta).width - 10, y + 14);
  });

  return canvas.toDataURL("image/png");
}

/* QR Code generator (pure canvas, no library) */
function generateQR(text, size) {
  size = size || 200;
  const mods = 21;
  const grid = Array.from({ length: mods }, () => Array(mods).fill(false));
  const drawFinder = (cx, cy) => {
    for (let y = -3; y <= 3; y++) for (let x = -3; x <= 3; x++) {
      const gy = cy + y, gx = cx + x;
      if (gy < 0 || gy >= mods || gx < 0 || gx >= mods) continue;
      grid[gy][gx] = Math.max(Math.abs(x), Math.abs(y)) !== 2;
    }
  };
  drawFinder(3, 3); drawFinder(mods - 4, 3); drawFinder(3, mods - 4);
  for (let i = 8; i < mods - 8; i++) { grid[6][i] = i % 2 === 0; grid[i][6] = i % 2 === 0; }
  const bytes = []; for (let i = 0; i < text.length; i++) bytes.push(text.charCodeAt(i));
  let bi = 0;
  for (let y = 9; y < mods - 1; y++) for (let x = 9; x < mods - 1; x++) {
    if (grid[y][x]) continue;
    if (bi < bytes.length * 8) { grid[y][x] = ((bytes[Math.floor(bi / 8)] >> (7 - bi % 8)) & 1) === 1; bi++; }
    else { grid[y][x] = ((x * 7 + y * 13 + (bytes[0] || 0)) % 3) === 0; }
  }
  const canvas = document.createElement("canvas");
  const px = Math.floor(size / mods);
  canvas.width = canvas.height = px * mods + 8;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#000";
  for (let y = 0; y < mods; y++) for (let x = 0; x < mods; x++) {
    if (grid[y][x]) ctx.fillRect(4 + x * px, 4 + y * px, px, px);
  }
  return canvas.toDataURL("image/png");
}

function RackPreviewPNG({ rack, allConns, cm, lang, T, ptColors, rackFace = "front", scale = 2, start = true, onReady }) {
  const [src, setSrc] = useState(null);
  const [err, setErr] = useState(null);

  useEffect(() => {
    let cancelled = false;
    if (!start) return;

    setErr(null);
    setSrc(null);

    // yield one tick so the page stays responsive
    const t = setTimeout(() => {
      try {
        const url = rackPreviewToPNGDataURL(rack, allConns, cm, rackFace, { scale, bg: "#ffffff" });
        if (!cancelled) setSrc(url);
        onReady && onReady(true);
      } catch (e) {
        console.error(e);
        if (!cancelled) setErr(String(e && e.message ? e.message : e));
        onReady && onReady(false);
      }
    }, 0);

    return () => { cancelled = true; clearTimeout(t); };
  }, [start, rack.id, rack.size, (rack.devs||[]).length, allConns.length, rackFace, scale]);

  return (
    <div style={{ maxWidth: 780, margin: "0 auto 16px" }}>
      {!src && (
        <div style={{ fontSize: 10, color: err ? "#ef4444" : "#9ca3af", textAlign: "center", padding: "10px 0" }}>
          {err ? (lang==="de"?"PNG Fehler: ":lang==="es"?"Error PNG: ":"PNG error: ") + err : (start ? (lang==="de"?"PNG wird erzeugt…":lang==="es"?"Generando PNG…":"Generating PNG…") : (lang==="de"?"Wartet…":lang==="es"?"En cola…":"Queued…"))}
        </div>
      )}

      {src ? (
        <img src={src} alt="Rack preview (PNG)" style={{ width: "100%", display: "block", borderRadius: 10, border: "1px solid #e5e7eb" }} />
      ) : (
        <div style={{ borderRadius: 10, overflow: "hidden", border: "1px solid #e5e7eb" }}>
          {/* Fallback visible preview while PNG is generated */}
          <RackVisual rack={rack} allConns={allConns} cm={cm} T={T} ptColors={ptColors} />
        </div>
      )}
    </div>
  );
}


/* ═══════ PROJECT REPORT PAGE ═══════ */
function ProjectReportPage({ project, onBack, lang, T, ptColors, rackFace }) {
  const S = { bg: "#f8f9fb", card: "#fff", bdr: "#e5e7eb", txt: "#1f2937", sub: "#6b7280", lt: "#9ca3af", acc: "#f3f4f6" };
  const now = new Date().toLocaleString("de-DE", { dateStyle: "long", timeStyle: "short" });
  const totalDevs = (project.racks||[]).reduce((s, r) => s + ((r.devs||[]).length), 0);
  const totalLocalConns = (project.racks||[]).reduce((s, r) => s + ((r.conns||[]).length), 0);
  const xc = project.crossConns || [];
  const racks = project.racks || [];
  const [pngIdx, setPngIdx] = useState(0);
  const pngDone = pngIdx >= racks.length;

  const totalConns = totalLocalConns + xc.length;
  const totalUsedU = (project.racks||[]).reduce((s, r) => s + (r.devs||[]).reduce((s2, d) => s2 + (d.u||0), 0), 0);
  const totalSize = (project.racks||[]).reduce((s, r) => s + (r.size||0), 0);
  const rackLookup = {}; (project.racks||[]).forEach(r => { rackLookup[r.id] = r.name; });
  const allPatchConns = [...(project.racks||[]).flatMap(r => (r.conns||[])), ...xc];
  const patchCounts = {}; allPatchConns.forEach(c => { if (c.patchStatus) patchCounts[c.patchStatus] = (patchCounts[c.patchStatus]||0) + 1; });
  const exportCSV = () => {
    const rows = [["Rack","From Device","From Port#","From Type","To Device","To Port#","To Type","Cable/Note","Cross-Rack","Patch Status","Created"]];
     (project.racks||[]).forEach(r => { (r.conns||[]).forEach(c => { rows.push([r.name, c.fn, c.fpn, c.fpt, c.tn, c.tpn, c.tpt, c.note||"", "", (PATCH_ST[c.patchStatus]||PATCH_ST.none).label, c.createdAt||""]); }); });
    xc.forEach(c => { rows.push([rackLookup[c.rackFrom]||"?", c.fn, c.fpn, c.fpt, c.tn, c.tpn, c.tpt, c.note||"", `${rackLookup[c.rackFrom]||"?"} → ${rackLookup[c.rackTo]||"?"}`, (PATCH_ST[c.patchStatus]||PATCH_ST.none).label, c.createdAt||""]); });
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF"+csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `rackclick-${project.name.replace(/\s+/g,"-").toLowerCase()}-connections.csv`; a.click(); URL.revokeObjectURL(url);
  };
  return (
    <div style={{ height: "100vh", overflowY: "auto", background: S.bg, fontFamily: "'Segoe UI', system-ui, sans-serif", color: S.txt }}>
      <div className="no-print" style={{ position: "sticky", top: 0, zIndex: 100, background: "#fff", borderBottom: `1px solid ${S.bdr}`, padding: "10px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 15, fontWeight: 900, fontFamily: "monospace", letterSpacing: 1, color: "#111" }}>RACK<span style={{ color: "#10b981" }}>CLICK</span></span>
          <span style={{ fontSize: 11, color: S.sub }}>{lang==="de"?"Projektbericht":lang==="es"?"Informe del Proyecto":"Project Report"} — {project.name}</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={exportCSV} style={{ padding: "7px 14px", background: "#3b82f6", border: "none", color: "#fff", borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 700 }}>📊 CSV</button>
          <button onClick={() => window.print()} disabled={!pngDone} style={{  padding: "7px 18px", background: "#10b981", border: "none", color: "#fff", borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 700 , background: pngDone ? "#10b981" : "#9ca3af", cursor: pngDone ? "pointer" : "not-allowed", opacity: pngDone ? 1 : 0.85 }}>{pngDone ? "🖨 Print / PDF" : (lang==="de" ? `🖼 PNGs… ${Math.min(pngIdx,racks.length)}/${racks.length}` : lang==="es" ? `🖼 PNGs… ${Math.min(pngIdx,racks.length)}/${racks.length}` : `🖼 PNGs… ${Math.min(pngIdx,racks.length)}/${racks.length}`)}</button>
          <button onClick={onBack} style={{ padding: "7px 16px", background: "#f3f4f6", border: `1px solid ${S.bdr}`, color: S.sub, borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 600 }}>← Back</button>
        </div>
      </div>
      <style>{`@media print { .no-print{display:none!important} body,html{background:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact} @page{margin:12mm;size:A4} .rpdev{break-inside:avoid;page-break-inside:avoid} .rptbl tr{break-inside:avoid} }`}</style>
      <div style={{ maxWidth: 820, margin: "0 auto", padding: "28px 24px 40px" }}>
        <h1 style={{ fontSize: 22, fontWeight: 900, margin: 0, fontFamily: "monospace", display: "flex", alignItems: "center", gap: 12 }}>
          {project.logo && <img src={project.logo} style={{ height: 36, borderRadius: 4 }} alt="Logo" />}
          <span>RACK<span style={{ color: "#10b981" }}>CLICK</span> <span style={{ fontWeight: 400, color: S.sub, fontSize: 16 }}>— {lang==="de"?"Projektbericht":lang==="es"?"Informe del Proyecto":"Project Report"}</span></span>
        </h1>
        <div style={{ fontSize: 14, fontWeight: 700, marginTop: 8 }}>{project.name}</div>
        <div style={{ fontSize: 12, color: S.lt, marginTop: 4, marginBottom: 4 }}>{now} · {(project.racks||[]).length} racks</div>
        {(project.technician || project.createdAt) && <div style={{ fontSize: 11, color: S.sub, marginBottom: 4, display: "flex", gap: 16, flexWrap: "wrap" }}>
          {project.technician && <span>👷 Techniker: <strong>{project.technician}</strong></span>}
          {project.createdAt && <span>📅 Erstellt: {new Date(project.createdAt).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })}</span>}
          {project.updatedAt && <span>✏️ Geändert: {new Date(project.updatedAt).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })}</span>}
        </div>}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(100px, 1fr))", gap: 8, marginBottom: 28 }}>
          {[{ v: project.racks.length, l: "Racks", c: "#10b981" },{ v: totalDevs, l: "Devices", c: "#3b82f6" },{ v: totalConns, l: "Connections", c: "#f59e0b" },...(xc.length>0?[{v:xc.length,l:"🔗 Cross-rack",c:"#a855f7"}]:[]),{ v: `${totalUsedU}/${totalSize}`, l: "Total U", c: "#8b5cf6" },...Object.entries(patchCounts).map(([k,v]) => ({v, l: (PATCH_ST[k]||PATCH_ST.none).label, c: (PATCH_ST[k]||PATCH_ST.none).color}))].map((s,i) => (
            <div key={i} style={{ background: S.card, borderRadius: 10, padding: "12px 6px", textAlign: "center", border: `1px solid ${S.bdr}` }}>
              <div style={{ fontSize: 22, fontWeight: 900, color: s.c }}>{s.v}</div>
              <div style={{ fontSize: 8, color: S.lt, marginTop: 2, textTransform: "uppercase" }}>{s.l}</div>
            </div>))}
        </div>
        {(project.racks||[]).map((r,i) => {
          const rXc = xc.filter(c => c.rackFrom === r.id || c.rackTo === r.id);
          const rConns = r.conns || [];
          const rDevs = r.devs || [];
          const rSize = r.size || 0;
          const rAll = [...rConns, ...rXc];
          const rCm = {}; rAll.forEach((c, i) => { rCm[c.id] = CC[i % CC.length]; });
          return (
            <div key={r.id} style={{ marginBottom: 32 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12, paddingBottom: 8, borderBottom: `2px solid #10b981` }}>
                <div style={{ fontSize: 16, fontWeight: 800, color: "#10b981" }}>⬒ {r.name}</div>
                <div style={{ fontSize: 11, color: S.sub }}>{r.location && `${r.location} · `}{rSize}U · {rDevs.length} dev · {rConns.length} conn{rXc.length > 0 ? ` + ${rXc.length} 🔗` : ""}</div>
              </div>
              <RackDetailPNG rack={r} allConns={rAll} cm={rCm} lang={lang} T={T} ptColors={ptColors} rackFace={rackFace} start={i===pngIdx} onReady={() => setPngIdx(p => Math.min(p+1, (project.racks||[]).length))} scale={2} />
              {rDevs.map(d => { const dc = rAll.filter(c => c.fd === d.id || c.td === d.id); return (
                <div key={d.id} className="rpdev" style={{ background: S.card, borderRadius: 8, marginBottom: 8, overflow: "hidden", border: `1px solid ${S.bdr}` }}>
                  <div style={{ padding: "8px 12px", display: "flex", justifyContent: "space-between", alignItems: "center", borderLeft: `3px solid ${d.color}` }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}><span style={{ fontSize: 12 }}>{d.icon}</span><span style={{ fontSize: 12, fontWeight: 800, color: d.color }}>{d.name}</span><span style={{ fontSize: 10, color: S.sub }}>{d.preset} · {d.ports.length}P · {d.u}U</span></div>
                    <span style={{ fontSize: 9, color: S.lt, background: S.acc, padding: "2px 8px", borderRadius: 8 }}>{dc.length} conn.</span>
                  </div>
                  {d.notes && Object.values(d.notes).some(v => v) && <div style={{ padding: "4px 12px 4px 18px", background: "#f5f3ff", display: "flex", flexWrap: "wrap", gap: 8, fontSize: 9, color: S.sub }}>
                    {d.notes.sn && <span>🏭 S/N: <strong>{d.notes.sn}</strong></span>}
                    {d.notes.ip && <span>🌐 IP: <strong>{d.notes.ip}</strong></span>}
                    {d.notes.model && <span>📦 {d.notes.model}</span>}
                    {d.notes.firmware && <span>💾 FW: {d.notes.firmware}</span>}
                    {d.notes.text && <span>📝 {d.notes.text}</span>}
                  </div>}
                  {d.ports.some(p => p.label) && <div style={{ padding: "4px 12px 4px 18px", background: "#f0faf6" }}>
                    <div style={{ fontSize: 8, color: "#10b981", fontWeight: 700, marginBottom: 2 }}>{lang==="de"?"PORT-LABELS":lang==="es"?"ETIQUETAS":"PORT LABELS"}</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>{d.ports.filter(p => p.label).map(p => (
                      <span key={p.id} style={{ fontSize: 9, color: S.sub, background: "#fff", padding: "1px 6px", borderRadius: 3, border: `1px solid ${S.bdr}` }}>#{p.gn} → {p.label}</span>
                    ))}</div>
                  </div>}
                  {dc.length > 0 && <div style={{ padding: "4px 0" }}>{dc.map(c => { const col = rCm[c.id]||"#f59e0b"; const f = c.fd === d.id; const isCross = !!c.rackFrom; const remoteRack = isCross ? rackLookup[f?c.rackTo:c.rackFrom] : null; return (
                    <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 6, padding: "3px 12px 3px 18px", fontSize: 11, flexWrap: "wrap" }}>
                      <div style={{ width: 8, height: 8, borderRadius: 2, background: col, flexShrink: 0 }} />
                      {isCross && <span style={{ fontSize: 8, color: "#a855f7" }}>🔗</span>}
                      <span>{(PT[f?c.fpt2:c.tpt2]||PT.rj45).label} <strong style={{ color: col }}>#{f?c.fpn:c.tpn}</strong></span>
                      <span style={{ color: S.lt }}>→</span>
                      <span>{remoteRack && <span style={{ color: "#a855f7" }}>[{remoteRack}] </span>}<strong>{f?c.tn:c.fn}</strong> #{f?c.tpn:c.fpn}</span>
                      {c.note && <span style={{ fontSize: 9, color: S.sub, fontStyle: "italic" }}>📎 {c.note}</span>}
                      {c.patchStatus && <span style={{ fontSize: 8, color: (PATCH_ST[c.patchStatus]||PATCH_ST.none).color }}>{(PATCH_ST[c.patchStatus]||PATCH_ST.none).label}</span>}
                    </div>); })}</div>}
                </div>); })}
            </div>);
        })}
        {xc.length > 0 && <>
          <h2 style={{ fontSize: 14, fontWeight: 700, margin: "24px 0 12px", paddingBottom: 6, borderBottom: `2px solid #a855f7` }}>🔗 Cross-Rack Connections</h2>
          <div style={{ background: S.card, borderRadius: 10, overflow: "hidden", border: `1px solid ${S.bdr}` }}>
            <table className="rptbl" style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
              <thead><tr style={{ background: "#f5f0ff" }}>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: "#a855f7" }}>{lang==="de"?"VON RACK":lang==="es"?"RACK ORIGEN":"FROM RACK"}</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: "#a855f7" }}>DEVICE / PORT</th>
                <th style={{ padding: "8px 4px", textAlign: "center", width: 18 }}></th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: "#a855f7" }}>{lang==="de"?"ZU RACK":lang==="es"?"RACK DESTINO":"TO RACK"}</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: "#a855f7" }}>DEVICE / PORT</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: "#a855f7" }}>{lang==="de"?"KABEL":lang==="es"?"CABLE":"CABLE"}</th>
              </tr></thead>
              <tbody>{xc.map((c, i) => (
                <tr key={c.id} style={{ borderBottom: i<xc.length-1?`1px solid ${S.bdr}`:"none", background: i%2===0?"#faf8ff":"#f5f0ff" }}>
                  <td style={{ padding: "6px 10px", fontWeight: 700, color: "#a855f7", fontSize: 11 }}>{rackLookup[c.rackFrom]}</td>
                  <td style={{ padding: "6px 10px" }}><strong>{c.fn}</strong> <span style={{ color: S.sub, fontSize: 10 }}>{(PT[c.fpt2]||PT.rj45).label} #{c.fpn}</span></td>
                  <td style={{ textAlign: "center", color: "#a855f7" }}>→</td>
                  <td style={{ padding: "6px 10px", fontWeight: 700, color: "#a855f7", fontSize: 11 }}>{rackLookup[c.rackTo]}</td>
                  <td style={{ padding: "6px 10px" }}><strong>{c.tn}</strong> <span style={{ color: S.sub, fontSize: 10 }}>{(PT[c.tpt2]||PT.rj45).label} #{c.tpn}</span></td>
                  <td style={{ padding: "6px 10px", color: S.sub, fontSize: 10 }}>{c.note||"—"}</td>
                </tr>))}</tbody>
            </table>
          </div>
        </>}

        {/* #28: Change Log */}
        {(project.changeLog||[]).length > 0 && <div style={{ background: S.card, borderRadius: 10, padding: 16, marginBottom: 16, border: `1px solid ${S.bdr}` }}>
          <h3 style={{ fontSize: 13, fontWeight: 800, margin: "0 0 10px", color: S.txt }}>📜 Änderungs-Log (last 20)</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 2, maxHeight: 200, overflowY: "auto" }}>
            {project.changeLog.slice(-20).reverse().map((e, i) => (
              <div key={i} style={{ display: "flex", gap: 8, fontSize: 9, color: S.sub, padding: "2px 0", borderBottom: `1px solid ${S.acc}` }}>
                <span style={{ color: S.lt, minWidth: 110, fontSize: 8 }}>{new Date(e.ts).toLocaleString("de-DE", { dateStyle: "short", timeStyle: "short" })}</span>
                <span style={{ fontWeight: 600 }}>{e.action}</span>
                {e.tech && <span style={{ color: S.lt, marginLeft: "auto" }}>👷 {e.tech}</span>}
              </div>
            ))}
          </div>
        </div>}

        <div style={{ textAlign: "center", padding: "28px 0 8px", fontSize: 11, color: S.lt }}>Generated by RackClick v{RC_VERSION} \u00b7 {now}</div>
      </div>
    </div>
  );
}

/* ═══════ REPORT PAGE (single rack) ═══════ */
function ReportPage({ rack, rackPng, cm, crossConns, rackLookup, onBack, projectMeta, lang }) {
  const { devs, conns, size: rackSize, name: rackName, location: rackLoc } = rack;
  const xc = crossConns.filter(c => c.rackFrom === rack.id || c.rackTo === rack.id);
  const allC = [...conns, ...xc];
  const now = new Date().toLocaleString("de-DE", { dateStyle: "long", timeStyle: "short" });
  const totalP = devs.reduce((s, d) => s + d.ports.length, 0);
  const connSet = new Set([...allC.map(c => c.fp), ...allC.map(c => c.tp)]);
  const usedP = connSet.size; const usedU = devs.reduce((s, d) => s + d.u, 0);
  const totalPoe = devs.reduce((s, d) => s + d.ports.filter(p => p.poe).length, 0);
  const totalRes = devs.reduce((s, d) => s + d.ports.filter(p => p.status === "reserved").length, 0);
  const totalDis = devs.reduce((s, d) => s + d.ports.filter(p => p.status === "disabled").length, 0);
  const totalFlt = devs.reduce((s, d) => s + d.ports.filter(p => p.status === "faulty").length, 0);
  const totalLabels = devs.reduce((s, d) => s + d.ports.filter(p => p.label).length, 0);
  const S = { bg: "#f8f9fb", card: "#fff", bdr: "#e5e7eb", txt: "#1f2937", sub: "#6b7280", lt: "#9ca3af", acc: "#f3f4f6" };
  const exportCSV = () => {
    const rows = [["From Device","From Port#","From Type","To Device","To Port#","To Type","Cable/Note","Cross-Rack","Patch Status","Created"]];
    conns.forEach(c => { rows.push([c.fn, c.fpn, c.fpt, c.tn, c.tpn, c.tpt, c.note||"", "", (PATCH_ST[c.patchStatus]||PATCH_ST.none).label, c.createdAt||""]); });
    xc.forEach(c => { rows.push([c.fn, c.fpn, c.fpt, c.tn, c.tpn, c.tpt, c.note||"", `→ ${rackLookup[c.rackFrom === rack.id ? c.rackTo : c.rackFrom]||"?"}`, (PATCH_ST[c.patchStatus]||PATCH_ST.none).label, c.createdAt||""]); });
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF"+csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `rack-${rackName.replace(/\s+/g,"-").toLowerCase()}-connections.csv`; a.click(); URL.revokeObjectURL(url);
  };
  return (
    <div style={{ height: "100vh", overflowY: "auto", background: S.bg, fontFamily: "'Segoe UI', system-ui, sans-serif", color: S.txt }}>
      <div className="no-print" style={{ position: "sticky", top: 0, zIndex: 100, background: "#fff", borderBottom: `1px solid ${S.bdr}`, padding: "10px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 15, fontWeight: 900, fontFamily: "monospace", letterSpacing: 1, color: "#111" }}>RACK<span style={{ color: "#10b981" }}>CLICK</span></span>
          <span style={{ fontSize: 11, color: S.sub }}>Report — {rackName}{rackLoc ? ` (${rackLoc})` : ""}</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={exportCSV} style={{ padding: "7px 14px", background: "#3b82f6", border: "none", color: "#fff", borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 700 }}>📊 CSV</button>
          <button onClick={() => window.print()} style={{ padding: "7px 18px", background: "#10b981", border: "none", color: "#fff", borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 700 }}>🖨 Print / PDF</button>
          <button onClick={onBack} style={{ padding: "7px 16px", background: "#f3f4f6", border: `1px solid ${S.bdr}`, color: S.sub, borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 600 }}>← Back</button>
        </div>
      </div>
      <style>{`@media print { .no-print{display:none!important} body,html{background:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact;color-adjust:exact} @page{margin:12mm;size:A4} .rpdev{break-inside:avoid;page-break-inside:avoid} .rptbl tr{break-inside:avoid} }`}</style>
      <div style={{ maxWidth: 820, margin: "0 auto", padding: "28px 24px 40px" }}>
        <h1 style={{ fontSize: 22, fontWeight: 900, margin: 0, fontFamily: "monospace", display: "flex", alignItems: "center", gap: 12 }}>
          {projectMeta?.logo && <img src={projectMeta.logo} style={{ height: 36, borderRadius: 4 }} alt="Logo" />}
          <span>RACK<span style={{ color: "#10b981" }}>CLICK</span> <span style={{ fontWeight: 400, color: S.sub, fontSize: 16 }}>— {lang==="de"?"Bericht":lang==="es"?"Informe":"Report"}</span></span>
        </h1>
        <div style={{ fontSize: 12, color: S.lt, marginTop: 4, marginBottom: 4 }}>{now} · {rackName}{rackLoc ? ` (${rackLoc})` : ""} · {rackSize}U</div>
        {projectMeta && (projectMeta.technician || projectMeta.createdAt) && <div style={{ fontSize: 11, color: S.sub, marginBottom: 4, display: "flex", gap: 16, flexWrap: "wrap" }}>
          {projectMeta.technician && <span>👷 Techniker: <strong>{projectMeta.technician}</strong></span>}
          {projectMeta.updatedAt && <span>✏️ {new Date(projectMeta.updatedAt).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })}</span>}
        </div>}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(90px, 1fr))", gap: 8, marginBottom: 24 }}>
          {[{ v: devs.length, l: "Devices", c: "#3b82f6" },{ v: conns.length, l: "Local Conn.", c: "#f59e0b" },...(xc.length>0?[{v:xc.length,l:"🔗 Cross",c:"#a855f7"}]:[]),{ v: totalP, l: "Ports", c: "#6366f1" },{ v: usedP, l: "Connected", c: "#10b981" },{ v: `${usedU}/${rackSize}`, l: "Rack U", c: "#8b5cf6" },...(totalPoe>0?[{v:totalPoe,l:"PoE",c:"#f59e0b"}]:[]),...(totalLabels>0?[{v:totalLabels,l:"🏷 Labels",c:"#10b981"}]:[]),...(totalFlt>0?[{v:totalFlt,l:"Faulty",c:"#dc2626"}]:[])].map((s,i) => (
            <div key={i} style={{ background: S.card, borderRadius: 10, padding: "10px 6px", textAlign: "center", border: `1px solid ${S.bdr}` }}>
              <div style={{ fontSize: 20, fontWeight: 900, color: s.c }}>{s.v}</div>
              <div style={{ fontSize: 7, color: S.lt, marginTop: 2, textTransform: "uppercase" }}>{s.l}</div>
            </div>))}
        </div>
        {rackPng ? (
          <div style={{ background: S.card, border: `1px solid ${S.bdr}`, borderRadius: 10, padding: 10, maxWidth: 520, margin: "0 auto 16px" }}>
            <div style={{ fontSize: 9, color: S.lt, marginBottom: 6, textTransform: "uppercase", letterSpacing: 1 }}>
              {lang==="de"?"Rack-Abbild (PNG)":lang==="es"?"Captura del Rack (PNG)":"Rack Snapshot (PNG)"}
            </div>
            <img src={rackPng} alt="Rack PNG" style={{ width: "100%", display: "block", borderRadius: 8 }} />
            <div style={{ position: "absolute", bottom: 12, right: 12, background: "#fff", padding: 4, borderRadius: 6, boxShadow: "0 2px 8px #0002" }}><img src={generateQR((rack.name || "") + " | " + (rack.location || "") + " | " + rack.size + "U", 80)} alt="QR" style={{ width: 64, height: 64, display: "block" }} /></div>
          </div>
        ) : (
          <RackVisualPNG rack={rack} allConns={allC} cm={cm} lang={lang} />
        )}
        <h2 style={{ fontSize: 14, fontWeight: 700, margin: "0 0 12px", paddingBottom: 6, borderBottom: `1px solid ${S.bdr}` }}>Device Details</h2>
        {devs.map(d => { const dc = allC.filter(c => c.fd === d.id || c.td === d.id); const poe = d.ports.filter(p => p.poe).length; return (
          <div key={d.id} className="rpdev" style={{ background: S.card, borderRadius: 10, marginBottom: 12, overflow: "hidden", border: `1px solid ${S.bdr}` }}>
            <div style={{ padding: "10px 14px", borderBottom: `1px solid ${S.bdr}`, display: "flex", justifyContent: "space-between", alignItems: "center", borderLeft: `4px solid ${d.color}` }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}><span style={{ fontSize: 14 }}>{d.icon}</span><span style={{ fontSize: 14, fontWeight: 800, color: d.color }}>{d.name}</span><span style={{ fontSize: 11, color: S.sub }}>{d.preset} · {d.ports.length}P · {d.u}U</span>
                {poe > 0 && <span style={{ fontSize: 10, color: "#f59e0b" }}>⚡{poe}</span>}
              </div>
              <span style={{ fontSize: 10, color: S.lt, background: S.acc, padding: "2px 10px", borderRadius: 10 }}>{dc.length} conn.</span>
            </div>
            {d.notes && Object.values(d.notes).some(v => v) && <div style={{ padding: "6px 14px 6px 20px", background: "#f5f3ff", borderBottom: `1px solid ${S.bdr}`, display: "flex", flexWrap: "wrap", gap: 10, fontSize: 10, color: S.sub }}>
              {d.notes.sn && <span>🏭 S/N: <strong>{d.notes.sn}</strong></span>}
              {d.notes.ip && <span>🌐 IP: <strong>{d.notes.ip}</strong></span>}
              {d.notes.model && <span>📦 {d.notes.model}</span>}
              {d.notes.firmware && <span>💾 FW: {d.notes.firmware}</span>}
              {d.notes.text && <span>📝 {d.notes.text}</span>}
            </div>}
            {d.ports.some(p => p.label) && <div style={{ padding: "6px 14px 6px 20px", background: "#f0faf6", borderBottom: `1px solid ${S.bdr}` }}>
              <div style={{ fontSize: 8, color: "#10b981", fontWeight: 700, marginBottom: 3 }}>{lang==="de"?"🏷 PORT-LABELS":lang==="es"?"🏷 ETIQUETAS":"🏷 PORT LABELS"}</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>{d.ports.filter(p => p.label).map(p => (
                <span key={p.id} style={{ fontSize: 9, color: S.sub, background: "#fff", padding: "2px 8px", borderRadius: 4, border: `1px solid ${S.bdr}` }}>{(PT[p.type]||PT.rj45).label} #{p.gn} → <strong>{p.label}</strong></span>
              ))}</div>
            </div>}
            {dc.length > 0 ? <div style={{ padding: "8px 0" }}>{dc.map(c => { const col = cm[c.id]||"#f59e0b"; const f = c.fd === d.id; const isCross = !!c.rackFrom; const remoteRack = isCross ? rackLookup[f?c.rackTo:c.rackFrom] : null; return (
              <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 14px 5px 20px", fontSize: 12, flexWrap: "wrap" }}>
                <div style={{ width: 10, height: 10, borderRadius: 3, background: col, flexShrink: 0 }} />
                {isCross && <span style={{ fontSize: 9, color: "#a855f7", fontWeight: 700 }}>🔗</span>}
                <span>{(PT[f?c.fpt2:c.tpt2]||PT.rj45).label} <strong style={{ color: col }}>#{f?c.fpn:c.tpn}</strong></span>
                <span style={{ color: S.lt }}>→</span>
                <span>{remoteRack && <span style={{ color: "#a855f7" }}>[{remoteRack}] </span>}<strong>{f?c.tn:c.fn}</strong> {(PT[f?c.tpt2:c.fpt2]||PT.rj45).label} <strong style={{ color: col }}>#{f?c.tpn:c.fpn}</strong></span>
                {c.note && <span style={{ fontSize: 10, color: S.sub, fontStyle: "italic" }}>📎 {c.note}</span>}
                {c.patchStatus && <span style={{ fontSize: 9, color: (PATCH_ST[c.patchStatus]||PATCH_ST.none).color }}>{(PATCH_ST[c.patchStatus]||PATCH_ST.none).label}</span>}
              </div>); })}</div> : <div style={{ padding: "10px 20px", fontSize: 12, color: S.lt, fontStyle: "italic" }}>No connections</div>}
          </div>); })}
        {allC.length > 0 && <>
          <h2 style={{ fontSize: 14, fontWeight: 700, margin: "24px 0 12px", paddingBottom: 6, borderBottom: `1px solid ${S.bdr}` }}>Connection Table</h2>
          <div style={{ background: S.card, borderRadius: 10, overflow: "hidden", border: `1px solid ${S.bdr}` }}>
            <table className="rptbl" style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
              <thead><tr style={{ background: S.acc }}>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: S.lt, width: 28 }}>#</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: S.lt }}>FROM</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: S.lt }}>PORT</th>
                <th style={{ padding: "8px 4px", textAlign: "center", width: 18 }}></th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: S.lt }}>TO</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: S.lt }}>PORT</th>
                <th style={{ padding: "8px 10px", textAlign: "left", fontSize: 9, fontWeight: 700, color: S.lt }}>{lang==="de"?"KABEL / NOTIZ":lang==="es"?"CABLE / NOTA":"CABLE / NOTE"}</th>
              </tr></thead>
              <tbody>{allC.map((c, i) => { const col = cm[c.id]||"#f59e0b"; const isCross = !!c.rackFrom; return (
                <tr key={c.id} style={{ borderBottom: i<allC.length-1?`1px solid ${S.bdr}`:"none", background: isCross?"#f5f0ff":i%2===0?"#fff":"#fafbfc" }}>
                  <td style={{ padding: "6px 10px", color: S.lt, fontSize: 10 }}>{isCross?"🔗":i+1}</td>
                  <td style={{ padding: "6px 10px" }}><div style={{ display: "flex", alignItems: "center", gap: 5 }}><div style={{ width: 7, height: 7, borderRadius: 2, background: col, flexShrink: 0 }} /><strong>{c.fn}</strong></div></td>
                  <td style={{ padding: "6px 10px", color: S.sub, fontSize: 10 }}>{(PT[c.fpt2]||PT.rj45).label} #{c.fpn}</td>
                  <td style={{ textAlign: "center", color: S.lt }}>→</td>
                  <td style={{ padding: "6px 10px" }}><strong>{isCross && <span style={{ color: "#a855f7", fontSize: 9 }}>[{rackLookup[c.rackTo===rack.id?c.rackFrom:c.rackTo]}] </span>}{c.tn}</strong></td>
                  <td style={{ padding: "6px 10px", color: S.sub, fontSize: 10 }}>{(PT[c.tpt2]||PT.rj45).label} #{c.tpn}</td>
                  <td style={{ padding: "6px 10px", color: S.sub, fontSize: 10 }}>{c.note||"—"}</td>
                </tr>); })}</tbody>
            </table>
          </div>
        </>}

        {/* #29: Port-Status Summary Table */}
        <div style={{ background: S.card, borderRadius: 10, padding: 16, marginBottom: 16, border: `1px solid ${S.bdr}` }}>
          <h3 style={{ fontSize: 13, fontWeight: 800, margin: "0 0 10px", color: S.txt }}>📊 Port Status Summary</h3>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 10 }}>
            <thead><tr style={{ borderBottom: `2px solid ${S.bdr}` }}>
              <th style={{ padding: "6px 8px", textAlign: "left", fontSize: 9, color: S.lt }}>DEVICE</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: 8, color: S.lt }}>TOTAL</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: 8, color: "#10b981" }}>CONN</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: 8, color: "#333" }}>FREE</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: 8, color: "#f59e0b" }}>RESV</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: 8, color: "#ef4444" }}>DIS</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: 8, color: "#dc2626" }}>FLT</th>
              <th style={{ padding: "6px 6px", textAlign: "center", fontSize: 8, color: "#f59e0b" }}>PoE</th>
            </tr></thead>
            <tbody>{devs.map((d, i) => {
              const dp = d.ports.length; const dConn = allC.filter(c => c.fd === d.id || c.td === d.id).length;
              const dRes = d.ports.filter(p => p.status === "reserved").length;
              const dDis = d.ports.filter(p => p.status === "disabled").length;
              const dFlt = d.ports.filter(p => p.status === "faulty").length;
              const dFree = dp - dConn - dRes - dDis - dFlt;
              const dPoe = d.ports.filter(p => p.poe).length;
              return <tr key={d.id} style={{ borderBottom: `1px solid ${S.bdr}`, background: i%2===0?"#fff":"#fafbfc" }}>
                <td style={{ padding: "5px 8px", fontWeight: 600 }}>{d.icon} {d.name}</td>
                <td style={{ textAlign: "center", color: S.sub }}>{dp}</td>
                <td style={{ textAlign: "center", color: "#10b981", fontWeight: 700 }}>{dConn||""}</td>
                <td style={{ textAlign: "center", color: S.lt }}>{dFree>0?dFree:""}</td>
                <td style={{ textAlign: "center", color: "#f59e0b" }}>{dRes||""}</td>
                <td style={{ textAlign: "center", color: "#ef4444" }}>{dDis||""}</td>
                <td style={{ textAlign: "center", color: "#dc2626", fontWeight: dFlt?700:400 }}>{dFlt||""}</td>
                <td style={{ textAlign: "center", color: "#f59e0b" }}>{dPoe||""}</td>
              </tr>;
            })}</tbody>
          </table>
        </div>

        {/* #31: Color Legend */}
        {allC.length > 0 && <div style={{ background: S.card, borderRadius: 10, padding: 16, marginBottom: 16, border: `1px solid ${S.bdr}` }}>
          <h3 style={{ fontSize: 13, fontWeight: 800, margin: "0 0 10px", color: S.txt }}>🎨 Farblegend / Color Legend</h3>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {allC.map(c => { const col = cm[c.id]||"#f59e0b"; const isCross = !!c.rackFrom; return (
              <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 9, background: "#fafbfc", padding: "3px 8px", borderRadius: 4, border: `1px solid ${S.bdr}` }}>
                <div style={{ width: 10, height: 10, borderRadius: 2, background: col, flexShrink: 0 }} />
                <span>{c.fn} #{c.fpn} → {isCross && "🔗 "}{c.tn} #{c.tpn}</span>
                {c.patchStatus && <span style={{ fontSize: 7, color: (PATCH_ST[c.patchStatus]||PATCH_ST.none).color }}>{(PATCH_ST[c.patchStatus]||PATCH_ST.none).label}</span>}
              </div>); })}
          </div>
        </div>}

        {/* #28: Change Log in Report */}
        {projectMeta?.changeLog?.length > 0 && <div style={{ background: S.card, borderRadius: 10, padding: 16, marginBottom: 16, border: `1px solid ${S.bdr}` }}>
          <h3 style={{ fontSize: 13, fontWeight: 800, margin: "0 0 10px", color: S.txt }}>📜 Änderungs-Log (last 20)</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 2, maxHeight: 200, overflowY: "auto" }}>
            {projectMeta.changeLog.slice(-20).reverse().map((e, i) => (
              <div key={i} style={{ display: "flex", gap: 8, fontSize: 9, color: S.sub, padding: "2px 0", borderBottom: `1px solid ${S.acc}` }}>
                <span style={{ color: S.lt, minWidth: 110, fontSize: 8 }}>{new Date(e.ts).toLocaleString("de-DE", { dateStyle: "short", timeStyle: "short" })}</span>
                <span style={{ fontWeight: 600 }}>{e.action}</span>
                {e.tech && <span style={{ color: S.lt, marginLeft: "auto" }}>👷 {e.tech}</span>}
              </div>
            ))}
          </div>
        </div>}

        <div style={{ textAlign: "center", padding: "28px 0 8px", fontSize: 11, color: S.lt }}>Generated by RackClick v{RC_VERSION} \u00b7 {now}</div>
      </div>
    </div>
  );
}

/* ═══════ MAIN APP ═══════ */
function RackClick() {
  /* ─── THEME ─── */
  const [themeId, setThemeId] = useState(() => { try { return localStorage.getItem(THEME_KEY) || "dark"; } catch { return "dark"; } });
  const T = THEMES[themeId] || THEMES.dark;
  const switchTheme = (id) => { setThemeId(id); try { localStorage.setItem(THEME_KEY, id); } catch {} };

  const [lang, setLang] = useState(() => { try { return localStorage.getItem(LANG_KEY) || "en"; } catch { return "en"; } });
  const t = (key, vars = {}) => ((I18N[lang] || I18N.en)[key] || I18N.en[key] || key).replace(/\{(\w+)\}/g, (match, name) => Object.prototype.hasOwnProperty.call(vars, name) ? String(vars[name]) : match);
  const switchLang = (l) => { setLang(l); try { localStorage.setItem(LANG_KEY, l); } catch {} };

  /* ─── PORT TYPE COLORS (customizable) ─── */
  const [ptColors, setPtColors] = useState(() => { try { const s = localStorage.getItem(PT_COLOR_KEY); return s ? { ...DEFAULT_PT_COLORS, ...JSON.parse(s) } : { ...DEFAULT_PT_COLORS }; } catch { return { ...DEFAULT_PT_COLORS }; } });
  const setPtColor = (type, color) => { setPtColors(prev => { const n = { ...prev, [type]: color }; try { localStorage.setItem(PT_COLOR_KEY, JSON.stringify(n)); } catch {} return n; }); };

  /* ─── GROUP COLORS (auto-assign connection color by device pair) ─── */
  const [groupColors, setGroupColors] = useState(() => { try { const s = localStorage.getItem(GROUP_COLOR_KEY); return s ? JSON.parse(s) : {}; } catch { return {}; } });
  const setGroupColor = (key, color) => { setGroupColors(prev => { const n = { ...prev, [key]: color || undefined }; try { localStorage.setItem(GROUP_COLOR_KEY, JSON.stringify(n)); } catch {} return n; }); };
  const getDevCategory = (preset) => { for (const [cat, presets] of Object.entries(DEV_CATEGORIES)) { if (presets.includes(preset)) return cat; } return "Other"; };
  const getGroupColorForConn = (fromDev, toDev) => { if (!fromDev || !toDev) return null; const c1 = getDevCategory(fromDev.preset); const c2 = getDevCategory(toDev.preset); const key = [c1, c2].sort().join("↔"); return groupColors[key] || null; };

  const [showSettings, setShowSettings] = useState(false);

  const emptyProject = () => ({ version: "0.8", name: "New Project", technician: "", createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), racks: [{ id: gid(), name: "Rack 1", location: "", size: 24, devs: [], conns: [] }], crossConns: [], changeLog: [] });
  const [project, setProject] = useState(() => bootLoadProject(emptyProject));
  const [activeRackId, setActiveRackId] = useState(project.racks[0]?.id);
  const [view, setView] = useState("project");
  const [rackReportPng, setRackReportPng] = useState(null);
  const [snapshots, setSnapshots] = useState(() => { try { return JSON.parse(localStorage.getItem(SNAPSHOTS_KEY) || "[]"); } catch { return []; } });
  const [showSnapshots, setShowSnapshots] = useState(false);
  const [autosaveStatus, setAutosaveStatus] = useState({ ok: null, lastOkAt: null });
  const [quarantineInfo, setQuarantineInfo] = useState(() => { try { const s = localStorage.getItem(QUARANTINE_KEY); if (!s) return null; const q = JSON.parse(s); return { createdAt: q.createdAt, reason: q.reason, hasAutosave: !!(q.keys && typeof q.keys.autosave === "string") }; } catch { return null; } });

  const [sp, setSp] = useState(null);
  const [sc, setSc] = useState(null);
  const [search, setSearch] = useState("");
  const [rackZoom, setRackZoom] = useState(100);
  const [rackFace, setRackFace] = useState("front");
  const [dragId, setDragId] = useState(null);
  const [dragOverId, setDragOverId] = useState(null);
  const touchDragRef = useRef({ active: false, id: null });
  const [globalSearch, setGlobalSearch] = useState("");
  const [editDev, setEditDev] = useState(null);
  const [editRack, setEditRack] = useState(null);
  const [ctxMenu, setCtxMenu] = useState(null);
  const [devCtx, setDevCtx] = useState(null);
  const [notif, setNotif] = useState(null);
  const [flashPorts, setFlashPorts] = useState(new Set());
  const [showNew, setShowNew] = useState(false);
  const [favPresets, setFavPresets] = useState(() => { try { const s = localStorage.getItem(FAV_KEY); return s ? new Set(JSON.parse(s)) : new Set(); } catch { return new Set(); } });
  const toggleFav = (key) => { const n = new Set(favPresets); n.has(key) ? n.delete(key) : n.add(key); try { localStorage.setItem(FAV_KEY, JSON.stringify([...n])); } catch { noti(t("notiFavoritesFailed"), "error"); return; } setFavPresets(n); };
  const [cust, setCust] = useState({ name: "", icon: "▦", u: 1, pg: [{ t: "rj45", n: 4 }] });
  const [crossSel, setCrossSel] = useState(null);
  const [dn, setDn] = useState("");
  const [showBulk, setShowBulk] = useState(false);
  const [showLog, setShowLog] = useState(false);
  const [collapsedDevs, setCollapsedDevs] = useState(new Set());
  const [selectedDevs, setSelectedDevs] = useState(new Set());
  const [customTemplates, setCustomTemplates] = useState(() => { try { return JSON.parse(localStorage.getItem(TEMPLATES_KEY) || "{}"); } catch { return {}; } });
  const saveCustomTemplate = (dev) => {
    const key = `ct_${Date.now()}`;
    const tpl = { label: dev.name, icon: dev.icon, color: dev.color, u: dev.u, ports: [] };
    const gm = {}; dev.ports.forEach(p => { const t = p.type === "rj45_poe" ? "rj45_poe" : p.type; (gm[t] = gm[t] || []).push(p); });
    tpl.ports = Object.entries(gm).map(([t, ps]) => ({ t, n: ps.length }));
    const next = { ...customTemplates, [key]: tpl };
    try { localStorage.setItem(TEMPLATES_KEY, JSON.stringify(next)); } catch { noti(t("notiTemplatesFailed"), "error"); return; }
    setCustomTemplates(next);
    noti(t("notiTemplateSaved", {name: dev.name}), "success");
  };
  const deleteCustomTemplate = (key) => {
    const next = { ...customTemplates }; delete next[key];
    try { localStorage.setItem(TEMPLATES_KEY, JSON.stringify(next)); } catch { noti(t("notiTemplatesFailed"), "error"); return; }
    setCustomTemplates(next);
    noti(t("notiTemplateRemoved"), "info");
  };
  const [dirty, setDirty] = useState(false);
  const lastSavedRef = useRef(JSON.stringify(project));
  const notifTimer = useRef(null);

  /* ─── UNDO ─── */
  const [undoStack, setUndoStack] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const pushUndo = useCallback((label) => {
    setUndoStack(prev => {
      const snap = { label, project: JSON.parse(JSON.stringify(project)), activeRackId };
      const next = [snap, ...prev].slice(0, MAX_UNDO);
      return next;
    });
    setRedoStack([]);
    // Auto-log change
    setProject(prev => {
      const log = prev.changeLog || [];
      const entry = { ts: new Date().toISOString(), action: label, tech: prev.technician || "" };
      return { ...prev, changeLog: [...log, entry].slice(-100) };
    });
  }, [project, activeRackId]);
  const undo = useCallback(() => {
    if (undoStack.length === 0) return;
    const [top, ...rest] = undoStack;
    setRedoStack(prev => [{ label: "redo", project: JSON.parse(JSON.stringify(project)), activeRackId }, ...prev].slice(0, MAX_UNDO));
    setProject(top.project);
    setActiveRackId(top.activeRackId);
    setUndoStack(rest);
    noti(t("notiUndoLabel", {label: top.label}), "info");
  }, [undoStack, project, activeRackId]);
  const redo = useCallback(() => {
    if (redoStack.length === 0) return;
    const [top, ...rest] = redoStack;
    setUndoStack(prev => [{ label: "undo", project: JSON.parse(JSON.stringify(project)), activeRackId }, ...prev].slice(0, MAX_UNDO));
    setProject(top.project);
    setActiveRackId(top.activeRackId);
    setRedoStack(rest);
    noti(`↪ ${t("notiRedo")}`, "info");
  }, [redoStack, project, activeRackId]);

  useEffect(() => {
    const h = e => {
      if ((e.ctrlKey || e.metaKey) && e.key === "z" && !e.shiftKey) { e.preventDefault(); undo(); }
      if ((e.ctrlKey || e.metaKey) && (e.key === "y" || (e.key === "z" && e.shiftKey))) { e.preventDefault(); redo(); }
      if ((e.ctrlKey || e.metaKey) && e.key === "s") { e.preventDefault(); saveJSON(); }
      if (e.key === "Escape") { setSp(null); setCrossSel(null); setCtxMenu(null); setDevCtx(null); setEditDev(null); setEditRack(null); setShowLog(false); setShowSettings(false); }
      if ((e.ctrlKey || e.metaKey) && e.key === "f" && view === "project") { e.preventDefault(); document.querySelector("[data-globalsearch]")?.focus(); }
      if (e.key === "Delete" && selectedDevs.size > 0 && view === "rack" && !editDev) { e.preventDefault(); bulkDeleteSelected(); }
    };
    window.addEventListener("keydown", h); return () => window.removeEventListener("keydown", h);
  }, [undo, redo, selectedDevs, view, editDev]);

  const noti = (msg, type = "success") => { clearTimeout(notifTimer.current); setNotif({ msg, type }); notifTimer.current = setTimeout(() => setNotif(null), 2500); };
  useEffect(() => {
    if (!BOOT_REPORT) return;
    const r = BOOT_REPORT; BOOT_REPORT = null;
    if (r.type === "repaired") noti(t("notiBootRepaired"), "info");
    else if (r.type === "backup") noti(t("notiBootBackup") + " (" + r.backupKey + ")", "info");
    else if (r.type === "ambiguous") noti(t("notiBackupAmbiguous"), "error");
    else if (r.type === "safeMode") noti(t("notiBootSafeMode"), "error");
  }, []);
  const downloadQuarantine = (autosaveOnly) => {
    try {
      const s = localStorage.getItem(QUARANTINE_KEY); if (!s) return;
      let content = s, suffix = "quarantine";
      if (autosaveOnly) { const q = JSON.parse(s); if (!q.keys || typeof q.keys.autosave !== "string") return; content = q.keys.autosave; suffix = "quarantine-autosave"; }
      const blob = new Blob([content], { type: "application/json" });
      const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `rackclick-${suffix}-${new Date().toISOString().slice(0,19).replace(/[:.]/g,"-")}.json`; a.click(); URL.revokeObjectURL(url);
    } catch {}
  };
  const deleteQuarantine = () => {
    if (!confirm(t("quarantineDeleteConfirm"))) return;
    try { localStorage.removeItem(QUARANTINE_KEY); } catch {}
    setQuarantineInfo(null); noti(t("notiQuarantineDeleted"), "info");
  };
  /* v0.8.4 [7]: label rápido por doble clic (solución mínima con prompt) */
  const quickLabel = useCallback((e, did, pid) => {
    const dev = devs.find(d => d.id === did); const port = dev?.ports.find(p => p.id === pid); if (!port) return;
    const nl = prompt(t("promptQuickLabel") + " \u2014 " + dev.name + " #" + port.gn, port.label || "");
    if (nl === null) return;
    pushUndo("Quick label");
    setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, label: nl.trim() || undefined } : p) } : d));
  }, [devs, t]);

  const rack = project.racks.find(r => r.id === activeRackId);
  const devs = rack?.devs || [];
  const conns = rack?.conns || [];
  const setDevs = fn => setProject(prev => ({ ...prev, racks: prev.racks.map(r => r.id === activeRackId ? { ...r, devs: typeof fn === "function" ? fn(r.devs) : fn } : r) }));
  const setConns = fn => setProject(prev => ({ ...prev, racks: prev.racks.map(r => r.id === activeRackId ? { ...r, conns: typeof fn === "function" ? fn(r.conns) : fn } : r) }));
  const setCrossConns = fn => setProject(prev => ({ ...prev, crossConns: typeof fn === "function" ? fn(prev.crossConns || []) : fn }));
  const crossForRack = (project.crossConns || []).filter(c => c.rackFrom === activeRackId || c.rackTo === activeRackId);
  const allConns = [...conns, ...crossForRack];
  const cm = {}; allConns.forEach((c, i) => { cm[c.id] = c.color || CC[i % CC.length]; });
  const usedU = devs.reduce((s, d) => s + d.u, 0);
  const freeU = rack ? rack.size - usedU : 0;
  const otherRacks = project.racks.filter(r => r.id !== activeRackId);
  const rackLookup = {}; (project.racks||[]).forEach(r => { rackLookup[r.id] = r.name; });

  useEffect(() => {
    if (BOOT_SUPPRESS_FIRST_AUTOSAVE) { BOOT_SUPPRESS_FIRST_AUTOSAVE = false; return; }
    /* Autosave honesto (v0.8.3):
       [1] Escritura crítica de SAVE_KEY. Si FALLA: estado ok:false (banner)
           y NO se intenta la rotación de backups en este ciclo (regla aprobada:
           con el almacenamiento lleno, cero escrituras adicionales).
       [2] Rotación de backups SOLO tras éxito de SAVE_KEY, en try propio:
           su fallo no activa el banner (el autosave principal funcionó). */
    let json;
    try { json = JSON.stringify({ ...project, updatedAt: new Date().toISOString() }); }
    catch { setAutosaveStatus(s => ({ ok: false, lastOkAt: s.lastOkAt })); return; }
    try {
      localStorage.setItem(SAVE_KEY, json);
    } catch {
      setAutosaveStatus(s => ({ ok: false, lastOkAt: s.lastOkAt }));
      return;
    }
    setAutosaveStatus({ ok: true, lastOkAt: Date.now() });
    try {
      // Rotate backup every 2 minutes
      const meta = JSON.parse(localStorage.getItem(BACKUP_META) || '{"slot":0,"lastBackup":0}');
      const now = Date.now();
      if (now - meta.lastBackup > 120000) {
        const slot = (meta.slot + 1) % BACKUP_KEYS.length;
        localStorage.setItem(BACKUP_KEYS[slot], json);
        localStorage.setItem(BACKUP_META, JSON.stringify({ slot, lastBackup: now }));
      }
    } catch { console.warn("RackClick: backup rotation failed"); }
  }, [project]);
  useEffect(() => { const current = JSON.stringify(project); setDirty(current !== lastSavedRef.current); }, [project]);
  useEffect(() => { const handler = e => { if (dirty) { e.preventDefault(); e.returnValue = ""; } }; window.addEventListener("beforeunload", handler); return () => window.removeEventListener("beforeunload", handler); }, [dirty]);
  useEffect(() => { document.title = `${dirty ? "● " : ""}RackClick — ${project.name}`; }, [dirty, project.name]);

  /* ─── Rack CRUD ─── */
  const addRack = (name, location, size) => {
    pushUndo("Add rack");
    const id = gid(); setProject(prev => ({ ...prev, racks: [...prev.racks, { id, name, location, size: +size, devs: [], conns: [] }] })); noti(t("notiRackCreated") + `: "${name}"`, "success"); return id;
  };
  const deleteRack = (id) => {
    pushUndo("Delete rack");
    setProject(prev => ({ ...prev, racks: prev.racks.filter(r => r.id !== id), crossConns: (prev.crossConns||[]).filter(c => c.rackFrom !== id && c.rackTo !== id) }));
    if (activeRackId === id) { const remaining = project.racks.filter(r => r.id !== id); if (remaining.length) setActiveRackId(remaining[0].id); }
    setView("project"); noti(t("notiRackDel"),"info");
  };
  const openRack = (id) => { setActiveRackId(id); setView("rack"); setSp(null); setSc(null); setSearch(""); setDevCtx(null); setSelectedDevs(new Set()); };
  const saveRackEdit = (changes) => {
    pushUndo("Edit rack");
    setProject(prev => ({ ...prev, racks: prev.racks.map(r => r.id === (editRack?.id || activeRackId) ? { ...r, ...changes } : r) })); setEditRack(null); noti(t("notiRackUpd"),"success");
  };

  /* ─── Move device to rack ─── */
  const moveDevToRack = (devId, targetRackId) => {
    const srcRack = project.racks.find(r => r.devs.some(d => d.id === devId));
    if (!srcRack) return;
    const dev = srcRack.devs.find(d => d.id === devId);
    const localConns = srcRack.conns.filter(c => c.fd === devId || c.td === devId);
    const crossConnsForDev = (project.crossConns||[]).filter(c => c.fd === devId || c.td === devId);
    const totalAffected = localConns.length + crossConnsForDev.length;
    const targetName = project.racks.find(r => r.id === targetRackId)?.name || "target rack";
    if (totalAffected > 0 && !confirm(t("confirmMoveDevice", {name: dev?.name, rack: targetName, local: localConns.length, cross: crossConnsForDev.length}))) return;
    pushUndo("Move device");
    setProject(prev => {
      let p = { ...prev, racks: prev.racks.map(r => {
        if (r.id === srcRack.id) return { ...r, devs: r.devs.filter(d => d.id !== devId) };
        if (r.id === targetRackId) return { ...r, devs: [...r.devs, dev] };
        return r;
      })};
      const localConns = srcRack.conns.filter(c => c.fd === devId || c.td === devId);
      const stayLocal = [], toCross = [];
      localConns.forEach(c => {
        const otherDev = c.fd === devId ? c.td : c.fd;
        const otherStaysInSrc = srcRack.devs.some(d => d.id === otherDev && d.id !== devId);
        if (otherStaysInSrc) toCross.push({ ...c, rackFrom: srcRack.id, rackTo: targetRackId });
        else stayLocal.push(c);
      });
      p.racks = p.racks.map(r => r.id === srcRack.id ? { ...r, conns: r.conns.filter(c => !localConns.includes(c)) } : r);
      const targetLocalConns = stayLocal.length > 0 ? p.racks.find(r => r.id === targetRackId)?.conns || [] : [];
      if (stayLocal.length) p.racks = p.racks.map(r => r.id === targetRackId ? { ...r, conns: [...r.conns, ...stayLocal] } : r);
      const xc = [...(p.crossConns || [])];
      toCross.forEach(c => xc.push(c));
      const existingCross = xc.filter(c => (c.fd === devId || c.td === devId) && !toCross.some(tc => tc.id === c.id));
      existingCross.forEach(c => {
        if (c.rackFrom === srcRack.id) c.rackFrom = targetRackId;
        if (c.rackTo === srcRack.id) c.rackTo = targetRackId;
      });
      const mergeToLocal = [];
      const finalXc = xc.filter(c => {
        if (c.rackFrom === c.rackTo) { mergeToLocal.push(c); return false; }
        return true;
      });
      if (mergeToLocal.length) {
        p.racks = p.racks.map(r => {
          const mine = mergeToLocal.filter(c => c.rackFrom === r.id);
          if (!mine.length) return r;
          const clean = mine.map(({ rackFrom, rackTo, ...rest }) => rest);
          return { ...r, conns: [...r.conns, ...clean] };
        });
      }
      p.crossConns = finalXc;
      return p;
    });
    setDevCtx(null); noti(`📦 ${t("notiMoved")} ${rackLookup[targetRackId]||"rack"}`, "success");
  };

  /* ─── Save/Load ─── */
  // Snapshot helpers (FIX v0.8.3: estaban definidos DENTRO de saveJSON por
  // error preexistente desde el original — inaccesibles desde el botón 📸 y
  // Settings → "saveSnapshot is not defined". Movidos a scope de componente
  // sin cambiar su lógica.)
  const saveSnapshot = (name) => {
    const snap = { id: Date.now().toString(36), name, date: new Date().toISOString(), data: JSON.stringify(project) };
    const updated = [snap, ...snapshots].slice(0, 20);
    try { localStorage.setItem(SNAPSHOTS_KEY, JSON.stringify(updated)); } catch { noti(t("notiSnapshotsFailed"), "error"); return; }
    setSnapshots(updated);
    noti(t("notiSnapshotSaved"), "success");
  };
  const restoreSnapshot = (snap) => {
    try { const p = JSON.parse(snap.data); setProject(p); noti(t("notiSnapshotRestored"), "success"); } catch { noti(t("notiInvalidJson"), "error"); }
  };
  const deleteSnapshot = (id) => {
    const updated = snapshots.filter(s => s.id !== id);
    try { localStorage.setItem(SNAPSHOTS_KEY, JSON.stringify(updated)); } catch { noti(t("notiSnapshotsFailed"), "error"); return; }
    setSnapshots(updated);
  };
  const saveJSON = () => {
    const p = { ...project, updatedAt: new Date().toISOString() };
    if (!p.createdAt) p.createdAt = p.updatedAt;
    setProject(p);
    // Force backup rotation on manual save
    try { const meta = JSON.parse(localStorage.getItem(BACKUP_META) || '{"slot":0,"lastBackup":0}'); const slot = (meta.slot + 1) % BACKUP_KEYS.length; localStorage.setItem(BACKUP_KEYS[slot], JSON.stringify(p)); localStorage.setItem(BACKUP_META, JSON.stringify({ slot, lastBackup: Date.now() })); } catch {}
    const blob = new Blob([JSON.stringify(p, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `rackclick-${p.name.replace(/\s+/g, "-").toLowerCase()}-${new Date().toISOString().slice(0,10)}.json`; a.click(); URL.revokeObjectURL(url); lastSavedRef.current = JSON.stringify(p); setDirty(false); noti(t("notiSaved"),"success");
  };
  const loadJSON = () => {
    const inp = document.createElement("input"); inp.type = "file"; inp.accept = ".json"; inp.onchange = e => {
      const f = e.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = ev => {
        try {
          const d = JSON.parse(ev.target.result);
          pushUndo("Load project");
          if (d.version === "0.8") {
            const vErr = validateProject(d);
            if (vErr) noti(t("notiFixed", {detail: vErr}), "info");
            setProject(d); setActiveRackId(d.racks[0]?.id); setView("project"); lastSavedRef.current = JSON.stringify(d); setDirty(false); noti(t("notiLoaded"),"success");
          } else if (d.devs) {
            const rid = gid(); const rack = { id: rid, name: d.note || f.name.replace(".json",""), location: "", size: d.rackSize || 24, devs: d.devs, conns: d.conns || [] };
            validateRack(rack);
            setProject(prev => ({ ...prev, racks: [...prev.racks, rack] })); setActiveRackId(rid); setView("rack"); noti(t("notiV07Import"),"success");
          } else { noti(t("notiUnknownFmt"),"error"); }
        } catch { noti(t("notiInvalidJson"),"error"); }
      }; r.readAsText(f);
    }; inp.click();
  };
  const importRackJSON = () => {
    const inp = document.createElement("input"); inp.type = "file"; inp.accept = ".json"; inp.multiple = true; inp.onchange = e => {
      pushUndo("Import racks");
      [...e.target.files].forEach(f => { const r = new FileReader(); r.onload = ev => {
        try {
          const d = JSON.parse(ev.target.result);
          const rid = gid();
          if (d.version === "0.8-rack") {
            const rack = { id: rid, name: d.note || f.name, location: "", size: d.rackSize || 24, devs: d.devs || [], conns: d.conns || [] };
            validateRack(rack);
            setProject(prev => ({ ...prev, racks: [...prev.racks, rack] }));
          } else if (d.devs) {
            const rack = { id: rid, name: d.note || f.name.replace(".json",""), location: "", size: d.rackSize || 24, devs: d.devs, conns: d.conns || [] };
            validateRack(rack);
            setProject(prev => ({ ...prev, racks: [...prev.racks, rack] }));
          } else if (d.version === "0.8") {
            validateProject(d);
            d.racks.forEach(r => setProject(prev => ({ ...prev, racks: [...prev.racks, { ...r, id: gid() }] })));
          } else { noti(t("notiUnknownFile", {name: f.name}), "error"); return; }
          noti(t("notiImportedFile", {name: f.name}), "success");
        } catch { noti(t("notiFailedFile", {name: f.name}), "error"); }
      }; r.readAsText(f); });
    }; inp.click();
  };
  const mergeProject = () => {
    const inp = document.createElement("input"); inp.type = "file"; inp.accept = ".json"; inp.onchange = e => {
      const f = e.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = ev => {
        try {
          const d = JSON.parse(ev.target.result);
          if (d.version !== "0.8") { noti(t("notiOnlyV08"), "error"); return; }
          validateProject(d);
          const existingNames = new Set(project.racks.map(r => r.name));
          let added = 0, skipped = 0;
          pushUndo("Merge project");
          const newRacks = []; const idMap = {};
          d.racks.forEach(r => {
            const newId = gid(); idMap[r.id] = newId;
            const dMap = {}; const newDevs = r.devs.map(dev => { const nid = gid(); dMap[dev.id] = nid; return { ...dev, id: nid, ports: dev.ports.map((p, pi) => ({ ...p, id: `${nid}-p${pi+1}` })) }; });
            const portMap = {}; r.devs.forEach(dev => dev.ports.forEach((p, pi) => { portMap[p.id] = `${dMap[dev.id]}-p${pi+1}`; }));
            const newConns = (r.conns||[]).map(c => ({ ...c, id: gid(), fd: dMap[c.fd]||c.fd, td: dMap[c.td]||c.td, fp: portMap[c.fp]||c.fp, tp: portMap[c.tp]||c.tp }));
            const name = existingNames.has(r.name) ? `${r.name} (merged)` : r.name;
            existingNames.add(name);
            newRacks.push({ id: newId, name, location: r.location, size: r.size, devs: newDevs, conns: newConns });
            added++;
          });
          const newXC = (d.crossConns||[]).map(c => ({ ...c, id: gid(), rackFrom: idMap[c.rackFrom]||c.rackFrom, rackTo: idMap[c.rackTo]||c.rackTo }));
          setProject(prev => ({ ...prev, racks: [...prev.racks, ...newRacks], crossConns: [...(prev.crossConns||[]), ...newXC] }));
          noti(t("notiMergedCounts", {count: added, cross: newXC.length, name: d.name}), "success");
        } catch { noti(t("notiFailedMerge"), "error"); }
      }; r.readAsText(f);
    }; inp.click();
  };
  const exportRack = () => {
    if (!rack) return;
    const data = { version: "0.8-rack", note: rack.name, rackSize: rack.size, devs: rack.devs, conns: rack.conns, exportedFrom: project.name, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `rack-${rack.name.replace(/\s+/g, "-").toLowerCase()}-${new Date().toISOString().slice(0,10)}.json`; a.click(); URL.revokeObjectURL(url); noti(t("notiExportedRack", {name: rack.name}), "success");
  };
  const importCSV = () => {
    if (!rack) return;
    const inp = document.createElement("input"); inp.type = "file"; inp.accept = ".csv,.txt"; inp.onchange = e => {
      const f = e.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = ev => {
        try {
          const lines = ev.target.result.split("\n").map(l => l.trim()).filter(l => l);
          if (lines.length < 2) { noti(t("notiCsvEmpty"), "error"); return; }
          const parseRow = line => { const result = []; let cur = ""; let inQ = false; for (const ch of line) { if (ch === '"') { inQ = !inQ; } else if (ch === ',' && !inQ) { result.push(cur.trim()); cur = ""; } else { cur += ch; } } result.push(cur.trim()); return result; };
          const header = parseRow(lines[0]);
          const fnIdx = header.findIndex(h => /from.*dev/i.test(h));
          const fpIdx = header.findIndex(h => /from.*port/i.test(h));
          const tnIdx = header.findIndex(h => /to.*dev/i.test(h));
          const tpIdx = header.findIndex(h => /to.*port/i.test(h));
          const noteIdx = header.findIndex(h => /cable|note/i.test(h));
          if (fnIdx < 0 || tnIdx < 0) { noti(t("notiCsvCols"), "error"); return; }
          pushUndo("Import CSV");
          let added = 0, skipped = 0;
          for (let i = 1; i < lines.length; i++) {
            const row = parseRow(lines[i]);
            const fromName = row[fnIdx]; const toName = row[tnIdx];
            const fromPortN = fpIdx >= 0 ? +row[fpIdx] : 0; const toPortN = tpIdx >= 0 ? +row[tpIdx] : 0;
            const note = noteIdx >= 0 ? row[noteIdx] : "";
            const fd = devs.find(d => d.name === fromName); const td = devs.find(d => d.name === toName);
            if (!fd || !td) { skipped++; continue; }
            const fp = fromPortN > 0 ? fd.ports.find(p => p.gn === fromPortN) : fd.ports[0];
            const tp = toPortN > 0 ? td.ports.find(p => p.gn === toPortN) : td.ports[0];
            if (!fp || !tp) { skipped++; continue; }
            const already = conns.some(c => (c.fp === fp.id && c.tp === tp.id) || (c.fp === tp.id && c.tp === fp.id));
            if (already) { skipped++; continue; }
            const fpt = PT[fp.type]||PT.rj45; const tpt = PT[tp.type]||PT.rj45;
            setConns(prev => [...prev, { id: gid(), fd: fd.id, fp: fp.id, td: td.id, tp: tp.id, fn: fd.name, tn: td.name, fpn: fp.gn, tpn: tp.gn, fpt: fpt.label, tpt: tpt.label, fpt2: fp.type, tpt2: tp.type, note, createdAt: new Date().toISOString() }]);
            added++;
          }
          noti(t("notiCsvCounts", {added, skipped}), added > 0 ? "success" : "info");
        } catch { noti(t("notiFailedCsv"), "error"); }
      }; r.readAsText(f);
    }; inp.click();
  };
  /* #41 Rack Label / ID Tag */
  const printRackLabel = () => {
    if (!rack) return;
    // v0.8.4: pseudo-barcode eliminado (imprim\u00eda como bloque oscuro sin
    // significado). Sustituido por cuadro de ID legible. QR real: fase posterior a F5, en el frontend nuevo.
    const w = window.open("", "_blank");
    w.document.write(`<!DOCTYPE html><html><head><title>Rack Label</title><style>
      body{font-family:monospace;padding:20px}
      .label{border:2px solid #111;border-radius:8px;padding:16px;width:300px;page-break-inside:avoid}
      .title{font-size:18px;font-weight:900;letter-spacing:1px;margin-bottom:4px}
      .loc{font-size:11px;color:#666;margin-bottom:8px}
      .info{font-size:10px;color:#333;margin-bottom:6px;display:flex;gap:12px}
      .bar{margin:8px 0;font-size:0;line-height:0;white-space:nowrap}
      .id{font-size:7px;color:#999;margin-top:4px}
      .proj{font-size:9px;color:#555;border-top:1px solid #ddd;padding-top:6px;margin-top:8px}
      @media print{body{padding:0}.label{border:2px solid #000}}
    </style></head><body>
    <div class="label">
      <div class="title">RACK: ${htmlEsc(rack.name)}</div>
      <div class="loc">${htmlEsc(rack.location||"No location")}</div>
      <div class="info"><span>${htmlEsc((rack.devs||[]).length)} Devices</span><span>${htmlEsc(rack.size)}U</span><span>${htmlEsc(rack.conns.length)} Links</span></div>
      <div style="border:1.5px solid #000;border-radius:4px;padding:6px 10px;margin:8px 0;font-size:13px;font-weight:900;letter-spacing:2px;text-align:center;background:#fff;color:#000">${htmlEsc(rack.id.toUpperCase())}</div>
      <div class="proj">${htmlEsc(project.name)} | ${htmlEsc(project.technician||"—")} | ${htmlEsc(new Date().toLocaleDateString("de-DE"))}</div>
    </div>
    <script>setTimeout(()=>window.print(),300)<\/script>
    </body></html>`);
  };

  
    /* #37A PNG Detail Export — DOM screenshot via html2canvas */
  const _captureRackDetailCanvas = async ({ scale = 3, transparent = false } = {}) => {
    if (!rack) return null;
    const el = document.getElementById("rack-detail-export");
    if (!el) { noti(t("notiRackAreaMissing"), "error"); return null; }

    let h2c = window.html2canvas;
    if (!h2c) {
      try { h2c = (await import("html2canvas")).default; } catch {}
    }
    if (!h2c) { noti(t("notiCanvasMissing"), "error"); return null; }

    // Neutraliza el zoom para exportar a 100% (captura consistente)
    const prevTransform = el.style.transform;
    const prevTransformOrigin = el.style.transformOrigin;
    const prevWidth = el.style.width;

    try {
      el.style.transform = "scale(1)";
      el.style.transformOrigin = "top left";
      el.style.width = "100%";

      // Espera 2 frames para que el layout se estabilice
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

      const canvas = await h2c(el, {
        scale,
        backgroundColor: transparent ? null : T.bg,
        useCORS: true,
        allowTaint: true,
        logging: false
      });

      return canvas;
    } finally {
      // Restaura estilos (siempre)
      el.style.transform = prevTransform;
      el.style.transformOrigin = prevTransformOrigin;
      el.style.width = prevWidth;
    }
  };

  const exportRackDetailPNG = async ({ scale = 3, transparent = false } = {}) => {
    try {
      const canvas = await _captureRackDetailCanvas({ scale, transparent });
      if (!canvas) return;

      const safe = (rack?.name || "rack").replace(/[^a-z0-9\-_]+/gi, "_");
      const filename = `rack-${safe}@${scale}x${transparent ? "-transparent" : ""}.png`;

      const downloadBlob = (blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      };

      canvas.toBlob((blob) => {
        if (blob) downloadBlob(blob);
        else {
          const a = document.createElement("a");
          a.href = canvas.toDataURL("image/png");
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          a.remove();
        }
      }, "image/png", 1);

      noti(t("notiPngSaved"), "success");
    } catch (e) {
      console.error(e);
      noti(t("notiPngFailed", {detail: e?.message || e}), "error");
    }
  };

  // Para reports: genera dataURL PNG (sin descargar)
  const captureRackDetailPNGDataURL = async ({ scale = 2, transparent = false } = {}) => {
    try {
      const canvas = await _captureRackDetailCanvas({ scale, transparent });
      if (!canvas) return null;
      return canvas.toDataURL("image/png");
    } catch (e) {
      console.error(e);
      return null;
    }
  };




  /* #38 PDF Export — opens print-optimized report */
  const exportPDF = () => {
    if (!rack) return;
    const allC = [...(rack.conns||[]), ...(project.crossConns||[]).filter(c => c.rackFrom === rack.id || c.rackTo === rack.id)];
    const portLabel = (did, pid) => project.racks.flatMap(r => r.devs).find(d => d.id === did)?.ports.find(p => p.id === pid)?.label || "";
    const rackLk = {}; project.racks.forEach(r => rackLk[r.id] = r.name);
    const usedU = rack.devs.reduce((s,d) => s+d.u, 0);
    const connRows = allC.map(c => {
      const xr = c.rackFrom ? `${rackLk[c.rackFrom]||"?"} → ${rackLk[c.rackTo]||"?"}` : "";
      return `<tr><td>${htmlEsc(c.fn||"")}</td><td>${htmlEsc(c.fpt||"")} #${htmlEsc(c.fpn||"")} ${htmlEsc(portLabel(c.fd, c.fp))}</td><td>→</td><td>${htmlEsc(c.tn||"")}</td><td>${htmlEsc(c.tpt||"")} #${htmlEsc(c.tpn||"")} ${htmlEsc(portLabel(c.td, c.tp))}</td><td>${htmlEsc(c.note||"")}</td><td style="color:#a855f7">${htmlEsc(xr)}</td></tr>`;
    }).join("");
    const devRows = rack.devs.map(d => {
      const used = allC.filter(c => c.fd === d.id || c.td === d.id).length;
      return `<tr><td>${htmlEsc(d.icon)} ${htmlEsc(d.name)}</td><td>${htmlEsc(d.preset)}</td><td>${htmlEsc(d.u)}U</td><td>${htmlEsc(d.ports.length)}</td><td>${htmlEsc(used)}</td></tr>`;
    }).join("");
    const w = window.open("", "_blank");
    w.document.write(`<!DOCTYPE html><html><head><title>RackClick Report — ${htmlEsc(rack.name)}</title>
    <style>body{font-family:'Segoe UI',sans-serif;padding:24px;color:#222;font-size:11px}
    h1{font-family:monospace;font-size:18px;margin-bottom:2px} h2{font-size:13px;margin:16px 0 6px;border-bottom:1px solid #ddd;padding-bottom:3px}
    .meta{color:#666;font-size:10px;margin-bottom:16px}
    .stats{display:flex;gap:16px;margin-bottom:12px} .stat{text-align:center;padding:8px 16px;border:1px solid #ddd;border-radius:6px}
    .stat b{display:block;font-size:18px;color:#10b981}
    table{width:100%;border-collapse:collapse;margin-bottom:16px;font-size:10px} th,td{border:1px solid #ddd;padding:4px 8px;text-align:left}
    th{background:#f5f5f5;font-weight:700} tr:nth-child(even){background:#fafafa}
    @media print{body{padding:12px}}</style></head><body>
    <h1>RACK<span style="color:#10b981">CLICK</span> — ${htmlEsc(rack.name)}</h1>
    <div class="meta">${htmlEsc(rack.location||"")} · ${htmlEsc(project.name)} · ${htmlEsc(project.technician||"")} · ${htmlEsc(new Date().toLocaleDateString("de-DE"))}</div>
    <div class="stats"><div class="stat"><b>${htmlEsc((rack.devs||[]).length)}</b>Devices</div><div class="stat"><b>${htmlEsc(usedU)}/${htmlEsc(rack.size)}</b>U Used</div><div class="stat"><b>${htmlEsc(allC.length)}</b>Connections</div></div>
    <h2>Devices</h2>
    <table><tr><th>Device</th><th>Preset</th><th>Size</th><th>Ports</th><th>Connected</th></tr>${devRows}</table>
    <h2>Connections</h2>
    <table><tr><th>From</th><th>Port</th><th></th><th>To</th><th>Port</th><th>Cable/Note</th><th>Cross-Rack</th></tr>${connRows}</table>
    <div style="margin-top:20px;font-size:8px;color:#aaa">Generated by RackClick v${htmlEsc(RC_VERSION)} \u00b7 ${htmlEsc(new Date().toISOString())}</div>
    <script>setTimeout(()=>window.print(),400)<\/script></body></html>`);
    noti(t("notiExportPdf"), "info");
  };

  /* #39 Excel Export — multi-sheet .xls (HTML table format) */
  const exportExcel = () => {
    if (!rack) return;
    const allC = [...(rack.conns||[]), ...(project.crossConns||[]).filter(c => c.rackFrom === rack.id || c.rackTo === rack.id)];
    const portLabel = (did, pid) => project.racks.flatMap(r => r.devs).find(d => d.id === did)?.ports.find(p => p.id === pid)?.label || "";
    const rackLk = {}; project.racks.forEach(r => rackLk[r.id] = r.name);
    let html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets>`;
    html += `<x:ExcelWorksheet><x:Name>Devices</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>`;
    html += `<x:ExcelWorksheet><x:Name>Connections</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>`;
    html += `<x:ExcelWorksheet><x:Name>Summary</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>`;
    html += `</x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body>`;
    // Sheet 1: Devices
    html += `<table x:str border="1"><tr><th>Name</th><th>Preset</th><th>Size (U)</th><th>Ports</th><th>Connected</th><th>Icon</th><th>Color</th></tr>`;
    rack.devs.forEach(d => { const used = allC.filter(c => c.fd === d.id || c.td === d.id).length; html += `<tr><td>${htmlEsc(d.name)}</td><td>${htmlEsc(d.preset)}</td><td>${htmlEsc(d.u)}</td><td>${htmlEsc(d.ports.length)}</td><td>${htmlEsc(used)}</td><td>${htmlEsc(d.icon)}</td><td>${htmlEsc(d.color)}</td></tr>`; });
    html += `</table>`;
    // Sheet 2: Connections
    html += `<table x:str border="1"><tr><th>From Device</th><th>From Port#</th><th>From Type</th><th>From Label</th><th>To Device</th><th>To Port#</th><th>To Type</th><th>To Label</th><th>Cable/Note</th><th>Cross-Rack</th><th>Color</th><th>Created</th></tr>`;
    allC.forEach(c => { const xr = c.rackFrom ? `${rackLk[c.rackFrom]||"?"} → ${rackLk[c.rackTo]||"?"}` : ""; html += `<tr><td>${htmlEsc(c.fn||"")}</td><td>${htmlEsc(c.fpn||"")}</td><td>${htmlEsc(c.fpt||"")}</td><td>${htmlEsc(portLabel(c.fd, c.fp))}</td><td>${htmlEsc(c.tn||"")}</td><td>${htmlEsc(c.tpn||"")}</td><td>${htmlEsc(c.tpt||"")}</td><td>${htmlEsc(portLabel(c.td, c.tp))}</td><td>${htmlEsc(c.note||"")}</td><td>${htmlEsc(xr)}</td><td>${htmlEsc(c.color||"")}</td><td>${htmlEsc(c.createdAt||"")}</td></tr>`; });
    html += `</table>`;
    // Sheet 3: Summary
    const usedU = rack.devs.reduce((s,d) => s+d.u, 0);
    html += `<table x:str border="1"><tr><th>Property</th><th>Value</th></tr>`;
    html += `<tr><td>Rack Name</td><td>${htmlEsc(rack.name)}</td></tr><tr><td>Location</td><td>${htmlEsc(rack.location||"")}</td></tr>`;
    html += `<tr><td>Size</td><td>${htmlEsc(rack.size)}U</td></tr><tr><td>Used</td><td>${htmlEsc(usedU)}U</td></tr><tr><td>Free</td><td>${htmlEsc(rack.size-usedU)}U</td></tr>`;
    html += `<tr><td>Devices</td><td>${htmlEsc((rack.devs||[]).length)}</td></tr><tr><td>Connections</td><td>${htmlEsc(allC.length)}</td></tr>`;
    html += `<tr><td>Project</td><td>${htmlEsc(project.name)}</td></tr><tr><td>Technician</td><td>${htmlEsc(project.technician||"")}</td></tr>`;
    html += `<tr><td>Exported</td><td>${htmlEsc(new Date().toISOString())}</td></tr></table>`;
    html += `</body></html>`;
    const blob = new Blob([html], { type: "application/vnd.ms-excel;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `rack-${rack.name.replace(/\s+/g,"-").toLowerCase()}.xls`; a.click(); URL.revokeObjectURL(url);
    noti(t("notiExportXls"), "success");
  };

  const duplicateRack = (rackId) => {
    const src = project.racks.find(r => r.id === rackId); if (!src) return;
    const withConns = src.conns.length > 0 ? confirm(t("confirmDuplicateRack", {name: src.name, count: src.conns.length})) : false;
    pushUndo("Duplicate rack");
    const newId = gid(); const idMap = {};
    const newDevs = src.devs.map(d => { const nid = gid(); idMap[d.id] = nid; return { ...d, id: nid, ports: d.ports.map((p, pi) => ({ ...p, id: `${nid}-p${pi+1}` })) }; });
    const portMap = {}; src.devs.forEach(d => d.ports.forEach((p, pi) => { portMap[p.id] = `${idMap[d.id]}-p${pi+1}`; }));
    const newConns = withConns ? src.conns.map(c => ({ ...c, id: gid(), fd: idMap[c.fd]||c.fd, td: idMap[c.td]||c.td, fp: portMap[c.fp]||c.fp, tp: portMap[c.tp]||c.tp })) : [];
    setProject(prev => ({ ...prev, racks: [...prev.racks, { id: newId, name: src.name + " (Copy)", location: src.location, size: src.size, devs: newDevs, conns: newConns }] }));
    noti(t("notiDuplicatedRack", {name: src.name, count: newConns.length}), "success");
  };

  /* ─── Device CRUD ─── */
  const addP = k => {
    pushUndo("Add device");
    const p = PRESETS[k] || customTemplates[k]; if (!p) return; const id = gid();
    setDevs(prev => [...prev, { id, name: dn.trim() || p.label, icon: p.icon, color: p.color, u: p.u, ports: mkP(p.ports, id), preset: p.label }]);
    setDn(""); setShowNew(false); noti(t("notiAddedPreset", {name: p.label}), "success");
  };
  const addCustom = () => {
    pushUndo("Add custom device");
    const id = gid();
    setDevs(prev => [...prev, { id, name: cust.name.trim() || "Custom", icon: cust.icon, color: "#6b7280", u: cust.u, ports: mkP(cust.pg, id), preset: "Custom" }]);
    setCust({ name: "", icon: "▦", u: 1, pg: [{ t: "rj45", n: 4 }] }); setDn(""); setShowNew(false); noti(t("notiCustomDev"), "success");
  };
  const delD = id => { const dev = devs.find(d => d.id === id); const cc = allConns.filter(c => c.fd === id || c.td === id).length; if (!confirm(t("confirmDeleteDevice", {name: dev?.name, count: cc}))) return; pushUndo("Delete device"); setDevs(p => p.filter(d => d.id !== id)); setConns(p => p.filter(c => c.fd !== id && c.td !== id)); setCrossConns(p => p.filter(c => c.fd !== id && c.td !== id)); setSp(null); noti(t("notiRemoved"),"info"); };
  const moveD = (id, dir) => { setDevs(prev => { const i = prev.findIndex(d => d.id === id); if (i < 0) return prev; const ni = i + dir; if (ni < 0 || ni >= prev.length) return prev; const a = [...prev]; [a[i], a[ni]] = [a[ni], a[i]]; return a; }); };
  const dragReorder = (fromId, toId) => { if (fromId === toId) { setDragId(null); setDragOverId(null); return; } pushUndo("Reorder devices"); setDevs(prev => { const a = [...prev]; const fi = a.findIndex(d => d.id === fromId); const ti = a.findIndex(d => d.id === toId); if (fi < 0 || ti < 0) return prev; const [item] = a.splice(fi, 1); a.splice(ti, 0, item); return a; }); setDragId(null); setDragOverId(null); };

  /* Touch drag for tablets */
  const onTouchDragStart = useCallback((devId, e) => {
    e.preventDefault(); e.stopPropagation();
    touchDragRef.current = { active: true, id: devId };
    setDragId(devId);
  }, []);
  const onTouchDragMove = useCallback((e) => {
    if (!touchDragRef.current.active) return;
    e.preventDefault();
    const touch = e.touches ? e.touches[0] : e;
    const els = document.elementsFromPoint(touch.clientX, touch.clientY);
    const hit = els.find(el => el.dataset && el.dataset.devid && el.dataset.devid !== touchDragRef.current.id);
    setDragOverId(hit ? hit.dataset.devid : null);
  }, []);
  const onTouchDragEnd = useCallback(() => {
    const td = touchDragRef.current;
    if (!td.active) return;
    touchDragRef.current = { active: false, id: null };
    setDragOverId(prev => { if (prev && td.id !== prev) { dragReorder(td.id, prev); } else { setDragId(null); } return null; });
  }, [dragReorder]);

  const toggleSelectDev = (id, ctrlKey) => {
    setSelectedDevs(prev => {
      const next = new Set(ctrlKey ? prev : []);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const bulkDeleteSelected = () => {
    if (selectedDevs.size === 0) return;
    const totalConns = allConns.filter(c => selectedDevs.has(c.fd) || selectedDevs.has(c.td)).length;
    if (!confirm(t("confirmDeleteDevices", {count: selectedDevs.size, connections: totalConns}))) return;
    pushUndo("Bulk delete");
    setDevs(p => p.filter(d => !selectedDevs.has(d.id)));
    setConns(p => p.filter(c => !selectedDevs.has(c.fd) && !selectedDevs.has(c.td)));
    setCrossConns(p => p.filter(c => !selectedDevs.has(c.fd) && !selectedDevs.has(c.td)));
    setSp(null); setSelectedDevs(new Set()); noti(`🗑 ${selectedDevs.size} ` + t("notiDevicesRemoved"), "info");
  };

  const saveEdit = (changes) => {
    const dev = devs.find(d => d.id === editDev?.id);
    if (!dev) return;
    const { portGroups: pg, ...rest } = changes;
    let ports;
    try { ports = reconcilePorts(dev, pg, project.racks.flatMap(r => r.devs.flatMap(d => d.ports))); }
    catch { noti(t("notiPortEditInvalid"), "error"); return; }
    const kept = new Set(ports.map(p => p.id));
    const removed = dev.ports.filter(p => !kept.has(p.id));
    const ids = new Set(removed.map(p => p.id));
    const touches = c => (c.fd === dev.id && ids.has(c.fp)) || (c.td === dev.id && ids.has(c.tp));
    const affected = [...conns, ...(project.crossConns || [])].filter(touches);
    if (removed.length && !confirm(t("confirmRemovePorts", {
      ports: removed.map(p => `${p.id} (${p.type} #${p.gn})`).join(", "), count: affected.length
    }))) return;
    pushUndo("Edit device");
    setProject(prev => ({ ...prev,
      racks: prev.racks.map(r => r.id !== activeRackId ? r : { ...r,
        devs: r.devs.map(d => d.id === dev.id ? { ...d, ...rest, ports } : d),
        conns: r.conns.filter(c => !touches(c)) }),
      crossConns: (prev.crossConns || []).filter(c => !touches(c))
    }));
    setEditDev(null); noti(t("notiUpdated"), "success");
  };

  /* ─── Port context actions (status, poe, label) ─── */
  const onPortCtx = useCallback((e, did, pid) => {
    const port = devs.find(d => d.id === did)?.ports.find(p => p.id === pid); if (!port) return;
    setCtxMenu({ x: e.clientX, y: e.clientY, did, pid, port });
  }, [devs]);

  const onCtxAction = useCallback((action, value) => {
    if (!ctxMenu) return;
    const { did, pid } = ctxMenu;
    if (action === "label") {
      pushUndo("Set label");
      setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, label: value || undefined } : p) } : d));
      if (value) noti(`🏷 ${value}`, "success"); else noti(t("notiLabelRemoved"), "info");
    } else if (action === "status") {
      pushUndo("Set status");
      setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, status: value === "free" ? undefined : value } : p) } : d));
    } else if (action === "poe") {
      pushUndo("Toggle PoE");
      setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, poe: value, type: value ? "rj45_poe" : "rj45" } : p) } : d));
      noti(t(value ? "notiPoeOn" : "notiPoeOff"), "info");
    } else if (action === "watts") {
      setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, watts: value || undefined } : p) } : d));
    } else if (action === "portColor") {
      pushUndo("Set port color");
      setDevs(prev => prev.map(d => d.id === did ? { ...d, ports: d.ports.map(p => p.id === pid ? { ...p, portColor: value || undefined } : p) } : d));
      if (value) noti(t("notiColorSet"), "success"); else noti(t("notiColorCleared"), "info");
    }
    if (action !== "watts") setCtxMenu(null);
  }, [ctxMenu, pushUndo]);

  const batchPortStatus = useCallback((devId, from, to, status) => {
    pushUndo(`Batch status ${status}`);
    setDevs(prev => prev.map(d => {
      if (d.id !== devId) return d;
      return { ...d, ports: d.ports.map(p => {
        if (p.gn >= from && p.gn <= to) return { ...p, status: status === "free" ? undefined : status };
        return p;
      }) };
    }));
    noti(t("notiPortRange", {from, to, status: PS[status].label}), "success");
  }, [pushUndo]);

  const batchPortColor = useCallback((devId, from, to, color) => {
    pushUndo("Batch port color");
    setDevs(prev => prev.map(d => {
      if (d.id !== devId) return d;
      return { ...d, ports: d.ports.map(p => {
        if (p.gn >= from && p.gn <= to) return { ...p, portColor: color || undefined };
        return p;
      }) };
    }));
    if (color) noti(t("notiPortColors", {from, to}), "success"); else noti(t("notiPortColorsCleared", {from, to}), "info");
  }, [pushUndo]);

  const allowNewPairs = pairs => {
    const seen = new Set();
    const links = [...project.racks.flatMap(r => r.conns), ...(project.crossConns || [])];
    for (const [did, pid] of pairs.flat()) {
      const d = project.racks.flatMap(r => r.devs).find(d => d.id === did);
      const p = d?.ports.find(p => p.id === pid);
      const key = JSON.stringify([did, pid]);
      if (!p || seen.has(key) || ["disabled", "faulty"].includes(p.status)
          || links.some(c => (c.fd === did && c.fp === pid) || (c.td === did && c.tp === pid))) {
        noti(t("notiPortBlocked"), "error"); return false;
      }
      seen.add(key);
    }
    const reserved = pairs.flat().some(([did, pid]) => project.racks.some(r =>
      r.devs.some(d => d.id === did && d.ports.some(p => p.id === pid && p.status === "reserved"))));
    return !reserved || confirm(t("confirmReserved"));
  };

  const startCrossConnect = useCallback((targetRackId) => {
    if (!ctxMenu) return;
    const { did, pid } = ctxMenu;
    const dev = devs.find(d => d.id === did); const port = dev?.ports.find(p => p.id === pid); if (!dev || !port) return;
    const pt = PT[port.type] || PT.rj45;
    setCrossSel({ fromRackId: activeRackId, did, pid, devName: dev.name, portGn: port.gn, portType: pt.label });
    setCtxMenu(null); openRack(targetRackId);
  }, [ctxMenu, devs, activeRackId]);

  /* ─── Port click handler ─── */
  const onPort = useCallback((did, pid) => {
    const dev = devs.find(d => d.id === did); if (!dev) return;
    const port = dev.ports.find(p => p.id === pid); if (!port) return;
    const pt = PT[port.type] || PT.rj45;
    /* v0.8.4 [6]: puertos disabled/faulty no admiten conexiones NUEVAS.
       Si ya tienen conexión, el clic sigue permitido (ver/desconectar). */
    if ((port.status === "disabled" || port.status === "faulty")
        && !allConns.some(c => (c.fd === did && c.fp === pid) || (c.td === did && c.tp === pid))) {
      noti(t("notiPortBlocked"), "error");
      return;
    }
    if (crossSel) {
      const cp = allConns.find(c => c.fp === pid || c.tp === pid);
      if (cp) { setSc(cp); setCrossSel(null); return; }
      const fromRack = project.racks.find(r => r.id === crossSel.fromRackId);
      const fromDev = fromRack?.devs.find(d => d.id === crossSel.did);
      const fromPort = fromDev?.ports.find(p => p.id === crossSel.pid);
      if (!fromPort || crossSel.fromRackId === activeRackId) { noti(t("notiPortBlocked"), "error"); return; }
      if (!allowNewPairs([[[crossSel.did, crossSel.pid], [did, pid]]])) return;
      pushUndo("Cross-rack connect");
      const id = gid();
      const fromPt = PT[fromPort?.type] || PT.rj45;
      const conn = { id, rackFrom: crossSel.fromRackId, rackTo: activeRackId, fd: crossSel.did, fp: crossSel.pid, td: did, tp: pid, fn: fromDev?.name||"?", tn: dev.name, fpn: fromPort?.gn||0, tpn: port.gn, fpt: fromPt.label, tpt: pt.label, fpt2: fromPort?.type||"rj45", tpt2: port.type, createdAt: new Date().toISOString(), ...(getGroupColorForConn(fromDev, dev) ? { color: getGroupColorForConn(fromDev, dev) } : {}) };
      setCrossConns(prev => [...prev, conn]);
      setCrossSel(null); noti(t("notiCrossRack"), "success");
      return;
    }
    const existing = allConns.find(c => (c.fd === did && c.fp === pid) || (c.td === did && c.tp === pid));
    if (existing) { setSc(existing); return; }
    if (!sp) { setSp({ did, pid, devName: dev.name, portGn: port.gn, portType: pt.label }); return; }
    if (sp.pid === pid) { setSp(null); return; }
    if (!allowNewPairs([[[sp.did, sp.pid], [did, pid]]])) return;
    pushUndo("Connect");
    const sDev = devs.find(d => d.id === sp.did); const sPort = sDev?.ports.find(p => p.id === sp.pid); const sPt = PT[sPort?.type] || PT.rj45;
    const id = gid();
    const gc = getGroupColorForConn(sDev, dev);
    setConns(prev => [...prev, { id, fd: sp.did, fp: sp.pid, td: did, tp: pid, fn: sDev?.name||"?", tn: dev.name, fpn: sPort?.gn||0, tpn: port.gn, fpt: sPt.label, tpt: pt.label, fpt2: sPort?.type||"rj45", tpt2: port.type, createdAt: new Date().toISOString(), ...(gc ? { color: gc } : {}) }]);
    setFlashPorts(new Set([sp.pid, pid])); setTimeout(() => setFlashPorts(new Set()), 800);
    setSp(null); noti(t("connected"), "success");
  }, [sp, devs, conns, allConns, crossSel, activeRackId, project, pushUndo, groupColors]);

  /* ─── Connection actions ─── */
  const delCn = id => { pushUndo("Disconnect"); const isLocal = conns.some(c => c.id === id); if (isLocal) setConns(p => p.filter(c => c.id !== id)); else setCrossConns(p => p.filter(c => c.id !== id)); setSc(null); noti(t("disconnected"),"info"); };
  const updateConnNote = (id, note) => {
    const isLocal = conns.some(c => c.id === id);
    if (isLocal) setConns(prev => prev.map(c => c.id === id ? { ...c, note } : c));
    else setCrossConns(prev => prev.map(c => c.id === id ? { ...c, note } : c));
  };
  const updateConnField = (id, field, value) => {
    const isLocal = conns.some(c => c.id === id);
    if (isLocal) setConns(prev => prev.map(c => c.id === id ? { ...c, [field]: value || undefined } : c));
    else setCrossConns(prev => prev.map(c => c.id === id ? { ...c, [field]: value || undefined } : c));
  };

  /* ─── Bulk connect ─── */
  const doBulkConnect = (srcDev, tgtDev, pairs) => {
    if (!pairs.length || !allowNewPairs(pairs.map(({ sp, tp }) => [[srcDev.id, sp.id], [tgtDev.id, tp.id]]))) return;
    pushUndo(`Bulk connect ${pairs.length}`);
    const srcPt = PT[pairs[0].sp.type] || PT.rj45;
    const tgtPt = PT[pairs[0].tp.type] || PT.rj45;
    const gc = getGroupColorForConn(srcDev, tgtDev);
    const newConns = pairs.map(({ sp: s, tp: t }) => ({
      id: gid(), fd: srcDev.id, fp: s.id, td: tgtDev.id, tp: t.id,
      fn: srcDev.name, tn: tgtDev.name, fpn: s.gn, tpn: t.gn,
      fpt: srcPt.label, tpt: tgtPt.label, fpt2: s.type, tpt2: t.type, createdAt: new Date().toISOString(), ...(gc ? { color: gc } : {})
    }));
    setConns(prev => [...prev, ...newConns]);
    setShowBulk(false);
    const fp = new Set(); pairs.forEach(({ sp: s, tp: t }) => { fp.add(s.id); fp.add(t.id); }); setFlashPorts(fp); setTimeout(() => setFlashPorts(new Set()), 800);
    noti(t("notiBulkConnections", {count: pairs.length}), "success");
  };

  const onDevCtx = useCallback((e, dev) => { e.preventDefault(); setDevCtx({ x: e.clientX, y: e.clientY, dev }); }, []);

  /* ─── Demo ─── */
  const newProject = () => { if (!confirm(t("confirmNewProject"))) return; pushUndo("New project"); setProject(emptyProject()); setActiveRackId(null); setView("project"); noti(t("notiNewProj"),"info"); };

  const loadDemo = () => {
    pushUndo("Load demo");
    const ids1 = Array.from({length:5}, () => gid()), ids2 = Array.from({length:3}, () => gid());
    const r1 = gid(), r2 = gid();
    const d1 = [
      { id: ids1[0], name: "PP-KEL-01", icon: "▥", color: "#2a9d8f", u: 1, preset: "Patch Panel 24P", ports: mkP([{t:"rj45",n:24}], ids1[0]) },
      { id: ids1[1], name: "SW-CORE-01", icon: "⇋", color: "#e76f51", u: 1, preset: "Switch 48P PoE", ports: mkP([{t:"rj45_poe",n:48},{t:"sfp",n:4},{t:"mgmt",n:1}], ids1[1]) },
      { id: ids1[2], name: "SRV-APP-01", icon: "▦", color: "#457b9d", u: 2, preset: "Server 2U", ports: mkP([{t:"rj45",n:4},{t:"sfp",n:2},{t:"mgmt",n:1}], ids1[2]) },
      { id: ids1[3], name: "NAS-BACKUP", icon: "▤", color: "#7c3aed", u: 4, preset: "NAS 4U", ports: mkP([{t:"rj45",n:4},{t:"sfp",n:2},{t:"mgmt",n:1}], ids1[3]) },
      { id: ids1[4], name: "USV-2200", icon: "🔋", color: "#eab308", u: 2, preset: "UPS 2U", ports: mkP([{t:"power",n:4},{t:"mgmt",n:1},{t:"usb_a",n:1}], ids1[4]) },
    ];
    // Port labels on patch panel
    d1[0].ports[0].label = "Büro 101 A"; d1[0].ports[1].label = "Büro 101 B"; d1[0].ports[2].label = "Büro 102 A";
    d1[0].ports[3].label = "Büro 102 B"; d1[0].ports[4].label = "Konferenz 1"; d1[0].ports[5].label = "Empfang";
    const c1 = [];
    for (let i = 0; i < 6; i++) c1.push({ id: gid(), fd: ids1[0], fp: `${ids1[0]}-p${i+1}`, td: ids1[1], tp: `${ids1[1]}-p${i+1}`, fn: "PP-KEL-01", tn: "SW-CORE-01", fpn: i+1, tpn: i+1, fpt: "RJ45", tpt: "RJ45 PoE", fpt2: "rj45", tpt2: "rj45_poe", note: `Cat6a ${i<4?"3m":"5m"} blau` });
    c1.push({ id: gid(), fd: ids1[1], fp: `${ids1[1]}-p49`, td: ids1[2], tp: `${ids1[2]}-p5`, fn: "SW-CORE-01", tn: "SRV-APP-01", fpn: 1, tpn: 1, fpt: "SFP/SFP+", tpt: "SFP/SFP+", fpt2: "sfp", tpt2: "sfp", note: "LWL OS2 3m gelb" });
    c1.push({ id: gid(), fd: ids1[1], fp: `${ids1[1]}-p50`, td: ids1[3], tp: `${ids1[3]}-p5`, fn: "SW-CORE-01", tn: "NAS-BACKUP", fpn: 2, tpn: 1, fpt: "SFP/SFP+", tpt: "SFP/SFP+", fpt2: "sfp", tpt2: "sfp", note: "LWL OM3 5m aqua" });
    const d2 = [
      { id: ids2[0], name: "PP-EG-01", icon: "▥", color: "#2a9d8f", u: 1, preset: "Patch Panel 24P", ports: mkP([{t:"rj45",n:24}], ids2[0]) },
      { id: ids2[1], name: "SW-EG-01", icon: "⇋", color: "#e76f51", u: 1, preset: "Switch 24P PoE", ports: mkP([{t:"rj45_poe",n:24},{t:"sfp",n:2},{t:"mgmt",n:1},{t:"console",n:1}], ids2[1]) },
      { id: ids2[2], name: "FW-EDGE", icon: "⛨", color: "#d97706", u: 1, preset: "Firewall", ports: mkP([{t:"rj45",n:8},{t:"sfp",n:2},{t:"mgmt",n:1}], ids2[2]) },
    ];
    d2[0].ports[0].label = "AP Flur"; d2[0].ports[1].label = "AP Meetingraum"; d2[0].ports[2].label = "Drucker EG";
    const c2 = [];
    for (let i = 0; i < 3; i++) c2.push({ id: gid(), fd: ids2[0], fp: `${ids2[0]}-p${i+1}`, td: ids2[1], tp: `${ids2[1]}-p${i+1}`, fn: "PP-EG-01", tn: "SW-EG-01", fpn: i+1, tpn: i+1, fpt: "RJ45", tpt: "RJ45 PoE", fpt2: "rj45", tpt2: "rj45_poe", note: "Cat6a 2m grau" });
    const xc = [{ id: gid(), rackFrom: r1, rackTo: r2, fd: ids1[1], fp: `${ids1[1]}-p51`, td: ids2[2], tp: `${ids2[2]}-p9`, fn: "SW-CORE-01", tn: "FW-EDGE", fpn: 3, tpn: 1, fpt: "SFP/SFP+", tpt: "SFP/SFP+", fpt2: "sfp", tpt2: "sfp", note: "LWL OS2 50m Keller→EG" }];
    setProject({ version: "0.8", name: "Demo Project", racks: [
      { id: r1, name: "Hauptverteiler", location: "Keller", size: 24, devs: d1, conns: c1 },
      { id: r2, name: "Etagenverteiler", location: "EG", size: 12, devs: d2, conns: c2 },
    ], crossConns: xc });
    setActiveRackId(r1); setView("project"); noti(t("notiDemo"), "success");
  };

  /* ─── Search/Filter ─── */
  const sq = search.trim().toLowerCase();
  const filtDevs = sq ? devs.filter(d => d.name.toLowerCase().includes(sq) || d.preset.toLowerCase().includes(sq) || d.ports.some(p => p.label?.toLowerCase().includes(sq))) : devs;
  const displayDevs = rackFace === "rear" ? [...filtDevs].reverse() : filtDevs;
  const filtConns = sq ? allConns.filter(c => c.fn.toLowerCase().includes(sq) || c.tn.toLowerCase().includes(sq) || c.note?.toLowerCase().includes(sq)) : allConns;

  /* ═══════ ROUTING ═══════ */
  if (view === "projectReport") return <ProjectReportPage project={project} onBack={() => setView("project")} lang={lang} T={T} ptColors={ptColors} rackFace={rackFace} />;
  if (view === "report" && rack) return <ReportPage rack={rack} rackPng={rackReportPng} cm={cm} crossConns={project.crossConns||[]} rackLookup={rackLookup} onBack={() => { setView("rack"); setRackReportPng(null); }} lang={lang} projectMeta={{ technician: project.technician, createdAt: project.createdAt, updatedAt: project.updatedAt, logo: project.logo, changeLog: project.changeLog }} />;

  /* ═══════ PROJECT VIEW ═══════ */
  if (view === "project" || !rack) return (
    <div className="rc-app" style={{ minHeight: "100vh", background: T.bg, color: T.txt, fontFamily: "monospace", padding: 0 }}>
      <style>{`
        .rc-app input, .rc-app select { background: ${T.inp} !important; border-color: ${T.bdr} !important; color: ${T.txt} !important; }
        .rc-app input::placeholder { color: ${T.vdim} !important; }
      `}</style>
      {editRack && <RackEditModal rack={editRack} onSave={saveRackEdit} onClose={() => setEditRack(null)} t={t} onDelete={project.racks.length > 1 ? deleteRack : null} />}

      {/* #28: Change Log Modal */}
      {showLog && <div onClick={() => setShowLog(false)} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
        <div onClick={e => e.stopPropagation()} style={{ background: T.bg2, border: `1px solid ${T.bdr}`, borderRadius: 12, padding: 24, minWidth: 400, maxWidth: 520, maxHeight: "70vh", display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <span style={{ fontSize: 14, fontWeight: 800 }}>📜 Änderungs-Log</span>
            <div style={{ display: "flex", gap: 6 }}>
              <button onClick={() => { if (confirm(t("confirmClearLog"))) { setProject(prev => ({ ...prev, changeLog: [] })); setShowLog(false); noti(t("notiLogCleared"), "info"); } }} style={{ padding: "3px 8px", background: "#ef444408", border: "1px solid #ef444422", color: "#ef4444", borderRadius: 4, cursor: "pointer", fontSize: 8, fontFamily: "inherit" }}>Clear</button>
              <button onClick={() => setShowLog(false)} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: 14 }}>×</button>
            </div>
          </div>
          <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 1 }}>
            {(project.changeLog||[]).slice().reverse().map((e, i) => (
              <div key={i} style={{ display: "flex", gap: 8, fontSize: 9, color: T.dim, padding: "3px 0", borderBottom: `1px solid ${T.bg3}` }}>
                <span style={{ color: T.mut, minWidth: 100, fontSize: 8, fontFamily: "monospace" }}>{new Date(e.ts).toLocaleString("de-DE", { dateStyle: "short", timeStyle: "short" })}</span>
                <span style={{ fontWeight: 600, color: T.txt }}>{e.action}</span>
                {e.tech && <span style={{ color: T.mut, marginLeft: "auto", fontSize: 8 }}>👷 {e.tech}</span>}
              </div>
            ))}
            {(project.changeLog||[]).length === 0 && <div style={{ fontSize: 10, color: T.vdim, textAlign: "center", padding: 20 }}>No log entries yet</div>}
          </div>
        </div>
      </div>}

      {/* ═══ SETTINGS MODAL ═══ */}
      {showSettings && <div onClick={() => setShowSettings(false)} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
        <div onClick={e => e.stopPropagation()} style={{ background: T.bg2, border: `1px solid ${T.bdr}`, borderRadius: 12, padding: 24, width: 480, maxHeight: "80vh", overflowY: "auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <span style={{ fontSize: 14, fontWeight: 800, color: T.txt }}>⚙️ Settings</span>
            <button onClick={() => setShowSettings(false)} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: 16 }}>×</button>
          </div>

          {/* Language */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 9, color: T.dim, fontWeight: 700, letterSpacing: 0.5, marginBottom: 6 }}>🌐 {t("language")}</div>
            <div style={{ display: "flex", gap: 4 }}>
              {[["en","🇬🇧 English"],["de","🇩🇪 Deutsch"],["es","🇪🇸 Español"]].map(([id,label]) => (
                <button key={id} onClick={() => switchLang(id)} style={{ flex: 1, padding: "8px 4px", background: lang === id ? T.acc+"22" : T.bg3, border: `2px solid ${lang === id ? T.acc : T.bdr}`, color: lang === id ? T.acc : T.dim, borderRadius: 6, cursor: "pointer", fontSize: 9, fontFamily: "inherit", fontWeight: lang === id ? 700 : 400 }}>{label}</button>
              ))}
            </div>
          </div>

          {/* Theme */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 9, color: T.dim, fontWeight: 700, letterSpacing: 0.5, marginBottom: 6 }}>{`🎨 ${t("theme")}`}</div>
            <div style={{ display: "flex", gap: 4 }}>
              {Object.values(THEMES).map(t => (
                <button key={t.id} onClick={() => switchTheme(t.id)} style={{ flex: 1, padding: "8px 4px", background: themeId === t.id ? T.acc+"22" : T.bg3, border: `2px solid ${themeId === t.id ? T.acc : T.bdr}`, color: themeId === t.id ? T.acc : T.dim, borderRadius: 6, cursor: "pointer", fontSize: 9, fontFamily: "inherit", fontWeight: themeId === t.id ? 700 : 400 }}>{t.label}</button>
              ))}
            </div>
          </div>

          {/* Port Type Colors */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 9, color: T.dim, fontWeight: 700, letterSpacing: 0.5, marginBottom: 6 }}>{`🔌 ${t("portColors")}`}</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
              {Object.entries(PT).map(([key, pt]) => (
                <div key={key} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 8px", background: T.bg3, borderRadius: 4, border: `1px solid ${T.bdr}` }}>
                  <input type="color" value={ptColors[key] || pt.color} onChange={e => setPtColor(key, e.target.value)} style={{ width: 20, height: 20, border: "none", cursor: "pointer", padding: 0, background: "none" }} />
                  <span style={{ fontSize: 9, color: T.txt, flex: 1 }}>{pt.label}</span>
                  {ptColors[key] !== DEFAULT_PT_COLORS[key] && <button onClick={() => setPtColor(key, DEFAULT_PT_COLORS[key])} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: 7 }}>↺</button>}
                </div>
              ))}
            </div>
            <button onClick={() => { setPtColors({...DEFAULT_PT_COLORS}); try { localStorage.removeItem(PT_COLOR_KEY); } catch {} }} style={{ marginTop: 4, padding: "3px 8px", background: "none", border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 3, cursor: "pointer", fontSize: 7, fontFamily: "inherit" }}>{`↺ ${t("resetAll")}`}</button>
          </div>

          {/* Group Connection Colors */}
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 9, color: T.dim, fontWeight: 700, letterSpacing: 0.5, marginBottom: 4 }}>{`🔗 ${t("groupColors")}`}</div>
            <div style={{ fontSize: 7, color: T.mut, marginBottom: 6 }}>{t("groupHint")}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
              {(() => { const cats = Object.keys(DEV_CATEGORIES); const pairs = []; for (let i = 0; i < cats.length; i++) for (let j = i; j < cats.length; j++) pairs.push([cats[i], cats[j]].sort().join("↔")); return pairs; })().map(pair => (
                <div key={pair} style={{ display: "flex", alignItems: "center", gap: 6, padding: "3px 8px", background: T.bg3, borderRadius: 4, border: `1px solid ${T.bdr}` }}>
                  <span style={{ fontSize: 8, color: T.txt, flex: 1, fontWeight: 600 }}>{pair}</span>
                  <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
                    {["#ffffff","#d1d5db","#fbbf24","#3b82f6","#10b981","#ef4444","#a855f7","#f97316","#06b6d4","#000000"].map(c => (
                      <div key={c} onClick={() => setGroupColor(pair, groupColors[pair] === c ? null : c)}
                        style={{ width: 14, height: 14, borderRadius: 3, background: c, border: `2px solid ${groupColors[pair] === c ? T.acc : c === "#ffffff" ? "#ccc" : c}`, cursor: "pointer", boxShadow: groupColors[pair] === c ? `0 0 4px ${T.acc}` : "none" }} />
                    ))}
                    {groupColors[pair] && <button onClick={() => setGroupColor(pair, null)} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: 7, padding: "0 2px" }}>×</button>}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Snapshots */}
          <div style={{ marginBottom: 12 }}>
            <div onClick={() => setShowSnapshots(!showSnapshots)} style={{ fontSize: 9, color: T.dim, fontWeight: 700, letterSpacing: 0.5, marginBottom: 4, cursor: "pointer" }}>{"📸 " + t("snapshots") + " (" + snapshots.length + ") " + (showSnapshots ? "▼" : "▶")}</div>
            {showSnapshots && <div style={{ maxHeight: 180, overflowY: "auto", display: "flex", flexDirection: "column", gap: 4 }}>
              {snapshots.length === 0 && <div style={{ fontSize: 9, color: T.dim, padding: 8 }}>{t("noSnapshots")}</div>}
              {snapshots.map(snap => <div key={snap.id} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 6px", background: T.bg3, borderRadius: 4, fontSize: 9 }}>
                <span style={{ flex: 1, color: T.txt, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={snap.name}>{snap.name}</span>
                <span style={{ color: T.dim, fontSize: 7, flexShrink: 0 }}>{new Date(snap.date).toLocaleDateString()}</span>
                <button onClick={e => { e.stopPropagation(); if (confirm(t("restoreSnapshot") + ": " + snap.name + "?")) restoreSnapshot(snap); }} style={{ background: "#10b98112", border: "1px solid #10b98133", color: "#10b981", borderRadius: 3, cursor: "pointer", fontSize: 7, padding: "2px 5px", fontFamily: "inherit" }}>{t("restoreSnapshot")}</button>
                <button onClick={e => { e.stopPropagation(); deleteSnapshot(snap.id); }} style={{ background: "#ef444412", border: "1px solid #ef444433", color: "#ef4444", borderRadius: 3, cursor: "pointer", fontSize: 7, padding: "2px 5px", fontFamily: "inherit" }}>{t("deleteSnapshot")}</button>
              </div>)}
            </div>}
          </div>

          {/* Quarantine (v0.8.2) */}
          {quarantineInfo && <div style={{ marginBottom: 12, border: "1px solid #ef444433", borderRadius: 8, padding: 10, background: "#ef444408" }}>
            <div style={{ fontSize: 9, color: "#ef4444", fontWeight: 700, letterSpacing: 0.5, marginBottom: 4 }}>{"\uD83D\uDEDF " + t("quarantine")}</div>
            <div style={{ fontSize: 8, color: T.dim, marginBottom: 4 }}>{t("quarantineInfo")}</div>
            <div style={{ fontSize: 8, color: T.mut, marginBottom: 8 }}>{t("quarantineCreatedAt") + ": " + new Date(quarantineInfo.createdAt).toLocaleString() + " \u00b7 " + t("quarantineReason") + ": " + quarantineInfo.reason}</div>
            <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
              <button onClick={() => downloadQuarantine(false)} style={{ padding: "5px 8px", background: "#10b98112", border: "1px solid #10b98133", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: 8, fontFamily: "inherit", fontWeight: 700 }}>{"\uD83D\uDCE5 " + t("quarantineDownload")}</button>
              {quarantineInfo.hasAutosave && <button onClick={() => downloadQuarantine(true)} style={{ padding: "5px 8px", background: "#3b82f612", border: "1px solid #3b82f633", color: "#3b82f6", borderRadius: 4, cursor: "pointer", fontSize: 8, fontFamily: "inherit", fontWeight: 700 }}>{"\uD83D\uDCE5 " + t("quarantineDownloadAutosave")}</button>}
              <button onClick={deleteQuarantine} style={{ padding: "5px 8px", background: "#ef444412", border: "1px solid #ef444433", color: "#ef4444", borderRadius: 4, cursor: "pointer", fontSize: 8, fontFamily: "inherit", fontWeight: 700 }}>{"\uD83D\uDDD1 " + t("quarantineDelete")}</button>
            </div>
          </div>}
        </div>
      </div>}

            {autosaveStatus.ok === false && <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 3000, background: "#7f1d1d", borderTop: "2px solid #ef4444", padding: "10px 16px", display: "flex", alignItems: "center", justifyContent: "center", gap: 12, flexWrap: "wrap" }}>
        <span style={{ color: "#fecaca", fontSize: 11, fontWeight: 700 }}>{"\u26A0\uFE0F " + t("autosaveBannerTitle") + " \u2014 " + t("autosaveBannerText")}</span>
        <button onClick={saveJSON} style={{ padding: "6px 12px", background: "#ef4444", border: "none", color: "#fff", borderRadius: 4, cursor: "pointer", fontSize: 10, fontWeight: 900, fontFamily: "inherit" }}>{"\uD83D\uDCBE " + t("autosaveExportNow")}</button>
      </div>}
      {notif && <div style={{ position: "fixed", top: 12, left: "50%", transform: "translateX(-50%)", zIndex: 2000, padding: "6px 18px", borderRadius: 8, fontSize: 11, fontWeight: 700, background: notif.type === "error" ? "#ef4444" : notif.type === "info" ? "#3b82f6" : "#10b981", color: "#fff", boxShadow: "0 4px 12px #000a" }}>{notif.msg}</div>}
      <div style={{ padding: "14px 20px 8px", display: "flex", alignItems: "center", gap: 12, borderBottom: `1px solid ${T.bg3}`, flexWrap: "wrap" }}>
        <span style={{ fontSize: 17, fontWeight: 900, letterSpacing: 1, color: T.txt }}>RACK<span style={{ color: T.acc }}>CLICK</span></span>
        <span style={{ fontSize: 9, color: T.vdim }}>v0.8</span>
        <span title={t("autosaveLabel")} style={{ fontSize: 9, color: autosaveStatus.ok === false ? "#ef4444" : T.vdim, fontWeight: autosaveStatus.ok === false ? 900 : 400 }}>
          {autosaveStatus.ok === true && ("\uD83D\uDCBE \u2713 " + new Date(autosaveStatus.lastOkAt).toLocaleTimeString("de-DE"))}
          {autosaveStatus.ok === false && ("\uD83D\uDCBE \u2717 " + t("autosaveFailing"))}
        </span>
        <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
          {Object.values(THEMES).map(t => (
            <button key={t.id} onClick={() => switchTheme(t.id)} style={{ padding: "2px 5px", background: themeId === t.id ? T.acc+"22" : "transparent", border: `1px solid ${themeId === t.id ? T.acc : T.bdr}`, color: themeId === t.id ? T.acc : T.mut, borderRadius: 3, cursor: "pointer", fontSize: 7, fontFamily: "inherit" }}>{t.label}</button>
          ))}
          <button onClick={() => setShowSettings(true)} style={{ padding: "2px 6px", background: T.bg2, border: `1px solid ${T.bdr}`, color: T.dim, borderRadius: 3, cursor: "pointer", fontSize: 8, fontFamily: "inherit", marginLeft: 4 }}>⚙️</button>
        </div>
        <div style={{ marginLeft: "auto", display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
          <button onClick={saveJSON} style={{ padding: "4px 10px", background: dirty ? "#10b98125" : "#10b98108", border: `1px solid ${dirty ? "#10b981" : "#10b98133"}`, color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit", position: "relative" }}>{dirty && <span style={{ position: "absolute", top: -2, right: -2, width: 6, height: 6, borderRadius: "50%", background: "#ef4444" }} />}{`💾 ${t("save")}${dirty ? " *" : ""}`}</button>
          <button onClick={() => { const name = prompt(t("snapshotName"), project.name + " " + new Date().toLocaleDateString()); if (name) saveSnapshot(name); }} style={{ padding: "4px 10px", background: "#f59e0b08", border: "1px solid #f59e0b33", color: "#f59e0b", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>{"📸 " + t("snapshot")}</button>
          <button onClick={loadJSON} style={{ padding: "4px 10px", background: "#3b82f608", border: "1px solid #3b82f633", color: "#3b82f6", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>{`📂 ${t("load")}`}</button>
          <button onClick={mergeProject} title="Merge another project into this one" style={{ padding: "4px 10px", background: "#a855f708", border: "1px solid #a855f733", color: "#a855f7", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>{`🔀 ${t("merge")}`}</button>
          <button onClick={importRackJSON} style={{ padding: "4px 10px", background: "#a855f708", border: "1px solid #a855f733", color: "#a855f7", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>{`📥 ${t("import")}`}</button>
          {project.racks.length > 0 && <button onClick={() => setView("projectReport")} style={{ padding: "4px 14px", background: "#f59e0b12", border: "1px solid #f59e0b44", color: "#f59e0b", borderRadius: 4, cursor: "pointer", fontSize: 10, fontWeight: 700, fontFamily: "inherit" }}>{`📊 ${t("report")}`}</button>}
          <button onClick={loadDemo} style={{ padding: "4px 10px", background: T.bg3, border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>{t("demo")}</button>
          <button onClick={newProject} title="Neues Projekt / New Project" style={{ padding: "4px 10px", background: "#ef444408", border: "1px solid #ef444422", color: "#ef4444", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>{`🗑 ${t("newProj")}`}</button>
        </div>
      </div>
      <div style={{ padding: "16px 20px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 8 }}>
          <input value={project.name} onChange={e => setProject(prev => ({ ...prev, name: e.target.value }))} style={{ background: "none", border: "none", color: T.txt, fontSize: 20, fontWeight: 900, fontFamily: "monospace", outline: "none", padding: 0, maxWidth: 400 }} />
          <div style={{ display: "flex", gap: 12, alignItems: "center", marginTop: 2 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <span style={{ fontSize: 8, color: T.vdim }}>👷</span>
              <input value={project.technician || ""} onChange={e => setProject(prev => ({ ...prev, technician: e.target.value }))} placeholder="Techniker..." style={{ background: "none", border: "none", borderBottom: `1px solid ${T.bdr}`, color: T.dim, fontSize: 10, fontFamily: "monospace", outline: "none", padding: "1px 4px", width: 140 }} />
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              {project.logo ? <img src={project.logo} style={{ height: 20, borderRadius: 3, border: `1px solid ${T.bdr}` }} alt="Logo" /> : null}
              <button onClick={() => { const inp = document.createElement("input"); inp.type = "file"; inp.accept = "image/*"; inp.onchange = e => { const f = e.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = ev => { setProject(prev => ({ ...prev, logo: ev.target.result })); noti(t("notiLogoSet"), "success"); }; r.readAsDataURL(f); }; inp.click(); }} style={{ padding: "2px 6px", background: "none", border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 3, cursor: "pointer", fontSize: 7, fontFamily: "inherit" }}>{project.logo ? "🖼" : "🖼 Logo"}</button>
              {project.logo && <button onClick={() => { setProject(prev => ({ ...prev, logo: undefined })); noti(t("notiLogoRemoved"), "info"); }} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: 8 }}>×</button>}
            </div>
            {project.updatedAt && <span style={{ fontSize: 8, color: T.vdim }}>📅 {new Date(project.updatedAt).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })}</span>}
            {(project.changeLog||[]).length > 0 && <button onClick={() => setShowLog(true)} style={{ padding: "2px 6px", background: "none", border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 3, cursor: "pointer", fontSize: 7, fontFamily: "inherit" }}>📜 Log ({(project.changeLog||[]).length})</button>}
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            {[{ v: project.racks.length, l: "Racks", c: "#10b981" },{ v: (project.racks||[]).reduce((s, r) => s + ((r.devs||[]).length), 0), l: "Devices", c: "#3b82f6" },{ v: project.racks.reduce((s, r) => s + (r.conns||[]).length, 0) + (project.crossConns||[]).length, l: "Connections", c: "#f59e0b" },...((project.crossConns||[]).length > 0 ? [{ v: (project.crossConns||[]).length, l: "🔗 Cross-rack", c: "#a855f7" }] : [])].map((s, i) => (
              <div key={i} style={{ background: T.bg2, borderRadius: 8, padding: "8px 14px", textAlign: "center", border: `1px solid ${T.bdr}` }}>
                <div style={{ fontSize: 18, fontWeight: 900, color: s.c }}>{s.v}</div>
                <div style={{ fontSize: 7, color: T.vdim, textTransform: "uppercase" }}>{s.l}</div>
              </div>))}
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 12, marginBottom: 16 }}>
          {/* Global search */}
          <div style={{ gridColumn: "1 / -1", marginBottom: 4 }}>
            <input data-globalsearch="1" placeholder={t("globalSearch")} value={globalSearch} onChange={e => setGlobalSearch(e.target.value)} style={{ width: "100%", background: T.bg2, border: `1px solid ${T.bdr}`, color: T.txt, padding: "8px 12px", borderRadius: 6, fontSize: 11, fontFamily: "inherit", outline: "none", boxSizing: "border-box" }} />
            {globalSearch.trim() && (() => {
              const gsq = globalSearch.trim().toLowerCase();
              const results = [];
              project.racks.forEach(r => {
                r.devs.forEach(d => {
                  const match = d.name.toLowerCase().includes(gsq) || d.preset.toLowerCase().includes(gsq) || (d.notes && Object.values(d.notes).some(v => v && String(v).toLowerCase().includes(gsq)));
                  const matchingPorts = d.ports.filter(p => p.label && p.label.toLowerCase().includes(gsq));
                  if (match || matchingPorts.length > 0) results.push({ rack: r, dev: d, ports: matchingPorts, type: "dev" });
                });
                (r.conns||[]).forEach(c => { if (c.fn.toLowerCase().includes(gsq) || c.tn.toLowerCase().includes(gsq) || (c.note && c.note.toLowerCase().includes(gsq))) results.push({ rack: r, conn: c, type: "conn" }); });
              });
              (project.crossConns||[]).forEach(c => { if (c.fn.toLowerCase().includes(gsq) || c.tn.toLowerCase().includes(gsq) || (c.note && c.note.toLowerCase().includes(gsq))) results.push({ rack: project.racks.find(r => r.id === c.rackFrom), conn: c, type: "xconn" }); });
              return results.length > 0 ? (
                <div style={{ marginTop: 6, maxHeight: 200, overflowY: "auto", border: `1px solid ${T.bdr}`, borderRadius: 6, background: T.bg2 }}>
                  <div style={{ fontSize: 8, color: T.mut, padding: "4px 10px" }}>{results.length} Treffer</div>
                  {results.slice(0, 30).map((r, i) => (
                    <div key={i} onClick={() => { setActiveRackId(r.rack?.id); setView("rack"); setSearch(r.type === "dev" ? r.dev?.name?.substring(0,8) : ""); setGlobalSearch(""); }}
                      style={{ padding: "4px 10px", fontSize: 9, cursor: "pointer", borderTop: `1px solid ${T.bg3}`, display: "flex", alignItems: "center", gap: 6, color: T.dim }}
                      onMouseEnter={e => e.currentTarget.style.background = "#10b98108"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                      <span style={{ fontSize: 7, color: "#10b981", minWidth: 60 }}>⬒ {r.rack?.name}</span>
                      {r.type === "dev" && <><span style={{ color: r.dev.color, fontWeight: 700 }}>{r.dev.icon} {r.dev.name}</span><span style={{ color: T.mut }}>{r.dev.preset}</span>{r.ports.length > 0 && <span style={{ color: "#10b981" }}>🏷 {r.ports.map(p => p.label).join(", ")}</span>}</>}
                      {r.type === "conn" && <><span style={{ color: "#f59e0b" }}>{r.conn.fn} → {r.conn.tn}</span>{r.conn.note && <span style={{ color: T.mut, fontStyle: "italic" }}>📎 {r.conn.note}</span>}</>}
                      {r.type === "xconn" && <><span style={{ color: "#a855f7" }}>🔗 {r.conn.fn} → {r.conn.tn}</span></>}
                    </div>
                  ))}
                </div>
              ) : <div style={{ padding: "6px 10px", fontSize: 9, color: T.vdim }}>Keine Treffer für "{globalSearch}"</div>;
            })()}
          </div>
          {(project.racks||[]).map((r,i) => {
            const rUsedU = r.devs.reduce((s, d) => s + d.u, 0);
            return (
              <div key={r.id} onClick={() => openRack(r.id)} style={{ background: T.bg2, border: `1px solid ${T.bdr}`, borderRadius: 10, padding: 16, cursor: "pointer", transition: "border-color 0.15s", position: "relative" }}
                onMouseEnter={e => e.currentTarget.style.borderColor = "#10b98144"} onMouseLeave={e => e.currentTarget.style.borderColor = "#1a1a2e"}>
                <button onClick={e => { e.stopPropagation(); duplicateRack(r.id); }} style={{ position: "absolute", top: 8, right: 30, background: "none", border: "none", color: T.vdim, cursor: "pointer", fontSize: 10, padding: "2px 6px" }} title="Duplicate">📋</button>
                <button onClick={e => { e.stopPropagation(); setEditRack(r); }} style={{ position: "absolute", top: 8, right: 8, background: "none", border: "none", color: T.vdim, cursor: "pointer", fontSize: 12, padding: "2px 6px" }} title="Edit">✎</button>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                  <div style={{ width: 24, height: 24, background: "#10b98115", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, color: "#10b981" }}>⬒</div>
                  <div><div style={{ fontSize: 12, fontWeight: 800, color: "#10b981" }}>{r.name}</div>{r.location && <div style={{ fontSize: 8, color: T.mut }}>{r.location}</div>}</div>
                </div>
                <div style={{ display: "flex", gap: 12, fontSize: 9, color: T.mut }}>
                  <span><span style={{ color: "#3b82f6", fontWeight: 700 }}>{(r.devs||[]).length}</span> devices</span>
                  <span><span style={{ color: "#f59e0b", fontWeight: 700 }}>{(r.conns||[]).length}</span> conn.</span>
                  <span><span style={{ color: "#8b5cf6", fontWeight: 700 }}>{rUsedU}/{r.size}</span>U</span>
                </div>
                <div style={{ marginTop: 6, height: 3, background: T.bdr, borderRadius: 2, overflow: "hidden" }}>
                  <div style={{ height: "100%", width: `${r.size > 0 ? (rUsedU/r.size)*100 : 0}%`, background: rUsedU/r.size > 0.8 ? "#ef4444" : "#10b981", borderRadius: 2 }} />
                </div>
              </div>
            );
          })}
          <div onClick={() => {
            const name = prompt(t("promptRackName") + ":", `Rack ${project.racks.length + 1}`);
            if (name) addRack(name, "", 24);
          }} style={{ background: T.inp, border: `1px dashed ${T.bdr}`, borderRadius: 10, padding: 16, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", minHeight: 100, color: T.vdim, fontSize: 12, transition: "border-color 0.15s" }}
            onMouseEnter={e => e.currentTarget.style.borderColor = "#10b98144"} onMouseLeave={e => e.currentTarget.style.borderColor = "#1a1a2e"}>
            + Add Rack
          </div>
        </div>
      </div>
    </div>
  );

  /* ═══════ RACK VIEW ═══════ */
  return (
    <div className="rc-app" style={{ minHeight: "100vh", background: T.bg, color: T.txt, fontFamily: "monospace", display: "flex", flexDirection: "column" }}>
      <style>{`
        .rc-app input, .rc-app select { background: ${T.inp} !important; border-color: ${T.bdr} !important; color: ${T.txt} !important; }
        .rc-app input::placeholder { color: ${T.vdim} !important; }
      `}</style>
      {editDev && <EditModal dev={editDev} onSave={saveEdit} onClose={() => setEditDev(null)} t={t} />}
      {editRack && <RackEditModal rack={rack} onSave={saveRackEdit} onClose={() => setEditRack(null)} t={t} onDelete={project.racks.length > 1 ? deleteRack : null} />}
      {ctxMenu && <PortCtxMenu pos={{ x: ctxMenu.x, y: ctxMenu.y }} port={(devs.find(d => d.id === ctxMenu.did)?.ports.find(pp => pp.id === ctxMenu.pid)) || ctxMenu.port} onAction={onCtxAction} onClose={() => setCtxMenu(null)} otherRacks={otherRacks} onCrossConnect={startCrossConnect} t={t} />}
      {devCtx && <DevCtxMenu pos={{ x: devCtx.x, y: devCtx.y }} dev={devCtx.dev} otherRacks={otherRacks} onMoveToRack={moveDevToRack} onBatchStatus={batchPortStatus} onBatchColor={batchPortColor} onSaveTemplate={saveCustomTemplate} onClose={() => setDevCtx(null)} t={t} />}
      {showBulk && <BulkConnectModal devs={devs} conns={conns} allConns={allConns} onBulk={doBulkConnect} onClose={() => setShowBulk(false)} t={t} />}
      {notif && <div style={{ position: "fixed", top: 12, left: "50%", transform: "translateX(-50%)", zIndex: 2000, padding: "6px 18px", borderRadius: 8, fontSize: 11, fontWeight: 700, background: notif.type === "error" ? "#ef4444" : notif.type === "info" ? "#3b82f6" : "#10b981", color: "#fff", boxShadow: "0 4px 12px #000a" }}>{notif.msg}</div>}

      {/* Connection detail modal */}
      {sc && (() => { const col = cm[sc.id]||"#f59e0b"; const isCross = !!sc.rackFrom; const ps = PATCH_ST[sc.patchStatus] || PATCH_ST.none; return (
        <div onClick={() => setSc(null)} style={{ position: "fixed", inset: 0, zIndex: 999, background: "#000b", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
          <div onClick={e => e.stopPropagation()} style={{ background: T.bg2, border: `1px solid ${col}44`, borderRadius: 12, padding: 24, minWidth: 340, maxWidth: 400 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
              <div style={{ width: 12, height: 12, borderRadius: 3, background: col }} />
              <span style={{ fontSize: 13, fontWeight: 800, color: col }}>Connection</span>
              {isCross && <span style={{ fontSize: 10, color: "#a855f7" }}>🔗 cross-rack</span>}
              {sc.patchStatus && <span style={{ fontSize: 8, color: ps.color, background: ps.color+"15", padding: "1px 6px", borderRadius: 3, marginLeft: "auto" }}>{ps.label}</span>}
            </div>
            <div style={{ background: T.bg3, borderRadius: 8, padding: 14, marginBottom: 12 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: col }} />
                {isCross && <span style={{ fontSize: 8, color: "#a855f7", background: "#a855f710", padding: "1px 5px", borderRadius: 3 }}>{rackLookup[sc.rackFrom]}</span>}
                <span style={{ fontSize: 12, fontWeight: 700 }}>{sc.fn}</span>
                <span style={{ fontSize: 10, color: T.mut }}>{(PT[sc.fpt2]||PT.rj45).label} #{sc.fpn}</span>
              </div>
              <div style={{ borderLeft: `2px solid ${col}33`, height: 10, marginLeft: 3 }} />
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: col }} />
                {isCross && <span style={{ fontSize: 8, color: "#a855f7", background: "#a855f710", padding: "1px 5px", borderRadius: 3 }}>{rackLookup[sc.rackTo]}</span>}
                <span style={{ fontSize: 12, fontWeight: 700 }}>{sc.tn}</span>
                <span style={{ fontSize: 10, color: T.mut }}>{(PT[sc.tpt2]||PT.rj45).label} #{sc.tpn}</span>
              </div>
            </div>
            <div style={{ marginBottom: 10 }}>
              <label style={{ fontSize: 8, color: T.mut, letterSpacing: 0.5 }}>{t("cableNote")}</label>
              <input value={sc.note || ""} onChange={e => { const v = e.target.value; updateConnNote(sc.id, v); setSc(prev => ({ ...prev, note: v })); }} placeholder="z.B. Cat6a 15m blau, LWL OS2, Trunk..." style={{ width: "100%", background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "6px 9px", borderRadius: 5, fontSize: 10, fontFamily: "inherit", outline: "none", boxSizing: "border-box", marginTop: 3 }} />
            </div>
            <div style={{ display: "flex", gap: 10, marginBottom: 10 }}>
              <div style={{ flex: 1 }}>
                <label style={{ fontSize: 8, color: T.mut, letterSpacing: 0.5 }}>PATCH STATUS</label>
                <div style={{ display: "flex", gap: 3, marginTop: 3, flexWrap: "wrap" }}>
                  {Object.entries(PATCH_ST).map(([k, v]) => (
                    <button key={k} onClick={() => { updateConnField(sc.id, "patchStatus", k === "none" ? undefined : k); setSc(prev => ({ ...prev, patchStatus: k === "none" ? undefined : k })); }}
                      style={{ padding: "3px 6px", background: (sc.patchStatus||"none") === k ? v.color+"22" : "transparent", border: `1px solid ${(sc.patchStatus||"none") === k ? v.color : "#1a1a2e"}`, color: v.color, borderRadius: 3, cursor: "pointer", fontSize: 7, fontFamily: "inherit" }}>{v.label}</button>
                  ))}
                </div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 10, marginBottom: 12, alignItems: "flex-end" }}>
              <div>
                <label style={{ fontSize: 8, color: T.mut, letterSpacing: 0.5 }}>{t("color")}</label>
                <div style={{ display: "flex", gap: 2, marginTop: 3, flexWrap: "wrap", maxWidth: 160 }}>
                  {["",...CC.slice(0,16)].map((c, i) => (
                    <div key={i} onClick={() => { updateConnField(sc.id, "color", c||undefined); setSc(prev => ({ ...prev, color: c||undefined })); }}
                      style={{ width: 14, height: 14, borderRadius: 3, background: c||"#1a1a2e", border: `1.5px solid ${(sc.color||"") === c ? "#fff" : "transparent"}`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 6, color: T.mut }}>
                      {!c && "A"}
                    </div>
                  ))}
                </div>
              </div>
              {sc.createdAt && <div style={{ fontSize: 8, color: T.vdim, marginLeft: "auto" }}>📅 {new Date(sc.createdAt).toLocaleString("de-DE", { dateStyle: "medium", timeStyle: "short" })}</div>}
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => delCn(sc.id)} style={{ flex: 1, padding: "8px 0", background: "#ef444412", border: "1px solid #ef4444", color: "#ef4444", borderRadius: 6, cursor: "pointer", fontSize: 11, fontWeight: 700, fontFamily: "inherit" }}>Disconnect</button>
              <button onClick={() => setSc(null)} style={{ flex: 1, padding: "8px 0", background: "#ffffff06", border: "1px solid #222", color: T.mut, borderRadius: 6, cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>Close</button>
            </div>
          </div>
        </div>); })()}

      {autosaveStatus.ok === false && <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 3000, background: "#7f1d1d", borderTop: "2px solid #ef4444", padding: "10px 16px", display: "flex", alignItems: "center", justifyContent: "center", gap: 12, flexWrap: "wrap" }}>
        <span style={{ color: "#fecaca", fontSize: 11, fontWeight: 700 }}>{"\u26A0\uFE0F " + t("autosaveBannerTitle") + " \u2014 " + t("autosaveBannerText")}</span>
        <button onClick={saveJSON} style={{ padding: "6px 12px", background: "#ef4444", border: "none", color: "#fff", borderRadius: 4, cursor: "pointer", fontSize: 10, fontWeight: 900, fontFamily: "inherit" }}>{"\uD83D\uDCBE " + t("autosaveExportNow")}</button>
      </div>}

      {/* Header */}
      <div style={{ padding: "8px 16px", display: "flex", alignItems: "center", gap: 8, borderBottom: `1px solid ${T.bg3}`, flexWrap: "wrap" }}>
        <span onClick={() => setView("project")} style={{ fontSize: 14, fontWeight: 900, letterSpacing: 1, cursor: "pointer" }}>RACK<span style={{ color: T.acc }}>CLICK</span></span>
        <span title={t("autosaveLabel")} style={{ fontSize: 9, color: autosaveStatus.ok === false ? "#ef4444" : T.vdim, fontWeight: autosaveStatus.ok === false ? 900 : 400 }}>
          {autosaveStatus.ok === true && ("\uD83D\uDCBE \u2713 " + new Date(autosaveStatus.lastOkAt).toLocaleTimeString("de-DE"))}
          {autosaveStatus.ok === false && ("\uD83D\uDCBE \u2717 " + t("autosaveFailing"))}
        </span>
        <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
          <button onClick={saveJSON} style={{ padding: "4px 10px", background: dirty ? T.acc+"25" : T.acc+"08", border: `1px solid ${dirty ? T.acc : T.acc+"33"}`, color: T.acc, borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit", position: "relative" }}>{dirty && <span style={{ position: "absolute", top: -2, right: -2, width: 6, height: 6, borderRadius: "50%", background: "#ef4444" }} />}{`💾 ${t("save")}${dirty ? " *" : ""}`}</button>
          <button onClick={() => setEditRack(rack)} style={{ padding: "4px 8px", background: "none", border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>✎</button>
          {allConns.length > 0 && <button onClick={async () => { const img = await captureRackDetailPNGDataURL({ scale: 3, transparent: false }); if (img) setRackReportPng(img); setView("report"); }} style={{ padding: "4px 14px", background: "#f59e0b12", border: "1px solid #f59e0b44", color: "#f59e0b", borderRadius: 4, cursor: "pointer", fontSize: 10, fontWeight: 700, fontFamily: "inherit" }}>{`📊 ${t("report")}`}</button>}
          <button onClick={exportRack} title="Export rack JSON" style={{ padding: "4px 10px", background: "#a855f708", border: "1px solid #a855f733", color: "#a855f7", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>📤 Export</button>
          <button onClick={importCSV} title="Import connections from CSV" style={{ padding: "4px 10px", background: "#3b82f608", border: "1px solid #3b82f633", color: "#3b82f6", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>📥 CSV</button>
          <button onClick={printRackLabel} title="Print rack label/tag" style={{ padding: "4px 10px", background: "#06b6d408", border: "1px solid #06b6d433", color: "#06b6d4", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>🏷️ Label</button>
          <button onClick={() => { const qr = generateQR((rack.name || "") + " | " + (rack.location || "") + " | " + rack.size + "U"); const a = document.createElement("a"); a.href = qr; a.download = "qr-" + (rack.name || "rack").replace(/\s+/g, "-") + ".png"; a.click(); }} title="QR Code" style={{ padding: "4px 10px", background: "#a855f708", border: "1px solid #a855f722", color: "#a855f7", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>{"📱 QR"}</button>
          <button onClick={() => exportRackDetailPNG({ scale: 3, transparent: false })} title="Export rack as PNG (3x)" style={{ padding: "4px 10px", background: "#10b98108", border: "1px solid #10b98122", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>🧾 PNG</button>
          <button onClick={() => exportRackDetailPNG({ scale: 4, transparent: false })} title="Export rack as PNG HD (4x)" style={{ padding: "4px 10px", background: "#10b98108", border: "1px solid #10b98122", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>🧾 PNG HD</button>
          <button onClick={() => exportRackDetailPNG({ scale: 4, transparent: true })} title="Export rack as PNG transparent (4x)" style={{ padding: "4px 10px", background: "#10b98108", border: "1px solid #10b98122", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>🧾 PNG (transp)</button>
          <button onClick={exportPDF} title="Export rack report as PDF" style={{ padding: "4px 10px", background: "#ef444408", border: "1px solid #ef444422", color: "#ef4444", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>📄 PDF</button>
          <button onClick={exportExcel} title="Export rack data as Excel" style={{ padding: "4px 10px", background: "#22c55e08", border: "1px solid #22c55e22", color: "#22c55e", borderRadius: 4, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>📊 XLS</button>
          <div style={{ display: "flex", alignItems: "center", gap: 2, background: T.bg2, borderRadius: 4, border: `1px solid ${T.bdr}`, padding: "0 2px" }}>
            <button onClick={() => setRackZoom(z => Math.max(50, z - 10))} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: 10, padding: "2px 4px" }}>−</button>
            <span style={{ fontSize: 7, color: T.mut, minWidth: 26, textAlign: "center" }}>{rackZoom}%</span>
            <button onClick={() => setRackZoom(z => Math.min(150, z + 10))} style={{ background: "none", border: "none", color: T.mut, cursor: "pointer", fontSize: 10, padding: "2px 4px" }}>+</button>
            {rackZoom !== 100 && <button onClick={() => setRackZoom(100)} style={{ background: "none", border: "none", color: T.vdim, cursor: "pointer", fontSize: 7, padding: "2px 3px" }}>↺</button>}
          </div>
          <button onClick={() => setRackFace(f => f === "front" ? "rear" : "front")} style={{ padding: "3px 8px", background: rackFace === "rear" ? "#a855f715" : T.bg2, border: `1px solid ${rackFace === "rear" ? "#a855f7" : T.bdr}`, color: rackFace === "rear" ? "#a855f7" : T.mut, borderRadius: 4, cursor: "pointer", fontSize: 8, fontFamily: "inherit" }}>{rackFace === "front" ? `▤ ${t("front")}` : `▥ ${t("rear")}`}</button>
        </div>
        <div style={{ marginLeft: "auto", display: "flex", gap: 4, alignItems: "center" }}>
          <button onClick={undo} disabled={undoStack.length === 0} title={`Undo${undoStack.length > 0 ? ` (${undoStack[0]?.label})` : ""} · Ctrl+Z`} style={{ padding: "3px 8px", background: undoStack.length ? "#3b82f608" : "transparent", border: `1px solid ${undoStack.length ? "#3b82f633" : "#111"}`, color: undoStack.length ? "#3b82f6" : "#222", borderRadius: 4, cursor: undoStack.length ? "pointer" : "default", fontSize: 10, fontFamily: "inherit" }}>↩{undoStack.length > 0 ? ` ${undoStack.length}` : ""}</button>
          <button onClick={redo} disabled={redoStack.length === 0} title="Redo · Ctrl+Y" style={{ padding: "3px 8px", background: redoStack.length ? "#f59e0b08" : "transparent", border: `1px solid ${redoStack.length ? "#f59e0b33" : "#111"}`, color: redoStack.length ? "#f59e0b" : "#222", borderRadius: 4, cursor: redoStack.length ? "pointer" : "default", fontSize: 10, fontFamily: "inherit" }}>↪</button>
        </div>
      </div>

      {/* Rack tabs */}
      {project.racks.length > 1 && <div style={{ display: "flex", padding: "0 16px", gap: 2, borderBottom: `1px solid ${T.bg3}`, overflow: "auto" }}>
        <button onClick={() => setView("project")} style={{ padding: "6px 12px", background: "none", border: "none", color: T.vdim, cursor: "pointer", fontSize: 10, fontFamily: "inherit" }}>← Project</button>
        {project.racks.map(r => (
          <button key={r.id} onClick={() => { openRack(r.id); if (crossSel) noti(t("notiPickDestination", {name: r.name}), "info"); }}
            style={{ padding: "6px 12px", background: r.id === activeRackId ? "#10b98112" : "transparent", border: "none", borderBottom: r.id === activeRackId ? "2px solid #10b981" : "2px solid transparent", color: r.id === activeRackId ? "#10b981" : "#444", cursor: "pointer", fontSize: 10, fontWeight: r.id === activeRackId ? 700 : 400, fontFamily: "inherit", whiteSpace: "nowrap" }}>
            {r.name}{r.location ? ` (${r.location})` : ""}
          </button>))}
      </div>}

      {/* Cross-connect banner */}
      {crossSel && <div style={{ padding: "5px 16px", background: "#a855f712", borderBottom: "1px solid #a855f733", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: 10, color: "#a855f7" }}>🔗 {crossSel.devName}:{crossSel.portType}#{crossSel.portGn} ({rackLookup[crossSel.fromRackId]}) → pick destination port</span>
        <button onClick={() => setCrossSel(null)} style={{ padding: "2px 10px", background: "none", border: "1px solid #a855f722", color: "#a855f7", borderRadius: 4, cursor: "pointer", fontSize: 9, fontFamily: "inherit" }}>{t("cancel")}</button>
      </div>}

      {/* Selection banner */}
      {sp && !crossSel && <div style={{ padding: "5px 16px", background: "#10b98112", borderBottom: "1px solid #10b98133", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: 10, color: "#10b981" }}>⚡ {devs.find(d => d.id === sp.did)?.name}:{sp.portType}#{sp.portGn} → pick destination</span>
        <button onClick={() => setSp(null)} style={{ padding: "2px 10px", background: "none", border: "1px solid #10b98122", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: 9, fontFamily: "inherit" }}>{t("cancel")}</button>
      </div>}

      {selectedDevs.size > 0 && <div style={{ padding: "5px 16px", background: "#3b82f612", borderBottom: "1px solid #3b82f633", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: 10, color: "#3b82f6" }}>☑ {selectedDevs.size} selected</span>
        <div style={{ display: "flex", gap: 4 }}>
          <button onClick={() => { const all = new Set(devs.map(d => d.id)); setSelectedDevs(all); }} style={{ padding: "2px 8px", background: "none", border: "1px solid #3b82f622", color: "#3b82f6", borderRadius: 4, cursor: "pointer", fontSize: 8, fontFamily: "inherit" }}>All</button>
          <button onClick={bulkDeleteSelected} style={{ padding: "2px 8px", background: "#ef444412", border: "1px solid #ef444433", color: "#ef4444", borderRadius: 4, cursor: "pointer", fontSize: 8, fontFamily: "inherit" }}>🗑 Delete</button>
          <button onClick={() => setSelectedDevs(new Set())} style={{ padding: "2px 8px", background: "none", border: "1px solid #22222a", color: T.mut, borderRadius: 4, cursor: "pointer", fontSize: 8, fontFamily: "inherit" }}>Clear</button>
        </div>
      </div>}

      <div style={{ display: "flex", height: `calc(100vh - ${project.racks.length > 1 ? 82 : 50}px${crossSel ? " - 30px" : ""}${sp && !crossSel ? " - 30px" : ""}${selectedDevs.size > 0 ? " - 30px" : ""})`, overflow: "hidden" }}>
        {/* Sidebar */}
        <div style={{ width: 268, minWidth: 268, borderRight: `1px solid ${T.bg3}`, display: "flex", flexDirection: "column", overflowY: "auto", background: T.bg2 }}>
          <div style={{ padding: "8px 10px 4px" }}>
            <input placeholder={t("rackSearch")} value={search} onChange={e => setSearch(e.target.value)} style={{ width: "100%", background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "6px 9px", borderRadius: 5, fontSize: 10, fontFamily: "inherit", outline: "none", boxSizing: "border-box" }} />
          </div>
          <div style={{ padding: "6px 10px", display: "flex", justifyContent: "space-around", borderBottom: `1px solid ${T.bg3}` }}>
            <div style={{ textAlign: "center" }}><div style={{ fontSize: 16, fontWeight: 900, color: T.acc }}>{ devs.length}</div><div style={{ fontSize: 7, color: T.vdim }}>{t("devices")}</div></div>
            <div style={{ textAlign: "center" }}><div style={{ fontSize: 16, fontWeight: 900, color: "#3b82f6" }}>{freeU}</div><div style={{ fontSize: 7, color: T.vdim }}>{t("freeU")}</div></div>
            <div style={{ textAlign: "center" }}><div style={{ fontSize: 16, fontWeight: 900, color: "#f59e0b" }}>{allConns.length}</div><div style={{ fontSize: 7, color: T.vdim }}>{t("links")}</div></div>
            {crossForRack.length > 0 && <div style={{ textAlign: "center" }}><div style={{ fontSize: 16, fontWeight: 900, color: "#a855f7" }}>{crossForRack.length}</div><div style={{ fontSize: 7, color: "#a855f7" }}>🔗</div></div>}
          </div>

          {/* Device port usage */}
          {devs.length > 0 && <div style={{ padding: "4px 10px 6px", borderBottom: `1px solid ${T.bg3}` }}>
            <div style={{ fontSize: 7, color: T.vdim, letterSpacing: 0.5, marginBottom: 3 }}>{t("portUsage")}</div>
            {devs.map(d => { const used = allConns.filter(c => c.fd === d.id || c.td === d.id).length; const total = d.ports.length; const pct = total > 0 ? Math.round(used / total * 100) : 0; return (
              <div key={d.id} style={{ display: "flex", alignItems: "center", gap: 6, padding: "2px 0", fontSize: 8 }}>
                <span style={{ color: d.color, fontWeight: 700, minWidth: 70, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "monospace" }}>{d.name}</span>
                <div style={{ flex: 1, height: 4, background: T.bdr, borderRadius: 2, overflow: "hidden" }}>
                  <div style={{ width: `${pct}%`, height: "100%", background: pct > 80 ? "#f59e0b" : "#10b981", borderRadius: 2, transition: "width 0.2s" }} />
                </div>
                <span style={{ color: T.mut, minWidth: 32, textAlign: "right", fontFamily: "monospace" }}>{used}/{total}</span>
              </div>); })}
          </div>}

          {/* New device */}
          <div style={{ padding: "8px 10px", borderBottom: `1px solid ${T.bg3}` }}>
            {!showNew ? (
              <div style={{ display: "flex", gap: 4 }}>
                <button onClick={() => setShowNew(true)} style={{ flex: 1, padding: "5px", background: "#10b98108", border: "1px solid #10b98122", color: "#10b981", borderRadius: 4, cursor: "pointer", fontSize: 9, fontWeight: 700, fontFamily: "inherit" }}>+ NEW DEVICE</button>
                {devs.length >= 2 && <button onClick={() => setShowBulk(true)} title="Bulk connect 1:1" style={{ padding: "5px 8px", background: "#f59e0b08", border: "1px solid #f59e0b22", color: "#f59e0b", borderRadius: 4, cursor: "pointer", fontSize: 9, fontWeight: 700, fontFamily: "inherit" }}>⚡ BULK</button>}
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                <input value={dn} onChange={e => setDn(e.target.value)} placeholder="Device name (optional)" style={{ background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "5px 8px", borderRadius: 4, fontSize: 9, fontFamily: "inherit", outline: "none" }} autoFocus />
                {favPresets.size > 0 && <div>
                  <div style={{ fontSize: 7, color: "#f59e0b", letterSpacing: 0.5, marginBottom: 2 }}>{`★ ${t("favorites")}`}</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>
                    {[...favPresets].filter(k => PRESETS[k]).map(k => { const p = PRESETS[k]; return (
                      <button key={k} onClick={() => addP(k)} disabled={freeU < p.u} style={{ padding: "3px 6px", background: freeU >= p.u ? "#f59e0b08" : "#1a1a2e08", border: `1px solid ${freeU >= p.u ? "#f59e0b33" : "#111"}`, color: freeU >= p.u ? "#f59e0b" : "#333", borderRadius: 3, cursor: freeU >= p.u ? "pointer" : "default", fontSize: 8, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 3 }}>
                        <span>{p.icon}</span> {p.label}
                      </button>); })}
                  </div>
                </div>}
                {CATS.map(cat => (
                  <div key={cat.label}>
                    <div style={{ fontSize: 7, color: T.vdim, letterSpacing: 0.5, marginBottom: 2, marginTop: 3 }}>{cat.label.toUpperCase()}</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>
                      {cat.keys.map(k => { const p = PRESETS[k]; return (
                        <button key={k} onClick={() => addP(k)} disabled={freeU < p.u} style={{ padding: "3px 6px", background: freeU >= p.u ? "#10b98108" : "#1a1a2e08", border: `1px solid ${freeU >= p.u ? "#10b98122" : "#111"}`, color: freeU >= p.u ? "#e0e0e0" : "#333", borderRadius: 3, cursor: freeU >= p.u ? "pointer" : "default", fontSize: 8, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 3 }}>
                          <span>{p.icon}</span> {p.label}
                          <span onClick={e => { e.stopPropagation(); toggleFav(k); }} style={{ fontSize: 8, cursor: "pointer", color: favPresets.has(k) ? "#f59e0b" : "#222", marginLeft: 2 }}>{favPresets.has(k) ? "★" : "☆"}</span>
                        </button>); })}
                    </div>
                  </div>
                ))}
                {Object.keys(customTemplates).length > 0 && <div>
                  <div style={{ fontSize: 7, color: "#10b981", letterSpacing: 0.5, marginBottom: 2, marginTop: 3 }}>{`📌 ${t("myTemplates")}`}</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>
                    {Object.entries(customTemplates).map(([k, t]) => (
                      <div key={k} style={{ display: "flex", alignItems: "center", gap: 0 }}>
                        <button onClick={() => addP(k)} disabled={freeU < t.u} style={{ padding: "3px 6px", background: freeU >= t.u ? "#10b98115" : "#1a1a2e08", border: `1px solid ${freeU >= t.u ? "#10b98133" : "#111"}`, color: freeU >= t.u ? "#10b981" : "#333", borderRadius: "3px 0 0 3px", cursor: freeU >= t.u ? "pointer" : "default", fontSize: 8, fontFamily: "inherit", display: "flex", alignItems: "center", gap: 3 }}>
                          <span>{t.icon}</span> {t.label}
                        </button>
                        <button onClick={() => deleteCustomTemplate(k)} title="Remove template" style={{ padding: "3px 4px", background: "#ef444408", border: "1px solid #ef444422", borderLeft: "none", color: "#ef4444", borderRadius: "0 3px 3px 0", cursor: "pointer", fontSize: 7, fontFamily: "inherit" }}>×</button>
                      </div>
                    ))}
                  </div>
                </div>}
                <details style={{ marginTop: 4 }}>
                  <summary style={{ fontSize: 8, color: T.mut, cursor: "pointer" }}>{`✏️ ${t("customDevice")}`}</summary>
                  <div style={{ display: "flex", flexDirection: "column", gap: 3, marginTop: 4 }}>
                    <input value={cust.name} onChange={e => setCust(prev => ({ ...prev, name: e.target.value }))} placeholder="Name" style={{ background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "4px 6px", borderRadius: 3, fontSize: 8, fontFamily: "inherit", outline: "none" }} />
                    <div style={{ display: "flex", gap: 3, alignItems: "center" }}>
                      <select value={cust.u} onChange={e => setCust(prev => ({ ...prev, u: +e.target.value }))} style={{ background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "3px", borderRadius: 3, fontSize: 8, fontFamily: "inherit" }}>
                        {[1,2,3,4,5,6,8].map(n => <option key={n} value={n}>{n}U</option>)}
                      </select>
                      <select value={cust.icon} onChange={e => setCust(prev => ({ ...prev, icon: e.target.value }))} style={{ background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "3px", borderRadius: 3, fontSize: 10 }}>
                        {ICONS.map(ic => <option key={ic} value={ic}>{ic}</option>)}
                      </select>
                    </div>
                    {cust.pg.map((g, gi) => (
                      <div key={gi} style={{ display: "flex", gap: 3 }}>
                        <select value={g.t} onChange={e => setCust(prev => ({ ...prev, pg: prev.pg.map((x, i) => i === gi ? { ...x, t: e.target.value } : x) }))} style={{ background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "3px", borderRadius: 3, fontSize: 8, fontFamily: "inherit", flex: 1 }}>
                          {Object.entries(PT).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                        </select>
                        <input type="number" min={1} max={96} value={g.n} onChange={e => setCust(prev => ({ ...prev, pg: prev.pg.map((x, i) => i === gi ? { ...x, n: Math.max(1, +e.target.value) } : x) }))} style={{ width: 40, background: T.inp, border: `1px solid ${T.bdr}`, color: T.txt, padding: "3px", borderRadius: 3, fontSize: 8, fontFamily: "inherit", textAlign: "center" }} />
                        {cust.pg.length > 1 && <button onClick={() => setCust(prev => ({ ...prev, pg: prev.pg.filter((_, i) => i !== gi) }))} style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: 10 }}>×</button>}
                      </div>
                    ))}
                    <button onClick={() => setCust(prev => ({ ...prev, pg: [...prev.pg, { t: "rj45", n: 4 }] }))} style={{ padding: "2px", background: "none", border: `1px dashed ${T.bdr}`, color: T.vdim, borderRadius: 3, cursor: "pointer", fontSize: 8, fontFamily: "inherit" }}>+ Port Group</button>
                    <button onClick={addCustom} style={{ padding: "4px", background: "#10b98112", border: "1px solid #10b98133", color: "#10b981", borderRadius: 3, cursor: "pointer", fontSize: 8, fontWeight: 700, fontFamily: "inherit" }}>Create</button>
                  </div>
                </details>
                <button onClick={() => setShowNew(false)} style={{ padding: "4px", background: "none", border: `1px solid ${T.bdr}`, color: T.mut, borderRadius: 3, cursor: "pointer", fontSize: 8, fontFamily: "inherit" }}>{t("cancel")}</button>
              </div>
            )}
          </div>

          {/* Connections list */}
          {filtConns.length > 0 && <div style={{ padding: "0 10px 10px" }}>
            <div style={{ fontSize: 9, fontWeight: 700, color: T.vdim, marginBottom: 5, letterSpacing: 0.5 }}>{t("connections")} ({filtConns.length}{sq ? `/${allConns.length}` : ""})</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              {filtConns.map(c => { const col = cm[c.id]; const isCross = !!c.rackFrom; return (
                <div key={c.id} onClick={() => setSc(c)} style={{ padding: "4px 7px", background: isCross ? "#a855f708" : `${col}08`, borderRadius: 4, fontSize: 9, cursor: "pointer", border: `1px solid ${isCross ? "#a855f715" : col+"15"}`, display: "flex", flexDirection: "column", gap: 1, transition: "border-color 0.1s" }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = (isCross ? "#a855f7" : col)+"55"} onMouseLeave={e => e.currentTarget.style.borderColor = (isCross ? "#a855f7" : col)+"15"}>
                  <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                    {isCross && <span style={{ fontSize: 7 }}>🔗</span>}
                    <div style={{ width: 7, height: 7, borderRadius: 2, background: col, flexShrink: 0 }} />
                    <span style={{ color: "#666" }}><span style={{ color: col, fontWeight: 700 }}>{c.fn}</span><span style={{ color: T.vdim }}>:{c.fpn}</span><span style={{ color: T.vdim, margin: "0 3px" }}>→</span><span style={{ color: col, fontWeight: 700 }}>{c.tn}</span><span style={{ color: T.vdim }}>:{c.tpn}</span></span>
                  </div>
                  {c.note && <div style={{ fontSize: 7, color: T.mut, paddingLeft: 12, fontStyle: "italic" }}>📎 {c.note}</div>}
                  {c.patchStatus && <div style={{ fontSize: 6, color: (PATCH_ST[c.patchStatus]||PATCH_ST.none).color, paddingLeft: 12 }}>{(PATCH_ST[c.patchStatus]||PATCH_ST.none).label}</div>}
                </div>); })}
            </div>
          </div>}

          <div style={{ marginTop: "auto", padding: 10, borderTop: `1px solid ${T.bg3}` }}>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, fontSize: 7, color: T.mut }}>
              <span>{t("hintLClick")}</span><span>{t("hintRClick")}</span><span>{t("hintDblClick")}</span><span>🔗: {t("hintCrossRack")}</span><span>⚡: {t("hintBulk")}</span><span>{t("hintUndo")}</span><span>{t("hintSave")}</span><span>{t("hintEsc")}</span><span>{t("hintDel")}</span>
            </div>
          </div>
        </div>

        {/* Main rack area */}
        <div style={{ flex: 1, overflowY: "auto", padding: 16 }}>
          <div id="rack-detail-export" onTouchMove={onTouchDragMove} onTouchEnd={onTouchDragEnd} style={{ display: "flex", flexDirection: "column", gap: 4, transform: `scale(${rackZoom/100})`, transformOrigin: "top left", width: `${10000/rackZoom}%` }}>
          {rackFace === "rear" && <div style={{ textAlign: "center", padding: "4px 0", fontSize: 8, color: "#a855f7", background: "#a855f708", borderRadius: 4, letterSpacing: 1, fontWeight: 700 }}>{`▥ ${t("rearView")}`}</div>}
          {(() => { let uPos = 1; return displayDevs.map((d, i) => {
            const startU = uPos; uPos += d.u;
            return (
              <div key={d.id} style={{ display: "flex", gap: 0 }}>
                <div style={{ width: 28, minWidth: 28, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", gap: 0, flexShrink: 0 }}>
                  {Array.from({ length: d.u }, (_, ui) => (
                    <div key={ui} style={{ fontSize: 7, color: T.vdim, height: Math.max(38, 48 / d.u), display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "monospace", lineHeight: 1 }}>{startU + ui}</div>
                  ))}
                </div>
                <div style={{ flex: 1 }}>
                  <DevRow dev={d} allConns={allConns} sp={sp} onPort={onPort} onCtx={onPortCtx} onDel={delD} onEdit={dev => setEditDev(dev)} onMove={moveD} onDevCtx={onDevCtx} cm={cm}
                    isFirst={i === 0} isLast={i === displayDevs.length - 1} dim={sq && !filtDevs.includes(d)} rackLookup={rackLookup} flashPorts={flashPorts} onDblClick={quickLabel}
                    isSelected={selectedDevs.has(d.id)} onSelect={toggleSelectDev} collapsed={collapsedDevs.has(d.id)} onToggleCollapse={() => setCollapsedDevs(prev => { const n = new Set(prev); n.has(d.id) ? n.delete(d.id) : n.add(d.id); return n; })} ptColors={ptColors}
                    onDrop={dragReorder} onDragStart={id => setDragId(id)} onDragEnter={id => setDragOverId(id)} onDragLeaveRow={() => { setDragId(null); setDragOverId(null); }}
                    isDragSource={dragId === d.id} isDragOver={dragOverId === d.id && dragId !== d.id} onTouchDragStart={onTouchDragStart} />
                </div>
              </div>);
          }); })()}
          {devs.length === 0 && <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 200, color: T.vdim, fontSize: 12 }}>{t("noDevices")}</div>}
          {/* Empty U indicator */}
          {freeU > 0 && devs.length > 0 && <div style={{ display: "flex", gap: 0 }}>
            <div style={{ width: 28, minWidth: 28, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 7, color: T.bdr, fontFamily: "monospace" }}>{usedU + 1}</div>
            <div style={{ flex: 1, height: Math.min(freeU * 12, 48), border: `1px dashed ${T.bdr}`, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: T.bdr, marginTop: 4 }}>{`${freeU} ${t("uFree")}`}</div>
          </div>}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ═══════ ERROR BOUNDARY (v0.8.1) — Red de seguridad de último recurso ═══════
   Reglas de este bloque (aprobadas en Paso 2):
   - SOLO LECTURA de localStorage (getItem). Cero setItem/removeItem/clear.
   - No parsea los datos del usuario: los trata como strings opacos.
   - Autocontenido: sin hooks, sin i18n de la app, textos estáticos DE+EN.
   - Limitación documentada: solo captura errores de RENDER. No cubre
     event handlers, código async, fallos de CDN ni errores de Babel. */
const RC_VERSION = "0.8.6";
const RESCUE_KEYS = [
  SAVE_KEY, ...BACKUP_KEYS, BACKUP_META, SNAPSHOTS_KEY, TEMPLATES_KEY,
  THEME_KEY, LANG_KEY, PT_COLOR_KEY, GROUP_COLOR_KEY,
  FAV_KEY, QUARANTINE_KEY
];

function rcReadRaw(key) {
  try { return localStorage.getItem(key); } catch { return null; }
}

function rcDownload(text, filename) {
  try {
    const blob = new Blob([text], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  } catch (e) { alert("Download fehlgeschlagen / Download failed: " + e.message); }
}

function rcTimestamp() {
  return new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
}

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null, info: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    this.setState({ info });
  }
  downloadFullRescue = () => {
    const bundle = {
      _meta: {
        type: "rackclick-rescue-bundle",
        appVersion: RC_VERSION,
        createdAt: new Date().toISOString(),
        error: this.state.error ? String(this.state.error.message || this.state.error) : "unknown",
        note: "Los valores son strings CRUDOS de localStorage, sin parsear. / Values are RAW localStorage strings, unparsed."
      },
      keys: {}
    };
    RESCUE_KEYS.forEach(k => { bundle.keys[k] = rcReadRaw(k); });
    rcDownload(JSON.stringify(bundle, null, 2), `rackclick-RESCATE-${rcTimestamp()}.json`);
  };
  downloadAutosaveOnly = () => {
    const raw = rcReadRaw(SAVE_KEY);
    if (raw === null) return;
    // Contenido crudo de SAVE_KEY tal cual — cargable directamente con Load
    rcDownload(raw, `rackclick-autosave-${rcTimestamp()}.json`);
  };
  retry = () => { this.setState({ error: null, info: null }); };
  render() {
    if (!this.state.error) return this.props.children;
    const hasAutosave = rcReadRaw(SAVE_KEY) !== null;
    const errMsg = String(this.state.error && (this.state.error.message || this.state.error));
    const stack = this.state.info && this.state.info.componentStack
      ? this.state.info.componentStack.split("\n").slice(0, 8).join("\n") : "";
    const btn = { padding: "10px 16px", borderRadius: 8, border: "1px solid #2a2a3e", cursor: "pointer",
      fontFamily: "inherit", fontSize: 13, fontWeight: 700, background: "#12121c", color: "#e0e0e0" };
    return (
      <div style={{ minHeight: "100vh", background: "#08080d", color: "#e0e0e0",
        fontFamily: "'JetBrains Mono','Fira Code',monospace", display: "flex",
        alignItems: "center", justifyContent: "center", padding: 20 }}>
        <div style={{ maxWidth: 640, width: "100%", background: "#0d0d15", border: "1px solid #2a2a3e",
          borderRadius: 12, padding: 28 }}>
          <div style={{ fontSize: 20, fontWeight: 900, marginBottom: 6 }}>
            {"\u26A0\uFE0F RackClick hat einen unerwarteten Fehler festgestellt"}
          </div>
          <div style={{ fontSize: 12, color: "#888", marginBottom: 14 }}>
            {"RackClick encountered an unexpected error"}
          </div>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#10b981", marginBottom: 16 }}>
            {"\u2714 Deine Daten sind NICHT verloren. / Your data is NOT lost."}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 18 }}>
            <button onClick={this.downloadFullRescue}
              style={{ ...btn, background: "#10b981", color: "#08080d", border: "1px solid #10b981" }}>
              {"\uD83D\uDCE5 Komplette Rettung herunterladen / Download full rescue"}
            </button>
            <button onClick={this.downloadAutosaveOnly} disabled={!hasAutosave}
              title={hasAutosave ? "" : "Kein Autosave vorhanden / No autosave found"}
              style={{ ...btn, opacity: hasAutosave ? 1 : 0.4, cursor: hasAutosave ? "pointer" : "not-allowed" }}>
              {hasAutosave
                ? "\uD83D\uDCE5 Nur Autosave herunterladen (direkt ladbar) / Download autosave only (loadable)"
                : "\uD83D\uDCE5 Kein Autosave vorhanden / No autosave found"}
            </button>
            <button onClick={this.retry} style={btn}>
              {"\uD83D\uDD04 Erneut versuchen / Retry"}
            </button>
          </div>
          <div style={{ fontSize: 11, color: "#aaa", lineHeight: 1.6, marginBottom: 14 }}>
            {"Wenn der Fehler wiederholt auftritt: Rettung herunterladen, die vorherige RackClick-Version \u00f6ffnen und das letzte gespeicherte JSON laden. / If the error repeats: download the rescue, open the previous RackClick version and load your last saved JSON."}
          </div>
          <details style={{ fontSize: 10, color: "#666" }}>
            <summary style={{ cursor: "pointer", marginBottom: 6 }}>{"Technische Details / Technical details"}</summary>
            <div style={{ whiteSpace: "pre-wrap", background: "#08080d", border: "1px solid #1a1a2e",
              borderRadius: 6, padding: 10, marginTop: 6 }}>
              {`Version: v${RC_VERSION}\nZeit/Time: ${new Date().toISOString()}\nFehler/Error: ${errMsg}\n${stack}`}
            </div>
          </details>
        </div>
      </div>
    );
  }
}

ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(ErrorBoundary, null, React.createElement(RackClick)));
